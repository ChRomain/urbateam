--
-- PostgreSQL database dump
--

\restrict atHaebenAvFUQ0aV8s8ZLvpRB1WOhhkbcRnpXcyetZKr6bBuZfk3ff4v3nUAG9o

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.10 (Ubuntu 17.10-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA auth;


ALTER SCHEMA auth OWNER TO supabase_admin;

--
-- Name: extensions; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA extensions;


ALTER SCHEMA extensions OWNER TO postgres;

--
-- Name: graphql; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA graphql;


ALTER SCHEMA graphql OWNER TO supabase_admin;

--
-- Name: graphql_public; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA graphql_public;


ALTER SCHEMA graphql_public OWNER TO supabase_admin;

--
-- Name: pgbouncer; Type: SCHEMA; Schema: -; Owner: pgbouncer
--

CREATE SCHEMA pgbouncer;


ALTER SCHEMA pgbouncer OWNER TO pgbouncer;

--
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA realtime;


ALTER SCHEMA realtime OWNER TO supabase_admin;

--
-- Name: storage; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA storage;


ALTER SCHEMA storage OWNER TO supabase_admin;

--
-- Name: supabase_migrations; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA supabase_migrations;


ALTER SCHEMA supabase_migrations OWNER TO postgres;

--
-- Name: vault; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA vault;


ALTER SCHEMA vault OWNER TO supabase_admin;

--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA extensions;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA extensions;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: supabase_vault; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS supabase_vault WITH SCHEMA vault;


--
-- Name: EXTENSION supabase_vault; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION supabase_vault IS 'Supabase Vault Extension';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA extensions;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.aal_level AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


ALTER TYPE auth.aal_level OWNER TO supabase_auth_admin;

--
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.code_challenge_method AS ENUM (
    's256',
    'plain'
);


ALTER TYPE auth.code_challenge_method OWNER TO supabase_auth_admin;

--
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.factor_status AS ENUM (
    'unverified',
    'verified'
);


ALTER TYPE auth.factor_status OWNER TO supabase_auth_admin;

--
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.factor_type AS ENUM (
    'totp',
    'webauthn',
    'phone'
);


ALTER TYPE auth.factor_type OWNER TO supabase_auth_admin;

--
-- Name: oauth_authorization_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.oauth_authorization_status AS ENUM (
    'pending',
    'approved',
    'denied',
    'expired'
);


ALTER TYPE auth.oauth_authorization_status OWNER TO supabase_auth_admin;

--
-- Name: oauth_client_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.oauth_client_type AS ENUM (
    'public',
    'confidential'
);


ALTER TYPE auth.oauth_client_type OWNER TO supabase_auth_admin;

--
-- Name: oauth_registration_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.oauth_registration_type AS ENUM (
    'dynamic',
    'manual'
);


ALTER TYPE auth.oauth_registration_type OWNER TO supabase_auth_admin;

--
-- Name: oauth_response_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.oauth_response_type AS ENUM (
    'code'
);


ALTER TYPE auth.oauth_response_type OWNER TO supabase_auth_admin;

--
-- Name: one_time_token_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.one_time_token_type AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


ALTER TYPE auth.one_time_token_type OWNER TO supabase_auth_admin;

--
-- Name: action; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.action AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE',
    'TRUNCATE',
    'ERROR'
);


ALTER TYPE realtime.action OWNER TO supabase_admin;

--
-- Name: equality_op; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.equality_op AS ENUM (
    'eq',
    'neq',
    'lt',
    'lte',
    'gt',
    'gte',
    'in'
);


ALTER TYPE realtime.equality_op OWNER TO supabase_admin;

--
-- Name: user_defined_filter; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.user_defined_filter AS (
	column_name text,
	op realtime.equality_op,
	value text
);


ALTER TYPE realtime.user_defined_filter OWNER TO supabase_admin;

--
-- Name: wal_column; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.wal_column AS (
	name text,
	type_name text,
	type_oid oid,
	value jsonb,
	is_pkey boolean,
	is_selectable boolean
);


ALTER TYPE realtime.wal_column OWNER TO supabase_admin;

--
-- Name: wal_rls; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.wal_rls AS (
	wal jsonb,
	is_rls_enabled boolean,
	subscription_ids uuid[],
	errors text[]
);


ALTER TYPE realtime.wal_rls OWNER TO supabase_admin;

--
-- Name: buckettype; Type: TYPE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TYPE storage.buckettype AS ENUM (
    'STANDARD',
    'ANALYTICS',
    'VECTOR'
);


ALTER TYPE storage.buckettype OWNER TO supabase_storage_admin;

--
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.email() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


ALTER FUNCTION auth.email() OWNER TO supabase_auth_admin;

--
-- Name: FUNCTION email(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.email() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.jwt() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


ALTER FUNCTION auth.jwt() OWNER TO supabase_auth_admin;

--
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.role() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


ALTER FUNCTION auth.role() OWNER TO supabase_auth_admin;

--
-- Name: FUNCTION role(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.role() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.uid() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


ALTER FUNCTION auth.uid() OWNER TO supabase_auth_admin;

--
-- Name: FUNCTION uid(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.uid() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- Name: grant_pg_cron_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.grant_pg_cron_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_cron'
  )
  THEN
    grant usage on schema cron to postgres with grant option;

    alter default privileges in schema cron grant all on tables to postgres with grant option;
    alter default privileges in schema cron grant all on functions to postgres with grant option;
    alter default privileges in schema cron grant all on sequences to postgres with grant option;

    alter default privileges for user supabase_admin in schema cron grant all
        on sequences to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on tables to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on functions to postgres with grant option;

    grant all privileges on all tables in schema cron to postgres with grant option;
    revoke all on table cron.job from postgres;
    grant select on table cron.job to postgres with grant option;
  END IF;
END;
$$;


ALTER FUNCTION extensions.grant_pg_cron_access() OWNER TO supabase_admin;

--
-- Name: FUNCTION grant_pg_cron_access(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.grant_pg_cron_access() IS 'Grants access to pg_cron';


--
-- Name: grant_pg_graphql_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.grant_pg_graphql_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
begin
    if not exists (
        select 1
        from pg_event_trigger_ddl_commands() ev
        join pg_catalog.pg_extension e on ev.objid = e.oid
        where e.extname = 'pg_graphql'
    ) then
        return;
    end if;

    drop function if exists graphql_public.graphql;
    create or replace function graphql_public.graphql(
        "operationName" text default null,
        query text default null,
        variables jsonb default null,
        extensions jsonb default null
    )
        returns jsonb
        language sql
    as $$
        select graphql.resolve(
            query := query,
            variables := coalesce(variables, '{}'),
            "operationName" := "operationName",
            extensions := extensions
        );
    $$;

    -- Attach the wrapper to the extension so DROP EXTENSION cascades to it,
    -- which in turn triggers set_graphql_placeholder to reinstall the "not enabled" stub.
    alter extension pg_graphql add function graphql_public.graphql(text, text, jsonb, jsonb);

    grant usage on schema graphql to postgres, anon, authenticated, service_role;
    grant execute on function graphql.resolve to postgres, anon, authenticated, service_role;
    grant usage on schema graphql to postgres with grant option;
    grant usage on schema graphql_public to postgres with grant option;
end;
$_$;


ALTER FUNCTION extensions.grant_pg_graphql_access() OWNER TO supabase_admin;

--
-- Name: FUNCTION grant_pg_graphql_access(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.grant_pg_graphql_access() IS 'Grants access to pg_graphql';


--
-- Name: grant_pg_net_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.grant_pg_net_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_net'
  )
  THEN
    IF NOT EXISTS (
      SELECT 1
      FROM pg_roles
      WHERE rolname = 'supabase_functions_admin'
    )
    THEN
      CREATE USER supabase_functions_admin NOINHERIT CREATEROLE LOGIN NOREPLICATION;
    END IF;

    GRANT USAGE ON SCHEMA net TO supabase_functions_admin, postgres, anon, authenticated, service_role;

    IF EXISTS (
      SELECT FROM pg_extension
      WHERE extname = 'pg_net'
      -- all versions in use on existing projects as of 2025-02-20
      -- version 0.12.0 onwards don't need these applied
      AND extversion IN ('0.2', '0.6', '0.7', '0.7.1', '0.8', '0.10.0', '0.11.0')
    ) THEN
      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;

      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;

      REVOKE ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
      REVOKE ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;

      GRANT EXECUTE ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
      GRANT EXECUTE ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
    END IF;
  END IF;
END;
$$;


ALTER FUNCTION extensions.grant_pg_net_access() OWNER TO supabase_admin;

--
-- Name: FUNCTION grant_pg_net_access(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.grant_pg_net_access() IS 'Grants access to pg_net';


--
-- Name: pgrst_ddl_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.pgrst_ddl_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    IF cmd.command_tag IN (
      'CREATE SCHEMA', 'ALTER SCHEMA'
    , 'CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO', 'ALTER TABLE'
    , 'CREATE FOREIGN TABLE', 'ALTER FOREIGN TABLE'
    , 'CREATE VIEW', 'ALTER VIEW'
    , 'CREATE MATERIALIZED VIEW', 'ALTER MATERIALIZED VIEW'
    , 'CREATE FUNCTION', 'ALTER FUNCTION'
    , 'CREATE TRIGGER'
    , 'CREATE TYPE', 'ALTER TYPE'
    , 'CREATE RULE'
    , 'COMMENT'
    )
    -- don't notify in case of CREATE TEMP table or other objects created on pg_temp
    AND cmd.schema_name is distinct from 'pg_temp'
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION extensions.pgrst_ddl_watch() OWNER TO supabase_admin;

--
-- Name: pgrst_drop_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.pgrst_drop_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  obj record;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_dropped_objects()
  LOOP
    IF obj.object_type IN (
      'schema'
    , 'table'
    , 'foreign table'
    , 'view'
    , 'materialized view'
    , 'function'
    , 'trigger'
    , 'type'
    , 'rule'
    )
    AND obj.is_temporary IS false -- no pg_temp objects
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION extensions.pgrst_drop_watch() OWNER TO supabase_admin;

--
-- Name: set_graphql_placeholder(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.set_graphql_placeholder() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
    DECLARE
    graphql_is_dropped bool;
    BEGIN
    graphql_is_dropped = (
        SELECT ev.schema_name = 'graphql_public'
        FROM pg_event_trigger_dropped_objects() AS ev
        WHERE ev.schema_name = 'graphql_public'
    );

    IF graphql_is_dropped
    THEN
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language plpgsql
        as $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;
    END IF;

    END;
$_$;


ALTER FUNCTION extensions.set_graphql_placeholder() OWNER TO supabase_admin;

--
-- Name: FUNCTION set_graphql_placeholder(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.set_graphql_placeholder() IS 'Reintroduces placeholder function for graphql_public.graphql';


--
-- Name: graphql(text, text, jsonb, jsonb); Type: FUNCTION; Schema: graphql_public; Owner: supabase_admin
--

CREATE FUNCTION graphql_public.graphql("operationName" text DEFAULT NULL::text, query text DEFAULT NULL::text, variables jsonb DEFAULT NULL::jsonb, extensions jsonb DEFAULT NULL::jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;


ALTER FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) OWNER TO supabase_admin;

--
-- Name: get_auth(text); Type: FUNCTION; Schema: pgbouncer; Owner: supabase_admin
--

CREATE FUNCTION pgbouncer.get_auth(p_usename text) RETURNS TABLE(username text, password text)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $_$
  BEGIN
      RAISE DEBUG 'PgBouncer auth request: %', p_usename;

      RETURN QUERY
      SELECT
          rolname::text,
          CASE WHEN rolvaliduntil < now()
              THEN null
              ELSE rolpassword::text
          END
      FROM pg_authid
      WHERE rolname=$1 and rolcanlogin;
  END;
  $_$;


ALTER FUNCTION pgbouncer.get_auth(p_usename text) OWNER TO supabase_admin;

--
-- Name: apply_rls(jsonb, integer); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer DEFAULT (1024 * 1024)) RETURNS SETOF realtime.wal_rls
    LANGUAGE plpgsql
    AS $$
declare
    -- Regclass of the table e.g. public.notes
    entity_ regclass = (quote_ident(wal ->> 'schema') || '.' || quote_ident(wal ->> 'table'))::regclass;

    -- I, U, D, T: insert, update ...
    action realtime.action = (
        case wal ->> 'action'
            when 'I' then 'INSERT'
            when 'U' then 'UPDATE'
            when 'D' then 'DELETE'
            else 'ERROR'
        end
    );

    -- Is row level security enabled for the table
    is_rls_enabled bool = relrowsecurity from pg_class where oid = entity_;

    subscriptions realtime.subscription[] = array_agg(subs)
        from
            realtime.subscription subs
        where
            subs.entity = entity_
            -- Filter by action early - only get subscriptions interested in this action
            -- action_filter column can be: '*' (all), 'INSERT', 'UPDATE', or 'DELETE'
            and (subs.action_filter = '*' or subs.action_filter = action::text);

    -- Subscription vars
    working_role regrole;
    working_selected_columns text[];
    claimed_role regrole;
    claims jsonb;

    subscription_id uuid;
    subscription_has_access bool;
    visible_to_subscription_ids uuid[] = '{}';

    -- structured info for wal's columns
    columns realtime.wal_column[];
    -- previous identity values for update/delete
    old_columns realtime.wal_column[];

    error_record_exceeds_max_size boolean = octet_length(wal::text) > max_record_bytes;

    -- Primary jsonb output for record
    output jsonb;

    -- Loop record for iterating unique roles (outer loop)
    role_record record;
    -- Loop record for iterating unique selected_columns within a role (inner loop)
    cols_record record;
    -- Subscription ids visible at the role level (before fanning out by selected_columns)
    visible_role_sub_ids uuid[] = '{}';

begin
    perform set_config('role', null, true);

    columns =
        array_agg(
            (
                x->>'name',
                x->>'type',
                x->>'typeoid',
                realtime.cast(
                    (x->'value') #>> '{}',
                    coalesce(
                        (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                        (x->>'type')::regtype
                    )
                ),
                (pks ->> 'name') is not null,
                true
            )::realtime.wal_column
        )
        from
            jsonb_array_elements(wal -> 'columns') x
            left join jsonb_array_elements(wal -> 'pk') pks
                on (x ->> 'name') = (pks ->> 'name');

    old_columns =
        array_agg(
            (
                x->>'name',
                x->>'type',
                x->>'typeoid',
                realtime.cast(
                    (x->'value') #>> '{}',
                    coalesce(
                        (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                        (x->>'type')::regtype
                    )
                ),
                (pks ->> 'name') is not null,
                true
            )::realtime.wal_column
        )
        from
            jsonb_array_elements(wal -> 'identity') x
            left join jsonb_array_elements(wal -> 'pk') pks
                on (x ->> 'name') = (pks ->> 'name');

    for role_record in
        select claims_role
        from (select distinct claims_role from unnest(subscriptions)) t
        order by claims_role::text
    loop
        working_role := role_record.claims_role;

        -- Update `is_selectable` for columns and old_columns (once per role)
        columns =
            array_agg(
                (
                    c.name,
                    c.type_name,
                    c.type_oid,
                    c.value,
                    c.is_pkey,
                    pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                )::realtime.wal_column
            )
            from
                unnest(columns) c;

        old_columns =
                array_agg(
                    (
                        c.name,
                        c.type_name,
                        c.type_oid,
                        c.value,
                        c.is_pkey,
                        pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                    )::realtime.wal_column
                )
                from
                    unnest(old_columns) c;

        if action <> 'DELETE' and count(1) = 0 from unnest(columns) c where c.is_pkey then
            -- Fan out 400 error per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;
                return next (
                    jsonb_build_object(
                        'schema', wal ->> 'schema',
                        'table', wal ->> 'table',
                        'type', action
                    ),
                    is_rls_enabled,
                    (select array_agg(s.subscription_id) from unnest(subscriptions) as s where s.claims_role = working_role and (s.selected_columns is not distinct from working_selected_columns)),
                    array['Error 400: Bad Request, no primary key']
                )::realtime.wal_rls;
            end loop;

        -- The claims role does not have SELECT permission to the primary key of entity
        elsif action <> 'DELETE' and sum(c.is_selectable::int) <> count(1) from unnest(columns) c where c.is_pkey then
            -- Fan out 401 error per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;
                return next (
                    jsonb_build_object(
                        'schema', wal ->> 'schema',
                        'table', wal ->> 'table',
                        'type', action
                    ),
                    is_rls_enabled,
                    (select array_agg(s.subscription_id) from unnest(subscriptions) as s where s.claims_role = working_role and (s.selected_columns is not distinct from working_selected_columns)),
                    array['Error 401: Unauthorized']
                )::realtime.wal_rls;
            end loop;

        else
            -- Create the prepared statement (once per role)
            if is_rls_enabled and action <> 'DELETE' then
                if (select 1 from pg_prepared_statements where name = 'walrus_rls_stmt' limit 1) > 0 then
                    deallocate walrus_rls_stmt;
                end if;
                execute realtime.build_prepared_statement_sql('walrus_rls_stmt', entity_, columns);
            end if;

            -- Collect all visible subscription IDs for this role (filter check + RLS check)
            visible_role_sub_ids = '{}';

            for subscription_id, claims in (
                    select
                        subs.subscription_id,
                        subs.claims
                    from
                        unnest(subscriptions) subs
                    where
                        subs.entity = entity_
                        and subs.claims_role = working_role
                        and (
                            realtime.is_visible_through_filters(columns, subs.filters)
                            or (
                              action = 'DELETE'
                              and realtime.is_visible_through_filters(old_columns, subs.filters)
                            )
                        )
            ) loop

                if not is_rls_enabled or action = 'DELETE' then
                    visible_role_sub_ids = visible_role_sub_ids || subscription_id;
                else
                    -- Check if RLS allows the role to see the record
                    perform
                        -- Trim leading and trailing quotes from working_role because set_config
                        -- doesn't recognize the role as valid if they are included
                        set_config('role', trim(both '"' from working_role::text), true),
                        set_config('request.jwt.claims', claims::text, true);

                    execute 'execute walrus_rls_stmt' into subscription_has_access;

                    if subscription_has_access then
                        visible_role_sub_ids = visible_role_sub_ids || subscription_id;
                    end if;
                end if;
            end loop;

            perform set_config('role', null, true);

            -- Inner loop: per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;

                output = jsonb_build_object(
                    'schema', wal ->> 'schema',
                    'table', wal ->> 'table',
                    'type', action,
                    'commit_timestamp', to_char(
                        ((wal ->> 'timestamp')::timestamptz at time zone 'utc'),
                        'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'
                    ),
                    'columns', (
                        select
                            jsonb_agg(
                                jsonb_build_object(
                                    'name', pa.attname,
                                    'type', pt.typname
                                )
                                order by pa.attnum asc
                            )
                        from
                            pg_attribute pa
                            join pg_type pt
                                on pa.atttypid = pt.oid
                            left join (
                                select unnest(conkey) as pkey_attnum
                                from pg_constraint
                                where conrelid = entity_ and contype = 'p'
                            ) pk on pk.pkey_attnum = pa.attnum
                        where
                            attrelid = entity_
                            and attnum > 0
                            and pg_catalog.has_column_privilege(working_role, entity_, pa.attname, 'SELECT')
                            and (working_selected_columns is null or pa.attname = any(working_selected_columns) or pk.pkey_attnum is not null)
                    )
                )
                -- Add "record" key for insert and update
                || case
                    when action in ('INSERT', 'UPDATE') then
                        jsonb_build_object(
                            'record',
                            (
                                select
                                    jsonb_object_agg(
                                        -- if unchanged toast, get column name and value from old record
                                        coalesce((c).name, (oc).name),
                                        case
                                            when (c).name is null then (oc).value
                                            else (c).value
                                        end
                                    )
                                from
                                    unnest(columns) c
                                    full outer join unnest(old_columns) oc
                                        on (c).name = (oc).name
                                where
                                    coalesce((c).is_selectable, (oc).is_selectable)
                                    and (working_selected_columns is null or coalesce((c).name, (oc).name) = any(working_selected_columns) or coalesce((c).is_pkey, (oc).is_pkey))
                                    and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                            )
                        )
                    else '{}'::jsonb
                end
                -- Add "old_record" key for update and delete
                || case
                    when action = 'UPDATE' then
                        jsonb_build_object(
                                'old_record',
                                (
                                    select jsonb_object_agg((c).name, (c).value)
                                    from unnest(old_columns) c
                                    where
                                        (c).is_selectable
                                        and (working_selected_columns is null or (c).name = any(working_selected_columns) or (c).is_pkey)
                                        and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                                )
                            )
                    when action = 'DELETE' then
                        jsonb_build_object(
                            'old_record',
                            (
                                select jsonb_object_agg((c).name, (c).value)
                                from unnest(old_columns) c
                                where
                                    (c).is_selectable
                                    and (working_selected_columns is null or (c).name = any(working_selected_columns) or (c).is_pkey)
                                    and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                                    and ( not is_rls_enabled or (c).is_pkey ) -- if RLS enabled, we can't secure deletes so filter to pkey
                            )
                        )
                    else '{}'::jsonb
                end;

                -- Filter visible_role_sub_ids to those matching the current selected_columns group
                visible_to_subscription_ids = coalesce(
                    (
                        select array_agg(s.subscription_id)
                        from unnest(subscriptions) s
                        where s.claims_role = working_role
                          and (s.selected_columns is not distinct from working_selected_columns)
                          and s.subscription_id = any(visible_role_sub_ids)
                    ),
                    '{}'::uuid[]
                );

                return next (
                    output,
                    is_rls_enabled,
                    visible_to_subscription_ids,
                    case
                        when error_record_exceeds_max_size then array['Error 413: Payload Too Large']
                        else '{}'
                    end
                )::realtime.wal_rls;
            end loop;

        end if;
    end loop;

    perform set_config('role', null, true);
end;
$$;


ALTER FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) OWNER TO supabase_admin;

--
-- Name: broadcast_changes(text, text, text, text, text, record, record, text); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text DEFAULT 'ROW'::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    -- Declare a variable to hold the JSONB representation of the row
    row_data jsonb := '{}'::jsonb;
BEGIN
    IF level = 'STATEMENT' THEN
        RAISE EXCEPTION 'function can only be triggered for each row, not for each statement';
    END IF;
    -- Check the operation type and handle accordingly
    IF operation = 'INSERT' OR operation = 'UPDATE' OR operation = 'DELETE' THEN
        row_data := jsonb_build_object('old_record', OLD, 'record', NEW, 'operation', operation, 'table', table_name, 'schema', table_schema);
        PERFORM realtime.send (row_data, event_name, topic_name);
    ELSE
        RAISE EXCEPTION 'Unexpected operation type: %', operation;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Failed to process the row: %', SQLERRM;
END;

$$;


ALTER FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text) OWNER TO supabase_admin;

--
-- Name: build_prepared_statement_sql(text, regclass, realtime.wal_column[]); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) RETURNS text
    LANGUAGE sql
    AS $$
      /*
      Builds a sql string that, if executed, creates a prepared statement to
      tests retrive a row from *entity* by its primary key columns.
      Example
          select realtime.build_prepared_statement_sql('public.notes', '{"id"}'::text[], '{"bigint"}'::text[])
      */
          select
      'prepare ' || prepared_statement_name || ' as
          select
              exists(
                  select
                      1
                  from
                      ' || entity || '
                  where
                      ' || string_agg(quote_ident(pkc.name) || '=' || quote_nullable(pkc.value #>> '{}') , ' and ') || '
              )'
          from
              unnest(columns) pkc
          where
              pkc.is_pkey
          group by
              entity
      $$;


ALTER FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) OWNER TO supabase_admin;

--
-- Name: cast(text, regtype); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime."cast"(val text, type_ regtype) RETURNS jsonb
    LANGUAGE plpgsql IMMUTABLE
    AS $$
declare
  res jsonb;
begin
  if type_::text = 'bytea' then
    return to_jsonb(val);
  end if;
  execute format('select to_jsonb(%L::'|| type_::text || ')', val) into res;
  return res;
end
$$;


ALTER FUNCTION realtime."cast"(val text, type_ regtype) OWNER TO supabase_admin;

--
-- Name: check_equality_op(realtime.equality_op, regtype, text, text); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) RETURNS boolean
    LANGUAGE plpgsql IMMUTABLE
    AS $$
      /*
      Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
      */
      declare
          op_symbol text = (
              case
                  when op = 'eq' then '='
                  when op = 'neq' then '!='
                  when op = 'lt' then '<'
                  when op = 'lte' then '<='
                  when op = 'gt' then '>'
                  when op = 'gte' then '>='
                  when op = 'in' then '= any'
                  else 'UNKNOWN OP'
              end
          );
          res boolean;
      begin
          execute format(
              'select %L::'|| type_::text || ' ' || op_symbol
              || ' ( %L::'
              || (
                  case
                      when op = 'in' then type_::text || '[]'
                      else type_::text end
              )
              || ')', val_1, val_2) into res;
          return res;
      end;
      $$;


ALTER FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) OWNER TO supabase_admin;

--
-- Name: is_visible_through_filters(realtime.wal_column[], realtime.user_defined_filter[]); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) RETURNS boolean
    LANGUAGE sql IMMUTABLE
    AS $_$
    /*
    Should the record be visible (true) or filtered out (false) after *filters* are applied
    */
        select
            -- Default to allowed when no filters present
            $2 is null -- no filters. this should not happen because subscriptions has a default
            or array_length($2, 1) is null -- array length of an empty array is null
            or bool_and(
                coalesce(
                    realtime.check_equality_op(
                        op:=f.op,
                        type_:=coalesce(
                            col.type_oid::regtype, -- null when wal2json version <= 2.4
                            col.type_name::regtype
                        ),
                        -- cast jsonb to text
                        val_1:=col.value #>> '{}',
                        val_2:=f.value
                    ),
                    false -- if null, filter does not match
                )
            )
        from
            unnest(filters) f
            join unnest(columns) col
                on f.column_name = col.name;
    $_$;


ALTER FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) OWNER TO supabase_admin;

--
-- Name: list_changes(name, name, integer, integer); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) RETURNS TABLE(wal jsonb, is_rls_enabled boolean, subscription_ids uuid[], errors text[], slot_changes_count bigint)
    LANGUAGE sql
    SET log_min_messages TO 'fatal'
    AS $$
  WITH pub AS (
    SELECT
      concat_ws(
        ',',
        CASE WHEN bool_or(pubinsert) THEN 'insert' ELSE NULL END,
        CASE WHEN bool_or(pubupdate) THEN 'update' ELSE NULL END,
        CASE WHEN bool_or(pubdelete) THEN 'delete' ELSE NULL END
      ) AS w2j_actions,
      coalesce(
        string_agg(
          realtime.quote_wal2json(format('%I.%I', schemaname, tablename)::regclass),
          ','
        ) filter (WHERE ppt.tablename IS NOT NULL),
        ''
      ) AS w2j_add_tables
    FROM pg_publication pp
    LEFT JOIN pg_publication_tables ppt ON pp.pubname = ppt.pubname
    WHERE pp.pubname = publication
    GROUP BY pp.pubname
    LIMIT 1
  ),
  -- MATERIALIZED ensures pg_logical_slot_get_changes is called exactly once
  w2j AS MATERIALIZED (
    SELECT x.*, pub.w2j_add_tables
    FROM pub,
         pg_logical_slot_get_changes(
           slot_name, null, max_changes,
           'include-pk', 'true',
           'include-transaction', 'false',
           'include-timestamp', 'true',
           'include-type-oids', 'true',
           'format-version', '2',
           'actions', pub.w2j_actions,
           'add-tables', pub.w2j_add_tables
         ) x
  ),
  slot_count AS (
    SELECT count(*)::bigint AS cnt
    FROM w2j
    WHERE w2j.w2j_add_tables <> ''
  ),
  rls_filtered AS (
    SELECT xyz.wal, xyz.is_rls_enabled, xyz.subscription_ids, xyz.errors
    FROM w2j,
         realtime.apply_rls(
           wal := w2j.data::jsonb,
           max_record_bytes := max_record_bytes
         ) xyz(wal, is_rls_enabled, subscription_ids, errors)
    WHERE w2j.w2j_add_tables <> ''
      AND xyz.subscription_ids[1] IS NOT NULL
  )
  SELECT rf.wal, rf.is_rls_enabled, rf.subscription_ids, rf.errors, sc.cnt
  FROM rls_filtered rf, slot_count sc

  UNION ALL

  SELECT null, null, null, null, sc.cnt
  FROM slot_count sc
  WHERE NOT EXISTS (SELECT 1 FROM rls_filtered)
$$;


ALTER FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) OWNER TO supabase_admin;

--
-- Name: quote_wal2json(regclass); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.quote_wal2json(entity regclass) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
  SELECT
    realtime.wal2json_escape_identifier(nsp.nspname::text)
    || '.'
    || realtime.wal2json_escape_identifier(pc.relname::text)
  FROM pg_class pc
  JOIN pg_namespace nsp ON pc.relnamespace = nsp.oid
  WHERE pc.oid = entity
$$;


ALTER FUNCTION realtime.quote_wal2json(entity regclass) OWNER TO supabase_admin;

--
-- Name: send(jsonb, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  generated_id uuid;
  final_payload jsonb;
BEGIN
  BEGIN
    generated_id := gen_random_uuid();

    -- Check if payload has an 'id' key, if not, add the generated UUID
    IF payload ? 'id' THEN
      final_payload := payload;
    ELSE
      final_payload := jsonb_set(payload, '{id}', to_jsonb(generated_id));
    END IF;

    -- Set the topic configuration
    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    INSERT INTO realtime.messages (id, payload, event, topic, private, extension)
    VALUES (generated_id, final_payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      RAISE WARNING 'WarnSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


ALTER FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean) OWNER TO supabase_admin;

--
-- Name: send_binary(bytea, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.send_binary(payload bytea, event text, topic text, private boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  generated_id uuid;
BEGIN
  BEGIN
    generated_id := gen_random_uuid();

    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    INSERT INTO realtime.messages (id, binary_payload, event, topic, private, extension)
    VALUES (generated_id, payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      RAISE WARNING 'WarnSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


ALTER FUNCTION realtime.send_binary(payload bytea, event text, topic text, private boolean) OWNER TO supabase_admin;

--
-- Name: subscription_check_filters(); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.subscription_check_filters() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
    col_names text[] = coalesce(
            array_agg(a.attname order by a.attnum),
            '{}'::text[]
        )
        from
            pg_catalog.pg_attribute a
        where
            a.attrelid = new.entity
            and a.attnum > 0
            and not a.attisdropped
            and pg_catalog.has_column_privilege(
                (new.claims ->> 'role'),
                a.attrelid,
                a.attnum,
                'SELECT'
            );
    filter realtime.user_defined_filter;
    col_type regtype;
    in_val jsonb;
    selected_col text;
begin
    for filter in select * from unnest(new.filters) loop
        if not filter.column_name = any(col_names) then
            raise exception 'invalid column for filter %', filter.column_name;
        end if;

        col_type = (
            select atttypid::regtype
            from pg_catalog.pg_attribute
            where attrelid = new.entity
                  and attname = filter.column_name
        );
        if col_type is null then
            raise exception 'failed to lookup type for column %', filter.column_name;
        end if;

        if filter.op = 'in'::realtime.equality_op then
            in_val = realtime.cast(filter.value, (col_type::text || '[]')::regtype);
            if coalesce(jsonb_array_length(in_val), 0) > 100 then
                raise exception 'too many values for `in` filter. Maximum 100';
            end if;
        else
            perform realtime.cast(filter.value, col_type);
        end if;
    end loop;

    if new.selected_columns is not null then
        for selected_col in select * from unnest(new.selected_columns) loop
            if not selected_col = any(col_names) then
                raise exception 'invalid column for select %', selected_col;
            end if;
        end loop;
    end if;

    new.filters = coalesce(
        array_agg(f order by f.column_name, f.op, f.value),
        '{}'
    ) from unnest(new.filters) f;

    new.selected_columns = (
        select array_agg(c order by c)
        from unnest(new.selected_columns) c
    );

    return new;
end;
$$;


ALTER FUNCTION realtime.subscription_check_filters() OWNER TO supabase_admin;

--
-- Name: to_regrole(text); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.to_regrole(role_name text) RETURNS regrole
    LANGUAGE sql IMMUTABLE
    AS $$ select role_name::regrole $$;


ALTER FUNCTION realtime.to_regrole(role_name text) OWNER TO supabase_admin;

--
-- Name: topic(); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.topic() RETURNS text
    LANGUAGE sql STABLE
    AS $$
select nullif(current_setting('realtime.topic', true), '')::text;
$$;


ALTER FUNCTION realtime.topic() OWNER TO supabase_realtime_admin;

--
-- Name: wal2json_escape_identifier(text); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.wal2json_escape_identifier(name text) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
  -- Prefix `\`, `,`, `.`, and any whitespace with `\`
  SELECT regexp_replace(name, '([\\,.[:space:]])', '\\\1', 'g')
$$;


ALTER FUNCTION realtime.wal2json_escape_identifier(name text) OWNER TO supabase_admin;

--
-- Name: allow_any_operation(text[]); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.allow_any_operation(expected_operations text[]) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT CASE
      WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
      ELSE raw_operation
    END AS current_operation
    FROM current_operation
  )
  SELECT EXISTS (
    SELECT 1
    FROM normalized n
    CROSS JOIN LATERAL unnest(expected_operations) AS expected_operation
    WHERE expected_operation IS NOT NULL
      AND expected_operation <> ''
      AND n.current_operation = CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END
  );
$$;


ALTER FUNCTION storage.allow_any_operation(expected_operations text[]) OWNER TO supabase_storage_admin;

--
-- Name: allow_only_operation(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.allow_only_operation(expected_operation text) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT
      CASE
        WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
        ELSE raw_operation
      END AS current_operation,
      CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END AS requested_operation
    FROM current_operation
  )
  SELECT CASE
    WHEN requested_operation IS NULL OR requested_operation = '' THEN FALSE
    ELSE COALESCE(current_operation = requested_operation, FALSE)
  END
  FROM normalized;
$$;


ALTER FUNCTION storage.allow_only_operation(expected_operation text) OWNER TO supabase_storage_admin;

--
-- Name: can_insert_object(text, text, uuid, jsonb); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


ALTER FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) OWNER TO supabase_storage_admin;

--
-- Name: enforce_bucket_name_length(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.enforce_bucket_name_length() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
    if length(new.name) > 100 then
        raise exception 'bucket name "%" is too long (% characters). Max is 100.', new.name, length(new.name);
    end if;
    return new;
end;
$$;


ALTER FUNCTION storage.enforce_bucket_name_length() OWNER TO supabase_storage_admin;

--
-- Name: extension(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.extension(name text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
    _filename text;
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Get the last path segment (the actual filename)
    SELECT _parts[array_length(_parts, 1)] INTO _filename;
    -- Extract extension: reverse, split on '.', then reverse again
    RETURN reverse(split_part(reverse(_filename), '.', 1));
END
$$;


ALTER FUNCTION storage.extension(name text) OWNER TO supabase_storage_admin;

--
-- Name: filename(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.filename(name text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[array_length(_parts,1)];
END
$$;


ALTER FUNCTION storage.filename(name text) OWNER TO supabase_storage_admin;

--
-- Name: foldername(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.foldername(name text) RETURNS text[]
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Return everything except the last segment
    RETURN _parts[1 : array_length(_parts,1) - 1];
END
$$;


ALTER FUNCTION storage.foldername(name text) OWNER TO supabase_storage_admin;

--
-- Name: get_common_prefix(text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.get_common_prefix(p_key text, p_prefix text, p_delimiter text) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $$
SELECT CASE
    WHEN position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)) > 0
    THEN left(p_key, length(p_prefix) + position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)))
    ELSE NULL
END;
$$;


ALTER FUNCTION storage.get_common_prefix(p_key text, p_prefix text, p_delimiter text) OWNER TO supabase_storage_admin;

--
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.get_size_by_bucket() RETURNS TABLE(size bigint, bucket_id text)
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::bigint)::bigint as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


ALTER FUNCTION storage.get_size_by_bucket() OWNER TO supabase_storage_admin;

--
-- Name: list_multipart_uploads_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, next_key_token text DEFAULT ''::text, next_upload_token text DEFAULT ''::text) RETURNS TABLE(key text, id text, created_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(key COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                        substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1)))
                    ELSE
                        key
                END AS key, id, created_at
            FROM
                storage.s3_multipart_uploads
            WHERE
                bucket_id = $5 AND
                key ILIKE $1 || ''%'' AND
                CASE
                    WHEN $4 != '''' AND $6 = '''' THEN
                        CASE
                            WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                                substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                key COLLATE "C" > $4
                            END
                    ELSE
                        true
                END AND
                CASE
                    WHEN $6 != '''' THEN
                        id COLLATE "C" > $6
                    ELSE
                        true
                    END
            ORDER BY
                key COLLATE "C" ASC, created_at ASC) as e order by key COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_key_token, bucket_id, next_upload_token;
END;
$_$;


ALTER FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer, next_key_token text, next_upload_token text) OWNER TO supabase_storage_admin;

--
-- Name: list_objects_with_delimiter(text, text, text, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.list_objects_with_delimiter(_bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, start_after text DEFAULT ''::text, next_token text DEFAULT ''::text, sort_order text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, metadata jsonb, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;

    -- Configuration
    v_is_asc BOOLEAN;
    v_prefix TEXT;
    v_start TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_is_asc := lower(coalesce(sort_order, 'asc')) = 'asc';
    v_prefix := coalesce(prefix_param, '');
    v_start := CASE WHEN coalesce(next_token, '') <> '' THEN next_token ELSE coalesce(start_after, '') END;
    v_file_batch_size := LEAST(GREATEST(max_keys * 2, 100), 1000);

    -- Calculate upper bound for prefix filtering (bytewise, using COLLATE "C")
    IF v_prefix = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix, 1) = delimiter_param THEN
        v_upper_bound := left(v_prefix, -1) || chr(ascii(delimiter_param) + 1);
    ELSE
        v_upper_bound := left(v_prefix, -1) || chr(ascii(right(v_prefix, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'AND o.name COLLATE "C" < $3 ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'AND o.name COLLATE "C" >= $3 ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- ========================================================================
    -- SEEK INITIALIZATION: Determine starting position
    -- ========================================================================
    IF v_start = '' THEN
        IF v_is_asc THEN
            v_next_seek := v_prefix;
        ELSE
            -- DESC without cursor: find the last item in range
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;

            IF v_next_seek IS NOT NULL THEN
                v_next_seek := v_next_seek || delimiter_param;
            ELSE
                RETURN;
            END IF;
        END IF;
    ELSE
        -- Cursor provided: determine if it refers to a folder or leaf
        IF EXISTS (
            SELECT 1 FROM storage.objects o
            WHERE o.bucket_id = _bucket_id
              AND o.name COLLATE "C" LIKE v_start || delimiter_param || '%'
            LIMIT 1
        ) THEN
            -- Cursor refers to a folder
            IF v_is_asc THEN
                v_next_seek := v_start || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_start || delimiter_param;
            END IF;
        ELSE
            -- Cursor refers to a leaf object
            IF v_is_asc THEN
                v_next_seek := v_start || delimiter_param;
            ELSE
                v_next_seek := v_start;
            END IF;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= max_keys;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(v_peek_name, v_prefix, delimiter_param);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Emit and skip to next folder (no heap access needed)
            name := rtrim(v_common_prefix, delimiter_param);
            id := NULL;
            updated_at := NULL;
            created_at := NULL;
            last_accessed_at := NULL;
            metadata := NULL;
            RETURN NEXT;
            v_count := v_count + 1;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := left(v_common_prefix, -1) || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_common_prefix;
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query USING _bucket_id, v_next_seek,
                CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix) ELSE v_prefix END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(v_current.name, v_prefix, delimiter_param);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := v_current.name;
                    EXIT;
                END IF;

                -- Emit file
                name := v_current.name;
                id := v_current.id;
                updated_at := v_current.updated_at;
                created_at := v_current.created_at;
                last_accessed_at := v_current.last_accessed_at;
                metadata := v_current.metadata;
                RETURN NEXT;
                v_count := v_count + 1;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := v_current.name || delimiter_param;
                ELSE
                    v_next_seek := v_current.name;
                END IF;

                EXIT WHEN v_count >= max_keys;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


ALTER FUNCTION storage.list_objects_with_delimiter(_bucket_id text, prefix_param text, delimiter_param text, max_keys integer, start_after text, next_token text, sort_order text) OWNER TO supabase_storage_admin;

--
-- Name: operation(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.operation() RETURNS text
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    RETURN current_setting('storage.operation', true);
END;
$$;


ALTER FUNCTION storage.operation() OWNER TO supabase_storage_admin;

--
-- Name: protect_delete(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.protect_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Check if storage.allow_delete_query is set to 'true'
    IF COALESCE(current_setting('storage.allow_delete_query', true), 'false') != 'true' THEN
        RAISE EXCEPTION 'Direct deletion from storage tables is not allowed. Use the Storage API instead.'
            USING HINT = 'This prevents accidental data loss from orphaned objects.',
                  ERRCODE = '42501';
    END IF;
    RETURN NULL;
END;
$$;


ALTER FUNCTION storage.protect_delete() OWNER TO supabase_storage_admin;

--
-- Name: search(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.search(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;
    v_delimiter CONSTANT TEXT := '/';

    -- Configuration
    v_limit INT;
    v_prefix TEXT;
    v_prefix_lower TEXT;
    v_is_asc BOOLEAN;
    v_order_by TEXT;
    v_sort_order TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;
    v_skipped INT := 0;
BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_limit := LEAST(coalesce(limits, 100), 1500);
    v_prefix := coalesce(prefix, '') || coalesce(search, '');
    v_prefix_lower := lower(v_prefix);
    v_is_asc := lower(coalesce(sortorder, 'asc')) = 'asc';
    v_file_batch_size := LEAST(GREATEST(v_limit * 2, 100), 1000);

    -- Validate sort column
    CASE lower(coalesce(sortcolumn, 'name'))
        WHEN 'name' THEN v_order_by := 'name';
        WHEN 'updated_at' THEN v_order_by := 'updated_at';
        WHEN 'created_at' THEN v_order_by := 'created_at';
        WHEN 'last_accessed_at' THEN v_order_by := 'last_accessed_at';
        ELSE v_order_by := 'name';
    END CASE;

    v_sort_order := CASE WHEN v_is_asc THEN 'asc' ELSE 'desc' END;

    -- ========================================================================
    -- NON-NAME SORTING: Use path_tokens approach (unchanged)
    -- ========================================================================
    IF v_order_by != 'name' THEN
        RETURN QUERY EXECUTE format(
            $sql$
            WITH folders AS (
                SELECT path_tokens[$1] AS folder
                FROM storage.objects
                WHERE objects.name ILIKE $2 || '%%'
                  AND bucket_id = $3
                  AND array_length(objects.path_tokens, 1) <> $1
                GROUP BY folder
                ORDER BY folder %s
            )
            (SELECT folder AS "name",
                   NULL::uuid AS id,
                   NULL::timestamptz AS updated_at,
                   NULL::timestamptz AS created_at,
                   NULL::timestamptz AS last_accessed_at,
                   NULL::jsonb AS metadata FROM folders)
            UNION ALL
            (SELECT path_tokens[$1] AS "name",
                   id, updated_at, created_at, last_accessed_at, metadata
             FROM storage.objects
             WHERE objects.name ILIKE $2 || '%%'
               AND bucket_id = $3
               AND array_length(objects.path_tokens, 1) = $1
             ORDER BY %I %s)
            LIMIT $4 OFFSET $5
            $sql$, v_sort_order, v_order_by, v_sort_order
        ) USING levels, v_prefix, bucketname, v_limit, offsets;
        RETURN;
    END IF;

    -- ========================================================================
    -- NAME SORTING: Hybrid skip-scan with batch optimization
    -- ========================================================================

    -- Calculate upper bound for prefix filtering
    IF v_prefix_lower = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix_lower, 1) = v_delimiter THEN
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(v_delimiter) + 1);
    ELSE
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(right(v_prefix_lower, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'AND lower(o.name) COLLATE "C" < $3 ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'AND lower(o.name) COLLATE "C" >= $3 ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- Initialize seek position
    IF v_is_asc THEN
        v_next_seek := v_prefix_lower;
    ELSE
        -- DESC: find the last item in range first (static SQL)
        IF v_upper_bound IS NOT NULL THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower AND lower(o.name) COLLATE "C" < v_upper_bound
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSIF v_prefix_lower <> '' THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSE
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        END IF;

        IF v_peek_name IS NOT NULL THEN
            v_next_seek := lower(v_peek_name) || v_delimiter;
        ELSE
            RETURN;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= v_limit;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek AND lower(o.name) COLLATE "C" < v_upper_bound
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix_lower <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(lower(v_peek_name), v_prefix_lower, v_delimiter);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Handle offset, emit if needed, skip to next folder
            IF v_skipped < offsets THEN
                v_skipped := v_skipped + 1;
            ELSE
                name := split_part(rtrim(storage.get_common_prefix(v_peek_name, v_prefix, v_delimiter), v_delimiter), v_delimiter, levels);
                id := NULL;
                updated_at := NULL;
                created_at := NULL;
                last_accessed_at := NULL;
                metadata := NULL;
                RETURN NEXT;
                v_count := v_count + 1;
            END IF;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := lower(left(v_common_prefix, -1)) || chr(ascii(v_delimiter) + 1);
            ELSE
                v_next_seek := lower(v_common_prefix);
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix_lower is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query
                USING bucketname, v_next_seek,
                    CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix_lower) ELSE v_prefix_lower END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(lower(v_current.name), v_prefix_lower, v_delimiter);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := lower(v_current.name);
                    EXIT;
                END IF;

                -- Handle offset skipping
                IF v_skipped < offsets THEN
                    v_skipped := v_skipped + 1;
                ELSE
                    -- Emit file
                    name := split_part(v_current.name, v_delimiter, levels);
                    id := v_current.id;
                    updated_at := v_current.updated_at;
                    created_at := v_current.created_at;
                    last_accessed_at := v_current.last_accessed_at;
                    metadata := v_current.metadata;
                    RETURN NEXT;
                    v_count := v_count + 1;
                END IF;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := lower(v_current.name) || v_delimiter;
                ELSE
                    v_next_seek := lower(v_current.name);
                END IF;

                EXIT WHEN v_count >= v_limit;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


ALTER FUNCTION storage.search(prefix text, bucketname text, limits integer, levels integer, offsets integer, search text, sortcolumn text, sortorder text) OWNER TO supabase_storage_admin;

--
-- Name: search_by_timestamp(text, text, integer, integer, text, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.search_by_timestamp(p_prefix text, p_bucket_id text, p_limit integer, p_level integer, p_start_after text, p_sort_order text, p_sort_column text, p_sort_column_after text) RETURNS TABLE(key text, name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_cursor_op text;
    v_query text;
    v_prefix text;
BEGIN
    v_prefix := coalesce(p_prefix, '');

    IF p_sort_order = 'asc' THEN
        v_cursor_op := '>';
    ELSE
        v_cursor_op := '<';
    END IF;

    v_query := format($sql$
        WITH raw_objects AS (
            SELECT
                o.name AS obj_name,
                o.id AS obj_id,
                o.updated_at AS obj_updated_at,
                o.created_at AS obj_created_at,
                o.last_accessed_at AS obj_last_accessed_at,
                o.metadata AS obj_metadata,
                storage.get_common_prefix(o.name, $1, '/') AS common_prefix
            FROM storage.objects o
            WHERE o.bucket_id = $2
              AND o.name COLLATE "C" LIKE $1 || '%%'
        ),
        -- Aggregate common prefixes (folders)
        -- Both created_at and updated_at use MIN(obj_created_at) to match the old prefixes table behavior
        aggregated_prefixes AS (
            SELECT
                rtrim(common_prefix, '/') AS name,
                NULL::uuid AS id,
                MIN(obj_created_at) AS updated_at,
                MIN(obj_created_at) AS created_at,
                NULL::timestamptz AS last_accessed_at,
                NULL::jsonb AS metadata,
                TRUE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NOT NULL
            GROUP BY common_prefix
        ),
        leaf_objects AS (
            SELECT
                obj_name AS name,
                obj_id AS id,
                obj_updated_at AS updated_at,
                obj_created_at AS created_at,
                obj_last_accessed_at AS last_accessed_at,
                obj_metadata AS metadata,
                FALSE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NULL
        ),
        combined AS (
            SELECT * FROM aggregated_prefixes
            UNION ALL
            SELECT * FROM leaf_objects
        ),
        filtered AS (
            SELECT *
            FROM combined
            WHERE (
                $5 = ''
                OR ROW(
                    date_trunc('milliseconds', %I),
                    name COLLATE "C"
                ) %s ROW(
                    COALESCE(NULLIF($6, '')::timestamptz, 'epoch'::timestamptz),
                    $5
                )
            )
        )
        SELECT
            split_part(name, '/', $3) AS key,
            name,
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
        FROM filtered
        ORDER BY
            COALESCE(date_trunc('milliseconds', %I), 'epoch'::timestamptz) %s,
            name COLLATE "C" %s
        LIMIT $4
    $sql$,
        p_sort_column,
        v_cursor_op,
        p_sort_column,
        p_sort_order,
        p_sort_order
    );

    RETURN QUERY EXECUTE v_query
    USING v_prefix, p_bucket_id, p_level, p_limit, p_start_after, p_sort_column_after;
END;
$_$;


ALTER FUNCTION storage.search_by_timestamp(p_prefix text, p_bucket_id text, p_limit integer, p_level integer, p_start_after text, p_sort_order text, p_sort_column text, p_sort_column_after text) OWNER TO supabase_storage_admin;

--
-- Name: search_v2(text, text, integer, integer, text, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.search_v2(prefix text, bucket_name text, limits integer DEFAULT 100, levels integer DEFAULT 1, start_after text DEFAULT ''::text, sort_order text DEFAULT 'asc'::text, sort_column text DEFAULT 'name'::text, sort_column_after text DEFAULT ''::text) RETURNS TABLE(key text, name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $$
DECLARE
    v_sort_col text;
    v_sort_ord text;
    v_limit int;
BEGIN
    -- Cap limit to maximum of 1500 records
    v_limit := LEAST(coalesce(limits, 100), 1500);

    -- Validate and normalize sort_order
    v_sort_ord := lower(coalesce(sort_order, 'asc'));
    IF v_sort_ord NOT IN ('asc', 'desc') THEN
        v_sort_ord := 'asc';
    END IF;

    -- Validate and normalize sort_column
    v_sort_col := lower(coalesce(sort_column, 'name'));
    IF v_sort_col NOT IN ('name', 'updated_at', 'created_at') THEN
        v_sort_col := 'name';
    END IF;

    -- Route to appropriate implementation
    IF v_sort_col = 'name' THEN
        -- Use list_objects_with_delimiter for name sorting (most efficient: O(k * log n))
        RETURN QUERY
        SELECT
            split_part(l.name, '/', levels) AS key,
            l.name AS name,
            l.id,
            l.updated_at,
            l.created_at,
            l.last_accessed_at,
            l.metadata
        FROM storage.list_objects_with_delimiter(
            bucket_name,
            coalesce(prefix, ''),
            '/',
            v_limit,
            start_after,
            '',
            v_sort_ord
        ) l;
    ELSE
        -- Use aggregation approach for timestamp sorting
        -- Not efficient for large datasets but supports correct pagination
        RETURN QUERY SELECT * FROM storage.search_by_timestamp(
            prefix, bucket_name, v_limit, levels, start_after,
            v_sort_ord, v_sort_col, sort_column_after
        );
    END IF;
END;
$$;


ALTER FUNCTION storage.search_v2(prefix text, bucket_name text, limits integer, levels integer, start_after text, sort_order text, sort_column text, sort_column_after text) OWNER TO supabase_storage_admin;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


ALTER FUNCTION storage.update_updated_at_column() OWNER TO supabase_storage_admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.audit_log_entries (
    instance_id uuid,
    id uuid NOT NULL,
    payload json,
    created_at timestamp with time zone,
    ip_address character varying(64) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE auth.audit_log_entries OWNER TO supabase_auth_admin;

--
-- Name: TABLE audit_log_entries; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.audit_log_entries IS 'Auth: Audit trail for user actions.';


--
-- Name: custom_oauth_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.custom_oauth_providers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider_type text NOT NULL,
    identifier text NOT NULL,
    name text NOT NULL,
    client_id text NOT NULL,
    client_secret text NOT NULL,
    acceptable_client_ids text[] DEFAULT '{}'::text[] NOT NULL,
    scopes text[] DEFAULT '{}'::text[] NOT NULL,
    pkce_enabled boolean DEFAULT true NOT NULL,
    attribute_mapping jsonb DEFAULT '{}'::jsonb NOT NULL,
    authorization_params jsonb DEFAULT '{}'::jsonb NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    email_optional boolean DEFAULT false NOT NULL,
    issuer text,
    discovery_url text,
    skip_nonce_check boolean DEFAULT false NOT NULL,
    cached_discovery jsonb,
    discovery_cached_at timestamp with time zone,
    authorization_url text,
    token_url text,
    userinfo_url text,
    jwks_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    custom_claims_allowlist text[] DEFAULT '{}'::text[] NOT NULL,
    CONSTRAINT custom_oauth_providers_authorization_url_https CHECK (((authorization_url IS NULL) OR (authorization_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_authorization_url_length CHECK (((authorization_url IS NULL) OR (char_length(authorization_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_client_id_length CHECK (((char_length(client_id) >= 1) AND (char_length(client_id) <= 512))),
    CONSTRAINT custom_oauth_providers_discovery_url_length CHECK (((discovery_url IS NULL) OR (char_length(discovery_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_identifier_format CHECK ((identifier ~ '^[a-z0-9][a-z0-9:-]{0,48}[a-z0-9]$'::text)),
    CONSTRAINT custom_oauth_providers_issuer_length CHECK (((issuer IS NULL) OR ((char_length(issuer) >= 1) AND (char_length(issuer) <= 2048)))),
    CONSTRAINT custom_oauth_providers_jwks_uri_https CHECK (((jwks_uri IS NULL) OR (jwks_uri ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_jwks_uri_length CHECK (((jwks_uri IS NULL) OR (char_length(jwks_uri) <= 2048))),
    CONSTRAINT custom_oauth_providers_name_length CHECK (((char_length(name) >= 1) AND (char_length(name) <= 100))),
    CONSTRAINT custom_oauth_providers_oauth2_requires_endpoints CHECK (((provider_type <> 'oauth2'::text) OR ((authorization_url IS NOT NULL) AND (token_url IS NOT NULL) AND (userinfo_url IS NOT NULL)))),
    CONSTRAINT custom_oauth_providers_oidc_discovery_url_https CHECK (((provider_type <> 'oidc'::text) OR (discovery_url IS NULL) OR (discovery_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_oidc_issuer_https CHECK (((provider_type <> 'oidc'::text) OR (issuer IS NULL) OR (issuer ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_oidc_requires_issuer CHECK (((provider_type <> 'oidc'::text) OR (issuer IS NOT NULL))),
    CONSTRAINT custom_oauth_providers_provider_type_check CHECK ((provider_type = ANY (ARRAY['oauth2'::text, 'oidc'::text]))),
    CONSTRAINT custom_oauth_providers_token_url_https CHECK (((token_url IS NULL) OR (token_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_token_url_length CHECK (((token_url IS NULL) OR (char_length(token_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_userinfo_url_https CHECK (((userinfo_url IS NULL) OR (userinfo_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_userinfo_url_length CHECK (((userinfo_url IS NULL) OR (char_length(userinfo_url) <= 2048)))
);


ALTER TABLE auth.custom_oauth_providers OWNER TO supabase_auth_admin;

--
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.flow_state (
    id uuid NOT NULL,
    user_id uuid,
    auth_code text,
    code_challenge_method auth.code_challenge_method,
    code_challenge text,
    provider_type text NOT NULL,
    provider_access_token text,
    provider_refresh_token text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    authentication_method text NOT NULL,
    auth_code_issued_at timestamp with time zone,
    invite_token text,
    referrer text,
    oauth_client_state_id uuid,
    linking_target_id uuid,
    email_optional boolean DEFAULT false NOT NULL
);


ALTER TABLE auth.flow_state OWNER TO supabase_auth_admin;

--
-- Name: TABLE flow_state; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.flow_state IS 'Stores metadata for all OAuth/SSO login flows';


--
-- Name: identities; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.identities (
    provider_id text NOT NULL,
    user_id uuid NOT NULL,
    identity_data jsonb NOT NULL,
    provider text NOT NULL,
    last_sign_in_at timestamp with time zone,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    email text GENERATED ALWAYS AS (lower((identity_data ->> 'email'::text))) STORED,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE auth.identities OWNER TO supabase_auth_admin;

--
-- Name: TABLE identities; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.identities IS 'Auth: Stores identities associated to a user.';


--
-- Name: COLUMN identities.email; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.identities.email IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- Name: instances; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.instances (
    id uuid NOT NULL,
    uuid uuid,
    raw_base_config text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE auth.instances OWNER TO supabase_auth_admin;

--
-- Name: TABLE instances; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.instances IS 'Auth: Manages users across multiple sites.';


--
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_amr_claims (
    session_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    authentication_method text NOT NULL,
    id uuid NOT NULL
);


ALTER TABLE auth.mfa_amr_claims OWNER TO supabase_auth_admin;

--
-- Name: TABLE mfa_amr_claims; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_amr_claims IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_challenges (
    id uuid NOT NULL,
    factor_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    verified_at timestamp with time zone,
    ip_address inet NOT NULL,
    otp_code text,
    web_authn_session_data jsonb
);


ALTER TABLE auth.mfa_challenges OWNER TO supabase_auth_admin;

--
-- Name: TABLE mfa_challenges; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_challenges IS 'auth: stores metadata about challenge requests made';


--
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_factors (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    friendly_name text,
    factor_type auth.factor_type NOT NULL,
    status auth.factor_status NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    secret text,
    phone text,
    last_challenged_at timestamp with time zone,
    web_authn_credential jsonb,
    web_authn_aaguid uuid,
    last_webauthn_challenge_data jsonb
);


ALTER TABLE auth.mfa_factors OWNER TO supabase_auth_admin;

--
-- Name: TABLE mfa_factors; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_factors IS 'auth: stores metadata about factors';


--
-- Name: COLUMN mfa_factors.last_webauthn_challenge_data; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.mfa_factors.last_webauthn_challenge_data IS 'Stores the latest WebAuthn challenge data including attestation/assertion for customer verification';


--
-- Name: oauth_authorizations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.oauth_authorizations (
    id uuid NOT NULL,
    authorization_id text NOT NULL,
    client_id uuid NOT NULL,
    user_id uuid,
    redirect_uri text NOT NULL,
    scope text NOT NULL,
    state text,
    resource text,
    code_challenge text,
    code_challenge_method auth.code_challenge_method,
    response_type auth.oauth_response_type DEFAULT 'code'::auth.oauth_response_type NOT NULL,
    status auth.oauth_authorization_status DEFAULT 'pending'::auth.oauth_authorization_status NOT NULL,
    authorization_code text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone DEFAULT (now() + '00:03:00'::interval) NOT NULL,
    approved_at timestamp with time zone,
    nonce text,
    CONSTRAINT oauth_authorizations_authorization_code_length CHECK ((char_length(authorization_code) <= 255)),
    CONSTRAINT oauth_authorizations_code_challenge_length CHECK ((char_length(code_challenge) <= 128)),
    CONSTRAINT oauth_authorizations_expires_at_future CHECK ((expires_at > created_at)),
    CONSTRAINT oauth_authorizations_nonce_length CHECK ((char_length(nonce) <= 255)),
    CONSTRAINT oauth_authorizations_redirect_uri_length CHECK ((char_length(redirect_uri) <= 2048)),
    CONSTRAINT oauth_authorizations_resource_length CHECK ((char_length(resource) <= 2048)),
    CONSTRAINT oauth_authorizations_scope_length CHECK ((char_length(scope) <= 4096)),
    CONSTRAINT oauth_authorizations_state_length CHECK ((char_length(state) <= 4096))
);


ALTER TABLE auth.oauth_authorizations OWNER TO supabase_auth_admin;

--
-- Name: oauth_client_states; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.oauth_client_states (
    id uuid NOT NULL,
    provider_type text NOT NULL,
    code_verifier text,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE auth.oauth_client_states OWNER TO supabase_auth_admin;

--
-- Name: TABLE oauth_client_states; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.oauth_client_states IS 'Stores OAuth states for third-party provider authentication flows where Supabase acts as the OAuth client.';


--
-- Name: oauth_clients; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.oauth_clients (
    id uuid NOT NULL,
    client_secret_hash text,
    registration_type auth.oauth_registration_type NOT NULL,
    redirect_uris text NOT NULL,
    grant_types text NOT NULL,
    client_name text,
    client_uri text,
    logo_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    client_type auth.oauth_client_type DEFAULT 'confidential'::auth.oauth_client_type NOT NULL,
    token_endpoint_auth_method text NOT NULL,
    CONSTRAINT oauth_clients_client_name_length CHECK ((char_length(client_name) <= 1024)),
    CONSTRAINT oauth_clients_client_uri_length CHECK ((char_length(client_uri) <= 2048)),
    CONSTRAINT oauth_clients_logo_uri_length CHECK ((char_length(logo_uri) <= 2048)),
    CONSTRAINT oauth_clients_token_endpoint_auth_method_check CHECK ((token_endpoint_auth_method = ANY (ARRAY['client_secret_basic'::text, 'client_secret_post'::text, 'none'::text])))
);


ALTER TABLE auth.oauth_clients OWNER TO supabase_auth_admin;

--
-- Name: oauth_consents; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.oauth_consents (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    client_id uuid NOT NULL,
    scopes text NOT NULL,
    granted_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    CONSTRAINT oauth_consents_revoked_after_granted CHECK (((revoked_at IS NULL) OR (revoked_at >= granted_at))),
    CONSTRAINT oauth_consents_scopes_length CHECK ((char_length(scopes) <= 2048)),
    CONSTRAINT oauth_consents_scopes_not_empty CHECK ((char_length(TRIM(BOTH FROM scopes)) > 0))
);


ALTER TABLE auth.oauth_consents OWNER TO supabase_auth_admin;

--
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.one_time_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_type auth.one_time_token_type NOT NULL,
    token_hash text NOT NULL,
    relates_to text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT one_time_tokens_token_hash_check CHECK ((char_length(token_hash) > 0))
);


ALTER TABLE auth.one_time_tokens OWNER TO supabase_auth_admin;

--
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.refresh_tokens (
    instance_id uuid,
    id bigint NOT NULL,
    token character varying(255),
    user_id character varying(255),
    revoked boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    parent character varying(255),
    session_id uuid
);


ALTER TABLE auth.refresh_tokens OWNER TO supabase_auth_admin;

--
-- Name: TABLE refresh_tokens; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.refresh_tokens IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: supabase_auth_admin
--

CREATE SEQUENCE auth.refresh_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE auth.refresh_tokens_id_seq OWNER TO supabase_auth_admin;

--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: supabase_auth_admin
--

ALTER SEQUENCE auth.refresh_tokens_id_seq OWNED BY auth.refresh_tokens.id;


--
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.saml_providers (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    entity_id text NOT NULL,
    metadata_xml text NOT NULL,
    metadata_url text,
    attribute_mapping jsonb,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    name_id_format text,
    CONSTRAINT "entity_id not empty" CHECK ((char_length(entity_id) > 0)),
    CONSTRAINT "metadata_url not empty" CHECK (((metadata_url = NULL::text) OR (char_length(metadata_url) > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK ((char_length(metadata_xml) > 0))
);


ALTER TABLE auth.saml_providers OWNER TO supabase_auth_admin;

--
-- Name: TABLE saml_providers; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.saml_providers IS 'Auth: Manages SAML Identity Provider connections.';


--
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.saml_relay_states (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    request_id text NOT NULL,
    for_email text,
    redirect_to text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    flow_state_id uuid,
    CONSTRAINT "request_id not empty" CHECK ((char_length(request_id) > 0))
);


ALTER TABLE auth.saml_relay_states OWNER TO supabase_auth_admin;

--
-- Name: TABLE saml_relay_states; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.saml_relay_states IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE auth.schema_migrations OWNER TO supabase_auth_admin;

--
-- Name: TABLE schema_migrations; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.schema_migrations IS 'Auth: Manages updates to the auth system.';


--
-- Name: sessions; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    factor_id uuid,
    aal auth.aal_level,
    not_after timestamp with time zone,
    refreshed_at timestamp without time zone,
    user_agent text,
    ip inet,
    tag text,
    oauth_client_id uuid,
    refresh_token_hmac_key text,
    refresh_token_counter bigint,
    scopes text,
    CONSTRAINT sessions_scopes_length CHECK ((char_length(scopes) <= 4096))
);


ALTER TABLE auth.sessions OWNER TO supabase_auth_admin;

--
-- Name: TABLE sessions; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sessions IS 'Auth: Stores session data associated to a user.';


--
-- Name: COLUMN sessions.not_after; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sessions.not_after IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- Name: COLUMN sessions.refresh_token_hmac_key; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sessions.refresh_token_hmac_key IS 'Holds a HMAC-SHA256 key used to sign refresh tokens for this session.';


--
-- Name: COLUMN sessions.refresh_token_counter; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sessions.refresh_token_counter IS 'Holds the ID (counter) of the last issued refresh token.';


--
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sso_domains (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    domain text NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK ((char_length(domain) > 0))
);


ALTER TABLE auth.sso_domains OWNER TO supabase_auth_admin;

--
-- Name: TABLE sso_domains; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sso_domains IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sso_providers (
    id uuid NOT NULL,
    resource_id text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    disabled boolean,
    CONSTRAINT "resource_id not empty" CHECK (((resource_id = NULL::text) OR (char_length(resource_id) > 0)))
);


ALTER TABLE auth.sso_providers OWNER TO supabase_auth_admin;

--
-- Name: TABLE sso_providers; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sso_providers IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- Name: COLUMN sso_providers.resource_id; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sso_providers.resource_id IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- Name: users; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.users (
    instance_id uuid,
    id uuid NOT NULL,
    aud character varying(255),
    role character varying(255),
    email character varying(255),
    encrypted_password character varying(255),
    email_confirmed_at timestamp with time zone,
    invited_at timestamp with time zone,
    confirmation_token character varying(255),
    confirmation_sent_at timestamp with time zone,
    recovery_token character varying(255),
    recovery_sent_at timestamp with time zone,
    email_change_token_new character varying(255),
    email_change character varying(255),
    email_change_sent_at timestamp with time zone,
    last_sign_in_at timestamp with time zone,
    raw_app_meta_data jsonb,
    raw_user_meta_data jsonb,
    is_super_admin boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    phone text DEFAULT NULL::character varying,
    phone_confirmed_at timestamp with time zone,
    phone_change text DEFAULT ''::character varying,
    phone_change_token character varying(255) DEFAULT ''::character varying,
    phone_change_sent_at timestamp with time zone,
    confirmed_at timestamp with time zone GENERATED ALWAYS AS (LEAST(email_confirmed_at, phone_confirmed_at)) STORED,
    email_change_token_current character varying(255) DEFAULT ''::character varying,
    email_change_confirm_status smallint DEFAULT 0,
    banned_until timestamp with time zone,
    reauthentication_token character varying(255) DEFAULT ''::character varying,
    reauthentication_sent_at timestamp with time zone,
    is_sso_user boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    is_anonymous boolean DEFAULT false NOT NULL,
    CONSTRAINT users_email_change_confirm_status_check CHECK (((email_change_confirm_status >= 0) AND (email_change_confirm_status <= 2)))
);


ALTER TABLE auth.users OWNER TO supabase_auth_admin;

--
-- Name: TABLE users; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.users IS 'Auth: Stores user login data within a secure schema.';


--
-- Name: COLUMN users.is_sso_user; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.users.is_sso_user IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- Name: webauthn_challenges; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.webauthn_challenges (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    challenge_type text NOT NULL,
    session_data jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    CONSTRAINT webauthn_challenges_challenge_type_check CHECK ((challenge_type = ANY (ARRAY['signup'::text, 'registration'::text, 'authentication'::text])))
);


ALTER TABLE auth.webauthn_challenges OWNER TO supabase_auth_admin;

--
-- Name: webauthn_credentials; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.webauthn_credentials (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    credential_id bytea NOT NULL,
    public_key bytea NOT NULL,
    attestation_type text DEFAULT ''::text NOT NULL,
    aaguid uuid,
    sign_count bigint DEFAULT 0 NOT NULL,
    transports jsonb DEFAULT '[]'::jsonb NOT NULL,
    backup_eligible boolean DEFAULT false NOT NULL,
    backed_up boolean DEFAULT false NOT NULL,
    friendly_name text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    last_used_at timestamp with time zone
);


ALTER TABLE auth.webauthn_credentials OWNER TO supabase_auth_admin;

--
-- Name: articles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.articles (
    id bigint NOT NULL,
    status text DEFAULT 'published'::text,
    sort integer,
    slug text NOT NULL,
    title text NOT NULL,
    excerpt text,
    content text,
    featured_image text,
    author text,
    tags jsonb DEFAULT '[]'::jsonb,
    category text,
    date_published timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT articles_status_check CHECK ((status = ANY (ARRAY['published'::text, 'draft'::text])))
);


ALTER TABLE public.articles OWNER TO postgres;

--
-- Name: articles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.articles ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.articles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: clients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clients (
    id bigint NOT NULL,
    status text DEFAULT 'published'::text,
    sort integer,
    name text NOT NULL,
    logo text,
    tags jsonb DEFAULT '[]'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    in_carousel boolean DEFAULT false,
    CONSTRAINT clients_status_check CHECK ((status = ANY (ARRAY['published'::text, 'draft'::text])))
);


ALTER TABLE public.clients OWNER TO postgres;

--
-- Name: clients_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.clients ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.clients_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: faq; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.faq (
    id bigint NOT NULL,
    status text DEFAULT 'published'::text,
    sort integer,
    question_fr text NOT NULL,
    answer_fr text,
    question_en text,
    answer_en text,
    question_br text,
    answer_br text,
    category text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT faq_status_check CHECK ((status = ANY (ARRAY['published'::text, 'draft'::text])))
);


ALTER TABLE public.faq OWNER TO postgres;

--
-- Name: faq_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.faq ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.faq_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: glossaire; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.glossaire (
    id bigint NOT NULL,
    status text DEFAULT 'published'::text,
    sort integer,
    term_fr text NOT NULL,
    definition_fr text,
    term_en text,
    definition_en text,
    term_br text,
    definition_br text,
    related_expertise text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT glossaire_status_check CHECK ((status = ANY (ARRAY['published'::text, 'draft'::text])))
);


ALTER TABLE public.glossaire OWNER TO postgres;

--
-- Name: glossaire_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.glossaire ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.glossaire_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: partenaires; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.partenaires (
    id bigint NOT NULL,
    status text DEFAULT 'published'::text,
    sort integer,
    name text NOT NULL,
    logo text,
    role text,
    website text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT partenaires_status_check CHECK ((status = ANY (ARRAY['published'::text, 'draft'::text])))
);


ALTER TABLE public.partenaires OWNER TO postgres;

--
-- Name: partenaires_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.partenaires ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.partenaires_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: projets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.projets (
    id bigint NOT NULL,
    status text DEFAULT 'published'::text,
    sort integer,
    slug text NOT NULL,
    title text NOT NULL,
    description text,
    location text,
    category text,
    client text,
    missions jsonb DEFAULT '[]'::jsonb,
    technical_details text,
    image_before text,
    image_after text,
    images_gallery jsonb DEFAULT '[]'::jsonb,
    latitude double precision,
    longitude double precision,
    date timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT projets_status_check CHECK ((status = ANY (ARRAY['published'::text, 'draft'::text])))
);


ALTER TABLE public.projets OWNER TO postgres;

--
-- Name: projets_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.projets ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.projets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: simulations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.simulations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    address text NOT NULL,
    parcel_ref text,
    total_surface text,
    lot_a_surface text,
    lot_b_surface text,
    client_name text NOT NULL,
    client_email text NOT NULL,
    client_phone text,
    client_message text,
    status text DEFAULT 'new'::text NOT NULL
);


ALTER TABLE public.simulations OWNER TO postgres;

--
-- Name: site_texts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.site_texts (
    key text NOT NULL,
    fr text NOT NULL,
    en text,
    br text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.site_texts OWNER TO postgres;

--
-- Name: social_posts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.social_posts (
    id bigint NOT NULL,
    status text DEFAULT 'published'::text,
    sort integer,
    url text NOT NULL,
    caption text,
    date timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT social_posts_status_check CHECK ((status = ANY (ARRAY['published'::text, 'draft'::text])))
);


ALTER TABLE public.social_posts OWNER TO postgres;

--
-- Name: social_posts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.social_posts ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.social_posts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: team_header; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.team_header (
    id integer DEFAULT 1 NOT NULL,
    title_fr text,
    subtitle_fr text,
    title_en text,
    subtitle_en text,
    title_br text,
    subtitle_br text,
    team_photo text,
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT only_one_row CHECK ((id = 1))
);


ALTER TABLE public.team_header OWNER TO postgres;

--
-- Name: team_members; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.team_members (
    id bigint NOT NULL,
    status text DEFAULT 'published'::text,
    sort integer,
    slug text,
    image text,
    linkedin text,
    generic boolean DEFAULT false,
    email text,
    phone text,
    name_fr text,
    role_fr text,
    desc_fr text,
    name_en text,
    role_en text,
    desc_en text,
    name_br text,
    role_br text,
    desc_br text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT team_members_status_check CHECK ((status = ANY (ARRAY['published'::text, 'draft'::text])))
);


ALTER TABLE public.team_members OWNER TO postgres;

--
-- Name: team_members_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.team_members ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.team_members_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: visits; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.visits (
    id bigint NOT NULL,
    path text NOT NULL,
    is_article boolean DEFAULT false,
    device text DEFAULT 'Desktop'::text,
    browser text DEFAULT 'Autre'::text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.visits OWNER TO postgres;

--
-- Name: visits_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.visits ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.visits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: messages; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE realtime.messages (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    binary_payload bytea
)
PARTITION BY RANGE (inserted_at);


ALTER TABLE realtime.messages OWNER TO supabase_realtime_admin;

--
-- Name: schema_migrations; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.schema_migrations (
    version bigint NOT NULL,
    inserted_at timestamp(0) without time zone
);


ALTER TABLE realtime.schema_migrations OWNER TO supabase_admin;

--
-- Name: subscription; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.subscription (
    id bigint NOT NULL,
    subscription_id uuid NOT NULL,
    entity regclass NOT NULL,
    filters realtime.user_defined_filter[] DEFAULT '{}'::realtime.user_defined_filter[] NOT NULL,
    claims jsonb NOT NULL,
    claims_role regrole GENERATED ALWAYS AS (realtime.to_regrole((claims ->> 'role'::text))) STORED NOT NULL,
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    action_filter text DEFAULT '*'::text,
    selected_columns text[],
    CONSTRAINT subscription_action_filter_check CHECK ((action_filter = ANY (ARRAY['*'::text, 'INSERT'::text, 'UPDATE'::text, 'DELETE'::text])))
);


ALTER TABLE realtime.subscription OWNER TO supabase_admin;

--
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE realtime.subscription ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME realtime.subscription_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: buckets; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.buckets (
    id text NOT NULL,
    name text NOT NULL,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    public boolean DEFAULT false,
    avif_autodetection boolean DEFAULT false,
    file_size_limit bigint,
    allowed_mime_types text[],
    owner_id text,
    type storage.buckettype DEFAULT 'STANDARD'::storage.buckettype NOT NULL
);


ALTER TABLE storage.buckets OWNER TO supabase_storage_admin;

--
-- Name: COLUMN buckets.owner; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN storage.buckets.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: buckets_analytics; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.buckets_analytics (
    name text NOT NULL,
    type storage.buckettype DEFAULT 'ANALYTICS'::storage.buckettype NOT NULL,
    format text DEFAULT 'ICEBERG'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE storage.buckets_analytics OWNER TO supabase_storage_admin;

--
-- Name: buckets_vectors; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.buckets_vectors (
    id text NOT NULL,
    type storage.buckettype DEFAULT 'VECTOR'::storage.buckettype NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE storage.buckets_vectors OWNER TO supabase_storage_admin;

--
-- Name: migrations; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.migrations (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    hash character varying(40) NOT NULL,
    executed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE storage.migrations OWNER TO supabase_storage_admin;

--
-- Name: objects; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.objects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id text,
    name text,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_accessed_at timestamp with time zone DEFAULT now(),
    metadata jsonb,
    path_tokens text[] GENERATED ALWAYS AS (string_to_array(name, '/'::text)) STORED,
    version text,
    owner_id text,
    user_metadata jsonb
);


ALTER TABLE storage.objects OWNER TO supabase_storage_admin;

--
-- Name: COLUMN objects.owner; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN storage.objects.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: s3_multipart_uploads; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.s3_multipart_uploads (
    id text NOT NULL,
    in_progress_size bigint DEFAULT 0 NOT NULL,
    upload_signature text NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    version text NOT NULL,
    owner_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    user_metadata jsonb,
    metadata jsonb
);


ALTER TABLE storage.s3_multipart_uploads OWNER TO supabase_storage_admin;

--
-- Name: s3_multipart_uploads_parts; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.s3_multipart_uploads_parts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    upload_id text NOT NULL,
    size bigint DEFAULT 0 NOT NULL,
    part_number integer NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    etag text NOT NULL,
    owner_id text,
    version text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE storage.s3_multipart_uploads_parts OWNER TO supabase_storage_admin;

--
-- Name: vector_indexes; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.vector_indexes (
    id text DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    bucket_id text NOT NULL,
    data_type text NOT NULL,
    dimension integer NOT NULL,
    distance_metric text NOT NULL,
    metadata_configuration jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE storage.vector_indexes OWNER TO supabase_storage_admin;

--
-- Name: schema_migrations; Type: TABLE; Schema: supabase_migrations; Owner: postgres
--

CREATE TABLE supabase_migrations.schema_migrations (
    version text NOT NULL,
    statements text[],
    name text
);


ALTER TABLE supabase_migrations.schema_migrations OWNER TO postgres;

--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('auth.refresh_tokens_id_seq'::regclass);


--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.audit_log_entries (instance_id, id, payload, created_at, ip_address) FROM stdin;
\.


--
-- Data for Name: custom_oauth_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.custom_oauth_providers (id, provider_type, identifier, name, client_id, client_secret, acceptable_client_ids, scopes, pkce_enabled, attribute_mapping, authorization_params, enabled, email_optional, issuer, discovery_url, skip_nonce_check, cached_discovery, discovery_cached_at, authorization_url, token_url, userinfo_url, jwks_uri, created_at, updated_at, custom_claims_allowlist) FROM stdin;
\.


--
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.flow_state (id, user_id, auth_code, code_challenge_method, code_challenge, provider_type, provider_access_token, provider_refresh_token, created_at, updated_at, authentication_method, auth_code_issued_at, invite_token, referrer, oauth_client_state_id, linking_target_id, email_optional) FROM stdin;
\.


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at, id) FROM stdin;
d997a92e-2df1-4660-b542-91c9968be7d8	d997a92e-2df1-4660-b542-91c9968be7d8	{"sub": "d997a92e-2df1-4660-b542-91c9968be7d8", "email": "admin@urbateam.fr", "email_verified": false, "phone_verified": false}	email	2026-06-02 03:08:53.760425+00	2026-06-02 03:08:53.760503+00	2026-06-02 03:08:53.760503+00	c0f05a0d-94dc-4f37-97bd-0fbc1a86bf03
\.


--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.instances (id, uuid, raw_base_config, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) FROM stdin;
eacd801c-2fa3-4f3e-be7c-ac96cc5378b0	2026-06-02 03:26:40.736171+00	2026-06-02 03:26:40.736171+00	password	4aa28525-6d28-435b-b598-edffb3df7bcd
40607303-3761-4c0f-9641-b880df7e2158	2026-06-02 03:36:14.257501+00	2026-06-02 03:36:14.257501+00	password	475c8502-4e76-48f9-9388-c200dbefa2e5
384e8392-bafd-4f49-a1e9-5ecd03373a6a	2026-06-02 03:39:19.023688+00	2026-06-02 03:39:19.023688+00	password	4faa0f10-e9db-4d8f-b698-6e167554c74e
68437c3c-372d-42da-98b2-bfea62e151d1	2026-06-02 15:27:46.355798+00	2026-06-02 15:27:46.355798+00	password	bd707fd5-d019-4135-88bb-726524f89273
8110ed04-a736-4ec6-bc06-6c26fdeda78b	2026-06-02 16:30:40.943059+00	2026-06-02 16:30:40.943059+00	password	293fe72d-2694-4573-97cf-afa30c73c7fc
6639f289-fa50-4961-b9df-c6e259afaa62	2026-06-03 15:20:52.626027+00	2026-06-03 15:20:52.626027+00	password	ff33e893-0e4b-4175-8c69-9233806da9c8
32509832-9ad8-44fe-866d-0f50959f3296	2026-06-03 15:21:10.405853+00	2026-06-03 15:21:10.405853+00	password	e1ba4925-d452-4749-a4f9-cb884bdc92d8
3d373496-9663-45e4-9a3c-bf772f99837b	2026-06-04 14:46:13.724428+00	2026-06-04 14:46:13.724428+00	password	d85ec7a1-5a52-41b1-9852-44355d939c17
fdd82c06-cd01-428e-b1ac-37a392fd960b	2026-06-04 15:37:43.476927+00	2026-06-04 15:37:43.476927+00	password	2f8447d0-6b30-440a-98da-778b59b6f398
a1d5e5d4-297b-4d66-851f-4a77be676910	2026-06-19 13:28:38.19562+00	2026-06-19 13:28:38.19562+00	password	35aa8358-f659-47da-9ef6-8ef5b87372e0
15251f06-6e20-4911-8a4f-a06e2e165b78	2026-06-19 14:36:46.776773+00	2026-06-19 14:36:46.776773+00	password	64c29e52-e342-4b45-a118-95289fded678
749a0226-ea70-4bde-9082-e4bfb3e79ed5	2026-06-19 14:49:39.226565+00	2026-06-19 14:49:39.226565+00	password	d346608f-9208-4a35-9d13-7d666efc748f
50255756-f09d-4eec-8e1a-c23e5b60e0a3	2026-06-22 12:18:36.430271+00	2026-06-22 12:18:36.430271+00	password	2a0554fc-def8-4388-928f-e4c76dc71739
78191201-b250-47be-9ec6-b6ff60a657b2	2026-06-22 13:18:46.272047+00	2026-06-22 13:18:46.272047+00	password	2420705a-29df-4ba1-b994-0b74a6fab068
598f2b9e-a84a-46b3-914b-0166e4284f0a	2026-06-22 14:47:33.70183+00	2026-06-22 14:47:33.70183+00	password	f02f4ab9-f216-466a-bfbe-270dea44d4fa
c581539c-5599-40bb-a6c9-c70d50a14b2e	2026-06-22 15:47:40.092566+00	2026-06-22 15:47:40.092566+00	password	014fd264-e092-4c9a-a592-e0c9c2b3e885
f51e1674-de29-4f8a-9bba-9461f497c6fc	2026-06-22 15:53:52.859246+00	2026-06-22 15:53:52.859246+00	password	fffa9272-1e39-46b3-98f8-2b3398f2c3ad
6c182147-24e9-437c-bd10-8c9253ce7389	2026-06-26 08:05:42.304267+00	2026-06-26 08:05:42.304267+00	password	efddd0de-b3c9-4b85-858b-16297533e196
\.


--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_challenges (id, factor_id, created_at, verified_at, ip_address, otp_code, web_authn_session_data) FROM stdin;
\.


--
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_factors (id, user_id, friendly_name, factor_type, status, created_at, updated_at, secret, phone, last_challenged_at, web_authn_credential, web_authn_aaguid, last_webauthn_challenge_data) FROM stdin;
\.


--
-- Data for Name: oauth_authorizations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.oauth_authorizations (id, authorization_id, client_id, user_id, redirect_uri, scope, state, resource, code_challenge, code_challenge_method, response_type, status, authorization_code, created_at, expires_at, approved_at, nonce) FROM stdin;
\.


--
-- Data for Name: oauth_client_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.oauth_client_states (id, provider_type, code_verifier, created_at) FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.oauth_clients (id, client_secret_hash, registration_type, redirect_uris, grant_types, client_name, client_uri, logo_uri, created_at, updated_at, deleted_at, client_type, token_endpoint_auth_method) FROM stdin;
\.


--
-- Data for Name: oauth_consents; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.oauth_consents (id, user_id, client_id, scopes, granted_at, revoked_at) FROM stdin;
\.


--
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.one_time_tokens (id, user_id, token_type, token_hash, relates_to, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) FROM stdin;
00000000-0000-0000-0000-000000000000	1	rqk4lhjg42an	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-06-02 03:26:40.723079+00	2026-06-02 03:26:40.723079+00	\N	eacd801c-2fa3-4f3e-be7c-ac96cc5378b0
00000000-0000-0000-0000-000000000000	2	kf4nrwtcyehe	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-06-02 03:36:14.253222+00	2026-06-02 03:36:14.253222+00	\N	40607303-3761-4c0f-9641-b880df7e2158
00000000-0000-0000-0000-000000000000	3	rpczbvep6w2f	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-06-02 03:39:19.017834+00	2026-06-02 03:39:19.017834+00	\N	384e8392-bafd-4f49-a1e9-5ecd03373a6a
00000000-0000-0000-0000-000000000000	4	cujf3vic3cr4	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-06-02 15:27:46.324624+00	2026-06-02 15:27:46.324624+00	\N	68437c3c-372d-42da-98b2-bfea62e151d1
00000000-0000-0000-0000-000000000000	5	s4cnoxpq6547	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-06-02 16:30:40.92631+00	2026-06-02 16:30:40.92631+00	\N	8110ed04-a736-4ec6-bc06-6c26fdeda78b
00000000-0000-0000-0000-000000000000	6	4yumy737hqwz	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-06-03 15:20:52.59781+00	2026-06-03 15:20:52.59781+00	\N	6639f289-fa50-4961-b9df-c6e259afaa62
00000000-0000-0000-0000-000000000000	7	pzqqvyro2ju7	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-06-03 15:21:10.397432+00	2026-06-03 15:21:10.397432+00	\N	32509832-9ad8-44fe-866d-0f50959f3296
00000000-0000-0000-0000-000000000000	8	vm55yto25rho	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-06-04 14:46:13.68519+00	2026-06-04 14:46:13.68519+00	\N	3d373496-9663-45e4-9a3c-bf772f99837b
00000000-0000-0000-0000-000000000000	9	x3uhermilgzq	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-06-04 15:37:43.462848+00	2026-06-04 15:37:43.462848+00	\N	fdd82c06-cd01-428e-b1ac-37a392fd960b
00000000-0000-0000-0000-000000000000	10	n5e7k5kaqhft	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-06-19 13:28:38.169625+00	2026-06-19 13:28:38.169625+00	\N	a1d5e5d4-297b-4d66-851f-4a77be676910
00000000-0000-0000-0000-000000000000	11	au43ev254zoi	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-06-19 14:36:46.76361+00	2026-06-19 14:36:46.76361+00	\N	15251f06-6e20-4911-8a4f-a06e2e165b78
00000000-0000-0000-0000-000000000000	12	3m7n75s4n5ad	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-06-19 14:49:39.222796+00	2026-06-19 14:49:39.222796+00	\N	749a0226-ea70-4bde-9082-e4bfb3e79ed5
00000000-0000-0000-0000-000000000000	13	wz2hdyqqhzrt	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-06-22 12:18:36.402598+00	2026-06-22 12:18:36.402598+00	\N	50255756-f09d-4eec-8e1a-c23e5b60e0a3
00000000-0000-0000-0000-000000000000	14	now2ts6yt3se	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-06-22 13:18:46.261182+00	2026-06-22 13:18:46.261182+00	\N	78191201-b250-47be-9ec6-b6ff60a657b2
00000000-0000-0000-0000-000000000000	15	q2kddpvlotcx	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-06-22 14:47:33.667757+00	2026-06-22 14:47:33.667757+00	\N	598f2b9e-a84a-46b3-914b-0166e4284f0a
00000000-0000-0000-0000-000000000000	16	3ndaby2d4xoa	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-06-22 15:47:40.067351+00	2026-06-22 15:47:40.067351+00	\N	c581539c-5599-40bb-a6c9-c70d50a14b2e
00000000-0000-0000-0000-000000000000	17	qgfnv4sg74tq	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-06-22 15:53:52.845401+00	2026-06-22 15:53:52.845401+00	\N	f51e1674-de29-4f8a-9bba-9461f497c6fc
00000000-0000-0000-0000-000000000000	18	lpesa3ghyagq	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-06-26 08:05:42.290531+00	2026-06-26 08:05:42.290531+00	\N	6c182147-24e9-437c-bd10-8c9253ce7389
\.


--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.saml_providers (id, sso_provider_id, entity_id, metadata_xml, metadata_url, attribute_mapping, created_at, updated_at, name_id_format) FROM stdin;
\.


--
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.saml_relay_states (id, sso_provider_id, request_id, for_email, redirect_to, created_at, updated_at, flow_state_id) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.schema_migrations (version) FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
00
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
20220811173540
20221003041349
20221003041400
20221011041400
20221020193600
20221021073300
20221021082433
20221027105023
20221114143122
20221114143410
20221125140132
20221208132122
20221215195500
20221215195800
20221215195900
20230116124310
20230116124412
20230131181311
20230322519590
20230402418590
20230411005111
20230508135423
20230523124323
20230818113222
20230914180801
20231027141322
20231114161723
20231117164230
20240115144230
20240214120130
20240306115329
20240314092811
20240427152123
20240612123726
20240729123726
20240802193726
20240806073726
20241009103726
20250717082212
20250731150234
20250804100000
20250901200500
20250903112500
20250904133000
20250925093508
20251007112900
20251104100000
20251111201300
20251201000000
20260115000000
20260121000000
20260219120000
20260302000000
20260625000000
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag, oauth_client_id, refresh_token_hmac_key, refresh_token_counter, scopes) FROM stdin;
eacd801c-2fa3-4f3e-be7c-ac96cc5378b0	d997a92e-2df1-4660-b542-91c9968be7d8	2026-06-02 03:26:40.702622+00	2026-06-02 03:26:40.702622+00	\N	aal1	\N	\N	node	44.211.74.12	\N	\N	\N	\N	\N
40607303-3761-4c0f-9641-b880df7e2158	d997a92e-2df1-4660-b542-91c9968be7d8	2026-06-02 03:36:14.240725+00	2026-06-02 03:36:14.240725+00	\N	aal1	\N	\N	node	3.236.162.232	\N	\N	\N	\N	\N
384e8392-bafd-4f49-a1e9-5ecd03373a6a	d997a92e-2df1-4660-b542-91c9968be7d8	2026-06-02 03:39:19.007275+00	2026-06-02 03:39:19.007275+00	\N	aal1	\N	\N	node	54.226.101.95	\N	\N	\N	\N	\N
68437c3c-372d-42da-98b2-bfea62e151d1	d997a92e-2df1-4660-b542-91c9968be7d8	2026-06-02 15:27:46.288806+00	2026-06-02 15:27:46.288806+00	\N	aal1	\N	\N	node	3.239.120.240	\N	\N	\N	\N	\N
8110ed04-a736-4ec6-bc06-6c26fdeda78b	d997a92e-2df1-4660-b542-91c9968be7d8	2026-06-02 16:30:40.903665+00	2026-06-02 16:30:40.903665+00	\N	aal1	\N	\N	node	100.31.199.114	\N	\N	\N	\N	\N
6639f289-fa50-4961-b9df-c6e259afaa62	d997a92e-2df1-4660-b542-91c9968be7d8	2026-06-03 15:20:52.566798+00	2026-06-03 15:20:52.566798+00	\N	aal1	\N	\N	node	100.26.100.38	\N	\N	\N	\N	\N
32509832-9ad8-44fe-866d-0f50959f3296	d997a92e-2df1-4660-b542-91c9968be7d8	2026-06-03 15:21:10.39289+00	2026-06-03 15:21:10.39289+00	\N	aal1	\N	\N	node	100.26.100.38	\N	\N	\N	\N	\N
3d373496-9663-45e4-9a3c-bf772f99837b	d997a92e-2df1-4660-b542-91c9968be7d8	2026-06-04 14:46:13.642663+00	2026-06-04 14:46:13.642663+00	\N	aal1	\N	\N	node	13.220.28.4	\N	\N	\N	\N	\N
fdd82c06-cd01-428e-b1ac-37a392fd960b	d997a92e-2df1-4660-b542-91c9968be7d8	2026-06-04 15:37:43.447901+00	2026-06-04 15:37:43.447901+00	\N	aal1	\N	\N	node	100.26.107.216	\N	\N	\N	\N	\N
a1d5e5d4-297b-4d66-851f-4a77be676910	d997a92e-2df1-4660-b542-91c9968be7d8	2026-06-19 13:28:38.133849+00	2026-06-19 13:28:38.133849+00	\N	aal1	\N	\N	node	54.92.154.185	\N	\N	\N	\N	\N
15251f06-6e20-4911-8a4f-a06e2e165b78	d997a92e-2df1-4660-b542-91c9968be7d8	2026-06-19 14:36:46.744005+00	2026-06-19 14:36:46.744005+00	\N	aal1	\N	\N	node	44.199.192.119	\N	\N	\N	\N	\N
749a0226-ea70-4bde-9082-e4bfb3e79ed5	d997a92e-2df1-4660-b542-91c9968be7d8	2026-06-19 14:49:39.21288+00	2026-06-19 14:49:39.21288+00	\N	aal1	\N	\N	node	44.203.167.84	\N	\N	\N	\N	\N
50255756-f09d-4eec-8e1a-c23e5b60e0a3	d997a92e-2df1-4660-b542-91c9968be7d8	2026-06-22 12:18:36.3662+00	2026-06-22 12:18:36.3662+00	\N	aal1	\N	\N	node	100.53.245.153	\N	\N	\N	\N	\N
78191201-b250-47be-9ec6-b6ff60a657b2	d997a92e-2df1-4660-b542-91c9968be7d8	2026-06-22 13:18:46.239251+00	2026-06-22 13:18:46.239251+00	\N	aal1	\N	\N	node	54.87.229.182	\N	\N	\N	\N	\N
598f2b9e-a84a-46b3-914b-0166e4284f0a	d997a92e-2df1-4660-b542-91c9968be7d8	2026-06-22 14:47:33.628881+00	2026-06-22 14:47:33.628881+00	\N	aal1	\N	\N	node	34.229.169.236	\N	\N	\N	\N	\N
c581539c-5599-40bb-a6c9-c70d50a14b2e	d997a92e-2df1-4660-b542-91c9968be7d8	2026-06-22 15:47:40.035594+00	2026-06-22 15:47:40.035594+00	\N	aal1	\N	\N	node	54.210.30.49	\N	\N	\N	\N	\N
f51e1674-de29-4f8a-9bba-9461f497c6fc	d997a92e-2df1-4660-b542-91c9968be7d8	2026-06-22 15:53:52.823516+00	2026-06-22 15:53:52.823516+00	\N	aal1	\N	\N	node	54.146.45.0	\N	\N	\N	\N	\N
6c182147-24e9-437c-bd10-8c9253ce7389	d997a92e-2df1-4660-b542-91c9968be7d8	2026-06-26 08:05:42.267019+00	2026-06-26 08:05:42.267019+00	\N	aal1	\N	\N	node	18.207.247.6	\N	\N	\N	\N	\N
\.


--
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sso_domains (id, sso_provider_id, domain, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sso_providers (id, resource_id, created_at, updated_at, disabled) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, invited_at, confirmation_token, confirmation_sent_at, recovery_token, recovery_sent_at, email_change_token_new, email_change, email_change_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, is_super_admin, created_at, updated_at, phone, phone_confirmed_at, phone_change, phone_change_token, phone_change_sent_at, email_change_token_current, email_change_confirm_status, banned_until, reauthentication_token, reauthentication_sent_at, is_sso_user, deleted_at, is_anonymous) FROM stdin;
00000000-0000-0000-0000-000000000000	d997a92e-2df1-4660-b542-91c9968be7d8	authenticated	authenticated	admin@urbateam.fr	$2a$10$r3zWXR6GbCS1v.9Sjjn2uuWPNCfl5B8PICJa9Mgc1jXY/WH/LX4iW	2026-06-02 03:08:53.76634+00	\N		\N		\N			\N	2026-06-26 08:05:42.265969+00	{"provider": "email", "providers": ["email"]}	{"email_verified": true}	\N	2026-06-02 03:08:53.740268+00	2026-06-26 08:05:42.299655+00	\N	\N			\N		0	\N		\N	f	\N	f
\.


--
-- Data for Name: webauthn_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.webauthn_challenges (id, user_id, challenge_type, session_data, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: webauthn_credentials; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.webauthn_credentials (id, user_id, credential_id, public_key, attestation_type, aaguid, sign_count, transports, backup_eligible, backed_up, friendly_name, created_at, updated_at, last_used_at) FROM stdin;
\.


--
-- Data for Name: articles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.articles (id, status, sort, slug, title, excerpt, content, featured_image, author, tags, category, date_published, created_at, updated_at) FROM stdin;
1	published	\N	division-parcellaire-valorisez-patrimoine-foncier	Division Parcellaire : Valorisez votre patrimoine foncier avec URBATEAM	Vous possédez un grand terrain et souhaitez en détacher une parcelle à bâtir ? Découvrez comment la division parcellaire peut valoriser votre patrimoine immobilier.	<h2>Optimiser le potentiel de votre terrain : La division foncière</h2><p>Dans un contexte de forte demande immobilière en Bretagne, posséder un grand jardin ou un terrain sous-exploité à <strong>Quimper</strong>, <strong>Lorient</strong> ou <strong>Brest</strong> représente une opportunité financière majeure. La <strong>division parcellaire</strong> (ou détachement de lot à bâtir) est une opération qui permet de créer un ou plusieurs nouveaux terrains constructibles à partir d'une propriété existante. Chez <strong>URBATEAM</strong>, nous accompagnons les particuliers et les professionnels pour transformer ce potentiel en réalité concrète.</p><p><img src="/uploads/blog/division-parcellaire.png" style="max-width:100%; height:auto; margin: 1.5rem 0; border-radius: 12px; display: block; box-shadow: 0 4px 12px rgba(0,0,0,0.1);" alt="Division parcellaire URBATEAM Bretagne"></p><h2>Pourquoi diviser son terrain ? Les avantages d'une stratégie foncière intelligente</h2><p>Vendre une partie de sa propriété peut répondre à plusieurs objectifs :</p><ul><li><strong>Se constituer un capital :</strong> La vente d'un terrain à bâtir permet souvent de financer des travaux de rénovation sur la maison principale ou de réaliser un nouvel investissement.</li><li><strong>Réduire l'entretien :</strong> Un jardin trop vaste devient parfois une charge. Diviser permet de conserver une surface gérable tout en valorisant l'excédent.</li><li><strong>Favoriser la densification urbaine :</strong> En créant de nouveaux logements en centre-ville de <strong>Landerneau</strong> ou <strong>Douarnenez</strong>, vous participez à la lutte contre l'étalement urbain, un enjeu écologique majeur soutenu par les PLU (Plan Local d'Urbanisme).</li></ul><h2>Le rôle crucial du Géomètre-Expert dans votre projet de division</h2><p>La division foncière n'est pas qu'une question de dessin sur un plan. C'est une opération juridique et technique complexe qui nécessite l'intervention exclusive du <strong>Géomètre-Expert</strong>. URBATEAM vous apporte une expertise à chaque étape :</p><ol><li><strong>Étude de faisabilité :</strong> Nous analysons les règles d'urbanisme de votre commune (PLU de <strong>Brest Métropole</strong> ou <strong>Quimper Bretagne Occidentale</strong>) pour vérifier les possibilités de construction (emprise au sol, hauteur, accès).</li><li><strong>Le relevé topographique :</strong> Nous mesurons précisément l'état actuel de votre propriété (limites, bâtiments, réseaux, arbres).</li><li><strong>La conception du projet :</strong> Nous dessinons les nouvelles limites en veillant à la qualité de vie des futurs occupants et à la préservation de la valeur de votre maison actuelle.</li><li><strong>Les démarches administratives :</strong> Nous préparons et déposons pour vous la <strong>Déclaration Préalable</strong> ou le <strong>Permis d'Aménager</strong> en mairie.</li><li><strong>Le bornage :</strong> Nous fixons juridiquement les nouvelles limites et posons les bornes pour garantir la sécurité de la transaction.</li></ol><h2>Éviter les pièges de la division foncière</h2><p>Une division mal préparée peut entraîner des litiges de voisinage ou des refus en mairie. URBATEAM veille sur des points critiques souvent négligés : la gestion des eaux pluviales, la création d'accès sécurisés, ou encore le respect des servitudes (passage, vue). Que vous soyez à <strong>Concarneau</strong>, <strong>Morlaix</strong> ou <strong>Fouesnant</strong>, notre connaissance du tissu local breton est votre meilleur atout pour réussir votre projet.</p><p>Faire appel à URBATEAM, c'est choisir la sérénité pour valoriser votre patrimoine foncier de manière durable et conforme à la loi.</p>	division-parcellaire.png	URBATEAM	["Foncier", "Division", "Expertise", "Urbanisme"]	Actualité	2026-05-15 10:00:00+00	2026-06-02 02:48:26.719751+00	2026-06-02 02:48:26.719751+00
2	published	\N	ingenierie-sportive-haute-precision-performance-athletique	Ingénierie Sportive : Quand la haute précision rencontre la performance athlétique	La conception d'un complexe sportif est un défi de précision millimétrique. Découvrez comment URBATEAM accompagne les collectivités dans la création d'équipements homologués.	<h2>L'expertise invisible derrière le record : L'ingénierie sportive par URBATEAM</h2><p>Le spectateur voit un stade, l'athlète voit une performance, mais pour <strong>URBATEAM</strong>, un complexe sportif est avant tout un chef-d'œuvre de précision technique. Que ce soit pour une piste d'athlétisme à <strong>Brest</strong>, un terrain de football synthétique à <strong>Quimper</strong> ou un complexe multisports à <strong>Concarneau</strong>, l'ingénierie sportive exige une rigueur que seuls quelques bureaux d'études spécialisés maîtrisent en Bretagne.</p><p><img src="/uploads/blog/ingenierie-sportive.png" style="max-width:100%; height:auto; margin: 1.5rem 0; border-radius: 12px; display: block; box-shadow: 0 4px 12px rgba(0,0,0,0.1);" alt="Ingénierie Sportive URBATEAM Bretagne"></p><h2>Le défi des pentes : Le millimètre au service du drainage et de la performance</h2><p>Le secret d'un bon terrain de sport, qu'il soit en gazon naturel ou synthétique, réside dans sa capacité à gérer les eaux météoriques. Pour qu'un match puisse se jouer sous une pluie battante à <strong>Morlaix</strong> ou <strong>Landerneau</strong>, la conception du drainage et des pentes doit être d'une précision chirurgicale.</p><p>Chez <strong>URBATEAM</strong>, nous ne nous contentons pas d'appliquer des pentes standards. Nous calculons des modèles de ruissellement complexes :</p><ul><li><strong>Précision Laser :</strong> Nous utilisons des stations totales robotisées pour garantir que les pentes de 0,5% à 1% sont respectées au millimètre près sur toute la surface du terrain.</li><li><strong>Drainage de pointe :</strong> Nous concevons des réseaux de drainage en "arête de poisson" ou en nappes drainantes, dimensionnés selon la pluviométrie spécifique du <strong>Finistère</strong>.</li><li><strong>Zéro stagnation :</strong> L'objectif est d'évacuer l'eau instantanément pour préserver la structure du sol et la sécurité des appuis des sportifs.</li></ul><p>Sur une piste d'athlétisme, comme celles que l'on peut trouver à <strong>Douarnenez</strong> ou <strong>Fouesnant</strong>, la tolérance est quasi nulle. Un faux-plat trop prononcé ou une stagnation d'eau, et la piste n'est plus homologuée par la Fédération Française d'Athlétisme (FFA) pour les records officiels. Notre rôle de <strong>Géomètre-Expert</strong> et d'Ingénieur VRD est de garantir cette conformité absolue par un contrôle rigoureux durant toute la phase de chantier.</p><h2>Une maîtrise complète du cycle de vie des équipements sportifs</h2><p>Notre accompagnement pour les collectivités du <strong>Pays de Brest</strong> et de <strong>Cornouaille</strong> va bien au-delà du simple tracé :</p><ul><li><strong>Études de faisabilité technique :</strong> Nous analysons la nature des sols et les contraintes topographiques pour optimiser les terrassements.</li><li><strong>Conception VRD Durable :</strong> Nous intégrons des solutions de récupération des eaux de pluie pour l'arrosage des terrains, réduisant ainsi l'empreinte écologique des installations.</li><li><strong>Maîtrise d'œuvre experte :</strong> Nous supervisons les entreprises spécialisées lors de la pose des revêtements techniques (enrobés poreux, résines athlétiques, gazons hybrides).</li><li><strong>Dossiers d'Homologation :</strong> URBATEAM prépare les plans de récolement et les certificats de pentes nécessaires pour obtenir les labels fédéraux indispensables aux compétitions régionales et nationales.</li></ul><h2>URBATEAM : Le partenaire technique des collectivités bretonnes</h2><p>L'aménagement d'un complexe sportif est un investissement majeur et structurant pour une ville. En choisissant l'expertise d'<strong>URBATEAM</strong>, les mairies et intercommunalités s'assurent d'un équipement qui durera dans le temps, avec des coûts de maintenance maîtrisés. Un terrain parfaitement nivelé et drainé, c'est l'assurance d'une pratique sportive sécurisée et de haute performance pour tous les clubs locaux.</p><p>Parce que chaque millimètre compte dans la quête de l'excellence, URBATEAM met son expertise de pointe au service du rayonnement sportif de notre territoire.</p>	ingenierie-sportive.png	URBATEAM	["Sport", "Ingénierie", "Précision", "VRD"]	Actualité	2026-04-20 10:00:00+00	2026-06-02 02:48:26.719751+00	2026-06-02 02:48:26.719751+00
3	published	\N	scanner-3d-jumeau-numerique-innovation-connaissance-batiment	Scanner 3D et Jumeau Numérique : Comment l'innovation transforme la connaissance du bâtiment	Découvrez comment URBATEAM utilise la lasergrammétrie pour transformer des structures physiques complexes en jumeaux numériques intelligents. Plongez dans l'univers du nuage de points et du Scan-to-BIM.	<h2>L'ère du jumeau numérique : Au-delà du simple plan 2D</h2><p>Dans un monde où la précision et la donnée sont devenues les clés de voûte de tout projet d'aménagement réussi, le <strong>Scanner 3D laser</strong> s'impose comme une révolution technologique majeure. Chez <strong>URBATEAM</strong>, nous ne nous contentons plus de dessiner des plans ; nous créons des <strong>jumeaux numériques</strong>, véritables doubles virtuels de vos bâtiments, capables de porter une intelligence technique sans précédent.</p><p><img src="/uploads/blog/scanner-3d-innovation.png" style="max-width:100%; height:auto; margin: 1.5rem 0; border-radius: 12px; display: block; box-shadow: 0 4px 12px rgba(0,0,0,0.1);" alt="Innovation Scanner 3D URBATEAM"></p><h2>Qu'est-ce qu'un nuage de points ? La capture millimétrique du réel</h2><p>Le point de départ de toute numérisation est le <strong>nuage de points</strong>. Imaginez des millions de points (souvent plusieurs centaines de millions pour un seul bâtiment) capturés en quelques minutes par un laser tournant à haute vitesse. Chaque point possède ses propres coordonnées X, Y, Z dans l'espace, ainsi qu'une information de couleur ou d'intensité.</p><p>Le résultat ? Une "photographie 3D" ultra-précise où chaque élément est mesurable au millimètre près. Cette base de données brute est l'archive la plus fidèle qui puisse exister d'un état des lieux à un instant T. Finies les omissions de relevés sur le terrain ou les cotes oubliées : tout est là, dans le nuage.</p><h2>Du nuage de points au modèle BIM : Le Scan-to-BIM</h2><p>Le nuage de points n'est que la matière première. La véritable valeur ajoutée d'URBATEAM réside dans sa capacité à transformer ces données brutes en une <strong>maquette numérique intelligente</strong> (BIM - Building Information Modeling). C'est ce qu'on appelle le processus <strong>Scan-to-BIM</strong>.</p><p>Contrairement à un dessin classique, chaque élément de la maquette (mur, fenêtre, poutre, réseau) possède des propriétés sémantiques. On ne dessine pas simplement un rectangle, on définit une paroi avec sa composition, sa résistance thermique ou son historique de maintenance. Le jumeau numérique devient alors un outil d'aide à la décision tout au long de la vie du bâtiment.</p><h2>Pourquoi investir dans un relevé 3D haute définition ?</h2><ul><li><strong>Précision absolue :</strong> Sécurisez vos études architecturales en travaillant sur une base dont la marge d'erreur est inférieure à 5mm.</li><li><strong>Gain de temps majeur :</strong> Un seul passage sur site suffit pour capturer l'intégralité des détails complexes (moulures, réseaux apparents, déformations de charpente).</li><li><strong>Anticipation des conflits :</strong> En phase de rénovation, le modèle 3D permet de détecter les collisions entre les réseaux existants et les nouveaux projets avant même le premier coup de pioche.</li><li><strong>Support de communication puissant :</strong> Visualisez vos projets de manière immersive et facilitez l'adhésion des parties prenantes (mairies, riverains, investisseurs).</li></ul><h2>L'innovation au service du patrimoine et de l'aménagement</h2><p>Que ce soit pour la réhabilitation d'un bâtiment historique en centre-ville de Brest ou pour la mise en copropriété d'un ensemble immobilier complexe à Douarnenez, le scanner 3D est votre meilleur allié. Chez URBATEAM, nous investissons continuellement dans les dernières technologies (Scanners Leica, Faro, Drones RTK) pour vous offrir une vision claire, précise et durable de vos actifs immobiliers.</p><p>Le jumeau numérique n'est plus une option futuriste, c'est aujourd'hui le standard de l'aménagement responsable et intelligent.</p>	scanner-3d-innovation.png	URBATEAM	["Innovation", "Scanner 3D", "Jumeau Numérique", "BIM"]	Actualité	2026-03-15 09:00:00+00	2026-06-02 02:48:26.719751+00	2026-06-02 02:48:26.719751+00
4	published	\N	le-bornage-de-propriete-pourquoi-est-ce-une-etape-cruciale	Le Bornage de Propriété : Pourquoi est-ce une étape cruciale pour votre terrain ?	Définir les limites exactes de son terrain est bien plus qu'une simple formalité. Découvrez les enjeux juridiques et techniques du bornage pour sécuriser votre patrimoine.	<h2>Le bornage : Bien plus qu'une simple pose de bornes</h2><p>Trop souvent confondu avec une simple clôture, le <strong>bornage</strong> est l'unique opération permettant de fixer juridiquement et de manière définitive la limite séparative entre deux propriétés privées contigües. C'est une mission fondamentale et exclusive du <strong>Géomètre-Expert</strong>, qui agit ici en tant que tiers de confiance pour garantir l'équité entre les voisins.</p><p><img src="/uploads/blog/bornage.jpg" style="max-width:100%; height:auto; margin: 1.5rem 0; border-radius: 12px; display: block; box-shadow: 0 4px 12px rgba(0,0,0,0.1);" alt="Bornage de propriété"></p><h2>Pourquoi le bornage est-il indispensable ?</h2><p>Que vous soyez sur le point de vendre, d'acheter ou de construire, le bornage répond à plusieurs impératifs majeurs :</p><ul><li><strong>La protection juridique :</strong> Seul le bornage garantit que votre voisin n'empiète pas sur votre terrain (et inversement). Un plan de cadastre, bien qu'utile, n'a qu'une valeur fiscale et ne définit pas précisément les limites de propriété.</li><li><strong>La sécurité des constructions :</strong> Avant d'ériger une clôture, un mur de soutènement ou une extension, connaître sa limite au centimètre près évite des litiges coûteux et des obligations de démolition.</li><li><strong>La valorisation du patrimoine :</strong> Un terrain borné offre une transparence totale lors d'une transaction immobilière, rassurant ainsi l'acquéreur et le notaire sur la consistance exacte du bien vendu.</li></ul><h2>Le déroulement d'une mission de bornage chez URBATEAM</h2><p>Notre cabinet suit une méthodologie rigoureuse pour assurer un résultat incontestable :</p><ol><li><strong>L'analyse documentaire :</strong> Nous étudions les titres de propriété, les plans de division anciens et les archives disponibles (notaires, cadastre).</li><li><strong>Le relevé sur le terrain :</strong> Nous mesurons l'état des lieux actuel, en relevant les clôtures, murs et fossés existants.</li><li><strong>La réunion de bornage :</strong> Nous convoquons tous les riverains pour une réunion contradictoire où nous exposons nos conclusions.</li><li><strong>Le Procès-Verbal (PV) :</strong> Une fois l'accord trouvé, nous rédigeons un PV de bornage et de reconnaissance de limites qui, une fois signé par tous, devient définitif et opposable à tous.</li></ol><h2>Et en cas de désaccord ?</h2><p>Si un voisin refuse de signer ou conteste la limite, on passe du bornage <em>amiable</em> au bornage <em>judiciaire</em>. Dans ce cas, le tribunal nomme un Géomètre-Expert en tant qu'expert judiciaire pour trancher le litige sur la base d'éléments techniques et juridiques. Chez URBATEAM, nous privilégions toujours la médiation pour parvenir à une solution pérenne et pacifiée.</p>	bornage.jpg	URBATEAM	["Bornage", "Foncier", "Expertise"]	Actualité	2026-02-05 14:00:00+00	2026-06-02 02:48:26.719751+00	2026-06-02 02:48:26.719751+00
5	published	\N	le-scanner-3d-la-revolution-numerique-pour-la-copropriete	Le Scanner 3D : La révolution numérique au service de la Copropriété	La technologie laser 3D transforme radicalement la gestion et la connaissance des bâtiments. Découvrez comment elle optimise la mise en copropriété et les projets de rénovation.	<h2>De la mesure traditionnelle au jumeau numérique</h2><p>Longtemps, le relevé de bâtiment s'est limité au mètre ruban ou au télémètre laser point par point. Aujourd'hui, <strong>URBATEAM</strong> déploie la technologie du <strong>Scanner 3D</strong> (lasergrammétrie) pour capturer la réalité avec une exhaustivité et une précision inégalées.</p><p><img src="/uploads/blog/scanner-3d.jpg" style="max-width:100%; height:auto; margin: 1.5rem 0; border-radius: 12px; display: block; box-shadow: 0 4px 12px rgba(0,0,0,0.1);" alt="Scanner 3D et Copropriété"></p><h2>Le nuage de points : Une archive vivante de votre immeuble</h2><p>Le scanner projette des millions de points laser par seconde pour créer un <strong>nuage de points</strong>. Cette copie numérique exacte de l'immeuble permet de :</p><ul><li><strong>Générer des plans 2D parfaits :</strong> Coupes, façades, plans d'étages et surfaces Carrez sont produits avec une marge d'erreur quasi nulle.</li><li><strong>Modéliser en 3D (BIM) :</strong> Nous créons des maquettes numériques qui servent de base de travail collaborative pour les architectes, les bureaux d'études et les syndics.</li><li><strong>Détecter les pathologies :</strong> Le relevé haute résolution permet d'identifier des fissures, des déformations de charpente ou des problèmes de verticalité invisibles à l'œil nu.</li></ul><h2>Un atout majeur pour la mise en copropriété</h2><p>Lors de la création ou de la modification d'une copropriété, la définition des tantièmes et des parties privatives/communes est cruciale. Le relevé 3D garantit :</p><ul><li>Une <strong>équité totale</strong> entre les copropriétaires grâce à des mesures de surfaces incontestables.</li><li>Une <strong>gestion simplifiée</strong> des futurs travaux : grâce à la maquette 3D, le syndic peut simuler l'impact d'une isolation par l'extérieur ou d'un remplacement de toiture.</li><li>Une <strong>valorisation du patrimoine</strong> : disposer d'un carnet de santé numérique complet est un argument fort lors de la vente de lots.</li></ul><p>En choisissant URBATEAM pour vos relevés 3D, vous investissez dans la connaissance durable de votre bâtiment, réduisant ainsi les risques d'erreurs lors des phases de conception et de travaux.</p>	scanner-3d.jpg	URBATEAM	["Scanner 3D", "Copropriété", "Innovation"]	Actualité	2026-01-06 09:00:00+00	2026-06-02 02:48:26.719751+00	2026-06-02 02:48:26.719751+00
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.clients (id, status, sort, name, logo, tags, created_at, in_carousel) FROM stdin;
1	published	0	Brest Metropole Oceane	bmo.webp	["Collectivite"]	2026-06-02 02:48:27.347707+00	t
2	published	1	Maisons Le Masson	\N	["Entreprise"]	2026-06-22 15:27:01.289155+00	t
4	published	2	Groupe François Léon	\N	["Entreprise"]	2026-06-22 15:30:01.860142+00	f
5	published	3	Barraine Immo	\N	["Entreprise"]	2026-06-22 15:30:23.483446+00	f
6	published	4	Trecobat	\N	["Entreprise"]	2026-06-22 15:30:41.662053+00	f
7	published	5	Brest Métropole Aménagement	\N	["Collectivite"]	2026-06-22 15:30:52.617282+00	f
8	published	6	Aménatys	\N	["Aménageur"]	2026-06-22 15:31:06.445325+00	f
9	published	7	Cap Architecture	\N	["Architecte"]	2026-06-22 15:33:46.11854+00	f
10	published	8	Aiguillon Construction	\N	["Entreprise"]	2026-06-22 15:36:24.721786+00	f
11	published	9	Angevin Personnic	\N	["Entreprise"]	2026-06-22 15:37:00.863606+00	f
12	published	10	Maisons de l'Avenir	\N	["Entreprise"]	2026-06-22 15:37:34.973995+00	f
13	published	11	123 Web Immo	\N	["Entreprise"]	2026-06-22 15:38:10.467286+00	f
14	published	12	Mairie de Saint-Renan	\N	["Collectivite"]	2026-06-22 15:38:42.616989+00	f
15	published	13	Floch Réalisations	\N	["Entreprise"]	2026-06-22 15:39:17.092498+00	f
16	published	14	Human Immobilier	\N	["Entreprise"]	2026-06-22 15:39:30.213187+00	f
17	published	15	Bouygues Bâtiment Grand Ouest	\N	["Entreprise"]	2026-06-22 15:40:32.445327+00	f
18	published	16	Les Constructions Renanaises	\N	["Entreprise"]	2026-06-22 15:41:30.69552+00	f
19	published	17	Maisons Georges Menez	\N	["Entreprise"]	2026-06-22 15:41:46.782168+00	f
20	published	18	Perco Constructions	\N	["Entreprise"]	2026-06-22 15:42:14.854823+00	f
21	published	19	Brest Métropole Habitat	\N	["Collectivite"]	2026-06-22 15:42:45.984396+00	f
22	published	20	Primo Construction	\N	["Entreprise"]	2026-06-22 15:43:08.199956+00	f
23	published	21	Département du Finistère	\N	["Collectivite"]	2026-06-22 15:43:44.556276+00	f
24	published	22	CCPI	\N	["Collectivite"]	2026-06-22 15:44:15.594962+00	f
25	published	23	CCPA	\N	["Collectivite"]	2026-06-22 15:44:18.209536+00	f
26	published	24	DDTM	\N	["Collectivite"]	2026-06-22 15:45:15.26307+00	f
27	published	25	Conservatoire du Littoral	\N	["Collectivite"]	2026-06-22 15:45:42.351991+00	f
28	published	26	Douarnenez Habitat	\N	["Collectivite"]	2026-06-22 15:46:00.05309+00	f
29	published	27	Douarnenez Communauté	\N	["Collectivite"]	2026-06-22 15:46:23.892106+00	f
30	published	28	Etablissement Public Foncier de Bretagne	\N	["Collectivite"]	2026-06-22 15:47:19.677515+00	f
\.


--
-- Data for Name: faq; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.faq (id, status, sort, question_fr, answer_fr, question_en, answer_en, question_br, answer_br, category, created_at) FROM stdin;
1	published	0	Le bornage est-il obligatoire ?	Le bornage n'est pas systématiquement obligatoire, mais il devient indispensable dès que vous souhaitez garantir les limites de votre propriété ou si vous envisagez une vente. Que votre terrain soit situé à Saint-Renan, Brest ou Douarnenez, c'est le seul acte qui définit juridiquement votre limite de propriété de manière définitive.	What is contradictory boundary marking and is it mandatory?	Boundary marking allows for the legal and definitive fixing of your land's property lines. In France (Article 646 of the Civil Code), any owner can compel their neighbor to boundary marking. This is also legally mandatory in the case of land division for building (subdivision). Only a Chartered Land Surveyor registered with the Order is authorized to carry it out and place official markers.	Petra eo ar bonnañ ha ret eo ober anezhañ ?	Ar bonnañ a sikour da lakaat un harz ofisiel etre ho touar hag hini hoc'h amezeien (Kod sivil gall Art. 646). Ret eo d'ober pa vez krouet ur lodenn douar nevez da sevel un ti. Un Douaroner-Barnour nemetken a c'hell ober an dra-se.	\N	2026-06-02 02:48:27.661696+00
2	published	1	Quelle est la différence entre un plan topographique et un plan de bornage ?	Un plan topographique est un relevé précis de l'existant (relief, murs, arbres, voirie). Il est indispensable pour l'architecte ou le maître d'œuvre, mais n'a aucune valeur juridique concernant la limite de propriété. Le plan de bornage, en revanche, détermine la limite juridique foncière garantie après analyse des actes notariés et accord contradictoire des voisins.	What is the difference between a topographic plan and a boundary plan?	A topographic plan is a precise survey of the existing situation (relief, walls, trees, roads). It is essential for the architect or project manager but has no legal value concerning the property line. The boundary plan, however, determines the guaranteed legal land boundary after analysis of notarized deeds and contradictory agreement from neighbors.	Petra eo ar cheñchamant etre un tres topografek hag un tres bonnañ ?	Un tres topografek a ziskouez an douar evel m'emañ (mogerioù, gwez, h.a...). N'en deus ket talvoudegezh lezennel evit an harzoù. Un tres bonnañ a laka an harz ofisiel gant asant an amezeien.	\N	2026-06-02 02:48:27.661696+00
3	published	2	Puis-je diviser mon terrain situé dans mon jardin pour le vendre ?	Oui, mais cette opération (détachement de parcelle) nécessite de s'assurer que le projet est conforme au PLU/PLUi (Plan Local d'Urbanisme). Le Géomètre-Expert vérifie la constructibilité, réalise le plan de division, borne la nouvelle limite créée et constitue le dossier d'urbanisme obligatoire (Déclaration Préalable de division) en Mairie.	Can I divide my garden land to sell it?	Yes, but this operation (parcel detachment) requires ensuring the project complies with the local urban plan (PLU/PLUi). The Land Surveyor verifies buildability, creates the division plan, marks the new created boundary and constitutes the mandatory urban planning file (Preliminary Declaration of division) at the City Hall.	Gallout a ran rannañ ma liorzh evit gwerzhañ un lodenn ?	Ya, met ret eo gwelet ma 'z eo a-du gant reolennoù an ti-kêr (PLU). An Douaroner a sikour ac'hanoc'h gant an deuliad melestradurel (DP).	\N	2026-06-02 02:48:27.661696+00
4	published	3	Le plan cadastral fait-il foi pour connaître la limite de mon terrain ?	Non. Contrairement aux idées reçues, le <a class="wiki-link" href="/lexique?search=Cadastre">cadastre</a> est un document à vocation purement fiscale (pour le calcul des impôts fonciers) et n'a aucune valeur probante de propriété foncière. En cas de litige, seul un Procès-Verbal de <a class="wiki-link" href="/lexique?search=Bornage">bornage</a> rédigé par un Géomètre-Expert fait foi.	Is the cadastral plan proof of my land's boundary?	No. Contrary to popular belief, the <a class="wiki-link" href="/lexique?search=Cadastre">cadastre</a> is a document with a purely fiscal vocation (for calculating property taxes) and has no probative value of land ownership. In case of dispute, only a <a class="wiki-link" href="/lexique?search=Boundary">boundary marking</a> minutes drafted by a Chartered Surveyor is authentic.	Ha talvoudegezh ofisiel en deus ar c'hadastr evit an harzoù ?	Nann. Ar c'hadastr a zo un teuliad evit an tailhoù (impôts). N'eo ket evit lakaat an harz ofisiel. Ar PV bonnañ nemetken a dalvez evit an harzoù.	\N	2026-06-02 02:48:27.661696+00
5	published	4	Comment faire corriger une erreur sur le plan cadastral ?	Si le cadastre public indique une limite erronée, vous devez solliciter un Géomètre-Expert. Après avoir effectué la recherche d'anciens actes et le relevé sur le terrain, notre équipe rédigera un plan de délimitation amiable et mettra à jour la documentation cadastrale (<a class="wiki-link" href="/lexique?search=DMPC">DMPC</a>) transmise aux impôts.	How can I correct an error on the cadastral plan?	If the public cadastre indicates an incorrect boundary, you must request a Chartered Surveyor. After researching old deeds and surveying the land, our team will draft an amicable delimitation plan and update the cadastral documentation (<a class="wiki-link" href="/lexique?search=DMPC">DMPC</a>) sent to the tax authorities.	Penaos reizhañ ur vioù er c'hadastr ?	Ret eo goulenn gant un Douaroner-Barnour evit sevel un tres bonnañ hag un teuliad DMPC evit kemmañ ar c'hadastr ofisiel.	\N	2026-06-02 02:48:27.661696+00
6	published	5	Qui paie les frais de bornage ?	Selon l'Article 646 du Code civil, les frais de bornage se font à frais communs entre les deux propriétaires voisins, bien que la répartition puisse être négociée différemment lors de la conciliation amiable.	Who pays for boundary marking costs?	According to Article 646 of the Civil Code, boundary marking costs are shared between the two neighboring owners, although the distribution can be negotiated differently during amicable conciliation.	Piv a bae evit ar bonnañ ?	Hervez an Art. 646 eus ar C'hod Sivil, ar mizioù a vez rannet etre an daou amezeg, met gallout a reer kemmañ an dra-se ma 'z int a-du.	\N	2026-06-02 02:48:27.661696+00
7	published	6	Pourquoi faire appel à un Géomètre-Expert pour une mise en copropriété ?	Le Géomètre-Expert est le seul professionnel qualifié pour garantir la précision des plans d'intérieurs et le calcul des millièmes (tantièmes) de copropriété. Son intervention sécurise juridiquement l'acte de vente et prévient les litiges futurs entre copropriétaires sur la répartition des charges.	Why hire a Chartered Surveyor for a co-ownership setup?	The Chartered Surveyor is the only qualified professional to guarantee the accuracy of interior plans and the calculation of co-ownership shares (tantièmes). Their intervention legally secures the sale deed and prevents future disputes between co-owners regarding charge distribution.			\N	2026-06-02 02:48:27.661696+00
8	published	7	Qu'est-ce qu'un modificatif de règlement de copropriété ?	Il s'agit d'une mise à jour du règlement suite à un changement dans l'immeuble (division d'un lot, changement d'usage, annexion de parties communes). Le Géomètre-Expert réalise les nouveaux plans et calcule la nouvelle répartition des tantièmes pour publication au fichier immobilier.	What is a co-ownership regulation amendment?	It is an update to the regulations following a change in the building (lot division, change of use, annexation of common areas). The Surveyor creates new plans and calculates the new share distribution for publication in the real estate file.			\N	2026-06-02 02:48:27.661696+00
9	published	8	Qu'est-ce qu'un relevé par Scanner Laser 3D ?	C'est une technologie qui permet de capturer des millions de points en quelques secondes pour créer une 'image 3D' millimétrée de l'existant. Cela permet de relever des structures complexes (monuments, usines, charpentes) avec une exhaustivité impossible à atteindre avec des méthodes classiques.	What is 3D Laser Scanning?	It is a technology that captures millions of points in seconds to create a millimeter-accurate '3D image' of the existing structure. This allows for surveying complex structures (monuments, factories, frameworks) with an exhaustiveness impossible to achieve with traditional methods.			\N	2026-06-02 02:48:27.661696+00
10	published	9	Comment utilisez-vous les drones dans vos missions ?	Le drone nous permet de réaliser des orthophotographies haute résolution et des modèles numériques de terrain (MNT) sur de grandes surfaces ou des zones d'accès difficile. C'est un outil précieux pour le suivi de chantier, le <a class="wiki-link" href="/lexique?search=Cubature">calcul de cubatures</a> (volumes de terre) et l'inspection d'ouvrages.	How do you use drones in your missions?	The drone allows us to produce high-resolution orthophotographs and digital terrain models (DTM) over large surfaces or difficult access areas. It is a valuable tool for site monitoring, <a class="wiki-link" href="/lexique?search=Cubature">cubature calculations</a> (earth volumes), and structure inspections.			\N	2026-06-02 02:48:27.661696+00
11	published	10	Quelle est la durée de validité d'un bornage ?	Un bornage contradictoire signé et archivé est définitif et immuable. Il 'suit le terrain' : même si les propriétaires changent, la limite fixée reste la même pour les générations futures. C'est la garantie de sérénité la plus forte pour votre patrimoine foncier.	How long is a boundary marking valid?	A signed and archived contradictory boundary marking is definitive and immutable. It 'follows the land': even if owners change, the set boundary remains the same for future generations. It is the strongest guarantee of peace of mind for your land heritage.			\N	2026-06-02 02:48:27.661696+00
12	published	11	Quels sont les documents nécessaires pour déposer un permis d'aménager ?	Le dossier type comprend un <a class="wiki-link" href="/lexique?search=Situation">plan de situation</a>, un plan de l'état initial du terrain, un plan de composition d'ensemble, ainsi qu'une <a class="wiki-link" href="/lexique?search=Notice">notice descriptive</a> expliquant l'insertion du projet dans son environnement. URBATEAM se charge de la constitution complète de ce dossier technique et administratif.	What documents are required to apply for a development permit?	The typical file includes a <a class="wiki-link" href="/lexique?search=Location">location plan</a>, a plan of the initial state of the land, a general composition plan, as well as a <a class="wiki-link" href="/lexique?search=Descriptive">descriptive notice</a> explaining the project's insertion into its environment. URBATEAM takes care of the complete technical and administrative constitution of this file.			\N	2026-06-02 02:48:27.661696+00
13	published	12	Qu'est-ce qu'une servitude et comment la vérifier ?	Une servitude est une contrainte imposée à un terrain (fonds servant) au profit d'un autre (fonds dominant), comme un <a class="wiki-link" href="/lexique?search=Passage">droit de passage</a> ou le passage de réseaux (<a class="wiki-link" href="/lexique?search=Tréfonds">servitude de tréfonds</a>). Elles sont mentionnées dans votre titre de propriété. Le Géomètre-Expert peut les identifier précisément sur le terrain et vérifier leur conformité.	What is an easement and how can it be verified?	An easement is a constraint imposed on land (servient estate) for the benefit of another (dominant estate), such as a <a class="wiki-link" href="/lexique?search=Passage">right of way</a> or the passage of networks (<a class="wiki-link" href="/lexique?search=Underground">underground easement</a>). They are mentioned in your property title. The Chartered Surveyor can identify them precisely on the ground and verify their compliance.			\N	2026-06-02 02:48:27.661696+00
14	published	13	Intervenez-vous pour la création de terrains de sport ?	Oui, URBATEAM possède une expertise spécifique en ingénierie sportive. Nous concevons des complexes sportifs (stades, pistes d'athlétisme, terrains synthétiques) en respectant les normes fédérales et les exigences de drainage et de nivellement de haute précision.	Do you intervene for the creation of sports fields?	Yes, URBATEAM has specific expertise in sports engineering. We design sports complexes (stadiums, athletics tracks, synthetic fields) respecting federal standards and high-precision drainage and leveling requirements.			\N	2026-06-02 02:48:27.661696+00
15	published	14	Comment sont calculés les honoraires d'un Géomètre-Expert ?	Chaque dossier est unique. Nos honoraires dépendent de la complexité technique de la mission, du temps de recherche en archives, du nombre de voisins à convoquer pour un bornage, et de la superficie du terrain. Nous fournissons systématiquement un devis détaillé et gratuit avant toute intervention.	How are a Land Surveyor's fees calculated?	Each case is unique. Our fees depend on the technical complexity of the mission, search time in archives, the number of neighbors to be summoned for boundary marking, and the land area. We systematically provide a free, detailed quote before any intervention.			\N	2026-06-02 02:48:27.661696+00
16	published	15	Quelle est la différence entre un bornage amiable et un bornage judiciaire ?	Le bornage amiable est le fruit d'un accord entre voisins avec l'aide d'un Géomètre-Expert. Si un accord est impossible, le juge peut ordonner un bornage judiciaire. Dans ce cas, un Géomètre-Expert est désigné comme expert judiciaire pour proposer une limite que le juge validera par un jugement.	What is the difference between amicable and judicial boundary marking?	Amicable boundary marking results from an agreement between neighbors with the help of a Land Surveyor. If agreement is impossible, a judge can order judicial boundary marking. In this case, a Land Surveyor is appointed as a judicial expert to propose a boundary that the judge will validate by a ruling.			\N	2026-06-02 02:48:27.661696+00
17	published	16	Pourquoi faire réaliser son mesurage Loi Carrez par un Géomètre-Expert ?	Bien que non obligatoire, l'intervention d'un Géomètre-Expert offre une garantie de responsabilité civile professionnelle. En cas d'erreur de mesure supérieure à 5%, l'acquéreur peut demander une baisse de prix. Notre précision et notre expertise juridique sécurisent votre transaction immobilière.	Why have a Land Surveyor perform your Carrez Law measurement?	While not mandatory, a Land Surveyor's intervention offers a professional civil liability guarantee. In case of a measurement error greater than 5%, the buyer can request a price reduction. Our precision and legal expertise secure your real estate transaction.			\N	2026-06-02 02:48:27.661696+00
18	published	17	Quelle est la différence entre une copropriété et une division en volumes ?	La copropriété s'applique généralement aux bâtiments simples avec des parties communes partagées. La division en volumes est utilisée pour des ensembles immobiliers complexes (ex: commerces au rez-de-chaussée et habitations au-dessus) afin de dissocier juridiquement des éléments sans parties communes, souvent gérés par une AFUL ou une ASL.	What is the difference between co-ownership and volume division?	Co-ownership usually applies to simple buildings with shared common areas. Volume division is used for complex real estate complexes (e.g., shops on the ground floor and housing above) to legally dissociate elements without common areas, often managed by a homeowner association (AFUL or ASL).			\N	2026-06-02 02:48:27.661696+00
19	published	18	Qu'est-ce que le processus Scan-to-BIM ?	C'est la transformation d'un nuage de points issu d'un scanner 3D en une maquette numérique intelligente (BIM). Cette maquette contient non seulement la géométrie du bâtiment, mais aussi des données sur les matériaux, les réseaux et les équipements, facilitant la gestion ultérieure du bâti.	What is the Scan-to-BIM process?	It is the transformation of a point cloud from a 3D scanner into an intelligent digital model (BIM). This model contains not only the building's geometry but also data on materials, networks, and equipment, facilitating subsequent building management.			\N	2026-06-02 02:48:27.661696+00
20	published	19	Proposez-vous des prestations d'auscultation d'ouvrages ?	Oui, nous réalisons des mesures de haute précision pour surveiller la stabilité de bâtiments, de ponts ou de soutènements via l'<a class="wiki-link" href="/lexique?search=Auscultation">auscultation d'ouvrages</a>. Grâce à des capteurs et des relevés périodiques, nous détectons les moindres mouvements ou tassements millimétriques pour garantir la sécurité des infrastructures.	Do you offer structural monitoring services?	Yes, we perform high-precision measurements to monitor the stability of buildings, bridges, or retaining walls via <a class="wiki-link" href="/lexique?search=Monitoring">structural monitoring</a>. Using sensors and periodic surveys, we detect the slightest movements or millimeter settlements to guarantee infrastructure security.			\N	2026-06-02 02:48:27.661696+00
21	published	20	Réalisez-vous des plans d'intérieurs et des coupes de bâtiments existants ?	Absolument. Nous intervenons pour relever des immeubles complets afin de produire des <a class="wiki-link" href="/lexique?search=Intérieurs">plans d'intérieurs</a>, des <a class="wiki-link" href="/lexique?search=Coupe">coupes</a> transversales et des plans de façades. Ces documents sont indispensables pour les architectes dans le cadre de projets de rénovation ou de réhabilitation.	Do you produce interior plans and sections of existing buildings?	Absolutely. We intervene to survey entire buildings to produce <a class="wiki-link" href="/lexique?search=Interior">interior plans</a>, transversal <a class="wiki-link" href="/lexique?search=Section">sections</a>, and facade plans. These documents are essential for architects in renovation or rehabilitation projects.			\N	2026-06-02 02:48:27.661696+00
22	published	21	Comment savoir si un Géomètre-Expert est déjà intervenu sur mon terrain ?	Toutes les interventions foncières des Géomètres-Experts sont enregistrées sur le portail GéoFoncier. Nous pouvons consulter cet historique pour retrouver d'anciens procès-verbaux de bornage ou des plans de division, ce qui permet de sécuriser votre projet en vous appuyant sur des données certifiées.	How can I know if a Land Surveyor has already intervened on my land?	All land interventions by Chartered Surveyors are recorded on the GéoFoncier portal. We can consult this history to find old boundary marking minutes or division plans, securing your project by relying on certified data.			\N	2026-06-02 02:48:27.661696+00
23	published	22	Comment se déroule une division parcellaire ?	La division consiste à détacher une ou plusieurs parcelles d'un terrain d'origine. URBATEAM vous accompagne de l'étude de faisabilité à la déclaration préalable en mairie (comme à Plouzané ou Landerneau), jusqu'au document d'arpentage et au bornage des nouveaux lots.	How does a land division work?	Division involves detaching one or more parcels from an original plot. URBATEAM supports you from the feasibility study to the preliminary declaration at the town hall (as in Plouzané or Landerneau), up to the surveying document and the boundary marking of new lots.			\N	2026-06-02 02:48:27.661696+00
24	published	23	Quelle est la garantie offerte par un Géomètre-Expert ?	Le Géomètre-Expert est un professionnel libéral dont le titre est protégé. Nous avons une obligation d'assurance et de formation continue. En cas d'erreur dans nos missions de bornage ou de conception, notre responsabilité civile professionnelle vous protège, offrant une sécurité bien supérieure à celle d'un simple prestataire non régulé.	What is the guarantee offered by a Chartered Surveyor?	The Chartered Surveyor is a professional whose title is protected by law. We have a professional indemnity insurance and continuous training obligations. In case of errors in our boundary or design missions, our civil liability protects you, offering security far superior to that of a simple unregulated service provider.			\N	2026-06-02 02:48:27.661696+00
\.


--
-- Data for Name: glossaire; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.glossaire (id, status, sort, term_fr, definition_fr, term_en, definition_en, term_br, definition_br, related_expertise, created_at) FROM stdin;
1	published	0	Bornage Contradictoire	Opération consistant à définir juridiquement et à matérialiser sur le terrain (au moyen de bornes) les limites physiques séparant des propriétés privées contiguës.	Contradictory Boundary Marking	Operation consisting of legally defining and materializing on the ground (using boundary markers) the physical limits separating contiguous private properties.	Bonnañ (Bornage)	Lakaat harzoù ofisiel gant bonnoù etre div dachenn douar.	\N	2026-06-02 02:48:27.983417+00
2	published	1	Cadastre	Ensemble de documents dressant l'état de la propriété foncière à des fins essentiellement fiscales. Le cadastre ne garantit pas la limite de propriété juridique exacte.	Cadastre	Set of documents establishing the state of land ownership for essentially fiscal purposes. The cadastre does not guarantee the exact legal property boundary.	Cadastre	Teuliad evit an tailhoù douar, n'eo ket un teuliad perc'henniezh ofisiel evit an harzoù.	\N	2026-06-02 02:48:27.983417+00
3	published	2	DMPC (Document d'Arpentage)	Document de Modification du Parcellaire Cadastral. Il est obligatoirement dressé par un Géomètre-Expert pour mettre à jour le plan cadastral suite à un changement de limites.	DMPC (Surveying Document)	Document for Modification of the Cadastral Parcel. It must be prepared by a Land Surveyor to update the cadastral map following a change in boundaries.	DMPC	Teuliad ofisiel evit cheñch ar c'hadastr pa vez rannet un douar.	\N	2026-06-02 02:48:27.983417+00
4	published	3	Détachement de parcelle	Action foncière visant à diviser une unité foncière en plusieurs entités distinctes, très souvent en vue de créer un nouveau terrain à bâtir.	Parcel detachment	Land action aimed at dividing a land unit into several distinct entities, very often with a view to creating a new building lot.	Lodennañ (Division)	Rannañ un douar e meur a lodenn nevez.	\N	2026-06-02 02:48:27.983417+00
5	published	4	PLU / PLUi	Plan Local d'Urbanisme (Intercommunal). Document de planification qui fixe les règles générales d'utilisation des sols sur le territoire d'une ou plusieurs communes.	PLU / PLUi	Local Urban Planning Map (Inter-municipal). Planning document that sets the general rules for land use in the territory of one or more municipalities.	PLU / PLUi	Reolennoù an ti-kêr evit implijout an douaroù (lakaat e tres pelec'h e c'heller sevel tiez).	\N	2026-06-02 02:48:27.983417+00
6	published	5	Servitude	Charge pesant sur une propriété foncière au bénéfice d'une autre propriété foncière (droit de passage, réseaux...).	Easement	Charge weighing on a land property for the benefit of another land property (right of way, networks...).	Sklent (Servitude)	Ur gwir o tremen war un douar evit un douar all (hent tremen, rouedadoù...).	\N	2026-06-02 02:48:27.983417+00
7	published	6	VRD (Voirie et Réseaux Divers)	Ensemble des ouvrages et des aménagements d'infrastructures permettant de viabiliser un terrain (routes, évacuation des eaux, électricité...).	VRD (Roads and Utilities)	Set of works and infrastructure developments for site servicing (roads, water evacuation, electricity, etc.).	VRD	Al labourioù evit an hentoù hag ar rouedadoù (dour, tredan, h.a...).	\N	2026-06-02 02:48:27.983417+00
8	published	7	ZAC (Zone d'Aménagement Concerté)	Opération d'urbanisme publique d'envergure par laquelle une collectivité aménage des terrains pour les céder à des constructeurs.	ZAC (Concerted Development Zone)	Large-scale public urban planning operation by which a local authority develops land to sell it to builders.	ZAC	Ur raktres aozañ bras renet gant ur strollad publik.	\N	2026-06-02 02:48:27.983417+00
9	published	8	Loi Carrez / Loi Boutin	Mesurage de la superficie privative (Carrez) pour la vente ou habitable (Boutin) pour la location.	Carrez / Boutin Laws	Measurement of private area (Carrez) for sale or habitable area (Boutin) for rental.	Lezenn Carrez	Muzuliañ gorread un ti ofisiel evit ur gwerzh pe ur feurm.	\N	2026-06-02 02:48:27.983417+00
10	published	9	HQE (Haute Qualité Environnementale)	Démarche d'aménagement visant à maîtriser les impacts environnementaux d'une opération urbaine ou immobilière.	HQE (High Environmental Quality)	Development approach aiming to master the environmental impacts of an urban or real estate operation.	HQE	Kalite uhel evit an natur en ur raktres sevel.	\N	2026-06-02 02:48:27.983417+00
11	published	10	Maîtrise d'œuvre (MOE)	Personne ou entité chargée par le maître d'ouvrage de concevoir, d'étudier et de diriger l'exécution des travaux.	Project Management (MOE)	Person or entity appointed by the project owner to design, study and direct the execution of works.	Mestroniezh-ober (MOE)	An hini a rener al labourioù hag a sevel an tresoù teknikel.	\N	2026-06-02 02:48:27.983417+00
12	published	11	Ordre des Géomètres-Experts (OGE)	L'institution nationale qui garantit la compétence, l'indépendance et la déontologie du Géomètre-Expert.	Order of Chartered Surveyors (OGE)	The national institution that guarantees the competence, independence and ethics of the Land Surveyor.	OGE	Urzh an Douaronerien-Varnourien a warant kalite an douaroner.	\N	2026-06-02 02:48:27.983417+00
13	published	12	AFUL (Association Foncière Urbaine Libre)	Groupement de propriétaires fonciers permettant la gestion commune d'ouvrages ou la réalisation de travaux de restructuration urbaine.	AFUL (Urban Land Association)	A group of landowners allowing for the joint management of works or the completion of urban restructuring projects.			\N	2026-06-02 02:48:27.983417+00
14	published	13	Alignement individuel	Acte par lequel l'administration fixe la limite de la voie publique au droit d'une propriété riveraine.	Individual Alignment	An act by which the administration sets the boundary of the public highway along a riparian property.			\N	2026-06-02 02:48:27.983417+00
15	published	14	ASL (Association Syndicale Libre)	Structure juridique regroupant des propriétaires au sein d'un lotissement ou d'une copropriété horizontale pour gérer les espaces et équipements communs.	ASL (Free Syndicate Association)	A legal structure grouping owners within a subdivision or horizontal co-ownership to manage common spaces and equipment.			\N	2026-06-02 02:48:27.983417+00
16	published	15	BIM (Building Information Modeling)	Maquette numérique intelligente regroupant l'ensemble des données techniques d'un bâtiment tout au long de son cycle de vie.	BIM (Building Information Modeling)	Intelligent digital model grouping all the technical data of a building throughout its life cycle.			\N	2026-06-02 02:48:27.983417+00
17	published	16	Bornage judiciaire	Procédure engagée devant le tribunal lorsque les propriétaires ne parviennent pas à un accord amiable sur la limite de leurs terrains.	Judicial Boundary Marking	A procedure initiated before the court when owners fail to reach an amicable agreement on the boundary of their land.			\N	2026-06-02 02:48:27.983417+00
18	published	17	Certificat d'Urbanisme (CU)	Document informant sur les règles d'urbanisme applicables à un terrain et sur la faisabilité d'un projet précis.	Planning Certificate (CU)	A document providing information on the urban planning rules applicable to a land and the feasibility of a specific project.			\N	2026-06-02 02:48:27.983417+00
19	published	18	Copropriété horizontale	Forme de copropriété s'appliquant à des maisons individuelles bâties sur un terrain commun, par opposition à la copropriété verticale (immeubles).	Horizontal Co-ownership	A form of co-ownership applying to detached houses built on common land, as opposed to vertical co-ownership (buildings).			\N	2026-06-02 02:48:27.983417+00
20	published	19	Cubature	Calcul du volume de matériaux (terre, gravats) à déplacer lors de travaux de terrassement, réalisé à partir de levés topographiques précis.	Earthwork Volume (Cubature)	Calculation of the volume of materials (soil, rubble) to be moved during earthworks, based on precise topographic surveys.			\N	2026-06-02 02:48:27.983417+00
21	published	20	Déclaration Préalable (DP)	Autorisation d'urbanisme obligatoire pour des travaux de faible importance ou des divisions de terrains sans création d'espaces communs.	Prior Declaration (DP)	A mandatory urban planning authorization for minor works or land divisions without the creation of common spaces.			\N	2026-06-02 02:48:27.983417+00
22	published	21	Division en volumes	Technique juridique complexe permettant de découper un ensemble immobilier en lots de propriété sans aucune partie commune.	Volume Division	A complex legal technique allowing for the splitting of a real estate complex into ownership lots without any common areas.			\N	2026-06-02 02:48:27.983417+00
23	published	22	Emprise au sol	Projection verticale au sol du volume de la construction, incluant les débords et surplombs.	Footprint (Emprise au sol)	The vertical projection on the ground of the building's volume, including overhangs and projections.			\N	2026-06-02 02:48:27.983417+00
24	published	23	GéoFoncier	Portail officiel de l'Ordre des Géomètres-Experts centralisant l'ensemble des interventions foncières réalisées sur le territoire.	GéoFoncier	The official portal of the Order of Chartered Surveyors centralizing all land interventions carried out in the territory.			\N	2026-06-02 02:48:27.983417+00
25	published	24	Implantation	Opération consistant à matérialiser sur le terrain la position exacte d'une future construction selon les plans de l'architecte.	Layout / Staking (Implantation)	The operation of materializing on the ground the exact position of a future construction according to the architect's plans.			\N	2026-06-02 02:48:27.983417+00
26	published	25	MNT (Modèle Numérique de Terrain)	Représentation 3D de la surface du sol permettant de réaliser des études hydrauliques, de visibilité ou des calculs de volumes.	DTM (Digital Terrain Model)	A 3D representation of the ground surface allowing for hydraulic, visibility studies, or volume calculations.			\N	2026-06-02 02:48:27.983417+00
27	published	26	Nivellement	Mesure des altitudes de différents points du sol par rapport à un système de référence (souvent le NGF - Nivellement Général de la France).	Leveling (Nivellement)	Measurement of the altitudes of different points on the ground relative to a reference system (often NGF in France).			\N	2026-06-02 02:48:27.983417+00
28	published	27	Nuage de points	Ensemble de millions de coordonnées 3D capturées par un scanner laser, formant une image numérique fidèle de l'existant.	Point Cloud	Set of millions of 3D coordinates captured by a laser scanner, forming a faithful digital image of the existing condition.			\N	2026-06-02 02:48:27.983417+00
29	published	28	Orthophotographie	Image aérienne rectifiée géométriquement pour obtenir une échelle uniforme, combinant la richesse d'une photo et la précision d'un plan.	Orthophotograph	An aerial image geometrically rectified to obtain a uniform scale, combining the richness of a photo and the precision of a plan.			\N	2026-06-02 02:48:27.983417+00
30	published	29	Plan de masse	Plan présentant le projet de construction dans sa totalité, indiquant l'emprise au sol, les accès et les raccordements aux réseaux.	Site Plan (Plan de masse)	A plan showing the entire construction project, indicating the footprint, access, and network connections.			\N	2026-06-02 02:48:27.983417+00
31	published	30	Récolement	Levé topographique réalisé après travaux pour vérifier la conformité des ouvrages (réseaux, voirie) par rapport au projet initial.	As-built Survey (Récolement)	A topographic survey carried out after works to verify the compliance of structures (networks, roads) with the initial project.			\N	2026-06-02 02:48:27.983417+00
32	published	31	Tantièmes / Millièmes	Quote-part de propriété des parties communes attribuée à chaque lot de copropriété, servant de base au calcul des charges.	Shares (Tantièmes / Millièmes)	Ownership share of the common areas attributed to each co-ownership lot, used as the basis for calculating charges.			\N	2026-06-02 02:48:27.983417+00
33	published	32	Aménagement foncier	Ensemble des opérations visant à améliorer la structure des exploitations agricoles ou le développement des territoires ruraux.	Land Consolidation	A set of operations aimed at improving the structure of agricultural holdings or the development of rural territories.			\N	2026-06-02 02:48:27.983417+00
34	published	33	Arpentage	Technique historique de mesure de la superficie des terres, aujourd'hui intégrée aux missions globales du Géomètre-Expert.	Land Surveying (Arpentage)	Historical technique for measuring land area, today integrated into the global missions of the Chartered Surveyor.			\N	2026-06-02 02:48:27.983417+00
35	published	34	Canevas	Réseau de points de référence aux coordonnées connues, servant d'ossature pour l'ensemble des levés topographiques d'un projet.	Survey Control Network (Canevas)	A network of reference points with known coordinates, serving as the backbone for all topographic surveys of a project.			\N	2026-06-02 02:48:27.983417+00
36	published	35	Coefficient d'Emprise au Sol (CES)	Rapport permettant de mesurer la surface maximale qu'une construction peut occuper sur un terrain.	Footprint Coefficient (CES)	A ratio used to measure the maximum surface area a building can occupy on a land.			\N	2026-06-02 02:48:27.983417+00
37	published	36	Condition suspensive	Clause d'un contrat (ex: vente de terrain) dont dépend l'exécution de l'acte, comme l'obtention d'un permis d'aménager.	Condition Precedent	A clause in a contract (e.g., land sale) on which the execution of the act depends, such as obtaining a development permit.			\N	2026-06-02 02:48:27.983417+00
38	published	37	Droit de passage	Type de servitude permettant à un propriétaire dont le terrain est enclavé de traverser la propriété de son voisin pour accéder à la voie publique.	Right of Way	A type of easement allowing a owner whose land is landlocked to cross their neighbor's property to access the public highway.			\N	2026-06-02 02:48:27.983417+00
39	published	38	Expropriation	Procédure permettant à une personne publique d'acquérir une propriété privée pour cause d'utilité publique, souvent avec l'expertise du géomètre pour l'évaluation.	Expropriation	A procedure allowing a public entity to acquire private property for public utility purposes, often involving surveyor expertise for valuation.			\N	2026-06-02 02:48:27.983417+00
40	published	39	Géodésie	Science qui étudie la forme de la Terre et permet de définir les systèmes de coordonnées utilisés par les GPS et les outils de mesure.	Geodesy	The science that studies the Earth's shape and allows for the definition of coordinate systems used by GPS and measuring tools.			\N	2026-06-02 02:48:27.983417+00
41	published	40	Géoréférencement	Opération consistant à attribuer des coordonnées géographiques précises (X, Y, Z) à un objet ou à un plan dans un système de référence national.	Georeferencing	The operation of assigning precise geographical coordinates (X, Y, Z) to an object or plan in a national reference system.			\N	2026-06-02 02:48:27.983417+00
42	published	41	Lot	Unité foncière issue d'une division (lotissement) ou unité de propriété dans un immeuble en copropriété.	Lot	A land unit resulting from a division (subdivision) or an ownership unit in a co-ownership building.			\N	2026-06-02 02:48:27.983417+00
43	published	42	NGF (Nivellement Général de la France)	Système de référence altimétrique officiel permettant d'exprimer les altitudes par rapport au niveau moyen de la mer.	NGF (General Leveling of France)	The official altimetric reference system used to express altitudes relative to mean sea level.			\N	2026-06-02 02:48:27.983417+00
44	published	43	Parcelle	Unité de base du plan cadastral, identifiée par une section et un numéro, représentant une étendue de terrain d'un seul tenant.	Parcel	The basic unit of the cadastral plan, identified by a section and number, representing a continuous stretch of land.			\N	2026-06-02 02:48:27.983417+00
45	published	44	Plan de bornage	Document graphique dressé par le Géomètre-Expert à l'issue d'une mission de bornage, identifiant les limites et les points de repère (bornes).	Boundary Plan	A graphic document drawn up by the Chartered Surveyor following a boundary marking mission, identifying boundaries and reference points (markers).			\N	2026-06-02 02:48:27.983417+00
46	published	45	Procès-Verbal (PV) de Bornage	Acte juridique signé par les propriétaires voisins qui consacre leur accord définitif sur la limite de leurs propriétés.	Boundary Marking Minutes (PV)	A legal act signed by neighboring owners that formalizes their final agreement on the boundary of their properties.			\N	2026-06-02 02:48:27.983417+00
47	published	46	Référentiel Lambert 93	Système de projection officiel utilisé en France métropolitaine pour l'ensemble des cartes et des levés topographiques.	Lambert 93 Reference	The official projection system used in metropolitan France for all maps and topographic surveys.			\N	2026-06-02 02:48:27.983417+00
48	published	47	Station totale	Instrument de mesure combinant un théodolite électronique et un télémètre laser pour mesurer des angles et des distances avec une extrême précision.	Total Station	A measuring instrument combining an electronic theodolite and a laser rangefinder to measure angles and distances with extreme precision.			\N	2026-06-02 02:48:27.983417+00
49	published	48	Talutage	Action de donner une pente inclinée (talus) aux terres lors d'un terrassement pour assurer la stabilité du terrain.	Batters / Sloping (Talutage)	The action of giving an inclined slope (batter) to soil during earthworks to ensure land stability.			\N	2026-06-02 02:48:27.983417+00
50	published	49	Topométrie	Art de la mesure des dimensions de la Terre sur une zone limitée, permettant la réalisation de plans à grande échelle.	Topometry	The art of measuring dimensions of the Earth on a limited area, allowing the creation of large-scale plans.			\N	2026-06-02 02:48:27.983417+00
51	published	50	Permis d'aménager	Autorisation d'urbanisme permettant à l'administration de contrôler les aménagements affectant l'utilisation du sol (lotissement, camping, etc.).	Development Permit	Urban planning authorization allowing the administration to control developments affecting land use (housing estates, camping, etc.).			\N	2026-06-02 02:48:27.983417+00
52	published	51	Notice descriptive	Document technique détaillant les caractéristiques d'un projet d'aménagement et son insertion dans le paysage.	Descriptive Notice	Technical document detailing the characteristics of a development project and its integration into the landscape.			\N	2026-06-02 02:48:27.983417+00
53	published	52	Calcul de cubatures	Évaluation précise des volumes de terrassement (déblais et remblais) à partir de levés topographiques comparatifs.	Cubature Calculation	Precise evaluation of earthwork volumes (excavation and embankment) based on comparative topographic surveys.			\N	2026-06-02 02:48:27.983417+00
54	published	53	Auscultation d'ouvrages	Mesures de précision répétées dans le temps pour surveiller la stabilité et les éventuelles déformations d'un bâtiment ou d'une infrastructure.	Structural Monitoring	Repeated precision measurements over time to monitor the stability and any potential deformations of a building or infrastructure.			\N	2026-06-02 02:48:27.983417+00
55	published	54	Plans d'intérieurs	Représentation graphique détaillée de chaque niveau d'un bâtiment, incluant les murs, cloisons, ouvertures et équipements.	Interior Plans	Detailed graphic representation of each level of a building, including walls, partitions, openings, and equipment.			\N	2026-06-02 02:48:27.983417+00
56	published	55	Coupe de bâtiment	Représentation d'une section verticale d'un édifice permettant d'en comprendre les hauteurs et la structure interne.	Building Section	Representation of a vertical section of a building to understand its heights and internal structure.			\N	2026-06-02 02:48:27.983417+00
57	published	56	Mitoyenneté	Droit de propriété partagé sur une clôture, un mur ou une haie séparant deux propriétés contiguës.	Joint Ownership	Shared property right on a fence, wall, or hedge separating two contiguous properties.			\N	2026-06-02 02:48:27.983417+00
58	published	57	Servitude de tréfonds	Droit permettant le passage de canalisations ou de réseaux souterrains sous la propriété d'autrui.	Underground Easement	Right allowing the passage of pipes or underground networks beneath another person's property.			\N	2026-06-02 02:48:27.983417+00
59	published	58	Lotissement	Division d'une unité foncière en plusieurs lots destinés à être bâtis, impliquant souvent la création d'espaces communs.	Housing Estate	Division of a land unit into several lots intended for building, often involving the creation of common spaces.			\N	2026-06-02 02:48:27.983417+00
60	published	59	Altidimétrie	Partie de la topographie traitant de la mesure des altitudes et de la représentation du relief.	Altimetry	Part of topography dealing with the measurement of altitudes and the representation of relief.			\N	2026-06-02 02:48:27.983417+00
61	published	60	Planimétrie	Représentation sur un plan horizontal des détails naturels et artificiels de la surface de la Terre, sans tenir compte du relief.	Planimetry	Representation on a horizontal plane of natural and artificial details of the Earth's surface, without regard to relief.			\N	2026-06-02 02:48:27.983417+00
62	published	61	Théodolite	Instrument de précision utilisé par le géomètre pour mesurer les angles horizontaux et verticaux.	Theodolite	Precision instrument used by the surveyor to measure horizontal and vertical angles.			\N	2026-06-02 02:48:27.983417+00
63	published	62	Règlement de copropriété	Document contractuel qui définit les règles de fonctionnement d'un immeuble et les droits et devoirs des copropriétaires.	Co-ownership Regulations	Contractual document defining the operating rules of a building and the rights and duties of co-owners.			\N	2026-06-02 02:48:27.983417+00
64	published	63	Plan de situation	Plan permettant de localiser précisément un terrain dans sa commune et son environnement global.	Location Plan	Plan used to precisely locate a piece of land within its municipality and its global environment.			\N	2026-06-02 02:48:27.983417+00
65	published	64	Droit de surplomb	Droit de faire passer une isolation thermique par l'extérieur au-dessus de la propriété voisine, sous certaines conditions légales.	Overhang Right	Right to pass external thermal insulation over the neighbor's property, under certain legal conditions.			\N	2026-06-02 02:48:27.983417+00
\.


--
-- Data for Name: partenaires; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.partenaires (id, status, sort, name, logo, role, website, created_at) FROM stdin;
\.


--
-- Data for Name: projets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.projets (id, status, sort, slug, title, description, location, category, client, missions, technical_details, image_before, image_after, images_gallery, latitude, longitude, date, created_at, updated_at) FROM stdin;
1	published	\N	eco-quartier-de-la-vallee	Éco-quartier de la Vallée	Création d'un nouveau quartier résidentiel durable privilégiant les mobilités douces et la gestion alternative des eaux pluviales. Le projet intègre 45 logements dans un cadre paysager préservé.	Saint-Renan (29)	urbanisme	Ville de Saint-Renan	["Maîtrise d'œuvre urbaine", "Conception paysagère", "VRD"]	45 lots, 3 hectares, 1.5km de pistes cyclables	vallee-before.webp	vallee-after.webp	[]	\N	\N	2026-05-01 02:22:44+00	2026-06-02 02:48:27.050417+00	2026-06-02 02:48:27.050417+00
\.


--
-- Data for Name: simulations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.simulations (id, created_at, address, parcel_ref, total_surface, lot_a_surface, lot_b_surface, client_name, client_email, client_phone, client_message, status) FROM stdin;
\.


--
-- Data for Name: site_texts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.site_texts (key, fr, en, br, created_at, updated_at) FROM stdin;
stats.creation.number	2007	\N	\N	2026-06-19 14:49:51.628722+00	2026-06-19 14:49:51.564+00
stats.collaborators.number	13	\N	\N	2026-06-22 12:31:52.002819+00	2026-06-22 12:31:51.533+00
stats.collaborators.label	Collaborateurs dédiés	Dedicated collaborators	Kenlabourerien	2026-06-22 12:31:55.477012+00	2026-06-22 12:31:55.405+00
stats.collaborators.desc	Géomètres, urbanistes, paysagiste et ingénieurs pluridisciplinaires.	Pluridisciplinary surveyors, planners and engineers.	Douaronerien, kêraourien ha dornourien liesplegek.	2026-06-22 12:32:09.647158+00	2026-06-22 12:32:09.587+00
hero.title_part1	Concrétisez vos projets d'aménagement	Materialize your development projects	Kasit ho raktresoù d'ober	2026-06-22 12:32:43.665634+00	2026-06-22 12:32:43.431+00
hero.title_part2	dans le Finistère	in Western Brittany	e Breizh-Izel	2026-06-22 12:32:46.612755+00	2026-06-22 12:32:46.556+00
hero.description	URBATEAM est basé à Saint-Renan et Douarnenez. Géomètre-Expert, urbanisme, paysage et VRD : une expertise complète au service de vos projets. 	URBATEAM accompanies you from design to completion. Land Surveying cabinet, urban planners and infrastructure engineering (VRD) based in Saint-Renan (Brest) and Douarnenez.	URBATEAM a ambroug ac'hanoc'h adalek ar meizad betek an ober. Burev Douaronerien-Varnourien, kêraourien ha gwazourien frammoù (VRD) e Lokournan (Brest) ha Douarnenez.	2026-06-22 12:32:50.547019+00	2026-06-22 12:32:50.482+00
stats.projects.desc	De la parcelle individuelle aux opérations d'aménagement d'envergure.	From individual housing to regional eco-neighborhoods.	Adalek an ti hiniennel betek karterioù ekologel.	2026-06-22 12:35:38.77118+00	2026-06-22 12:35:38.284+00
expertise.subtitle	Une approche globale et pluridisciplinaire pour répondre aux enjeux de vos projets fonciers, d'aménagement et de développement territorial.	A comprehensive and multidisciplinary approach to meet the requirements of your urban, land and infrastructure development projects.	Ur sell hollek ha liesplegek evit respont da ezhommoù ho raktresoù kêraozerezh, douar ha frammoù.	2026-06-22 12:37:30.480628+00	2026-06-22 12:37:30.208+00
stats.projects.label	Dossiers traités	Large-scale projects	Raktresoù meur	2026-06-22 12:39:07.587548+00	2026-06-22 12:39:07.498+00
stats.projects.number	500	\N	\N	2026-06-22 12:39:10.089123+00	2026-06-22 12:39:09.858+00
expertise.items.geometre.desc	Missions foncières : bornage, délimitation, division parcellaire, copropriété, division en volumes, permis d'aménager, déclaration préalable	Land studies office: boundary marking, parcel divisions, co-ownerships, amicable property delimitations.	Burev studial douar : bonnañ, rannañ lodennoù, kenperc'henniezh ha lakaat harzoù d'an douaroù.	2026-06-22 12:41:21.183948+00	2026-06-22 12:41:39.237+00
expertise.items.geometre.longDesc	Seul professionnel habilité à définir et garantir les limites de propriété, le Géomètre-Expert est le garant de la sécurité juridique du foncier. Il sécurise les biens et accompagne tous les projets fonciers, immobiliers et d’aménagement. Il intervient sur toutes les problématiques liées au droit du sol, du <a class="wiki-link" href="/lexique?search=Bornage">bornage</a> à la gestion des <a class="wiki-link" href="/lexique?search=Servitude">servitudes</a>.	As the only professional authorized to set property boundaries, the URBATEAM Chartered Surveyor guarantees the legal security of your assets. We intervene on all land-related issues, from <a class="wiki-link" href="/lexique?search=Boundary">boundary marking</a> to <a class="wiki-link" href="/lexique?search=Easement">easement</a> management.	An Douaroner-Barnour eo an den nemetañ a c'hell lakaat harzoù ofisiel d'ho touar, gwarantiñ a ra URBATEAM surentez ho madoù. Labourat a reomp war holl gudennoù gwir an douar, adalek ar <a class="wiki-link" href="/lexique?search=Bornage">bonnañ</a> betek ar <a class="wiki-link" href="/lexique?search=Servitude">sklentoù</a>.	2026-06-22 12:48:00.361324+00	2026-06-22 12:47:59.873+00
expertise.items.topographie.desc	Opérations topographiques : plans topographiques de précision, relevés de terrain et d'architecture, implantations de bâtiments.	Topographic studies office: precision topographic plans, land and architectural surveys, site layouts.	Burev studial topografiezh : tresoù topografek resis, kempenn an douar hag ar savouriezh.	2026-06-22 12:49:02.596019+00	2026-06-22 12:49:02.343+00
expertise.items.topographie.longDesc	La précision est au cœur de notre métier. Grâce à des outils de haute technologie, nous capturons l'existant avec une fidélité absolue pour servir de base à vos projets.	Precision is at the heart of our business. Using high-tech tools (<a class="wiki-link" href="/lexique?search=Scanner">3D Scanner</a>, <a class="wiki-link" href="/lexique?search=Drone">Drone</a>, GPS), we capture existing conditions with absolute fidelity to serve as a basis for your projects.	Ar resisted eo hor micher. A-drugarez d'hon dafar teknologel (<a class="wiki-link" href="/lexique?search=Scanner">Scanner 3D</a>, <a class="wiki-link" href="/lexique?search=Drone">Dron</a>, GPS), lakaat a reomp e tres pep tra gant ur resisted a-feson evit sikour ho raktresoù.	2026-06-22 12:49:27.270097+00	2026-06-22 12:49:26.968+00
expertise.items.copropriete.longDesc	Grâce au relevé scanner laser 3D, URBATEAM intervient sur l’ensemble des missions de copropriété et de division en volumes : état descriptif de division, règlement de copropriété et organisation juridique des ensembles immobiliers. 	URBATEAM excels in capturing and modeling existing structures. We transform your physical buildings into intelligent digital twins (<a class="wiki-link" href="/lexique?search=BIM">BIM</a>), centralizing all technical data.	URBATEAM a oar ober e-barzh lakaat ha meizañ ar savadurioù. Cheñch a reomp ho savadurioù da gevelled niverel speredek (<a class="wiki-link" href="/lexique?search=BIM">BIM</a>).	2026-06-22 12:53:34.379748+00	2026-06-22 12:53:34.114+00
expertise.items.copropriete.desc	Relevés par scanner 3D, mise en copropriété, division en volumes, état descriptif de division et règlement de copropriété.	Expertise in building surveys, co-ownership setup, and BIM modeling for intelligent building management.	Varregezh war muzuliañ savadurioù, lakaat e kenperc'henniezh ha diskouez e 3D.	2026-06-22 12:52:33.126463+00	2026-06-22 12:53:36.992+00
references.subtitle	Collectivités, promoteurs et donneurs d'ordres institutionnels nous confient leurs projets d'aménagement.	Local authorities, developers and institutional clients entrust us with their development projects.	Strolladoù tiriadel, saverien ha mestrourien a fiz o raktresoù aozañ ennomp.	2026-06-22 12:58:18.513323+00	2026-06-22 12:58:18.296+00
about.header.subtitle	Votre cabinet de référence pour l’aménagement et le développement des territoires dans le Finistère.	Your privileged partner for land planning in Western Brittany.	Ho kenoberour pennañ evit aozañ an diriadoù e Breizh-Izel.	2026-06-22 13:00:08.651162+00	2026-06-22 13:00:08.386+00
about.society.title	Notre Cabinet	Our Company	Hor Sosiete	2026-06-22 13:00:18.214448+00	2026-06-22 13:00:18.121+00
about.society.p1	Depuis plus de 40 ans, URBATEAM accompagne les collectivités, les professionnels et les particuliers dans leurs projets fonciers et d’aménagement du territoire.	URBATEAM accompanies you throughout your development projects in Western Brittany through our two local offices located in Saint-Renan (near Brest) and Douarnenez.	URBATEAM a ambroug ac'hanoc'h e-pad ho raktresoù aozañ e Breizh-Izel a-drugarez d'hon div ajañs e Lokournan (kostez Brest) ha Douarnenez.	2026-06-22 13:01:53.11387+00	2026-06-22 13:01:52.868+00
expertise.items.vrd.desc	Bureau d'études en voirie, réseaux divers, assainissement, traitement des eaux pluviales, parkings, giratoires.	Infrastructure studies office: roads, diverse networks, sanitation, rainwater treatment, parking lots, roundabouts.	Burev studial frammoù : hentoù, rouedadoù liesseurt, dour-lous ha dour-glav, parkingoù.	2026-06-22 15:54:59.178234+00	2026-06-22 15:54:58.792+00
expertise.items.urbanisme.desc	ZAC, éco-quartiers, parcs d'activités, entrées de ville, réaménagement urbain, aménagement de quartiers et d'espaces publics, aménagement de rues, conception de lotissements.	Development studies office: ZAC, eco-neighborhoods, city sections, activity parks, town entrances, and urban redevelopment.	Burev studial an aozañ : ZAC, karterioù ekologel, lodennoù kêr, takadoù obererezh ha reneveziñ kêr.	2026-06-22 15:55:42.475973+00	2026-06-22 15:57:25.438+00
expertise.items.urbanisme.longDesc	URBATEAM accompagne les collectivités et les aménageurs privés dans la conception de cadres de vie durables et harmonieux. Notre approche mêle vision stratégique urbaine et sensibilité paysagère pour créer des espaces qui font sens, en intégrant les enjeux du <a class="wiki-link" href="/lexique?search=PLU">PLU</a> et du développement durable.\nNotre savoir-faire permet d’intégrer chaque projet dans son environnement et de créer des lieux de vie qualitatifs, durables et agréables à vivre, adaptés aux enjeux des territoires.	URBATEAM supports local authorities and private developers in the design of sustainable and harmonious living environments. Our approach combines strategic urban vision and landscape sensitivity to create meaningful spaces, integrating <a class="wiki-link" href="/lexique?search=PLU">PLU</a> requirements and sustainable development goals.	URBATEAM a ambroug ar strollegezhioù hag an aozourien prevez evit meizañ karterioù padus ha plijus. Meskañ a reomp strategiezh kêr ha gweledva evit krouiñ takadoù a ra ster, en ur doujañ da ezhommoù ar <a class="wiki-link" href="/lexique?search=PLU">PLU</a> hag an diorren padus.	2026-06-22 15:57:29.819076+00	2026-06-22 15:59:51.293+00
expertise.items.vrd.longDesc	Études techniques, conception de réseaux d’assainissement, d’eau potable et de gestion des eaux pluviales, aménagement de voiries, suivi de travaux…\nNos ingénieurs et techniciens assurent la conception et le pilotage technique des aménagements jusqu’à leur réalisation.	Our engineers and technicians design the essential technical infrastructure for project servicing. We favor innovative solutions for <a class="wiki-link" href="/lexique?search=VRD">roads and utilities</a> and sustainable water management.	Hon dornourien a veiz ar frammoù a zo ezhomm evit ur raktres (dour, hentoù, h.a). Dibab a reomp diskoulmoù nevez evit ar <a class="wiki-link" href="/lexique?search=VRD">rouedadoù</a> ha mestroniañ an dour e mod padus.	2026-06-22 15:55:28.07805+00	2026-06-22 16:01:57.693+00
about.society.p3	Les valeurs qui guident notre action :\n\nL’éthique professionnelle :\nNeutralité, impartialité, transparence et respect du cadre réglementaire guident notre manière d’exercer nos métiers au quotidien.\n\nLe conseil :\nComprendre les besoins, accompagner les décisions et orienter vers les bonnes solutions font partie intégrante de notre métier.\n\nLa précision :\nParce que nos métiers exigent rigueur et fiabilité, nous accordons une attention particulière à la qualité des études, des mesures et des réalisations.\n\nL’esprit d’équipe :\nLa diversité des compétences et le travail collectif sont au cœur du fonctionnement d’Urbateam.	We are committed to mastering, enhancing and guaranteeing the quality of the services offered, while scrupulously respecting the needs of our clients.	Gouestlañ a reomp da vestroniañ ha da warantiñ kalite hor servijoù, en ur doujañ d'an ezhommoù ho peus.	2026-06-22 13:01:55.092152+00	2026-06-22 16:05:11.933+00
about.society.p2	Implantée à Saint-Renan et à Douarnenez, notre équipe pluridisciplinaire réunit des géomètres-experts ainsi que des compétences en urbanisme, paysage et VRD (voiries et réseaux divers), afin de proposer un accompagnement global, de l’étude jusqu’à la réalisation. Notre force : associer l’ensemble de ces compétences pour concevoir des projets cohérents, durables et adaptés aux usages de demain.\nNous nous engageons à maîtriser, valoriser et garantir la qualité des services offerts, tout en respectant scrupuleusement les besoins de nos maîtres d'ouvrage.	Our missions cover the traditional fields of activity of Chartered Land Surveyors (boundary marking, divisions, building land creation, co-ownerships, site layouts, expertise, topography), but also historically urban planning, landscape and infrastructure engineering (VRD).	Hor c'hefridioù a denn da dachennoù boas an Douaronerien-Varnourien (bonnañ, rannañ, sevel lodennoù da sevel tiez, kenperc'henniezh, topografiezh), met ivez da geriaozerezh, gweledva ha dornouriezh frammoù (VRD).	2026-06-22 13:01:50.681847+00	2026-06-22 16:04:47.98+00
technical.sections	[{"id":"infra","title":"Bureaux & Infrastructures","icon":"building","list":["Un bureau à Saint-Renan (29)","Un bureau à Douarnenez (29)"]},{"id":"field","title":"Équipements Terrain","icon":"map-pin","list":["1 scanner Trimble X9","3 stations totales (Trimble S3 et S5)","2 récepteurs GNSS Teria PYX"],"showFieldImages":true},{"id":"software","title":"Environnement Logiciel","icon":"software","desc":"Dessin assisté par ordinateur, conception 3D et modélisation logicielle :","showSoftwareImages":true}]	\N	\N	2026-06-22 16:06:35.030547+00	2026-06-22 16:07:41.417+00
tools.cadastre_map.visible	false	false	false	2026-06-22 16:08:33.551317+00	2026-06-22 16:08:33.295+00
tools.sun_simulator.visible	false	false	false	2026-06-22 16:08:35.310226+00	2026-06-22 16:08:35.226+00
tools.profil_long.visible	false	false	false	2026-06-22 16:08:38.072931+00	2026-06-22 16:08:38.005+00
\.


--
-- Data for Name: social_posts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.social_posts (id, status, sort, url, caption, date, created_at) FROM stdin;
1	published	0	/uploads/social/1777520111868-IMG_0478.jpg	Conseil d'Expert : Division de terrain en zone constructible. Comprendre la différence entre Déclaration Préalable (DP) et Permis d'Aménager (PA) pour sécuriser votre projet foncier.	2026-04-30 03:35:11.871+00	2026-06-02 02:48:29.015882+00
2	published	1	/uploads/social/1777520102568-IMG_0477.jpg	Sur le terrain avec nos partenaires curieux ! 🐮 Relevé topographique de précision en zone rurale. L'expertise foncière au plus près de la nature.	2026-04-30 03:35:02.571+00	2026-06-02 02:48:29.015882+00
3	published	2	/uploads/social/1777520095758-IMG_0476.jpg	Intervention à Douarnenez : relevé de corps de rue et bornage de propriété. URBATEAM se déplace partout en Bretagne-Ouest pour vos projets immobiliers.	2026-04-30 03:34:55.761+00	2026-06-02 02:48:29.015882+00
4	published	3	/uploads/social/1777520090386-IMG_0475.jpg	Vue aérienne d'un lotissement conçu par URBATEAM. Maîtrise d'œuvre urbaine et ingénierie VRD pour des quartiers durables et optimisés.	2026-04-30 03:34:50.391+00	2026-06-02 02:48:29.015882+00
5	published	4	/uploads/social/1777520086084-IMG_0474.jpg	Phase de conception : plan de composition d'un futur éco-quartier. De l'étude de faisabilité à la division parcellaire, nous dessinons demain.	2026-04-30 03:34:46.087+00	2026-06-02 02:48:29.015882+00
6	published	5	/uploads/social/1777520079022-IMG_0472.jpg	Relevé topographique de corps de rue pour un projet d'aménagement urbain. La précision millimétrée au service des collectivités.	2026-04-30 03:34:39.024+00	2026-06-02 02:48:29.015882+00
7	published	6	/uploads/social/1777520072885-IMG_0471.jpg	Litiges de voisinage : que faire en cas d'empiètement ? URBATEAM vous conseille et réalise le bornage contradictoire pour définir vos limites de propriété de manière incontestable.	2026-04-30 03:34:32.888+00	2026-06-02 02:48:29.015882+00
8	published	7	/uploads/social/1777520023211-IMG_0470.jpg	Quand faire appel à un Géomètre-Expert ? Que ce soit pour une mise en copropriété, un bornage, une division de terrain ou une implantation, URBATEAM vous apporte son expertise légale et technique.	2026-04-30 03:33:43.213+00	2026-06-02 02:48:29.015882+00
\.


--
-- Data for Name: team_header; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.team_header (id, title_fr, subtitle_fr, title_en, subtitle_en, title_br, subtitle_br, team_photo, updated_at) FROM stdin;
1	Notre Équipe	Une équipe conviviale, dynamique et pluridisciplinaire d'environ 10 collaborateurs réunissant Géomètres-Experts, urbanistes, ingénieurs et techniciens topographes au service de la réussite de vos projets.	Our Team	A friendly, dynamic and multidisciplinary team of about 10 collaborators bringing together Land Surveyors, urban planners, engineers and surveying technicians at the service of your projects' success.	Hor Skipailh	Ur skipailh plijus, oberiant ha liesplegek gant war-dro 10 kenlabourer (Douaronerien, kêraourien, dornourien) evit sevel ho raktresoù.	\N	2026-06-02 02:48:28.148291+00
\.


--
-- Data for Name: team_members; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.team_members (id, status, sort, slug, image, linkedin, generic, email, phone, name_fr, role_fr, desc_fr, name_en, role_en, desc_en, name_br, role_br, desc_br, created_at) FROM stdin;
1	published	0	frank	/pictures/FrankLeGall.jpg	\N	f	franck.legall@urbateam.fr	02 98 84 29 65	Frank Le Gall	Co-Gérant	Maîtrise d'œuvre, urbanisme & infrastructures.	Frank Le Gall	Co-Manager	Project management, urban planning & infrastructure.	Frank Le Gall	Kenrener	Mestroniezh-ober, kêraaozerezh ha frammoù.	2026-06-02 02:48:28.444603+00
2	published	1	laura	/pictures/LauraCharretteur.jpg	https://www.linkedin.com/in/laura-charretteur/	f	laura.charretteur@urbateam.fr	02 98 84 29 65	Laura Charretteur	Co-Gérante	Problématiques foncières, topographie & direction.	Laura Charretteur	Co-Manager	Land issues, topography & management.	Laura Charretteur	Kenrenerez	Kudennoù douar, topografiezh ha renerezh.	2026-06-02 02:48:28.444603+00
3	published	2	yves	\N	\N	f	yves.jegot@urbateam.fr	06 84 90 62 20	Yves Jégot	Maître d'Œuvre VRD	Expert en conception routière et réseaux divers.	Yves Jégot	Infrastructure Project Manager	Expert in road design and diverse networks.	Yves Jégot	Mestroniezh-ober VRD	Arberigour war an hentoù hag ar roudadoù.	2026-06-02 02:48:28.444603+00
4	published	3	trang	\N	\N	f	trang.stephan@urbateam.fr	06 77 97 93 96	Trang Stephan	Maître d'Œuvre VRD	Spécialiste de la conception technique et suivi d'infrastructures.	Trang Stephan	Infrastructure Project Manager	Specialist in technical design and infrastructure monitoring.	Trang Stephan	Mestroniezh-ober VRD	Ispisialour war ar meizañ teknikel hag an heuliañ frammoù.	2026-06-02 02:48:28.444603+00
5	published	4	camille	\N	\N	f	camille.lormeteau@urbateam.fr	06 78 73 03 26	Camille Lormeteau	Paysagiste-Conceptrice	Conception paysagère et intégration environnementale.	Camille Lormeteau	Landscape Designer	Landscape design and environmental integration.	Camille Lormeteau	Gweledvaourez-Meizerez	Meizañ gweledvaoù hag enframmañ en natur.	2026-06-02 02:48:28.444603+00
6	published	5	urbanistes	\N	\N	t	\N	\N		Urbanistes & Paysagistes	Conception et aménagement des espaces urbains.		Urban Planners & Landscape Architects	Design and development of urban spaces.		Kêraourien & Gweledvaourien	Meizañ hag aozañ an takadoù kêr.	2026-06-02 02:48:28.444603+00
7	published	6	engineers	\N	\N	t	\N	\N		Ingénieurs d'Infrastructures	Conception technique de la voirie et des réseaux.		Infrastructure Engineers	Technical design of roads and networks.		Dornourien Frammoù	Meizañ teknikel an hentoù hag ar rouedadoù.	2026-06-02 02:48:28.444603+00
8	published	7	topographers	\N	\N	t	\N	\N		Techniciens Topographes	Relevés terrains et implantations de grande précision.		Surveying Technicians	High-precision field surveys and layouts.		Teknikourien Topografourien	Lakaat an douar e tresoù resis-kenañ.	2026-06-02 02:48:28.444603+00
9	published	8	drafters	\N	\N	t	\N	\N		Dessinateurs Projeteurs	Modélisation 3D et réalisation des plans d'aménagement.		Draftspeople	3D modeling and production of development plans.		Tresourien-Raktresourien	Sevel tresoù 3D hag aozañ an tresoù kêr.	2026-06-02 02:48:28.444603+00
10	published	9	lawyers	\N	\N	t	\N	\N		Experts Juristes	Accompagnement juridique sur le droit foncier et la copropriété.		Legal Experts	Legal support on land law and co-ownership.		Varnourien-Gwir	Sikour war gwir an douar hag ar c'henperc'henniezh.	2026-06-02 02:48:28.444603+00
11	published	10	assistants	\N	\N	t	\N	\N		Assistantes de Direction	Gestion administrative, financière et relation clientèle.		Executive Assistants	Administrative, financial management and client relations.		Sikourezed Renerezh	Melestradurezh, arc'hant ha darempred gant an aratourien.	2026-06-02 02:48:28.444603+00
\.


--
-- Data for Name: visits; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.visits (id, path, is_article, device, browser, created_at) FROM stdin;
1	/	f	Desktop	Chrome	2026-06-02 03:35:51.917866+00
2	/projets	f	Desktop	Chrome	2026-06-02 03:35:55.227405+00
3	/projets/eco-quartier-de-la-vallee	f	Desktop	Chrome	2026-06-02 03:36:01.29981+00
4	/	f	Desktop	Chrome	2026-06-02 03:38:34.184994+00
5	/blog	f	Desktop	Chrome	2026-06-02 03:39:11.619317+00
6	/	f	Desktop	Chrome	2026-06-02 03:39:28.782839+00
7	/	f	Desktop	Chrome	2026-06-02 13:12:19.041539+00
8	/profil-long	f	Desktop	Chrome	2026-06-02 13:12:21.304584+00
9	/carte-cadastre	f	Desktop	Chrome	2026-06-02 13:12:25.415241+00
10	/simulateur-ensoleillement	f	Desktop	Chrome	2026-06-02 13:12:27.261651+00
11	/simulateur-division	f	Desktop	Chrome	2026-06-02 13:12:30.300416+00
12	/apropos	f	Mobile	Chrome	2026-06-02 13:12:57.093684+00
13	/	f	Mobile	Chrome	2026-06-02 13:13:09.553923+00
14	/	f	Mobile	Safari	2026-06-02 13:14:09.53819+00
15	/	f	Desktop	Chrome	2026-06-02 13:14:33.670324+00
16	/	f	Desktop	Chrome	2026-06-02 13:49:40.677812+00
17	/	f	Mobile	Safari	2026-06-02 14:13:33.242901+00
18	/	f	Mobile	Safari	2026-06-02 14:33:39.455612+00
19	/	f	Mobile	Safari	2026-06-02 14:34:06.1411+00
20	/	f	Mobile	Safari	2026-06-02 15:00:00.052426+00
21	/	f	Mobile	Safari	2026-06-02 15:13:24.568269+00
22	/	f	Desktop	Chrome	2026-06-02 15:28:18.962774+00
23	/	f	Desktop	Chrome	2026-06-02 15:32:33.967568+00
24	/expertise/topographie	f	Desktop	Chrome	2026-06-02 15:33:11.133327+00
25	/	f	Desktop	Chrome	2026-06-02 15:33:20.138712+00
26	/lexique	f	Desktop	Chrome	2026-06-02 15:33:29.150423+00
27	/apropos	f	Desktop	Chrome	2026-06-02 15:34:09.329376+00
28	/simulateur-ensoleillement	f	Desktop	Chrome	2026-06-02 15:34:23.926297+00
29	/eco-diagnostic	f	Desktop	Chrome	2026-06-02 15:36:30.398928+00
30	/simulateur-division	f	Desktop	Chrome	2026-06-02 15:36:37.566901+00
31	/mon-projet	f	Desktop	Chrome	2026-06-02 15:37:44.796493+00
32	/moyens-techniques	f	Desktop	Chrome	2026-06-02 15:37:54.163155+00
33	/projets	f	Desktop	Chrome	2026-06-02 15:38:49.624662+00
34	/apropos	f	Desktop	Chrome	2026-06-02 15:39:03.622375+00
35	/faq	f	Desktop	Chrome	2026-06-02 15:39:18.429439+00
36	/nous-suivre	f	Desktop	Chrome	2026-06-02 15:39:23.272329+00
37	/profil-long	f	Desktop	Chrome	2026-06-02 15:39:29.859657+00
38	/mon-projet	f	Desktop	Chrome	2026-06-02 15:40:55.248846+00
39	/blog	f	Desktop	Chrome	2026-06-02 15:41:00.959216+00
40	/	f	Desktop	Chrome	2026-06-02 15:42:49.222646+00
41	/vieprivee	f	Desktop	Chrome	2026-06-02 15:44:57.568807+00
42	/	f	Desktop	Chrome	2026-06-02 15:45:00.547678+00
43	/apropos	f	Desktop	Chrome	2026-06-02 15:45:37.610596+00
44	/nous-suivre	f	Desktop	Chrome	2026-06-02 15:46:01.693236+00
45	/	f	Desktop	Chrome	2026-06-02 15:48:45.776893+00
46	/expertise/urbanisme	f	Desktop	Chrome	2026-06-02 15:49:17.939106+00
47	/apropos	f	Desktop	Chrome	2026-06-02 15:49:33.608714+00
48	/	f	Desktop	Chrome	2026-06-02 15:51:00.401091+00
49	/apropos	f	Desktop	Chrome	2026-06-02 15:51:05.676833+00
50	/	f	Desktop	Chrome	2026-06-02 15:51:07.981665+00
51	/blog	f	Desktop	Chrome	2026-06-02 15:51:23.496041+00
52	/	f	Desktop	Chrome	2026-06-02 15:51:32.170912+00
53	/blog	f	Desktop	Chrome	2026-06-02 15:51:39.717667+00
54	/	f	Desktop	Chrome	2026-06-02 15:51:53.411896+00
55	/nous-suivre	f	Desktop	Chrome	2026-06-02 15:53:49.057503+00
56	/vieprivee	f	Desktop	Chrome	2026-06-02 15:54:04.304552+00
57	/mentions-legales	f	Desktop	Chrome	2026-06-02 15:57:23.517368+00
58	/vieprivee	f	Desktop	Chrome	2026-06-02 15:57:28.09618+00
59	/mentions-legales	f	Desktop	Chrome	2026-06-02 15:57:35.824101+00
60	/privacy	f	Desktop	Chrome	2026-06-02 15:58:08.007245+00
61	/vieprivee	f	Desktop	Chrome	2026-06-02 15:58:25.885221+00
62	/blog	f	Desktop	Chrome	2026-06-02 15:59:04.110038+00
63	/apropos	f	Desktop	Chrome	2026-06-02 15:59:06.871723+00
64	/rse	f	Desktop	Chrome	2026-06-02 15:59:15.776229+00
65	/simulateur-division	f	Desktop	Chrome	2026-06-02 15:59:54.353151+00
66	/simulateur-ensoleillement	f	Desktop	Chrome	2026-06-02 16:03:07.258334+00
67	/eco-diagnostic	f	Desktop	Chrome	2026-06-02 16:05:55.6359+00
68	/carte-cadastre	f	Desktop	Chrome	2026-06-02 16:17:47.374351+00
69	/profil-long	f	Desktop	Chrome	2026-06-02 16:19:12.082011+00
70	/mon-projet	f	Desktop	Chrome	2026-06-02 16:21:38.769097+00
71	/contact	f	Desktop	Chrome	2026-06-02 16:23:57.617275+00
72	/eco-diagnostic	f	Desktop	Chrome	2026-06-02 18:14:47.178052+00
73	/	f	Mobile	Safari	2026-06-02 23:03:30.77082+00
74	/eco-diagnostic	f	Desktop	Chrome	2026-06-03 01:01:59.413326+00
75	/	f	Desktop	Chrome	2026-06-03 01:03:11.80095+00
76	/	f	Mobile	Safari	2026-06-03 01:32:53.684335+00
77	/eco-diagnostic	f	Mobile	Safari	2026-06-03 01:32:59.723257+00
78	/eco-diagnostic	f	Mobile	Safari	2026-06-03 01:43:01.136883+00
79	/	f	Mobile	Safari	2026-06-03 03:55:06.342136+00
80	/br	f	Mobile	Safari	2026-06-03 03:55:08.916869+00
81	/	f	Mobile	Safari	2026-06-03 03:55:10.766982+00
82	/br	f	Mobile	Safari	2026-06-03 03:55:13.744378+00
83	/	f	Mobile	Safari	2026-06-03 03:55:21.714679+00
84	/br	f	Mobile	Safari	2026-06-03 03:55:23.450752+00
85	/	f	Mobile	Safari	2026-06-03 03:55:25.81366+00
86	/br	f	Mobile	Safari	2026-06-03 03:55:27.215826+00
87	/	f	Mobile	Safari	2026-06-03 03:55:29.116062+00
88	/	f	Mobile	Safari	2026-06-03 04:20:35.012896+00
89	/	f	Desktop	Chrome	2026-06-03 13:05:05.849406+00
90	/en	f	Desktop	Chrome	2026-06-03 13:05:11.685512+00
91	/br	f	Desktop	Chrome	2026-06-03 13:05:16.792337+00
92	/	f	Desktop	Chrome	2026-06-03 13:05:19.955755+00
93	/	f	Mobile	Safari	2026-06-03 13:05:37.949063+00
94	/	f	Mobile	Safari	2026-06-03 13:05:38.024205+00
95	/br	f	Mobile	Safari	2026-06-03 13:05:50.628112+00
96	/	f	Mobile	Safari	2026-06-03 13:05:52.922527+00
97	/br	f	Mobile	Safari	2026-06-03 13:05:55.643555+00
98	/	f	Mobile	Safari	2026-06-03 13:05:58.873538+00
99	/br	f	Mobile	Safari	2026-06-03 13:06:03.658864+00
100	/	f	Mobile	Safari	2026-06-03 13:06:18.438169+00
101	/	f	Mobile	Safari	2026-06-03 13:06:27.343859+00
102	/br	f	Mobile	Safari	2026-06-03 13:06:28.638408+00
103	/	f	Mobile	Safari	2026-06-03 13:06:30.052914+00
104	/br	f	Mobile	Safari	2026-06-03 13:06:30.472683+00
105	/	f	Mobile	Safari	2026-06-03 13:06:31.089271+00
106	/br	f	Mobile	Safari	2026-06-03 13:06:31.241226+00
107	/	f	Mobile	Safari	2026-06-03 13:06:32.091798+00
108	/	f	Mobile	Safari	2026-06-03 13:06:34.180766+00
109	/	f	Mobile	Safari	2026-06-03 13:06:53.252187+00
110	/br	f	Mobile	Safari	2026-06-03 13:07:06.879031+00
111	/en	f	Mobile	Safari	2026-06-03 13:08:02.657516+00
112	/en	f	Mobile	Safari	2026-06-03 13:09:30.403216+00
113	/br	f	Mobile	Safari	2026-06-03 13:09:31.5054+00
114	/	f	Mobile	Safari	2026-06-03 13:09:33.786881+00
115	/en	f	Mobile	Safari	2026-06-03 13:09:35.552503+00
116	/br	f	Mobile	Safari	2026-06-03 13:14:17.721027+00
117	/	f	Mobile	Safari	2026-06-03 13:14:21.010332+00
118	/	f	Mobile	Safari	2026-06-03 13:14:24.631084+00
119	/br	f	Mobile	Safari	2026-06-03 13:14:27.14213+00
120	/	f	Mobile	Safari	2026-06-03 13:14:29.106655+00
121	/	f	Mobile	Safari	2026-06-03 13:14:31.264372+00
122	/	f	Mobile	Safari	2026-06-03 13:16:50.902286+00
123	/	f	Mobile	Safari	2026-06-03 13:16:55.260256+00
124	/en	f	Mobile	Safari	2026-06-03 13:16:58.493287+00
125	/br	f	Mobile	Safari	2026-06-03 13:17:00.173333+00
126	/	f	Desktop	Chrome	2026-06-03 13:17:44.636259+00
127	/	f	Desktop	Chrome	2026-06-03 13:17:44.963786+00
128	/	f	Desktop	Chrome	2026-06-03 13:38:59.475631+00
129	/mentions-legales	f	Desktop	Chrome	2026-06-03 13:44:26.229608+00
130	/contact	f	Desktop	Chrome	2026-06-03 13:44:48.041216+00
131	/mentions-legales	f	Desktop	Chrome	2026-06-03 13:47:52.397636+00
132	/	f	Desktop	Chrome	2026-06-03 13:50:21.202644+00
133	/	f	Desktop	Chrome	2026-06-03 14:57:47.673026+00
134	/	f	Desktop	Chrome	2026-06-03 15:18:30.535868+00
135	/	f	Desktop	Chrome	2026-06-03 15:18:55.635903+00
136	/	f	Desktop	Chrome	2026-06-03 15:19:11.874898+00
137	/	f	Desktop	Chrome	2026-06-03 15:19:57.953124+00
138	/	f	Desktop	Chrome	2026-06-03 15:21:49.966906+00
139	/	f	Desktop	Chrome	2026-06-03 15:22:18.618968+00
140	/	f	Desktop	Chrome	2026-06-03 15:22:42.108988+00
141	/lexique	f	Desktop	Chrome	2026-06-03 15:23:16.536002+00
142	/	f	Desktop	Chrome	2026-06-03 15:23:18.873411+00
143	/projets	f	Desktop	Chrome	2026-06-03 15:23:35.231784+00
144	/projets	f	Desktop	Chrome	2026-06-03 15:23:37.771811+00
145	/projets/eco-quartier-de-la-vallee	f	Desktop	Chrome	2026-06-03 15:23:56.646895+00
146	/projets/eco-quartier-de-la-vallee	f	Desktop	Chrome	2026-06-03 15:24:04.559617+00
147	/simulateur-division	f	Desktop	Chrome	2026-06-03 15:25:05.32215+00
148	/simulateur-division	f	Desktop	Chrome	2026-06-03 15:25:09.472365+00
149	/simulateur-ensoleillement	f	Desktop	Chrome	2026-06-03 15:27:01.345673+00
150	/simulateur-ensoleillement	f	Desktop	Chrome	2026-06-03 15:27:01.665522+00
151	/eco-diagnostic	f	Desktop	Chrome	2026-06-03 15:28:56.994354+00
152	/eco-diagnostic	f	Desktop	Chrome	2026-06-03 15:28:59.258819+00
153	/carte-cadastre	f	Desktop	Chrome	2026-06-03 15:31:30.5088+00
154	/carte-cadastre	f	Desktop	Chrome	2026-06-03 15:31:35.614204+00
155	/profil-long	f	Desktop	Chrome	2026-06-03 15:33:49.160401+00
156	/profil-long	f	Desktop	Chrome	2026-06-03 15:33:52.584695+00
157	/mon-projet	f	Desktop	Chrome	2026-06-03 15:36:18.100088+00
158	/mon-projet	f	Desktop	Chrome	2026-06-03 15:36:35.805403+00
159	/apropos	f	Desktop	Chrome	2026-06-03 15:37:01.265636+00
160	/simulateur-division	f	Desktop	Chrome	2026-06-03 15:37:03.851008+00
161	/	f	Mobile	Safari	2026-06-03 15:39:31.500739+00
162	/br/simulateur-division	f	Desktop	Chrome	2026-06-03 15:39:41.165879+00
163	/en/simulateur-division	f	Desktop	Chrome	2026-06-03 15:40:06.561387+00
164	/simulateur-division	f	Desktop	Chrome	2026-06-03 15:40:12.716984+00
165	/	f	Desktop	Chrome	2026-06-03 15:43:39.998576+00
166	/	f	Desktop	Chrome	2026-06-03 15:43:40.395358+00
167	/simulateur-division	f	Desktop	Chrome	2026-06-03 15:44:03.186861+00
168	/simulateur-division	f	Desktop	Chrome	2026-06-03 15:47:40.47693+00
169	/simulateur-division	f	Desktop	Chrome	2026-06-03 15:47:48.611255+00
170	/eco-diagnostic	f	Desktop	Chrome	2026-06-03 15:48:18.636622+00
171	/simulateur-ensoleillement	f	Desktop	Chrome	2026-06-03 15:48:25.841719+00
172	/eco-diagnostic	f	Desktop	Chrome	2026-06-03 15:48:33.646679+00
173	/apropos	f	Desktop	Chrome	2026-06-03 15:49:34.068316+00
174	/	f	Desktop	Chrome	2026-06-03 15:49:53.946966+00
175	/simulateur-division	f	Desktop	Chrome	2026-06-03 15:50:12.983648+00
176	/apropos	f	Desktop	Chrome	2026-06-03 15:52:19.9785+00
177	/eco-diagnostic	f	Desktop	Chrome	2026-06-03 16:04:25.030187+00
178	/simulateur-ensoleillement	f	Desktop	Chrome	2026-06-03 17:02:51.742565+00
179	/eco-diagnostic	f	Desktop	Chrome	2026-06-03 17:02:57.978438+00
180	/	f	Mobile	Safari	2026-06-04 13:03:03.252355+00
181	/	f	Mobile	Safari	2026-06-04 13:03:06.239711+00
182	/	f	Desktop	Chrome	2026-06-04 13:38:11.02003+00
183	/	f	Mobile	Safari	2026-06-04 14:29:33.535873+00
184	/simulateur-division	f	Desktop	Chrome	2026-06-04 14:29:59.255864+00
185	/apropos	f	Desktop	Chrome	2026-06-04 14:30:16.89158+00
186	/	f	Desktop	Chrome	2026-06-04 14:35:05.153569+00
187	/projets	f	Desktop	Chrome	2026-06-04 14:35:54.047505+00
188	/projets/eco-quartier-de-la-vallee	f	Desktop	Chrome	2026-06-04 14:36:04.74537+00
189	/moyens-techniques	f	Desktop	Chrome	2026-06-04 14:36:32.296145+00
190	/simulateur-division	f	Desktop	Chrome	2026-06-04 14:38:34.403807+00
191	/apropos	f	Desktop	Chrome	2026-06-04 14:42:18.097136+00
192	/br/simulateur-division	f	Desktop	Chrome	2026-06-04 14:43:23.08381+00
193	/simulateur-division	f	Desktop	Chrome	2026-06-04 14:43:26.751312+00
194	/simulateur-ensoleillement	f	Desktop	Chrome	2026-06-04 14:43:29.277522+00
195	/eco-diagnostic	f	Desktop	Chrome	2026-06-04 14:48:04.603931+00
196	/contact	f	Desktop	Chrome	2026-06-04 14:54:51.491008+00
197	/eco-diagnostic	f	Desktop	Chrome	2026-06-04 15:16:56.364639+00
198	/contact	f	Desktop	Chrome	2026-06-04 15:19:59.687054+00
199	/carte-cadastre	f	Desktop	Chrome	2026-06-04 15:20:48.997225+00
200	/profil-long	f	Desktop	Chrome	2026-06-04 15:22:04.067503+00
201	/mon-projet	f	Desktop	Chrome	2026-06-04 15:23:55.177578+00
202	/nous-suivre	f	Desktop	Chrome	2026-06-04 15:26:12.216049+00
203	/faq	f	Desktop	Chrome	2026-06-04 15:26:54.05067+00
204	/rse	f	Desktop	Chrome	2026-06-04 15:27:16.715911+00
205	/lexique	f	Desktop	Chrome	2026-06-04 15:27:30.994441+00
206	/apropos	f	Desktop	Chrome	2026-06-04 15:28:18.68619+00
207	/clients	f	Desktop	Chrome	2026-06-04 15:29:10.46861+00
208	/projets	f	Desktop	Chrome	2026-06-04 15:29:14.292939+00
209	/partenaires	f	Desktop	Chrome	2026-06-04 15:29:46.771749+00
210	/apropos	f	Desktop	Chrome	2026-06-04 15:29:53.064775+00
211	/projets	f	Desktop	Chrome	2026-06-04 15:30:02.294924+00
212	/partenaires	f	Desktop	Chrome	2026-06-04 15:30:20.571112+00
213	/moyens-techniques	f	Desktop	Chrome	2026-06-04 15:30:35.570547+00
214	/apropos	f	Desktop	Chrome	2026-06-04 15:30:57.170136+00
215	/expertise/urbanisme	f	Desktop	Chrome	2026-06-04 15:31:57.214539+00
216	/moyens-techniques	f	Desktop	Chrome	2026-06-04 15:32:26.768783+00
217	/projets	f	Desktop	Chrome	2026-06-04 15:32:36.105155+00
218	/moyens-techniques	f	Desktop	Chrome	2026-06-04 15:32:41.843011+00
219	/faq	f	Desktop	Chrome	2026-06-04 15:33:21.876382+00
220	/expertise/geometre	f	Desktop	Chrome	2026-06-04 15:33:24.442518+00
221	/contact	f	Desktop	Chrome	2026-06-04 15:33:29.966285+00
222	/nous-suivre	f	Desktop	Chrome	2026-06-04 15:35:23.427945+00
223	/blog	f	Desktop	Chrome	2026-06-04 15:36:00.114982+00
224	/nous-suivre	f	Desktop	Chrome	2026-06-04 15:36:15.270676+00
225	/lexique	f	Desktop	Chrome	2026-06-04 15:36:55.387159+00
226	/faq	f	Desktop	Chrome	2026-06-04 15:37:03.555404+00
227	/faq	f	Desktop	Chrome	2026-06-04 15:37:31.082657+00
228	/	f	Desktop	Chrome	2026-06-04 15:42:15.765816+00
229	/	f	Desktop	Chrome	2026-06-04 15:42:38.730096+00
230	/	f	Desktop	Chrome	2026-06-04 15:42:42.887381+00
231	/br	f	Desktop	Chrome	2026-06-04 15:42:50.140062+00
232	/	f	Desktop	Chrome	2026-06-04 15:42:55.126456+00
233	/simulateur-division	f	Desktop	Chrome	2026-06-04 15:43:31.789714+00
234	/	f	Desktop	Chrome	2026-06-04 15:44:36.483548+00
235	/moyens-techniques	f	Desktop	Chrome	2026-06-04 15:45:10.465629+00
236	/contact	f	Desktop	Chrome	2026-06-04 15:46:45.488997+00
237	/expertise/urbanisme	f	Desktop	Chrome	2026-06-04 15:46:54.8083+00
238	/contact	f	Desktop	Chrome	2026-06-04 15:47:01.736764+00
239	/mon-projet	f	Desktop	Chrome	2026-06-04 15:47:21.20214+00
240	/contact	f	Desktop	Chrome	2026-06-04 15:47:46.597927+00
241	/mon-projet	f	Desktop	Chrome	2026-06-04 15:47:54.397785+00
242	/contact	f	Desktop	Chrome	2026-06-04 15:48:17.760972+00
243	/mon-projet	f	Desktop	Chrome	2026-06-04 15:48:46.086915+00
244	/contact	f	Desktop	Chrome	2026-06-04 15:49:12.839709+00
245	/	f	Desktop	Chrome	2026-06-04 15:49:32.09738+00
246	/simulateur-division	f	Desktop	Chrome	2026-06-04 15:50:10.624715+00
247	/projets	f	Desktop	Chrome	2026-06-04 15:53:38.075754+00
248	/apropos	f	Desktop	Chrome	2026-06-04 15:54:00.512497+00
249	/expertise/urbanisme	f	Desktop	Chrome	2026-06-04 15:57:24.301942+00
250	/apropos	f	Desktop	Chrome	2026-06-04 15:57:40.157513+00
251	/apropos	f	Desktop	Chrome	2026-06-04 16:03:33.877111+00
252	/	f	Desktop	Chrome	2026-06-04 16:04:44.86151+00
253	/	f	Desktop	Chrome	2026-06-04 16:12:14.828754+00
254	/	f	Desktop	Chrome	2026-06-05 15:41:47.787864+00
255	/apropos	f	Desktop	Chrome	2026-06-05 15:41:50.366108+00
256	/expertise/urbanisme	f	Desktop	Chrome	2026-06-05 15:42:04.791738+00
257	/expertise/copropriete	f	Desktop	Chrome	2026-06-05 15:42:06.500012+00
258	/	f	Desktop	Chrome	2026-06-05 15:42:25.493275+00
259	/mon-projet	f	Desktop	Chrome	2026-06-05 15:42:31.834471+00
260	/moyens-techniques	f	Desktop	Chrome	2026-06-05 15:42:39.682055+00
261	/partenaires	f	Desktop	Chrome	2026-06-05 15:48:29.523045+00
262	/apropos	f	Desktop	Chrome	2026-06-05 15:49:34.139003+00
263	/rse	f	Desktop	Chrome	2026-06-05 15:50:39.838756+00
264	/apropos	f	Desktop	Chrome	2026-06-05 15:50:43.181982+00
265	/	f	Desktop	Chrome	2026-06-05 18:50:38.492146+00
266	/	f	Desktop	Chrome	2026-06-05 18:50:43.990356+00
267	/mentions-legales	f	Desktop	Chrome	2026-06-05 18:52:32.180663+00
268	/expertise/urbanisme	f	Desktop	Chrome	2026-06-05 18:52:41.743018+00
269	/contact	f	Desktop	Chrome	2026-06-05 18:52:46.805356+00
270	/projets	f	Desktop	Chrome	2026-06-05 18:53:12.324188+00
271	/clients	f	Desktop	Chrome	2026-06-05 18:53:28.227514+00
272	/moyens-techniques	f	Desktop	Chrome	2026-06-05 18:53:35.937844+00
273	/simulateur-division	f	Desktop	Chrome	2026-06-05 18:53:56.00129+00
274	/simulateur-ensoleillement	f	Desktop	Chrome	2026-06-05 18:55:15.303501+00
275	/eco-diagnostic	f	Desktop	Chrome	2026-06-05 18:55:23.677273+00
276	/contact	f	Desktop	Chrome	2026-06-05 18:56:22.342868+00
277	/br/contact	f	Desktop	Chrome	2026-06-05 18:56:30.025598+00
278	/	f	Desktop	Chrome	2026-06-10 14:42:04.024107+00
279	/en	f	Desktop	Chrome	2026-06-10 14:42:15.088874+00
280	/	f	Desktop	Chrome	2026-06-10 14:42:18.519115+00
281	/apropos	f	Desktop	Chrome	2026-06-10 14:42:47.488268+00
282	/clients	f	Desktop	Chrome	2026-06-10 14:44:20.581044+00
283	/projets	f	Desktop	Chrome	2026-06-10 14:44:21.415499+00
284	/apropos	f	Desktop	Chrome	2026-06-10 14:44:24.175116+00
285	/expertise/urbanisme	f	Desktop	Chrome	2026-06-10 14:51:48.977014+00
286	/expertise/geometre	f	Desktop	Chrome	2026-06-10 14:51:51.643084+00
287	/projets	f	Desktop	Chrome	2026-06-10 14:52:06.954799+00
288	/projets/eco-quartier-de-la-vallee	f	Desktop	Chrome	2026-06-10 14:52:12.113735+00
289	/partenaires	f	Desktop	Chrome	2026-06-10 14:52:39.618523+00
290	/moyens-techniques	f	Desktop	Chrome	2026-06-10 14:52:41.542043+00
291	/apropos	f	Desktop	Chrome	2026-06-10 14:52:45.970753+00
292	/eco-diagnostic	f	Desktop	Chrome	2026-06-10 14:53:20.6292+00
293	/	f	Desktop	Chrome	2026-06-10 14:53:23.835323+00
294	/apropos	f	Desktop	Chrome	2026-06-10 14:53:28.061629+00
295	/	f	Desktop	Chrome	2026-06-18 14:15:22.126262+00
296	/expertise/urbanisme	f	Desktop	Chrome	2026-06-18 14:16:38.070402+00
297	/projets	f	Desktop	Chrome	2026-06-18 14:16:51.988211+00
298	/	f	Desktop	Chrome	2026-06-18 14:20:28.319662+00
299	/	f	Desktop	Chrome	2026-06-19 13:28:47.562328+00
300	/	f	Desktop	Chrome	2026-06-19 13:29:17.577301+00
301	/	f	Desktop	Chrome	2026-06-19 14:41:49.905388+00
302	/	f	Desktop	Chrome	2026-06-19 14:41:51.265356+00
303	/	f	Desktop	Chrome	2026-06-19 14:45:58.722275+00
304	/	f	Desktop	Chrome	2026-06-19 14:45:59.162975+00
305	/	f	Desktop	Chrome	2026-06-19 14:49:15.887967+00
306	/	f	Desktop	Chrome	2026-06-19 14:49:16.271855+00
307	/	f	Desktop	Chrome	2026-06-19 14:49:33.918259+00
308	/	f	Desktop	Chrome	2026-06-19 16:02:10.81529+00
309	/	f	Desktop	Chrome	2026-06-19 16:05:58.61806+00
310	/apropos	f	Desktop	Chrome	2026-06-19 16:06:01.910364+00
311	/	f	Desktop	Chrome	2026-06-19 16:06:09.649193+00
312	/moyens-techniques	f	Desktop	Chrome	2026-06-19 16:07:00.930413+00
313	/contact	f	Desktop	Chrome	2026-06-19 16:07:52.298206+00
314	/moyens-techniques	f	Desktop	Chrome	2026-06-19 16:07:55.082663+00
315	/	f	Desktop	Edge	2026-06-22 12:07:24.674416+00
316	/	f	Desktop	Chrome	2026-06-22 12:07:31.838091+00
317	/	f	Desktop	Chrome	2026-06-22 12:08:32.749027+00
318	/	f	Desktop	Chrome	2026-06-22 12:08:53.884402+00
319	/	f	Desktop	Chrome	2026-06-22 12:09:16.141639+00
320	/	f	Desktop	Chrome	2026-06-22 12:11:05.088131+00
321	/	f	Mobile	Safari	2026-06-22 12:14:42.305372+00
322	/	f	Mobile	Safari	2026-06-22 12:15:38.214029+00
323	/	f	Desktop	Chrome	2026-06-22 12:18:08.436172+00
324	/	f	Desktop	Chrome	2026-06-22 12:18:49.130393+00
325	/contact	f	Desktop	Chrome	2026-06-22 12:29:51.368926+00
326	/apropos	f	Desktop	Chrome	2026-06-22 12:29:57.71888+00
327	/	f	Desktop	Chrome	2026-06-22 12:32:27.567947+00
328	/	f	Desktop	Chrome	2026-06-22 12:32:31.901136+00
329	/	f	Desktop	Chrome	2026-06-22 12:33:09.827344+00
330	/	f	Desktop	Chrome	2026-06-22 12:39:14.036378+00
331	/	f	Desktop	Chrome	2026-06-22 12:41:22.698232+00
332	/	f	Desktop	Chrome	2026-06-22 12:48:04.453093+00
333	/	f	Desktop	Chrome	2026-06-22 12:49:29.765237+00
334	/	f	Desktop	Chrome	2026-06-22 12:53:39.772532+00
335	/contact	f	Desktop	Chrome	2026-06-22 12:53:59.753054+00
336	/apropos	f	Desktop	Chrome	2026-06-22 12:58:11.323717+00
337	/apropos	f	Desktop	Chrome	2026-06-22 13:00:27.294516+00
338	/apropos	f	Desktop	Chrome	2026-06-22 13:01:58.972426+00
339	/rse	f	Desktop	Chrome	2026-06-22 13:22:15.700074+00
340	/	f	Desktop	Chrome	2026-06-22 13:36:36.975654+00
341	/apropos	f	Desktop	Chrome	2026-06-22 13:36:57.499744+00
342	/	f	Desktop	Chrome	2026-06-22 13:37:00.561805+00
343	/expertise/urbanisme	f	Desktop	Chrome	2026-06-22 13:41:07.852367+00
344	/simulateur-division	f	Desktop	Chrome	2026-06-22 13:44:00.748351+00
345	/eco-diagnostic	f	Desktop	Chrome	2026-06-22 13:45:01.52896+00
346	/mon-projet	f	Desktop	Chrome	2026-06-22 13:46:22.000171+00
347	/rse	f	Desktop	Chrome	2026-06-22 13:46:42.76496+00
348	/apropos	f	Desktop	Chrome	2026-06-22 13:47:10.634492+00
349	/moyens-techniques	f	Desktop	Chrome	2026-06-22 13:51:48.476015+00
350	/br/moyens-techniques	f	Desktop	Chrome	2026-06-22 13:53:16.648211+00
351	/moyens-techniques	f	Desktop	Chrome	2026-06-22 13:53:19.050229+00
352	/eco-diagnostic	f	Desktop	Chrome	2026-06-22 13:59:00.386696+00
353	/mon-projet	f	Desktop	Chrome	2026-06-22 14:06:20.692149+00
354	/expertise/urbanisme	f	Desktop	Chrome	2026-06-22 14:06:34.901557+00
355	/contact	f	Desktop	Chrome	2026-06-22 14:07:05.084247+00
356	/nous-suivre	f	Desktop	Chrome	2026-06-22 14:10:45.771076+00
357	/partenaires	f	Desktop	Chrome	2026-06-22 14:16:42.689891+00
358	/apropos	f	Desktop	Chrome	2026-06-22 14:42:06.085423+00
359	/expertise/urbanisme	f	Desktop	Chrome	2026-06-22 14:42:25.605323+00
360	/apropos	f	Desktop	Chrome	2026-06-22 14:42:32.256017+00
361	/expertise/urbanisme	f	Desktop	Chrome	2026-06-22 14:42:40.813076+00
362	/projets	f	Desktop	Chrome	2026-06-22 14:42:48.122313+00
363	/partenaires	f	Desktop	Chrome	2026-06-22 14:44:09.103662+00
364	/projets	f	Desktop	Chrome	2026-06-22 14:46:42.911039+00
365	/	f	Desktop	Chrome	2026-06-22 14:49:14.653422+00
366	/apropos	f	Desktop	Chrome	2026-06-22 14:52:46.915548+00
367	/partenaires	f	Desktop	Chrome	2026-06-22 15:25:13.364368+00
368	/partenaires	f	Desktop	Chrome	2026-06-22 15:27:04.772803+00
369	/clients	f	Desktop	Chrome	2026-06-22 15:27:06.997867+00
370	/clients	f	Desktop	Chrome	2026-06-22 15:27:41.30096+00
371	/clients	f	Desktop	Chrome	2026-06-22 15:27:56.36675+00
372	/clients	f	Desktop	Chrome	2026-06-22 15:28:11.79014+00
373	/clients	f	Desktop	Chrome	2026-06-22 15:28:52.0041+00
374	/clients	f	Desktop	Chrome	2026-06-22 15:29:25.648593+00
375	/clients	f	Desktop	Chrome	2026-06-22 15:31:23.400265+00
376	/partenaires	f	Desktop	Chrome	2026-06-22 15:32:26.470234+00
377	/clients	f	Desktop	Chrome	2026-06-22 15:32:30.151535+00
378	/clients	f	Desktop	Chrome	2026-06-22 15:38:53.245934+00
379	/clients	f	Desktop	Chrome	2026-06-22 15:43:58.099669+00
380	/clients	f	Desktop	Chrome	2026-06-22 15:44:21.715608+00
381	/clients	f	Desktop	Chrome	2026-06-22 15:47:22.823172+00
382	/apropos	f	Desktop	Chrome	2026-06-22 15:50:08.163809+00
383	/blog	f	Desktop	Chrome	2026-06-22 15:50:12.778195+00
384	/nous-suivre	f	Desktop	Chrome	2026-06-22 15:50:26.214805+00
385	/apropos	f	Desktop	Chrome	2026-06-22 15:57:35.900047+00
386	/faq	f	Desktop	Chrome	2026-06-22 15:57:48.729043+00
387	/lexique	f	Desktop	Chrome	2026-06-22 15:57:50.246311+00
388	/blog	f	Desktop	Chrome	2026-06-22 15:57:51.255856+00
389	/apropos	f	Desktop	Chrome	2026-06-22 15:57:52.741452+00
390	/rse	f	Desktop	Chrome	2026-06-22 15:57:56.79118+00
391	/apropos	f	Desktop	Chrome	2026-06-22 15:58:05.908343+00
392	/	f	Desktop	Chrome	2026-06-22 15:58:08.939955+00
393	/expertise/vrd	f	Desktop	Chrome	2026-06-22 15:58:21.744059+00
394	/expertise/urbanisme	f	Desktop	Chrome	2026-06-22 15:58:56.895808+00
395	/	f	Desktop	Chrome	2026-06-22 15:59:54.707425+00
396	/	f	Desktop	Chrome	2026-06-22 16:02:00.819611+00
397	/expertise/urbanisme	f	Desktop	Chrome	2026-06-22 16:03:10.096755+00
398	/apropos	f	Desktop	Chrome	2026-06-22 16:04:25.932924+00
399	/apropos	f	Desktop	Chrome	2026-06-22 16:04:28.704044+00
400	/apropos	f	Desktop	Chrome	2026-06-22 16:04:53.775844+00
401	/apropos	f	Desktop	Chrome	2026-06-22 16:05:37.507769+00
402	/moyens-techniques	f	Desktop	Chrome	2026-06-22 16:06:42.14836+00
403	/moyens-techniques	f	Desktop	Chrome	2026-06-22 16:07:44.637302+00
404	/moyens-techniques	f	Desktop	Chrome	2026-06-22 16:08:10.704225+00
405	/moyens-techniques	f	Desktop	Chrome	2026-06-22 16:08:42.761951+00
406	/mon-projet	f	Desktop	Chrome	2026-06-22 16:08:59.439015+00
407	/	f	Desktop	Chrome	2026-06-26 08:05:16.740523+00
408	/	f	Desktop	Chrome	2026-06-26 08:13:16.901316+00
409	/expertise/urbanisme	f	Desktop	Chrome	2026-06-26 08:32:43.654141+00
410	/apropos	f	Desktop	Chrome	2026-06-26 08:32:54.01609+00
411	/	f	Desktop	Chrome	2026-06-26 08:32:57.48805+00
412	/expertise/urbanisme	f	Desktop	Chrome	2026-06-26 08:33:30.579334+00
413	/expertise/geometre	f	Desktop	Chrome	2026-06-26 08:33:33.774659+00
414	/	f	Desktop	Chrome	2026-06-26 08:33:36.072363+00
415	/projets	f	Desktop	Chrome	2026-06-26 08:34:26.512551+00
416	/	f	Desktop	Chrome	2026-06-26 08:34:42.303428+00
417	/clients	f	Desktop	Chrome	2026-06-26 08:34:59.795361+00
418	/apropos	f	Desktop	Chrome	2026-06-26 08:39:24.89627+00
419	/	f	Desktop	Chrome	2026-06-26 08:39:34.68332+00
420	/contact	f	Desktop	Chrome	2026-06-26 08:39:39.89676+00
421	/	f	Desktop	Chrome	2026-06-26 08:39:48.598337+00
422	/contact	f	Desktop	Chrome	2026-06-26 08:39:49.764944+00
423	/simulateur-division	f	Desktop	Chrome	2026-06-26 08:40:05.23374+00
424	/contact	f	Desktop	Chrome	2026-06-26 08:40:08.256832+00
425	/	f	Desktop	Chrome	2026-06-26 08:41:05.735992+00
426	/expertise/geometre	f	Desktop	Chrome	2026-06-26 08:43:13.52166+00
427	/	f	Desktop	Chrome	2026-06-26 08:43:37.235351+00
428	/expertise/vrd	f	Desktop	Chrome	2026-06-26 08:47:01.652826+00
429	/	f	Desktop	Chrome	2026-06-26 08:47:03.578649+00
430	/expertise/geometre	f	Desktop	Chrome	2026-06-26 08:49:55.849581+00
431	/	f	Desktop	Chrome	2026-06-26 08:50:00.129335+00
432	/lexique	f	Desktop	Chrome	2026-06-26 08:51:24.505201+00
433	/	f	Desktop	Chrome	2026-06-26 08:51:28.710135+00
434	/lexique	f	Desktop	Chrome	2026-06-26 08:51:35.922494+00
435	/	f	Desktop	Chrome	2026-06-26 08:51:38.991593+00
436	/lexique	f	Desktop	Chrome	2026-06-26 08:51:52.230241+00
437	/	f	Desktop	Chrome	2026-06-26 08:51:54.183511+00
438	/lexique	f	Desktop	Chrome	2026-06-26 08:52:44.479407+00
439	/	f	Desktop	Chrome	2026-06-26 08:52:46.110918+00
442	/expertise/vrd	f	Desktop	Chrome	2026-06-26 08:53:20.409818+00
440	/lexique	f	Desktop	Chrome	2026-06-26 08:53:08.572978+00
441	/	f	Desktop	Chrome	2026-06-26 08:53:19.653661+00
443	/	f	Desktop	Chrome	2026-06-26 08:53:22.135466+00
444	/expertise/urbanisme	f	Desktop	Chrome	2026-06-26 08:57:31.032578+00
445	/apropos	f	Desktop	Chrome	2026-06-26 08:57:55.207223+00
446	/	f	Desktop	Chrome	2026-06-26 08:57:55.851825+00
447	/expertise/urbanisme	f	Desktop	Chrome	2026-06-26 08:58:34.208833+00
448	/	f	Desktop	Chrome	2026-06-26 08:58:41.917758+00
449	/expertise/urbanisme	f	Desktop	Chrome	2026-06-26 09:00:05.058421+00
450	/	f	Desktop	Chrome	2026-06-26 09:01:00.428106+00
451	/contact	f	Desktop	Chrome	2026-06-26 09:06:49.179369+00
452	/	f	Desktop	Chrome	2026-06-26 09:06:56.538254+00
453	/contact	f	Desktop	Chrome	2026-06-26 09:07:00.248769+00
454	/apropos	f	Desktop	Chrome	2026-06-26 09:07:45.014526+00
455	/	f	Desktop	Chrome	2026-06-26 09:07:50.478609+00
456	/partenaires	f	Desktop	Chrome	2026-06-26 09:09:17.427654+00
457	/	f	Desktop	Chrome	2026-06-26 09:09:22.487003+00
458	/partenaires	f	Desktop	Chrome	2026-06-26 09:09:30.807497+00
459	/	f	Desktop	Chrome	2026-06-26 09:09:32.223194+00
460	/partenaires	f	Desktop	Chrome	2026-06-26 09:09:34.401092+00
461	/	f	Desktop	Chrome	2026-06-26 09:09:36.463122+00
462	/partenaires	f	Desktop	Chrome	2026-06-26 09:11:03.225417+00
463	/	f	Desktop	Chrome	2026-06-26 09:11:08.355068+00
464	/apropos	f	Desktop	Chrome	2026-06-26 09:11:35.269048+00
465	/	f	Desktop	Chrome	2026-06-26 09:11:37.659763+00
466	/apropos	f	Desktop	Chrome	2026-06-26 09:12:20.81103+00
467	/	f	Desktop	Chrome	2026-06-26 09:12:23.425917+00
468	/contact	f	Desktop	Chrome	2026-06-26 09:14:43.476073+00
469	/	f	Desktop	Chrome	2026-06-26 09:14:44.992763+00
470	/apropos	f	Desktop	Chrome	2026-06-26 09:14:51.79237+00
471	/	f	Desktop	Chrome	2026-06-26 09:14:53.414078+00
472	/expertise/urbanisme	f	Desktop	Chrome	2026-06-26 09:14:59.433706+00
473	/	f	Desktop	Chrome	2026-06-26 09:15:02.621877+00
474	/expertise/urbanisme	f	Desktop	Chrome	2026-06-26 09:16:50.385508+00
475	/	f	Desktop	Chrome	2026-06-26 09:16:52.163328+00
476	/projets	f	Desktop	Chrome	2026-06-26 09:20:15.002485+00
477	/nous-suivre	f	Desktop	Chrome	2026-06-26 09:20:55.242437+00
478	/nous-suivre	f	Desktop	Chrome	2026-06-26 09:21:47.228914+00
479	/blog	f	Desktop	Chrome	2026-06-26 09:22:00.098609+00
480	/plan-du-site	f	Desktop	Chrome	2026-06-26 09:24:49.613896+00
481	/	f	Desktop	Chrome	2026-06-26 09:24:51.91036+00
482	/nous-suivre	f	Desktop	Chrome	2026-06-26 09:25:26.011915+00
483	/	f	Desktop	Chrome	2026-06-26 09:25:34.429145+00
484	/nous-suivre	f	Desktop	Chrome	2026-06-26 09:26:21.874451+00
485	/	f	Desktop	Chrome	2026-06-26 09:26:33.283576+00
486	/nous-suivre	f	Desktop	Chrome	2026-06-26 09:27:20.206025+00
487	/	f	Desktop	Chrome	2026-06-26 09:27:39.322282+00
488	/nous-suivre	f	Desktop	Chrome	2026-06-26 09:27:45.173549+00
489	/	f	Desktop	Chrome	2026-06-26 09:27:48.76788+00
490	/expertise/urbanisme	f	Desktop	Chrome	2026-06-26 09:28:33.653174+00
491	/	f	Desktop	Chrome	2026-06-26 09:28:39.514837+00
492	/expertise/urbanisme	f	Desktop	Chrome	2026-06-26 09:28:42.000953+00
493	/apropos	f	Desktop	Chrome	2026-06-26 09:29:08.432174+00
494	/projets	f	Desktop	Chrome	2026-06-26 09:34:02.803597+00
495	/	f	Desktop	Chrome	2026-06-26 09:34:09.243057+00
496	/apropos	f	Desktop	Chrome	2026-06-26 09:37:04.116217+00
497	/rse	f	Desktop	Chrome	2026-06-26 09:37:59.258363+00
498	/apropos	f	Desktop	Chrome	2026-06-26 09:38:06.226778+00
499	/rse	f	Desktop	Chrome	2026-06-26 09:38:09.124173+00
500	/apropos	f	Desktop	Chrome	2026-06-26 09:38:20.811761+00
501	/rse	f	Desktop	Chrome	2026-06-26 09:39:24.094199+00
502	/apropos	f	Desktop	Chrome	2026-06-26 09:39:56.987584+00
503	/contact	f	Desktop	Chrome	2026-06-26 09:41:01.694489+00
504	/faq	f	Desktop	Chrome	2026-06-26 09:41:42.500199+00
505	/	f	Desktop	Chrome	2026-06-26 09:41:53.673407+00
506	/faq	f	Desktop	Chrome	2026-06-26 09:41:55.37581+00
507	/expertise/geometre	f	Desktop	Chrome	2026-06-26 09:42:12.928822+00
508	/	f	Desktop	Chrome	2026-07-02 09:07:13.821033+00
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.schema_migrations (version, inserted_at) FROM stdin;
20211116024918	2026-06-02 02:45:51
20211116045059	2026-06-02 02:45:51
20211116050929	2026-06-02 02:45:51
20211116051442	2026-06-02 02:45:51
20211116212300	2026-06-02 02:45:51
20211116213355	2026-06-02 02:45:51
20211116213934	2026-06-02 02:45:51
20211116214523	2026-06-02 02:45:52
20211122062447	2026-06-02 02:45:52
20211124070109	2026-06-02 02:45:52
20211202204204	2026-06-02 02:45:52
20211202204605	2026-06-02 02:45:52
20211210212804	2026-06-02 02:45:52
20211228014915	2026-06-02 02:45:52
20220107221237	2026-06-02 02:45:52
20220228202821	2026-06-02 02:45:52
20220312004840	2026-06-02 02:45:53
20220603231003	2026-06-02 02:45:53
20220603232444	2026-06-02 02:45:53
20220615214548	2026-06-02 02:45:53
20220712093339	2026-06-02 02:45:53
20220908172859	2026-06-02 02:45:53
20220916233421	2026-06-02 02:45:53
20230119133233	2026-06-02 02:45:53
20230128025114	2026-06-02 02:45:53
20230128025212	2026-06-02 02:45:53
20230227211149	2026-06-02 02:45:53
20230228184745	2026-06-02 02:45:54
20230308225145	2026-06-02 02:45:54
20230328144023	2026-06-02 02:45:54
20231018144023	2026-06-02 02:45:54
20231204144023	2026-06-02 02:45:54
20231204144024	2026-06-02 02:45:54
20231204144025	2026-06-02 02:45:54
20240108234812	2026-06-02 02:45:54
20240109165339	2026-06-02 02:45:54
20240227174441	2026-06-02 02:45:54
20240311171622	2026-06-02 02:45:55
20240321100241	2026-06-02 02:45:55
20240401105812	2026-06-02 02:45:55
20240418121054	2026-06-02 02:45:55
20240523004032	2026-06-02 02:45:55
20240618124746	2026-06-02 02:45:55
20240801235015	2026-06-02 02:45:56
20240805133720	2026-06-02 02:45:56
20240827160934	2026-06-02 02:45:56
20240919163303	2026-06-02 02:45:56
20240919163305	2026-06-02 02:45:56
20241019105805	2026-06-02 02:45:56
20241030150047	2026-06-02 02:45:56
20241108114728	2026-06-02 02:45:56
20241121104152	2026-06-02 02:45:57
20241130184212	2026-06-02 02:45:57
20241220035512	2026-06-02 02:45:57
20241220123912	2026-06-02 02:45:57
20241224161212	2026-06-02 02:45:57
20250107150512	2026-06-02 02:45:57
20250110162412	2026-06-02 02:45:57
20250123174212	2026-06-02 02:45:57
20250128220012	2026-06-02 02:45:57
20250506224012	2026-06-02 02:45:57
20250523164012	2026-06-02 02:45:57
20250714121412	2026-06-02 02:45:57
20250905041441	2026-06-02 02:45:58
20251103001201	2026-06-02 02:45:58
20251120212548	2026-06-02 02:45:58
20251120215549	2026-06-02 02:45:58
20260218120000	2026-06-02 02:45:58
20260326120000	2026-06-02 02:45:58
20260514120000	2026-06-04 03:00:29
20260527120000	2026-06-04 03:00:29
20260528120000	2026-06-04 03:00:29
20260603120000	2026-06-04 03:00:30
20260605120000	2026-06-19 14:02:49
20260606110000	2026-06-19 14:02:49
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.subscription (id, subscription_id, entity, filters, claims, created_at, action_filter, selected_columns) FROM stdin;
\.


--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.buckets (id, name, owner, created_at, updated_at, public, avif_autodetection, file_size_limit, allowed_mime_types, owner_id, type) FROM stdin;
urbateam-media	urbateam-media	\N	2026-06-02 02:49:33.596208+00	2026-06-02 02:49:33.596208+00	t	f	10485760	\N	\N	STANDARD
\.


--
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.buckets_analytics (name, type, format, created_at, updated_at, id, deleted_at) FROM stdin;
\.


--
-- Data for Name: buckets_vectors; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.buckets_vectors (id, type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.migrations (id, name, hash, executed_at) FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2026-06-01 21:36:35.407219
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2026-06-01 21:36:35.443951
2	storage-schema	f6a1fa2c93cbcd16d4e487b362e45fca157a8dbd	2026-06-01 21:36:35.450423
3	pathtoken-column	2cb1b0004b817b29d5b0a971af16bafeede4b70d	2026-06-01 21:36:35.474044
4	add-migrations-rls	427c5b63fe1c5937495d9c635c263ee7a5905058	2026-06-01 21:36:35.486223
5	add-size-functions	79e081a1455b63666c1294a440f8ad4b1e6a7f84	2026-06-01 21:36:35.493777
6	change-column-name-in-get-size	ded78e2f1b5d7e616117897e6443a925965b30d2	2026-06-01 21:36:35.49977
7	add-rls-to-buckets	e7e7f86adbc51049f341dfe8d30256c1abca17aa	2026-06-01 21:36:35.505332
8	add-public-to-buckets	fd670db39ed65f9d08b01db09d6202503ca2bab3	2026-06-01 21:36:35.51085
9	fix-search-function	af597a1b590c70519b464a4ab3be54490712796b	2026-06-01 21:36:35.516103
10	search-files-search-function	b595f05e92f7e91211af1bbfe9c6a13bb3391e16	2026-06-01 21:36:35.521601
11	add-trigger-to-auto-update-updated_at-column	7425bdb14366d1739fa8a18c83100636d74dcaa2	2026-06-01 21:36:35.529193
12	add-automatic-avif-detection-flag	8e92e1266eb29518b6a4c5313ab8f29dd0d08df9	2026-06-01 21:36:35.534564
13	add-bucket-custom-limits	cce962054138135cd9a8c4bcd531598684b25e7d	2026-06-01 21:36:35.539747
14	use-bytes-for-max-size	941c41b346f9802b411f06f30e972ad4744dad27	2026-06-01 21:36:35.54471
15	add-can-insert-object-function	934146bc38ead475f4ef4b555c524ee5d66799e5	2026-06-01 21:36:35.569695
16	add-version	76debf38d3fd07dcfc747ca49096457d95b1221b	2026-06-01 21:36:35.574763
17	drop-owner-foreign-key	f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101	2026-06-01 21:36:35.579622
18	add_owner_id_column_deprecate_owner	e7a511b379110b08e2f214be852c35414749fe66	2026-06-01 21:36:35.584383
19	alter-default-value-objects-id	02e5e22a78626187e00d173dc45f58fa66a4f043	2026-06-01 21:36:35.590656
20	list-objects-with-delimiter	cd694ae708e51ba82bf012bba00caf4f3b6393b7	2026-06-01 21:36:35.595774
21	s3-multipart-uploads	8c804d4a566c40cd1e4cc5b3725a664a9303657f	2026-06-01 21:36:35.602657
22	s3-multipart-uploads-big-ints	9737dc258d2397953c9953d9b86920b8be0cdb73	2026-06-01 21:36:35.618303
23	optimize-search-function	9d7e604cddc4b56a5422dc68c9313f4a1b6f132c	2026-06-01 21:36:35.629682
24	operation-function	8312e37c2bf9e76bbe841aa5fda889206d2bf8aa	2026-06-01 21:36:35.634716
25	custom-metadata	d974c6057c3db1c1f847afa0e291e6165693b990	2026-06-01 21:36:35.640371
26	objects-prefixes	215cabcb7f78121892a5a2037a09fedf9a1ae322	2026-06-01 21:36:35.645451
27	search-v2	859ba38092ac96eb3964d83bf53ccc0b141663a6	2026-06-01 21:36:35.650495
28	object-bucket-name-sorting	c73a2b5b5d4041e39705814fd3a1b95502d38ce4	2026-06-01 21:36:35.655334
29	create-prefixes	ad2c1207f76703d11a9f9007f821620017a66c21	2026-06-01 21:36:35.660115
30	update-object-levels	2be814ff05c8252fdfdc7cfb4b7f5c7e17f0bed6	2026-06-01 21:36:35.664713
31	objects-level-index	b40367c14c3440ec75f19bbce2d71e914ddd3da0	2026-06-01 21:36:35.670039
32	backward-compatible-index-on-objects	e0c37182b0f7aee3efd823298fb3c76f1042c0f7	2026-06-01 21:36:35.674853
33	backward-compatible-index-on-prefixes	b480e99ed951e0900f033ec4eb34b5bdcb4e3d49	2026-06-01 21:36:35.68023
34	optimize-search-function-v1	ca80a3dc7bfef894df17108785ce29a7fc8ee456	2026-06-01 21:36:35.685665
35	add-insert-trigger-prefixes	458fe0ffd07ec53f5e3ce9df51bfdf4861929ccc	2026-06-01 21:36:35.690263
36	optimise-existing-functions	6ae5fca6af5c55abe95369cd4f93985d1814ca8f	2026-06-01 21:36:35.694813
37	add-bucket-name-length-trigger	3944135b4e3e8b22d6d4cbb568fe3b0b51df15c1	2026-06-01 21:36:35.699564
38	iceberg-catalog-flag-on-buckets	02716b81ceec9705aed84aa1501657095b32e5c5	2026-06-01 21:36:35.706664
39	add-search-v2-sort-support	6706c5f2928846abee18461279799ad12b279b78	2026-06-01 21:36:35.720578
40	fix-prefix-race-conditions-optimized	7ad69982ae2d372b21f48fc4829ae9752c518f6b	2026-06-01 21:36:35.725066
41	add-object-level-update-trigger	07fcf1a22165849b7a029deed059ffcde08d1ae0	2026-06-01 21:36:35.73032
42	rollback-prefix-triggers	771479077764adc09e2ea2043eb627503c034cd4	2026-06-01 21:36:35.735145
43	fix-object-level	84b35d6caca9d937478ad8a797491f38b8c2979f	2026-06-01 21:36:35.740398
44	vector-bucket-type	99c20c0ffd52bb1ff1f32fb992f3b351e3ef8fb3	2026-06-01 21:36:35.745213
45	vector-buckets	049e27196d77a7cb76497a85afae669d8b230953	2026-06-01 21:36:35.751074
46	buckets-objects-grants	fedeb96d60fefd8e02ab3ded9fbde05632f84aed	2026-06-01 21:36:35.762377
47	iceberg-table-metadata	649df56855c24d8b36dd4cc1aeb8251aa9ad42c2	2026-06-01 21:36:35.767706
48	iceberg-catalog-ids	e0e8b460c609b9999ccd0df9ad14294613eed939	2026-06-01 21:36:35.772618
49	buckets-objects-grants-postgres	072b1195d0d5a2f888af6b2302a1938dd94b8b3d	2026-06-01 21:36:35.788862
50	search-v2-optimised	6323ac4f850aa14e7387eb32102869578b5bd478	2026-06-01 21:36:35.794226
51	index-backward-compatible-search	2ee395d433f76e38bcd3856debaf6e0e5b674011	2026-06-01 21:36:36.536242
52	drop-not-used-indexes-and-functions	5cc44c8696749ac11dd0dc37f2a3802075f3a171	2026-06-01 21:36:36.538588
53	drop-index-lower-name	d0cb18777d9e2a98ebe0bc5cc7a42e57ebe41854	2026-06-01 21:36:36.55059
54	drop-index-object-level	6289e048b1472da17c31a7eba1ded625a6457e67	2026-06-01 21:36:36.554811
55	prevent-direct-deletes	262a4798d5e0f2e7c8970232e03ce8be695d5819	2026-06-01 21:36:36.556963
56	fix-optimized-search-function	b823ed1e418101032fa01374edc9a436e54e3ed4	2026-06-01 21:36:36.564658
57	s3-multipart-uploads-metadata	f127886e00d1b374fadbc7c6b31e09336aad5287	2026-06-01 21:36:36.571247
58	operation-ergonomics	00ca5d483b3fe0d522133d9002ccc5df98365120	2026-06-01 21:36:36.578566
59	drop-unused-functions	38456f13e39691c2bbb4b5151d0d1cdbabd4a8c4	2026-06-01 21:36:36.587097
60	optimize-existing-functions-again	db35e1c91a9201e59f4fef8d972c2f277d68b157	2026-06-01 21:36:36.592496
\.


--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.objects (id, bucket_id, name, owner, created_at, updated_at, last_accessed_at, metadata, version, owner_id, user_metadata) FROM stdin;
61ea60b9-55e6-487d-aa3a-51b643e4526e	urbateam-media	1777520926226-IMG_0470.jpg	\N	2026-06-02 03:37:44.284138+00	2026-06-02 03:37:44.284138+00	2026-06-02 03:37:44.284138+00	{"eTag": "\\"c3c62b571ab4bd75446b07c1fca18976\\"", "size": 123438, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:45.000Z", "contentLength": 123438, "httpStatusCode": 200}	b93f5e0e-21ce-4ad8-9fd1-a6d57e01c384	\N	{}
ae68dc36-32fe-4a0f-bac1-ade8a5033543	urbateam-media	1777520989702-IMG_0470.jpg	\N	2026-06-02 03:37:45.289864+00	2026-06-02 03:37:45.289864+00	2026-06-02 03:37:45.289864+00	{"eTag": "\\"c3c62b571ab4bd75446b07c1fca18976\\"", "size": 123438, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:46.000Z", "contentLength": 123438, "httpStatusCode": 200}	93a6392f-5dfe-4b29-897a-39f11bd50dc1	\N	{}
c5cfb049-262b-42ec-8781-2d27f228e564	urbateam-media	1777521002237-IMG_0474.jpg	\N	2026-06-02 03:37:45.760465+00	2026-06-02 03:37:45.760465+00	2026-06-02 03:37:45.760465+00	{"eTag": "\\"2edfb95c474330ea8cfa9cc9ff82d789\\"", "size": 222541, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:46.000Z", "contentLength": 222541, "httpStatusCode": 200}	278ef626-35d5-4003-92fe-d3b57cf00ba7	\N	{}
a0800be6-1d80-484e-bb75-2232add2247a	urbateam-media	1777521191768-IMG_0471.jpg	\N	2026-06-02 03:37:46.158743+00	2026-06-02 03:37:46.158743+00	2026-06-02 03:37:46.158743+00	{"eTag": "\\"937be74cbd4d6c56abe1b7861bb3d303\\"", "size": 110185, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:47.000Z", "contentLength": 110185, "httpStatusCode": 200}	838bb015-2d9c-4869-b6d0-857f385f28b6	\N	{}
9e079b7f-6729-4a4a-aa48-392cda4eb39e	urbateam-media	1777917028929-Gemini_Generated_Image_ti5w5xti5w5xti5w.png	\N	2026-06-02 03:37:47.412528+00	2026-06-02 03:37:47.412528+00	2026-06-02 03:37:47.412528+00	{"eTag": "\\"6f904b1bb073197340e3319de8e32b13\\"", "size": 2199634, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:48.000Z", "contentLength": 2199634, "httpStatusCode": 200}	a8b99c2d-19d1-4fcc-8d22-4b741f41b4f1	\N	{}
f6fc067b-02e5-42a8-9bc9-2c5842f399f9	urbateam-media	bornage.jpg	\N	2026-06-02 03:37:47.86491+00	2026-06-02 03:37:47.86491+00	2026-06-02 03:37:47.86491+00	{"eTag": "\\"937be74cbd4d6c56abe1b7861bb3d303\\"", "size": 110185, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:48.000Z", "contentLength": 110185, "httpStatusCode": 200}	631d262d-cdc0-46df-8916-f732f4d39c7f	\N	{}
1c955797-79d3-4f5c-a88e-b6d0b39574ac	urbateam-media	division-parcellaire.png	\N	2026-06-02 03:37:48.637612+00	2026-06-02 03:37:48.637612+00	2026-06-02 03:37:48.637612+00	{"eTag": "\\"3c482b6ce8718b18252744ee78cf0bfd\\"", "size": 1040147, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:49.000Z", "contentLength": 1040147, "httpStatusCode": 200}	fb79ef75-e02c-44cb-b33b-5f0184b40eeb	\N	{}
0b9f47ea-a830-474e-9c51-732147be1ebe	urbateam-media	ingenierie-sportive.png	\N	2026-06-02 03:37:49.870058+00	2026-06-02 03:37:49.870058+00	2026-06-02 03:37:49.870058+00	{"eTag": "\\"3c8a624b4f3de482e2cc276dd58b3b55\\"", "size": 1047385, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:50.000Z", "contentLength": 1047385, "httpStatusCode": 200}	d8dd837e-02df-4f40-85aa-47990d34a507	\N	{}
c126fdb4-28db-4564-a78c-ddaec18161b0	urbateam-media	scanner-3d-innovation.png	\N	2026-06-02 03:37:50.642539+00	2026-06-02 03:37:50.642539+00	2026-06-02 03:37:50.642539+00	{"eTag": "\\"564a39983f3741410608a142c76752fa\\"", "size": 894811, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:51.000Z", "contentLength": 894811, "httpStatusCode": 200}	06386e31-1fe0-4979-b448-de642ebf60d7	\N	{}
a59fdd85-c601-4f67-b184-4f37a1639876	urbateam-media	scanner-3d.jpg	\N	2026-06-02 03:37:51.003754+00	2026-06-02 03:37:51.003754+00	2026-06-02 03:37:51.003754+00	{"eTag": "\\"c3c62b571ab4bd75446b07c1fca18976\\"", "size": 123438, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:51.000Z", "contentLength": 123438, "httpStatusCode": 200}	b0536ce0-af67-4737-af3c-9998531be1c7	\N	{}
784c2267-bea0-45a6-8a4e-00ed2726f1ea	urbateam-media	vallee-after.webp	\N	2026-06-02 03:37:51.592991+00	2026-06-02 03:37:51.592991+00	2026-06-02 03:37:51.592991+00	{"eTag": "\\"7a067d4bab802bf85cdbc849a563fa85\\"", "size": 969024, "mimetype": "image/webp", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:52.000Z", "contentLength": 969024, "httpStatusCode": 200}	f07394c3-31d0-4972-824c-054b4d1e7e1b	\N	{}
72bc5b00-4f13-4c33-86b2-fff69ec158c9	urbateam-media	vallee-before.webp	\N	2026-06-02 03:37:52.358699+00	2026-06-02 03:37:52.358699+00	2026-06-02 03:37:52.358699+00	{"eTag": "\\"32c942860858a54da9b49f5d03919bfd\\"", "size": 1040668, "mimetype": "image/webp", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:53.000Z", "contentLength": 1040668, "httpStatusCode": 200}	4818985c-cc55-483e-8837-e14031ac4382	\N	{}
9de18732-0134-45fb-895d-d0730da43867	urbateam-media	bmo.webp	\N	2026-06-02 03:37:52.93894+00	2026-06-02 03:37:52.93894+00	2026-06-02 03:37:52.93894+00	{"eTag": "\\"36b545247916b24caf37fad04aefc88e\\"", "size": 9492, "mimetype": "image/webp", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:53.000Z", "contentLength": 9492, "httpStatusCode": 200}	967f93a3-4e95-4b4f-8d3b-91273d99ef77	\N	{}
1a08d2ea-9406-44cc-8b68-3a04ff3db800	urbateam-media	1777520023211-IMG_0470.jpg	\N	2026-06-02 03:37:53.524814+00	2026-06-02 03:37:53.524814+00	2026-06-02 03:37:53.524814+00	{"eTag": "\\"c3c62b571ab4bd75446b07c1fca18976\\"", "size": 123438, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:54.000Z", "contentLength": 123438, "httpStatusCode": 200}	98019ce7-5fda-4888-b3d5-68b5051168ba	\N	{}
ba691b39-16ee-42e2-8497-be83708b4e74	urbateam-media	1777520072885-IMG_0471.jpg	\N	2026-06-02 03:37:54.133499+00	2026-06-02 03:37:54.133499+00	2026-06-02 03:37:54.133499+00	{"eTag": "\\"937be74cbd4d6c56abe1b7861bb3d303\\"", "size": 110185, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:55.000Z", "contentLength": 110185, "httpStatusCode": 200}	71916148-5275-4a82-9226-a0802db72ba0	\N	{}
7286c43f-d011-4ed4-80f0-12a18cc4e551	urbateam-media	1777520079022-IMG_0472.jpg	\N	2026-06-02 03:37:54.540147+00	2026-06-02 03:37:54.540147+00	2026-06-02 03:37:54.540147+00	{"eTag": "\\"9696718d679e26ad07bcbffd60b1c42a\\"", "size": 379606, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:55.000Z", "contentLength": 379606, "httpStatusCode": 200}	28f30746-ee29-463b-9afe-5335f2e3dc12	\N	{}
087d4bb9-5828-4728-99b4-a30396aaef92	urbateam-media	1777520086084-IMG_0474.jpg	\N	2026-06-02 03:37:55.079787+00	2026-06-02 03:37:55.079787+00	2026-06-02 03:37:55.079787+00	{"eTag": "\\"2edfb95c474330ea8cfa9cc9ff82d789\\"", "size": 222541, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:56.000Z", "contentLength": 222541, "httpStatusCode": 200}	0e18f87d-5860-4050-881d-c7beec5af119	\N	{}
de3f180b-d874-4d7c-861a-2428dce6f198	urbateam-media	1777520090386-IMG_0475.jpg	\N	2026-06-02 03:37:55.544942+00	2026-06-02 03:37:55.544942+00	2026-06-02 03:37:55.544942+00	{"eTag": "\\"1f6ed59c7f7391e4ac3bb20499ac3bb0\\"", "size": 220543, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:56.000Z", "contentLength": 220543, "httpStatusCode": 200}	49d5d5c3-b8d2-42ab-902c-1c55d7ae063d	\N	{}
fd076d11-167c-4510-b651-1dc595b1088a	urbateam-media	1777520095758-IMG_0476.jpg	\N	2026-06-02 03:37:56.341044+00	2026-06-02 03:37:56.341044+00	2026-06-02 03:37:56.341044+00	{"eTag": "\\"d25a1856d223ebc1828f187fda65c4bb\\"", "size": 420968, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:57.000Z", "contentLength": 420968, "httpStatusCode": 200}	b05532fb-a08b-4a80-8b3c-dc808e5765e3	\N	{}
d05130db-4bc2-4db7-bc8e-4fab25fb67c7	urbateam-media	1777520102568-IMG_0477.jpg	\N	2026-06-02 03:37:56.953677+00	2026-06-02 03:37:56.953677+00	2026-06-02 03:37:56.953677+00	{"eTag": "\\"768ce84f32210d761ee1cee19ebaed61\\"", "size": 519832, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:57.000Z", "contentLength": 519832, "httpStatusCode": 200}	7907fc3a-21d1-4c94-8882-844d640bdebb	\N	{}
61be886b-a790-47c9-9124-159527f14e86	urbateam-media	1777520111868-IMG_0478.jpg	\N	2026-06-02 03:37:57.525352+00	2026-06-02 03:37:57.525352+00	2026-06-02 03:37:57.525352+00	{"eTag": "\\"2e7af75e66c75b7c9bf95f0cceaae3a6\\"", "size": 164502, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:58.000Z", "contentLength": 164502, "httpStatusCode": 200}	2d43b600-1902-4cea-9854-91d2c542e651	\N	{}
\.


--
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.s3_multipart_uploads (id, in_progress_size, upload_signature, bucket_id, key, version, owner_id, created_at, user_metadata, metadata) FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.s3_multipart_uploads_parts (id, upload_id, size, part_number, bucket_id, key, etag, owner_id, version, created_at) FROM stdin;
\.


--
-- Data for Name: vector_indexes; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.vector_indexes (id, name, bucket_id, data_type, dimension, distance_metric, metadata_configuration, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: supabase_migrations; Owner: postgres
--

COPY supabase_migrations.schema_migrations (version, statements, name) FROM stdin;
20260531000000	{"-- supabase/migrations/20260531000000_create_urbateam_schema.sql\n-- Urbateam Database Schema for Supabase\n\n-- Enable required extensions\nCREATE EXTENSION IF NOT EXISTS \\"uuid-ossp\\"","-- 1. Table ARTICLES (Blog posts)\nCREATE TABLE IF NOT EXISTS articles (\n    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,\n    status TEXT DEFAULT 'published' CHECK (status IN ('published', 'draft')),\n    sort INTEGER,\n    slug TEXT UNIQUE NOT NULL,\n    title TEXT NOT NULL,\n    excerpt TEXT,\n    content TEXT,\n    featured_image TEXT,\n    author TEXT,\n    tags JSONB DEFAULT '[]'::jsonb,\n    category TEXT,\n    date_published TIMESTAMP WITH TIME ZONE DEFAULT NOW(),\n    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),\n    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()\n)","-- 2. Table PROJETS (Portfolio cases with geospatial coordinates)\nCREATE TABLE IF NOT EXISTS projets (\n    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,\n    status TEXT DEFAULT 'published' CHECK (status IN ('published', 'draft')),\n    sort INTEGER,\n    slug TEXT UNIQUE NOT NULL,\n    title TEXT NOT NULL,\n    description TEXT,\n    location TEXT,\n    category TEXT,\n    client TEXT,\n    missions JSONB DEFAULT '[]'::jsonb,\n    technical_details TEXT,\n    image_before TEXT,\n    image_after TEXT,\n    images_gallery JSONB DEFAULT '[]'::jsonb,\n    latitude DOUBLE PRECISION,\n    longitude DOUBLE PRECISION,\n    date TIMESTAMP WITH TIME ZONE,\n    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),\n    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()\n)","-- 3. Table CLIENTS (Logos and brand references)\nCREATE TABLE IF NOT EXISTS clients (\n    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,\n    status TEXT DEFAULT 'published' CHECK (status IN ('published', 'draft')),\n    sort INTEGER,\n    name TEXT NOT NULL,\n    logo TEXT,\n    tags JSONB DEFAULT '[]'::jsonb,\n    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()\n)","-- 4. Table PARTENAIRES (Professional ecosystem)\nCREATE TABLE IF NOT EXISTS partenaires (\n    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,\n    status TEXT DEFAULT 'published' CHECK (status IN ('published', 'draft')),\n    sort INTEGER,\n    name TEXT NOT NULL,\n    logo TEXT,\n    role TEXT,\n    website TEXT,\n    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()\n)","-- 5. Table FAQ (Multilingual Q&A)\nCREATE TABLE IF NOT EXISTS faq (\n    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,\n    status TEXT DEFAULT 'published' CHECK (status IN ('published', 'draft')),\n    sort INTEGER,\n    question_fr TEXT NOT NULL,\n    answer_fr TEXT,\n    question_en TEXT,\n    answer_en TEXT,\n    question_br TEXT,\n    answer_br TEXT,\n    category TEXT,\n    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()\n)","-- 6. Table GLOSSAIRE (Definitions of land terms)\nCREATE TABLE IF NOT EXISTS glossaire (\n    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,\n    status TEXT DEFAULT 'published' CHECK (status IN ('published', 'draft')),\n    sort INTEGER,\n    term_fr TEXT NOT NULL,\n    definition_fr TEXT,\n    term_en TEXT,\n    definition_en TEXT,\n    term_br TEXT,\n    definition_br TEXT,\n    related_expertise TEXT,\n    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()\n)","-- 7. Table TEAM_HEADER (Header photo and intro)\nCREATE TABLE IF NOT EXISTS team_header (\n    id INT PRIMARY KEY DEFAULT 1,\n    title_fr TEXT,\n    subtitle_fr TEXT,\n    title_en TEXT,\n    subtitle_en TEXT,\n    title_br TEXT,\n    subtitle_br TEXT,\n    team_photo TEXT,\n    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),\n    CONSTRAINT only_one_row CHECK (id = 1)\n)","-- 8. Table TEAM_MEMBERS (Team members and specialists)\nCREATE TABLE IF NOT EXISTS team_members (\n    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,\n    status TEXT DEFAULT 'published' CHECK (status IN ('published', 'draft')),\n    sort INTEGER,\n    slug TEXT UNIQUE,\n    image TEXT,\n    linkedin TEXT,\n    generic BOOLEAN DEFAULT FALSE,\n    email TEXT,\n    phone TEXT,\n    name_fr TEXT,\n    role_fr TEXT,\n    desc_fr TEXT,\n    name_en TEXT,\n    role_en TEXT,\n    desc_en TEXT,\n    name_br TEXT,\n    role_br TEXT,\n    desc_br TEXT,\n    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()\n)","-- 9. Table SOCIAL_POSTS (Instagram posts feed)\nCREATE TABLE IF NOT EXISTS social_posts (\n    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,\n    status TEXT DEFAULT 'published' CHECK (status IN ('published', 'draft')),\n    sort INTEGER,\n    url TEXT NOT NULL,\n    caption TEXT,\n    date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),\n    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()\n)","-- Enable Row Level Security (RLS)\n-- We make the reading public for simplicity, and keep write operations private to authenticated admin users (Supabase Auth).\n\nALTER TABLE articles ENABLE ROW LEVEL SECURITY","ALTER TABLE projets ENABLE ROW LEVEL SECURITY","ALTER TABLE clients ENABLE ROW LEVEL SECURITY","ALTER TABLE partenaires ENABLE ROW LEVEL SECURITY","ALTER TABLE faq ENABLE ROW LEVEL SECURITY","ALTER TABLE glossaire ENABLE ROW LEVEL SECURITY","ALTER TABLE team_header ENABLE ROW LEVEL SECURITY","ALTER TABLE team_members ENABLE ROW LEVEL SECURITY","ALTER TABLE social_posts ENABLE ROW LEVEL SECURITY","-- Create Public Read Policies\nCREATE POLICY \\"Allow public read access on articles\\" ON articles FOR SELECT USING (true)","CREATE POLICY \\"Allow public read access on projets\\" ON projets FOR SELECT USING (true)","CREATE POLICY \\"Allow public read access on clients\\" ON clients FOR SELECT USING (true)","CREATE POLICY \\"Allow public read access on partenaires\\" ON partenaires FOR SELECT USING (true)","CREATE POLICY \\"Allow public read access on faq\\" ON faq FOR SELECT USING (true)","CREATE POLICY \\"Allow public read access on glossaire\\" ON glossaire FOR SELECT USING (true)","CREATE POLICY \\"Allow public read access on team_header\\" ON team_header FOR SELECT USING (true)","CREATE POLICY \\"Allow public read access on team_members\\" ON team_members FOR SELECT USING (true)","CREATE POLICY \\"Allow public read access on social_posts\\" ON social_posts FOR SELECT USING (true)","-- Create Write/Modify Policies for Authenticated Admin Users\nCREATE POLICY \\"Allow all actions for authenticated users on articles\\" ON articles FOR ALL TO authenticated USING (true)","CREATE POLICY \\"Allow all actions for authenticated users on projets\\" ON projets FOR ALL TO authenticated USING (true)","CREATE POLICY \\"Allow all actions for authenticated users on clients\\" ON clients FOR ALL TO authenticated USING (true)","CREATE POLICY \\"Allow all actions for authenticated users on partenaires\\" ON partenaires FOR ALL TO authenticated USING (true)","CREATE POLICY \\"Allow all actions for authenticated users on faq\\" ON faq FOR ALL TO authenticated USING (true)","CREATE POLICY \\"Allow all actions for authenticated users on glossaire\\" ON glossaire FOR ALL TO authenticated USING (true)","CREATE POLICY \\"Allow all actions for authenticated users on team_header\\" ON team_header FOR ALL TO authenticated USING (true)","CREATE POLICY \\"Allow all actions for authenticated users on team_members\\" ON team_members FOR ALL TO authenticated USING (true)","CREATE POLICY \\"Allow all actions for authenticated users on social_posts\\" ON social_posts FOR ALL TO authenticated USING (true)"}	create_urbateam_schema
20260531000001	{"-- supabase/migrations/20260531000001_create_simulations_table.sql\n-- Table pour stocker les prospects générés par le Simulateur de Division Foncière\n\nCREATE TABLE IF NOT EXISTS public.simulations (\n    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),\n    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,\n    address TEXT NOT NULL,\n    parcel_ref TEXT,\n    total_surface TEXT,\n    lot_a_surface TEXT,\n    lot_b_surface TEXT,\n    client_name TEXT NOT NULL,\n    client_email TEXT NOT NULL,\n    client_phone TEXT,\n    client_message TEXT,\n    status TEXT DEFAULT 'new' NOT NULL\n)","-- Activation de RLS (Row Level Security)\nALTER TABLE public.simulations ENABLE ROW LEVEL SECURITY","-- Politique d'insertion publique (permet à n'importe quel prospect de soumettre sa simulation)\nCREATE POLICY \\"Allow public inserts on simulations\\" \nON public.simulations \nFOR INSERT \nWITH CHECK (true)","-- Politiques administratives (lecture/mise à jour/suppression uniquement pour les admins connectés)\nCREATE POLICY \\"Allow authenticated select on simulations\\" \nON public.simulations \nFOR SELECT \nTO authenticated \nUSING (true)","CREATE POLICY \\"Allow authenticated update on simulations\\" \nON public.simulations \nFOR UPDATE \nTO authenticated \nUSING (true)","CREATE POLICY \\"Allow authenticated delete on simulations\\" \nON public.simulations \nFOR DELETE \nTO authenticated \nUSING (true)"}	create_simulations_table
20260531000002	{"-- supabase/migrations/20260531000002_secure_rls_policies.sql\n-- Sécurisation des politiques RLS pour la mise en production\n\n-- 1. Nettoyage des anciennes politiques permissives\nDROP POLICY IF EXISTS \\"Allow all actions for authenticated users on articles\\" ON articles","DROP POLICY IF EXISTS \\"Allow all actions for authenticated users on projets\\" ON projets","DROP POLICY IF EXISTS \\"Allow all actions for authenticated users on clients\\" ON clients","DROP POLICY IF EXISTS \\"Allow all actions for authenticated users on partenaires\\" ON partenaires","DROP POLICY IF EXISTS \\"Allow all actions for authenticated users on faq\\" ON faq","DROP POLICY IF EXISTS \\"Allow all actions for authenticated users on glossaire\\" ON glossaire","DROP POLICY IF EXISTS \\"Allow all actions for authenticated users on team_header\\" ON team_header","DROP POLICY IF EXISTS \\"Allow all actions for authenticated users on team_members\\" ON team_members","DROP POLICY IF EXISTS \\"Allow all actions for authenticated users on social_posts\\" ON social_posts","DROP POLICY IF EXISTS \\"Allow authenticated select on simulations\\" ON public.simulations","DROP POLICY IF EXISTS \\"Allow authenticated update on simulations\\" ON public.simulations","DROP POLICY IF EXISTS \\"Allow authenticated delete on simulations\\" ON public.simulations","-- 2. Création de politiques basées sur l'adresse email de l'administrateur\nCREATE POLICY \\"Allow admin write access on articles\\" ON articles \n    FOR ALL TO authenticated \n    USING (auth.jwt() ->> 'email' = 'admin@urbateam.fr')\n    WITH CHECK (auth.jwt() ->> 'email' = 'admin@urbateam.fr')","CREATE POLICY \\"Allow admin write access on projets\\" ON projets \n    FOR ALL TO authenticated \n    USING (auth.jwt() ->> 'email' = 'admin@urbateam.fr')\n    WITH CHECK (auth.jwt() ->> 'email' = 'admin@urbateam.fr')","CREATE POLICY \\"Allow admin write access on clients\\" ON clients \n    FOR ALL TO authenticated \n    USING (auth.jwt() ->> 'email' = 'admin@urbateam.fr')\n    WITH CHECK (auth.jwt() ->> 'email' = 'admin@urbateam.fr')","CREATE POLICY \\"Allow admin write access on partenaires\\" ON partenaires \n    FOR ALL TO authenticated \n    USING (auth.jwt() ->> 'email' = 'admin@urbateam.fr')\n    WITH CHECK (auth.jwt() ->> 'email' = 'admin@urbateam.fr')","CREATE POLICY \\"Allow admin write access on faq\\" ON faq \n    FOR ALL TO authenticated \n    USING (auth.jwt() ->> 'email' = 'admin@urbateam.fr')\n    WITH CHECK (auth.jwt() ->> 'email' = 'admin@urbateam.fr')","CREATE POLICY \\"Allow admin write access on glossaire\\" ON glossaire \n    FOR ALL TO authenticated \n    USING (auth.jwt() ->> 'email' = 'admin@urbateam.fr')\n    WITH CHECK (auth.jwt() ->> 'email' = 'admin@urbateam.fr')","CREATE POLICY \\"Allow admin write access on team_header\\" ON team_header \n    FOR ALL TO authenticated \n    USING (auth.jwt() ->> 'email' = 'admin@urbateam.fr')\n    WITH CHECK (auth.jwt() ->> 'email' = 'admin@urbateam.fr')","CREATE POLICY \\"Allow admin write access on team_members\\" ON team_members \n    FOR ALL TO authenticated \n    USING (auth.jwt() ->> 'email' = 'admin@urbateam.fr')\n    WITH CHECK (auth.jwt() ->> 'email' = 'admin@urbateam.fr')","CREATE POLICY \\"Allow admin write access on social_posts\\" ON social_posts \n    FOR ALL TO authenticated \n    USING (auth.jwt() ->> 'email' = 'admin@urbateam.fr')\n    WITH CHECK (auth.jwt() ->> 'email' = 'admin@urbateam.fr')","-- 3. Sécurisation stricte des simulations (leads clients)\nCREATE POLICY \\"Allow admin full access on simulations\\" ON public.simulations \n    FOR ALL TO authenticated \n    USING (auth.jwt() ->> 'email' = 'admin@urbateam.fr')\n    WITH CHECK (auth.jwt() ->> 'email' = 'admin@urbateam.fr')"}	secure_rls_policies
20260602000003	{"-- supabase/migrations/20260602000003_create_visits_table.sql\n-- Create table to track live user visits in real-time\n\nCREATE TABLE IF NOT EXISTS public.visits (\n    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,\n    path TEXT NOT NULL,\n    is_article BOOLEAN DEFAULT FALSE,\n    device TEXT DEFAULT 'Desktop',\n    browser TEXT DEFAULT 'Autre',\n    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()\n)","-- Enable Row Level Security (RLS)\nALTER TABLE public.visits ENABLE ROW LEVEL SECURITY","-- 1. Policy to allow anonymous visitors to log page visits\nCREATE POLICY \\"Allow public insert on visits\\" ON public.visits\n    FOR INSERT WITH CHECK (true)","-- 2. Policy to restrict select queries to admin@urbateam.fr users\nCREATE POLICY \\"Allow admin read access on visits\\" ON public.visits\n    FOR SELECT TO authenticated\n    USING (auth.jwt() ->> 'email' = 'admin@urbateam.fr')"}	create_visits_table
\.


--
-- Data for Name: secrets; Type: TABLE DATA; Schema: vault; Owner: supabase_admin
--

COPY vault.secrets (id, name, description, secret, key_id, nonce, created_at, updated_at) FROM stdin;
\.


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: supabase_auth_admin
--

SELECT pg_catalog.setval('auth.refresh_tokens_id_seq', 18, true);


--
-- Name: articles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.articles_id_seq', 5, true);


--
-- Name: clients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.clients_id_seq', 30, true);


--
-- Name: faq_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.faq_id_seq', 24, true);


--
-- Name: glossaire_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.glossaire_id_seq', 65, true);


--
-- Name: partenaires_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.partenaires_id_seq', 1, false);


--
-- Name: projets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.projets_id_seq', 1, true);


--
-- Name: social_posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.social_posts_id_seq', 8, true);


--
-- Name: team_members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.team_members_id_seq', 11, true);


--
-- Name: visits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.visits_id_seq', 508, true);


--
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: supabase_admin
--

SELECT pg_catalog.setval('realtime.subscription_id_seq', 1, false);


--
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT amr_id_pk PRIMARY KEY (id);


--
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.audit_log_entries
    ADD CONSTRAINT audit_log_entries_pkey PRIMARY KEY (id);


--
-- Name: custom_oauth_providers custom_oauth_providers_identifier_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.custom_oauth_providers
    ADD CONSTRAINT custom_oauth_providers_identifier_key UNIQUE (identifier);


--
-- Name: custom_oauth_providers custom_oauth_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.custom_oauth_providers
    ADD CONSTRAINT custom_oauth_providers_pkey PRIMARY KEY (id);


--
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.flow_state
    ADD CONSTRAINT flow_state_pkey PRIMARY KEY (id);


--
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_pkey PRIMARY KEY (id);


--
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_provider_id_provider_unique UNIQUE (provider_id, provider);


--
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.instances
    ADD CONSTRAINT instances_pkey PRIMARY KEY (id);


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_authentication_method_pkey UNIQUE (session_id, authentication_method);


--
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_pkey PRIMARY KEY (id);


--
-- Name: mfa_factors mfa_factors_last_challenged_at_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_last_challenged_at_key UNIQUE (last_challenged_at);


--
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_pkey PRIMARY KEY (id);


--
-- Name: oauth_authorizations oauth_authorizations_authorization_code_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_authorization_code_key UNIQUE (authorization_code);


--
-- Name: oauth_authorizations oauth_authorizations_authorization_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_authorization_id_key UNIQUE (authorization_id);


--
-- Name: oauth_authorizations oauth_authorizations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_pkey PRIMARY KEY (id);


--
-- Name: oauth_client_states oauth_client_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_client_states
    ADD CONSTRAINT oauth_client_states_pkey PRIMARY KEY (id);


--
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_clients
    ADD CONSTRAINT oauth_clients_pkey PRIMARY KEY (id);


--
-- Name: oauth_consents oauth_consents_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_pkey PRIMARY KEY (id);


--
-- Name: oauth_consents oauth_consents_user_client_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_user_client_unique UNIQUE (user_id, client_id);


--
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_unique UNIQUE (token);


--
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_entity_id_key UNIQUE (entity_id);


--
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_pkey PRIMARY KEY (id);


--
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_pkey PRIMARY KEY (id);


--
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_providers
    ADD CONSTRAINT sso_providers_pkey PRIMARY KEY (id);


--
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_phone_key UNIQUE (phone);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: webauthn_challenges webauthn_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.webauthn_challenges
    ADD CONSTRAINT webauthn_challenges_pkey PRIMARY KEY (id);


--
-- Name: webauthn_credentials webauthn_credentials_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_pkey PRIMARY KEY (id);


--
-- Name: articles articles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_pkey PRIMARY KEY (id);


--
-- Name: articles articles_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_slug_key UNIQUE (slug);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: faq faq_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faq
    ADD CONSTRAINT faq_pkey PRIMARY KEY (id);


--
-- Name: glossaire glossaire_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.glossaire
    ADD CONSTRAINT glossaire_pkey PRIMARY KEY (id);


--
-- Name: partenaires partenaires_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.partenaires
    ADD CONSTRAINT partenaires_pkey PRIMARY KEY (id);


--
-- Name: projets projets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projets
    ADD CONSTRAINT projets_pkey PRIMARY KEY (id);


--
-- Name: projets projets_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projets
    ADD CONSTRAINT projets_slug_key UNIQUE (slug);


--
-- Name: simulations simulations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.simulations
    ADD CONSTRAINT simulations_pkey PRIMARY KEY (id);


--
-- Name: site_texts site_texts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.site_texts
    ADD CONSTRAINT site_texts_pkey PRIMARY KEY (key);


--
-- Name: social_posts social_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.social_posts
    ADD CONSTRAINT social_posts_pkey PRIMARY KEY (id);


--
-- Name: team_header team_header_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team_header
    ADD CONSTRAINT team_header_pkey PRIMARY KEY (id);


--
-- Name: team_members team_members_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_pkey PRIMARY KEY (id);


--
-- Name: team_members team_members_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_slug_key UNIQUE (slug);


--
-- Name: visits visits_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.visits
    ADD CONSTRAINT visits_pkey PRIMARY KEY (id);


--
-- Name: messages messages_payload_exclusive; Type: CHECK CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE realtime.messages
    ADD CONSTRAINT messages_payload_exclusive CHECK (((payload IS NULL) OR (binary_payload IS NULL))) NOT VALID;


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY realtime.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: subscription pk_subscription; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.subscription
    ADD CONSTRAINT pk_subscription PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: buckets_analytics buckets_analytics_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.buckets_analytics
    ADD CONSTRAINT buckets_analytics_pkey PRIMARY KEY (id);


--
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.buckets
    ADD CONSTRAINT buckets_pkey PRIMARY KEY (id);


--
-- Name: buckets_vectors buckets_vectors_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.buckets_vectors
    ADD CONSTRAINT buckets_vectors_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_name_key UNIQUE (name);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT objects_pkey PRIMARY KEY (id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_pkey PRIMARY KEY (id);


--
-- Name: s3_multipart_uploads s3_multipart_uploads_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_pkey PRIMARY KEY (id);


--
-- Name: vector_indexes vector_indexes_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.vector_indexes
    ADD CONSTRAINT vector_indexes_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: supabase_migrations; Owner: postgres
--

ALTER TABLE ONLY supabase_migrations.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX audit_logs_instance_id_idx ON auth.audit_log_entries USING btree (instance_id);


--
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX confirmation_token_idx ON auth.users USING btree (confirmation_token) WHERE ((confirmation_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: custom_oauth_providers_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX custom_oauth_providers_created_at_idx ON auth.custom_oauth_providers USING btree (created_at);


--
-- Name: custom_oauth_providers_enabled_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX custom_oauth_providers_enabled_idx ON auth.custom_oauth_providers USING btree (enabled);


--
-- Name: custom_oauth_providers_identifier_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX custom_oauth_providers_identifier_idx ON auth.custom_oauth_providers USING btree (identifier);


--
-- Name: custom_oauth_providers_provider_type_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX custom_oauth_providers_provider_type_idx ON auth.custom_oauth_providers USING btree (provider_type);


--
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX email_change_token_current_idx ON auth.users USING btree (email_change_token_current) WHERE ((email_change_token_current)::text !~ '^[0-9 ]*$'::text);


--
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX email_change_token_new_idx ON auth.users USING btree (email_change_token_new) WHERE ((email_change_token_new)::text !~ '^[0-9 ]*$'::text);


--
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX factor_id_created_at_idx ON auth.mfa_factors USING btree (user_id, created_at);


--
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX flow_state_created_at_idx ON auth.flow_state USING btree (created_at DESC);


--
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX identities_email_idx ON auth.identities USING btree (email text_pattern_ops);


--
-- Name: INDEX identities_email_idx; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX auth.identities_email_idx IS 'Auth: Ensures indexed queries on the email column';


--
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX identities_user_id_idx ON auth.identities USING btree (user_id);


--
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_auth_code ON auth.flow_state USING btree (auth_code);


--
-- Name: idx_oauth_client_states_created_at; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_oauth_client_states_created_at ON auth.oauth_client_states USING btree (created_at);


--
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_user_id_auth_method ON auth.flow_state USING btree (user_id, authentication_method);


--
-- Name: idx_users_created_at_desc; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_users_created_at_desc ON auth.users USING btree (created_at DESC);


--
-- Name: idx_users_email; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_users_email ON auth.users USING btree (email);


--
-- Name: idx_users_last_sign_in_at_desc; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_users_last_sign_in_at_desc ON auth.users USING btree (last_sign_in_at DESC);


--
-- Name: idx_users_name; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_users_name ON auth.users USING btree (((raw_user_meta_data ->> 'name'::text))) WHERE ((raw_user_meta_data ->> 'name'::text) IS NOT NULL);


--
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX mfa_challenge_created_at_idx ON auth.mfa_challenges USING btree (created_at DESC);


--
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX mfa_factors_user_friendly_name_unique ON auth.mfa_factors USING btree (friendly_name, user_id) WHERE (TRIM(BOTH FROM friendly_name) <> ''::text);


--
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX mfa_factors_user_id_idx ON auth.mfa_factors USING btree (user_id);


--
-- Name: oauth_auth_pending_exp_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_auth_pending_exp_idx ON auth.oauth_authorizations USING btree (expires_at) WHERE (status = 'pending'::auth.oauth_authorization_status);


--
-- Name: oauth_clients_deleted_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_clients_deleted_at_idx ON auth.oauth_clients USING btree (deleted_at);


--
-- Name: oauth_consents_active_client_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_consents_active_client_idx ON auth.oauth_consents USING btree (client_id) WHERE (revoked_at IS NULL);


--
-- Name: oauth_consents_active_user_client_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_consents_active_user_client_idx ON auth.oauth_consents USING btree (user_id, client_id) WHERE (revoked_at IS NULL);


--
-- Name: oauth_consents_user_order_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_consents_user_order_idx ON auth.oauth_consents USING btree (user_id, granted_at DESC);


--
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX one_time_tokens_relates_to_hash_idx ON auth.one_time_tokens USING hash (relates_to);


--
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX one_time_tokens_token_hash_hash_idx ON auth.one_time_tokens USING hash (token_hash);


--
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX one_time_tokens_user_id_token_type_key ON auth.one_time_tokens USING btree (user_id, token_type);


--
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX reauthentication_token_idx ON auth.users USING btree (reauthentication_token) WHERE ((reauthentication_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX recovery_token_idx ON auth.users USING btree (recovery_token) WHERE ((recovery_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_instance_id_idx ON auth.refresh_tokens USING btree (instance_id);


--
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_instance_id_user_id_idx ON auth.refresh_tokens USING btree (instance_id, user_id);


--
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_parent_idx ON auth.refresh_tokens USING btree (parent);


--
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_session_id_revoked_idx ON auth.refresh_tokens USING btree (session_id, revoked);


--
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_updated_at_idx ON auth.refresh_tokens USING btree (updated_at DESC);


--
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_providers_sso_provider_id_idx ON auth.saml_providers USING btree (sso_provider_id);


--
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_created_at_idx ON auth.saml_relay_states USING btree (created_at DESC);


--
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_for_email_idx ON auth.saml_relay_states USING btree (for_email);


--
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_sso_provider_id_idx ON auth.saml_relay_states USING btree (sso_provider_id);


--
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sessions_not_after_idx ON auth.sessions USING btree (not_after DESC);


--
-- Name: sessions_oauth_client_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sessions_oauth_client_id_idx ON auth.sessions USING btree (oauth_client_id);


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sessions_user_id_idx ON auth.sessions USING btree (user_id);


--
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX sso_domains_domain_idx ON auth.sso_domains USING btree (lower(domain));


--
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sso_domains_sso_provider_id_idx ON auth.sso_domains USING btree (sso_provider_id);


--
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX sso_providers_resource_id_idx ON auth.sso_providers USING btree (lower(resource_id));


--
-- Name: sso_providers_resource_id_pattern_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sso_providers_resource_id_pattern_idx ON auth.sso_providers USING btree (resource_id text_pattern_ops);


--
-- Name: unique_phone_factor_per_user; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX unique_phone_factor_per_user ON auth.mfa_factors USING btree (user_id, phone);


--
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX user_id_created_at_idx ON auth.sessions USING btree (user_id, created_at);


--
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX users_email_partial_key ON auth.users USING btree (email) WHERE (is_sso_user = false);


--
-- Name: INDEX users_email_partial_key; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX auth.users_email_partial_key IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_instance_id_email_idx ON auth.users USING btree (instance_id, lower((email)::text));


--
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_instance_id_idx ON auth.users USING btree (instance_id);


--
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_is_anonymous_idx ON auth.users USING btree (is_anonymous);


--
-- Name: webauthn_challenges_expires_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX webauthn_challenges_expires_at_idx ON auth.webauthn_challenges USING btree (expires_at);


--
-- Name: webauthn_challenges_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX webauthn_challenges_user_id_idx ON auth.webauthn_challenges USING btree (user_id);


--
-- Name: webauthn_credentials_credential_id_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX webauthn_credentials_credential_id_key ON auth.webauthn_credentials USING btree (credential_id);


--
-- Name: webauthn_credentials_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX webauthn_credentials_user_id_idx ON auth.webauthn_credentials USING btree (user_id);


--
-- Name: ix_realtime_subscription_entity; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX ix_realtime_subscription_entity ON realtime.subscription USING btree (entity);


--
-- Name: messages_inserted_at_topic_index; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX messages_inserted_at_topic_index ON ONLY realtime.messages USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- Name: subscription_subscription_id_entity_filters_action_filter_selec; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE UNIQUE INDEX subscription_subscription_id_entity_filters_action_filter_selec ON realtime.subscription USING btree (subscription_id, entity, filters, action_filter, COALESCE(selected_columns, '{}'::text[]));


--
-- Name: bname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX bname ON storage.buckets USING btree (name);


--
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX bucketid_objname ON storage.objects USING btree (bucket_id, name);


--
-- Name: buckets_analytics_unique_name_idx; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX buckets_analytics_unique_name_idx ON storage.buckets_analytics USING btree (name) WHERE (deleted_at IS NULL);


--
-- Name: idx_multipart_uploads_list; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_multipart_uploads_list ON storage.s3_multipart_uploads USING btree (bucket_id, key, created_at);


--
-- Name: idx_objects_bucket_id_name; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_objects_bucket_id_name ON storage.objects USING btree (bucket_id, name COLLATE "C");


--
-- Name: idx_objects_bucket_id_name_lower; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_objects_bucket_id_name_lower ON storage.objects USING btree (bucket_id, lower(name) COLLATE "C");


--
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX name_prefix_search ON storage.objects USING btree (name text_pattern_ops);


--
-- Name: vector_indexes_name_bucket_id_idx; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX vector_indexes_name_bucket_id_idx ON storage.vector_indexes USING btree (name, bucket_id);


--
-- Name: subscription tr_check_filters; Type: TRIGGER; Schema: realtime; Owner: supabase_admin
--

CREATE TRIGGER tr_check_filters BEFORE INSERT OR UPDATE ON realtime.subscription FOR EACH ROW EXECUTE FUNCTION realtime.subscription_check_filters();


--
-- Name: buckets enforce_bucket_name_length_trigger; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER enforce_bucket_name_length_trigger BEFORE INSERT OR UPDATE OF name ON storage.buckets FOR EACH ROW EXECUTE FUNCTION storage.enforce_bucket_name_length();


--
-- Name: buckets protect_buckets_delete; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER protect_buckets_delete BEFORE DELETE ON storage.buckets FOR EACH STATEMENT EXECUTE FUNCTION storage.protect_delete();


--
-- Name: objects protect_objects_delete; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER protect_objects_delete BEFORE DELETE ON storage.objects FOR EACH STATEMENT EXECUTE FUNCTION storage.protect_delete();


--
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER update_objects_updated_at BEFORE UPDATE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.update_updated_at_column();


--
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_auth_factor_id_fkey FOREIGN KEY (factor_id) REFERENCES auth.mfa_factors(id) ON DELETE CASCADE;


--
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_client_id_fkey FOREIGN KEY (client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_client_id_fkey FOREIGN KEY (client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_flow_state_id_fkey FOREIGN KEY (flow_state_id) REFERENCES auth.flow_state(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_oauth_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_oauth_client_id_fkey FOREIGN KEY (oauth_client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: webauthn_challenges webauthn_challenges_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.webauthn_challenges
    ADD CONSTRAINT webauthn_challenges_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: webauthn_credentials webauthn_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads s3_multipart_uploads_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_upload_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES storage.s3_multipart_uploads(id) ON DELETE CASCADE;


--
-- Name: vector_indexes vector_indexes_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.vector_indexes
    ADD CONSTRAINT vector_indexes_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets_vectors(id);


--
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.audit_log_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.flow_state ENABLE ROW LEVEL SECURITY;

--
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.identities ENABLE ROW LEVEL SECURITY;

--
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.instances ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_amr_claims ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_challenges ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_factors ENABLE ROW LEVEL SECURITY;

--
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.one_time_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.refresh_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.saml_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.saml_relay_states ENABLE ROW LEVEL SECURITY;

--
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.schema_migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sso_domains ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sso_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

--
-- Name: simulations Allow admin full access on simulations; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow admin full access on simulations" ON public.simulations TO authenticated USING (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text)) WITH CHECK (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text));


--
-- Name: visits Allow admin read access on visits; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow admin read access on visits" ON public.visits FOR SELECT TO authenticated USING (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text));


--
-- Name: articles Allow admin write access on articles; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow admin write access on articles" ON public.articles TO authenticated USING (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text)) WITH CHECK (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text));


--
-- Name: clients Allow admin write access on clients; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow admin write access on clients" ON public.clients TO authenticated USING (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text)) WITH CHECK (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text));


--
-- Name: faq Allow admin write access on faq; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow admin write access on faq" ON public.faq TO authenticated USING (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text)) WITH CHECK (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text));


--
-- Name: glossaire Allow admin write access on glossaire; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow admin write access on glossaire" ON public.glossaire TO authenticated USING (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text)) WITH CHECK (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text));


--
-- Name: partenaires Allow admin write access on partenaires; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow admin write access on partenaires" ON public.partenaires TO authenticated USING (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text)) WITH CHECK (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text));


--
-- Name: projets Allow admin write access on projets; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow admin write access on projets" ON public.projets TO authenticated USING (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text)) WITH CHECK (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text));


--
-- Name: social_posts Allow admin write access on social_posts; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow admin write access on social_posts" ON public.social_posts TO authenticated USING (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text)) WITH CHECK (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text));


--
-- Name: team_header Allow admin write access on team_header; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow admin write access on team_header" ON public.team_header TO authenticated USING (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text)) WITH CHECK (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text));


--
-- Name: team_members Allow admin write access on team_members; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow admin write access on team_members" ON public.team_members TO authenticated USING (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text)) WITH CHECK (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text));


--
-- Name: site_texts Allow all actions for authenticated users on site_texts; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow all actions for authenticated users on site_texts" ON public.site_texts TO authenticated USING (true);


--
-- Name: visits Allow public insert on visits; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public insert on visits" ON public.visits FOR INSERT WITH CHECK (true);


--
-- Name: simulations Allow public inserts on simulations; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public inserts on simulations" ON public.simulations FOR INSERT WITH CHECK (true);


--
-- Name: articles Allow public read access on articles; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public read access on articles" ON public.articles FOR SELECT USING (true);


--
-- Name: clients Allow public read access on clients; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public read access on clients" ON public.clients FOR SELECT USING (true);


--
-- Name: faq Allow public read access on faq; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public read access on faq" ON public.faq FOR SELECT USING (true);


--
-- Name: glossaire Allow public read access on glossaire; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public read access on glossaire" ON public.glossaire FOR SELECT USING (true);


--
-- Name: partenaires Allow public read access on partenaires; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public read access on partenaires" ON public.partenaires FOR SELECT USING (true);


--
-- Name: projets Allow public read access on projets; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public read access on projets" ON public.projets FOR SELECT USING (true);


--
-- Name: site_texts Allow public read access on site_texts; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public read access on site_texts" ON public.site_texts FOR SELECT USING (true);


--
-- Name: social_posts Allow public read access on social_posts; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public read access on social_posts" ON public.social_posts FOR SELECT USING (true);


--
-- Name: team_header Allow public read access on team_header; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public read access on team_header" ON public.team_header FOR SELECT USING (true);


--
-- Name: team_members Allow public read access on team_members; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public read access on team_members" ON public.team_members FOR SELECT USING (true);


--
-- Name: articles; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.articles ENABLE ROW LEVEL SECURITY;

--
-- Name: clients; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.clients ENABLE ROW LEVEL SECURITY;

--
-- Name: faq; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.faq ENABLE ROW LEVEL SECURITY;

--
-- Name: glossaire; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.glossaire ENABLE ROW LEVEL SECURITY;

--
-- Name: partenaires; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.partenaires ENABLE ROW LEVEL SECURITY;

--
-- Name: projets; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.projets ENABLE ROW LEVEL SECURITY;

--
-- Name: simulations; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.simulations ENABLE ROW LEVEL SECURITY;

--
-- Name: site_texts; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.site_texts ENABLE ROW LEVEL SECURITY;

--
-- Name: social_posts; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.social_posts ENABLE ROW LEVEL SECURITY;

--
-- Name: team_header; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.team_header ENABLE ROW LEVEL SECURITY;

--
-- Name: team_members; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.team_members ENABLE ROW LEVEL SECURITY;

--
-- Name: visits; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.visits ENABLE ROW LEVEL SECURITY;

--
-- Name: messages; Type: ROW SECURITY; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE realtime.messages ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.buckets ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_analytics; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.buckets_analytics ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_vectors; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.buckets_vectors ENABLE ROW LEVEL SECURITY;

--
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.s3_multipart_uploads ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads_parts; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.s3_multipart_uploads_parts ENABLE ROW LEVEL SECURITY;

--
-- Name: vector_indexes; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.vector_indexes ENABLE ROW LEVEL SECURITY;

--
-- Name: supabase_realtime; Type: PUBLICATION; Schema: -; Owner: postgres
--

CREATE PUBLICATION supabase_realtime WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION supabase_realtime OWNER TO postgres;

--
-- Name: SCHEMA auth; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA auth TO anon;
GRANT USAGE ON SCHEMA auth TO authenticated;
GRANT USAGE ON SCHEMA auth TO service_role;
GRANT ALL ON SCHEMA auth TO supabase_auth_admin;
GRANT ALL ON SCHEMA auth TO dashboard_user;
GRANT USAGE ON SCHEMA auth TO postgres;


--
-- Name: SCHEMA extensions; Type: ACL; Schema: -; Owner: postgres
--

GRANT USAGE ON SCHEMA extensions TO anon;
GRANT USAGE ON SCHEMA extensions TO authenticated;
GRANT USAGE ON SCHEMA extensions TO service_role;
GRANT ALL ON SCHEMA extensions TO dashboard_user;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO postgres;
GRANT USAGE ON SCHEMA public TO anon;
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT USAGE ON SCHEMA public TO service_role;


--
-- Name: SCHEMA realtime; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA realtime TO postgres;
GRANT USAGE ON SCHEMA realtime TO anon;
GRANT USAGE ON SCHEMA realtime TO authenticated;
GRANT USAGE ON SCHEMA realtime TO service_role;
GRANT ALL ON SCHEMA realtime TO supabase_realtime_admin;


--
-- Name: SCHEMA storage; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA storage TO postgres WITH GRANT OPTION;
GRANT USAGE ON SCHEMA storage TO anon;
GRANT USAGE ON SCHEMA storage TO authenticated;
GRANT USAGE ON SCHEMA storage TO service_role;
GRANT ALL ON SCHEMA storage TO supabase_storage_admin WITH GRANT OPTION;
GRANT ALL ON SCHEMA storage TO dashboard_user;


--
-- Name: SCHEMA vault; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA vault TO postgres WITH GRANT OPTION;
GRANT USAGE ON SCHEMA vault TO service_role;


--
-- Name: FUNCTION email(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.email() TO dashboard_user;


--
-- Name: FUNCTION jwt(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.jwt() TO postgres;
GRANT ALL ON FUNCTION auth.jwt() TO dashboard_user;


--
-- Name: FUNCTION role(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.role() TO dashboard_user;


--
-- Name: FUNCTION uid(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.uid() TO dashboard_user;


--
-- Name: FUNCTION armor(bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.armor(bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.armor(bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.armor(bytea) TO dashboard_user;


--
-- Name: FUNCTION armor(bytea, text[], text[]); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.armor(bytea, text[], text[]) FROM postgres;
GRANT ALL ON FUNCTION extensions.armor(bytea, text[], text[]) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.armor(bytea, text[], text[]) TO dashboard_user;


--
-- Name: FUNCTION crypt(text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.crypt(text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.crypt(text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.crypt(text, text) TO dashboard_user;


--
-- Name: FUNCTION dearmor(text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.dearmor(text) FROM postgres;
GRANT ALL ON FUNCTION extensions.dearmor(text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.dearmor(text) TO dashboard_user;


--
-- Name: FUNCTION decrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.decrypt(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.decrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.decrypt(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION decrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.decrypt_iv(bytea, bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.decrypt_iv(bytea, bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.decrypt_iv(bytea, bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION digest(bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.digest(bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.digest(bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.digest(bytea, text) TO dashboard_user;


--
-- Name: FUNCTION digest(text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.digest(text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.digest(text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.digest(text, text) TO dashboard_user;


--
-- Name: FUNCTION encrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.encrypt(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.encrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.encrypt(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION encrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.encrypt_iv(bytea, bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.encrypt_iv(bytea, bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.encrypt_iv(bytea, bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION gen_random_bytes(integer); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.gen_random_bytes(integer) FROM postgres;
GRANT ALL ON FUNCTION extensions.gen_random_bytes(integer) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.gen_random_bytes(integer) TO dashboard_user;


--
-- Name: FUNCTION gen_random_uuid(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.gen_random_uuid() FROM postgres;
GRANT ALL ON FUNCTION extensions.gen_random_uuid() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.gen_random_uuid() TO dashboard_user;


--
-- Name: FUNCTION gen_salt(text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.gen_salt(text) FROM postgres;
GRANT ALL ON FUNCTION extensions.gen_salt(text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.gen_salt(text) TO dashboard_user;


--
-- Name: FUNCTION gen_salt(text, integer); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.gen_salt(text, integer) FROM postgres;
GRANT ALL ON FUNCTION extensions.gen_salt(text, integer) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.gen_salt(text, integer) TO dashboard_user;


--
-- Name: FUNCTION grant_pg_cron_access(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION extensions.grant_pg_cron_access() FROM supabase_admin;
GRANT ALL ON FUNCTION extensions.grant_pg_cron_access() TO supabase_admin WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.grant_pg_cron_access() TO dashboard_user;


--
-- Name: FUNCTION grant_pg_graphql_access(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.grant_pg_graphql_access() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION grant_pg_net_access(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION extensions.grant_pg_net_access() FROM supabase_admin;
GRANT ALL ON FUNCTION extensions.grant_pg_net_access() TO supabase_admin WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.grant_pg_net_access() TO dashboard_user;


--
-- Name: FUNCTION hmac(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.hmac(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.hmac(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.hmac(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION hmac(text, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.hmac(text, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.hmac(text, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.hmac(text, text, text) TO dashboard_user;


--
-- Name: FUNCTION pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT shared_blk_read_time double precision, OUT shared_blk_write_time double precision, OUT local_blk_read_time double precision, OUT local_blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision, OUT jit_deform_count bigint, OUT jit_deform_time double precision, OUT stats_since timestamp with time zone, OUT minmax_stats_since timestamp with time zone); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT shared_blk_read_time double precision, OUT shared_blk_write_time double precision, OUT local_blk_read_time double precision, OUT local_blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision, OUT jit_deform_count bigint, OUT jit_deform_time double precision, OUT stats_since timestamp with time zone, OUT minmax_stats_since timestamp with time zone) FROM postgres;
GRANT ALL ON FUNCTION extensions.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT shared_blk_read_time double precision, OUT shared_blk_write_time double precision, OUT local_blk_read_time double precision, OUT local_blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision, OUT jit_deform_count bigint, OUT jit_deform_time double precision, OUT stats_since timestamp with time zone, OUT minmax_stats_since timestamp with time zone) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT shared_blk_read_time double precision, OUT shared_blk_write_time double precision, OUT local_blk_read_time double precision, OUT local_blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision, OUT jit_deform_count bigint, OUT jit_deform_time double precision, OUT stats_since timestamp with time zone, OUT minmax_stats_since timestamp with time zone) TO dashboard_user;


--
-- Name: FUNCTION pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone) FROM postgres;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone) TO dashboard_user;


--
-- Name: FUNCTION pg_stat_statements_reset(userid oid, dbid oid, queryid bigint, minmax_only boolean); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pg_stat_statements_reset(userid oid, dbid oid, queryid bigint, minmax_only boolean) FROM postgres;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_reset(userid oid, dbid oid, queryid bigint, minmax_only boolean) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_reset(userid oid, dbid oid, queryid bigint, minmax_only boolean) TO dashboard_user;


--
-- Name: FUNCTION pgp_armor_headers(text, OUT key text, OUT value text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_armor_headers(text, OUT key text, OUT value text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_armor_headers(text, OUT key text, OUT value text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_armor_headers(text, OUT key text, OUT value text) TO dashboard_user;


--
-- Name: FUNCTION pgp_key_id(bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_key_id(bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_key_id(bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_key_id(bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_encrypt(text, bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_encrypt(text, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_decrypt(bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_decrypt(bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_encrypt(text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_encrypt(text, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgrst_ddl_watch(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgrst_ddl_watch() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION pgrst_drop_watch(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgrst_drop_watch() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION set_graphql_placeholder(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.set_graphql_placeholder() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION uuid_generate_v1(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v1() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1() TO dashboard_user;


--
-- Name: FUNCTION uuid_generate_v1mc(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v1mc() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1mc() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1mc() TO dashboard_user;


--
-- Name: FUNCTION uuid_generate_v3(namespace uuid, name text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v3(namespace uuid, name text) FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v3(namespace uuid, name text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v3(namespace uuid, name text) TO dashboard_user;


--
-- Name: FUNCTION uuid_generate_v4(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v4() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v4() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v4() TO dashboard_user;


--
-- Name: FUNCTION uuid_generate_v5(namespace uuid, name text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v5(namespace uuid, name text) FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v5(namespace uuid, name text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v5(namespace uuid, name text) TO dashboard_user;


--
-- Name: FUNCTION uuid_nil(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_nil() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_nil() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_nil() TO dashboard_user;


--
-- Name: FUNCTION uuid_ns_dns(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_ns_dns() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_ns_dns() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_ns_dns() TO dashboard_user;


--
-- Name: FUNCTION uuid_ns_oid(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_ns_oid() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_ns_oid() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_ns_oid() TO dashboard_user;


--
-- Name: FUNCTION uuid_ns_url(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_ns_url() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_ns_url() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_ns_url() TO dashboard_user;


--
-- Name: FUNCTION uuid_ns_x500(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_ns_x500() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_ns_x500() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_ns_x500() TO dashboard_user;


--
-- Name: FUNCTION graphql("operationName" text, query text, variables jsonb, extensions jsonb); Type: ACL; Schema: graphql_public; Owner: supabase_admin
--

GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO postgres;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO anon;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO authenticated;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO service_role;


--
-- Name: FUNCTION pg_reload_conf(); Type: ACL; Schema: pg_catalog; Owner: supabase_admin
--

GRANT ALL ON FUNCTION pg_catalog.pg_reload_conf() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION get_auth(p_usename text); Type: ACL; Schema: pgbouncer; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION pgbouncer.get_auth(p_usename text) FROM PUBLIC;
GRANT ALL ON FUNCTION pgbouncer.get_auth(p_usename text) TO pgbouncer;


--
-- Name: FUNCTION apply_rls(wal jsonb, max_record_bytes integer); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO postgres;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO anon;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO authenticated;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO service_role;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO supabase_realtime_admin;


--
-- Name: FUNCTION broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text) TO postgres;
GRANT ALL ON FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text) TO dashboard_user;


--
-- Name: FUNCTION build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO postgres;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO anon;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO authenticated;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO service_role;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO supabase_realtime_admin;


--
-- Name: FUNCTION "cast"(val text, type_ regtype); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO postgres;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO dashboard_user;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO anon;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO authenticated;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO service_role;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO supabase_realtime_admin;


--
-- Name: FUNCTION check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO postgres;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO anon;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO authenticated;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO service_role;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO supabase_realtime_admin;


--
-- Name: FUNCTION is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO postgres;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO anon;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO authenticated;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO service_role;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO supabase_realtime_admin;


--
-- Name: FUNCTION list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO postgres;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO dashboard_user;


--
-- Name: FUNCTION quote_wal2json(entity regclass); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO postgres;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO anon;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO authenticated;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO service_role;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO supabase_realtime_admin;


--
-- Name: FUNCTION send(payload jsonb, event text, topic text, private boolean); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean) TO postgres;
GRANT ALL ON FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean) TO dashboard_user;


--
-- Name: FUNCTION send_binary(payload bytea, event text, topic text, private boolean); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.send_binary(payload bytea, event text, topic text, private boolean) TO postgres;
GRANT ALL ON FUNCTION realtime.send_binary(payload bytea, event text, topic text, private boolean) TO dashboard_user;


--
-- Name: FUNCTION subscription_check_filters(); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO postgres;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO dashboard_user;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO anon;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO authenticated;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO service_role;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO supabase_realtime_admin;


--
-- Name: FUNCTION to_regrole(role_name text); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO postgres;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO anon;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO authenticated;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO service_role;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO supabase_realtime_admin;


--
-- Name: FUNCTION topic(); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.topic() TO postgres;
GRANT ALL ON FUNCTION realtime.topic() TO dashboard_user;


--
-- Name: FUNCTION wal2json_escape_identifier(name text); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.wal2json_escape_identifier(name text) TO postgres;
GRANT ALL ON FUNCTION realtime.wal2json_escape_identifier(name text) TO dashboard_user;


--
-- Name: FUNCTION _crypto_aead_det_decrypt(message bytea, additional bytea, key_id bigint, context bytea, nonce bytea); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION vault._crypto_aead_det_decrypt(message bytea, additional bytea, key_id bigint, context bytea, nonce bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION vault._crypto_aead_det_decrypt(message bytea, additional bytea, key_id bigint, context bytea, nonce bytea) TO service_role;


--
-- Name: FUNCTION create_secret(new_secret text, new_name text, new_description text, new_key_id uuid); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION vault.create_secret(new_secret text, new_name text, new_description text, new_key_id uuid) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION vault.create_secret(new_secret text, new_name text, new_description text, new_key_id uuid) TO service_role;


--
-- Name: FUNCTION update_secret(secret_id uuid, new_secret text, new_name text, new_description text, new_key_id uuid); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION vault.update_secret(secret_id uuid, new_secret text, new_name text, new_description text, new_key_id uuid) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION vault.update_secret(secret_id uuid, new_secret text, new_name text, new_description text, new_key_id uuid) TO service_role;


--
-- Name: TABLE audit_log_entries; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.audit_log_entries TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.audit_log_entries TO postgres;
GRANT SELECT ON TABLE auth.audit_log_entries TO postgres WITH GRANT OPTION;


--
-- Name: TABLE custom_oauth_providers; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.custom_oauth_providers TO postgres;
GRANT ALL ON TABLE auth.custom_oauth_providers TO dashboard_user;


--
-- Name: TABLE flow_state; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.flow_state TO postgres;
GRANT SELECT ON TABLE auth.flow_state TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.flow_state TO dashboard_user;


--
-- Name: TABLE identities; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.identities TO postgres;
GRANT SELECT ON TABLE auth.identities TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.identities TO dashboard_user;


--
-- Name: TABLE instances; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.instances TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.instances TO postgres;
GRANT SELECT ON TABLE auth.instances TO postgres WITH GRANT OPTION;


--
-- Name: TABLE mfa_amr_claims; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.mfa_amr_claims TO postgres;
GRANT SELECT ON TABLE auth.mfa_amr_claims TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.mfa_amr_claims TO dashboard_user;


--
-- Name: TABLE mfa_challenges; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.mfa_challenges TO postgres;
GRANT SELECT ON TABLE auth.mfa_challenges TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.mfa_challenges TO dashboard_user;


--
-- Name: TABLE mfa_factors; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.mfa_factors TO postgres;
GRANT SELECT ON TABLE auth.mfa_factors TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.mfa_factors TO dashboard_user;


--
-- Name: TABLE oauth_authorizations; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.oauth_authorizations TO postgres;
GRANT ALL ON TABLE auth.oauth_authorizations TO dashboard_user;


--
-- Name: TABLE oauth_client_states; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.oauth_client_states TO postgres;
GRANT ALL ON TABLE auth.oauth_client_states TO dashboard_user;


--
-- Name: TABLE oauth_clients; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.oauth_clients TO postgres;
GRANT ALL ON TABLE auth.oauth_clients TO dashboard_user;


--
-- Name: TABLE oauth_consents; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.oauth_consents TO postgres;
GRANT ALL ON TABLE auth.oauth_consents TO dashboard_user;


--
-- Name: TABLE one_time_tokens; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.one_time_tokens TO postgres;
GRANT SELECT ON TABLE auth.one_time_tokens TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.one_time_tokens TO dashboard_user;


--
-- Name: TABLE refresh_tokens; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.refresh_tokens TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.refresh_tokens TO postgres;
GRANT SELECT ON TABLE auth.refresh_tokens TO postgres WITH GRANT OPTION;


--
-- Name: SEQUENCE refresh_tokens_id_seq; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON SEQUENCE auth.refresh_tokens_id_seq TO dashboard_user;
GRANT ALL ON SEQUENCE auth.refresh_tokens_id_seq TO postgres;


--
-- Name: TABLE saml_providers; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.saml_providers TO postgres;
GRANT SELECT ON TABLE auth.saml_providers TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.saml_providers TO dashboard_user;


--
-- Name: TABLE saml_relay_states; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.saml_relay_states TO postgres;
GRANT SELECT ON TABLE auth.saml_relay_states TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.saml_relay_states TO dashboard_user;


--
-- Name: TABLE schema_migrations; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT SELECT ON TABLE auth.schema_migrations TO postgres WITH GRANT OPTION;


--
-- Name: TABLE sessions; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.sessions TO postgres;
GRANT SELECT ON TABLE auth.sessions TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.sessions TO dashboard_user;


--
-- Name: TABLE sso_domains; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.sso_domains TO postgres;
GRANT SELECT ON TABLE auth.sso_domains TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.sso_domains TO dashboard_user;


--
-- Name: TABLE sso_providers; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.sso_providers TO postgres;
GRANT SELECT ON TABLE auth.sso_providers TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.sso_providers TO dashboard_user;


--
-- Name: TABLE users; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.users TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.users TO postgres;
GRANT SELECT ON TABLE auth.users TO postgres WITH GRANT OPTION;


--
-- Name: TABLE webauthn_challenges; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.webauthn_challenges TO postgres;
GRANT ALL ON TABLE auth.webauthn_challenges TO dashboard_user;


--
-- Name: TABLE webauthn_credentials; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.webauthn_credentials TO postgres;
GRANT ALL ON TABLE auth.webauthn_credentials TO dashboard_user;


--
-- Name: TABLE pg_stat_statements; Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON TABLE extensions.pg_stat_statements FROM postgres;
GRANT ALL ON TABLE extensions.pg_stat_statements TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE extensions.pg_stat_statements TO dashboard_user;


--
-- Name: TABLE pg_stat_statements_info; Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON TABLE extensions.pg_stat_statements_info FROM postgres;
GRANT ALL ON TABLE extensions.pg_stat_statements_info TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE extensions.pg_stat_statements_info TO dashboard_user;


--
-- Name: TABLE articles; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.articles TO anon;
GRANT ALL ON TABLE public.articles TO authenticated;
GRANT ALL ON TABLE public.articles TO service_role;


--
-- Name: SEQUENCE articles_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.articles_id_seq TO anon;
GRANT ALL ON SEQUENCE public.articles_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.articles_id_seq TO service_role;


--
-- Name: TABLE clients; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.clients TO anon;
GRANT ALL ON TABLE public.clients TO authenticated;
GRANT ALL ON TABLE public.clients TO service_role;


--
-- Name: SEQUENCE clients_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.clients_id_seq TO anon;
GRANT ALL ON SEQUENCE public.clients_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.clients_id_seq TO service_role;


--
-- Name: TABLE faq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.faq TO anon;
GRANT ALL ON TABLE public.faq TO authenticated;
GRANT ALL ON TABLE public.faq TO service_role;


--
-- Name: SEQUENCE faq_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.faq_id_seq TO anon;
GRANT ALL ON SEQUENCE public.faq_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.faq_id_seq TO service_role;


--
-- Name: TABLE glossaire; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.glossaire TO anon;
GRANT ALL ON TABLE public.glossaire TO authenticated;
GRANT ALL ON TABLE public.glossaire TO service_role;


--
-- Name: SEQUENCE glossaire_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.glossaire_id_seq TO anon;
GRANT ALL ON SEQUENCE public.glossaire_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.glossaire_id_seq TO service_role;


--
-- Name: TABLE partenaires; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.partenaires TO anon;
GRANT ALL ON TABLE public.partenaires TO authenticated;
GRANT ALL ON TABLE public.partenaires TO service_role;


--
-- Name: SEQUENCE partenaires_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.partenaires_id_seq TO anon;
GRANT ALL ON SEQUENCE public.partenaires_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.partenaires_id_seq TO service_role;


--
-- Name: TABLE projets; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.projets TO anon;
GRANT ALL ON TABLE public.projets TO authenticated;
GRANT ALL ON TABLE public.projets TO service_role;


--
-- Name: SEQUENCE projets_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.projets_id_seq TO anon;
GRANT ALL ON SEQUENCE public.projets_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.projets_id_seq TO service_role;


--
-- Name: TABLE simulations; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.simulations TO anon;
GRANT ALL ON TABLE public.simulations TO authenticated;
GRANT ALL ON TABLE public.simulations TO service_role;


--
-- Name: TABLE site_texts; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.site_texts TO anon;
GRANT ALL ON TABLE public.site_texts TO authenticated;
GRANT ALL ON TABLE public.site_texts TO service_role;


--
-- Name: TABLE social_posts; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.social_posts TO anon;
GRANT ALL ON TABLE public.social_posts TO authenticated;
GRANT ALL ON TABLE public.social_posts TO service_role;


--
-- Name: SEQUENCE social_posts_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.social_posts_id_seq TO anon;
GRANT ALL ON SEQUENCE public.social_posts_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.social_posts_id_seq TO service_role;


--
-- Name: TABLE team_header; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.team_header TO anon;
GRANT ALL ON TABLE public.team_header TO authenticated;
GRANT ALL ON TABLE public.team_header TO service_role;


--
-- Name: TABLE team_members; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.team_members TO anon;
GRANT ALL ON TABLE public.team_members TO authenticated;
GRANT ALL ON TABLE public.team_members TO service_role;


--
-- Name: SEQUENCE team_members_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.team_members_id_seq TO anon;
GRANT ALL ON SEQUENCE public.team_members_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.team_members_id_seq TO service_role;


--
-- Name: TABLE visits; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.visits TO anon;
GRANT ALL ON TABLE public.visits TO authenticated;
GRANT ALL ON TABLE public.visits TO service_role;


--
-- Name: SEQUENCE visits_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.visits_id_seq TO anon;
GRANT ALL ON SEQUENCE public.visits_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.visits_id_seq TO service_role;


--
-- Name: TABLE messages; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE realtime.messages TO postgres;
GRANT ALL ON TABLE realtime.messages TO dashboard_user;
GRANT SELECT,INSERT,UPDATE ON TABLE realtime.messages TO anon;
GRANT SELECT,INSERT,UPDATE ON TABLE realtime.messages TO authenticated;
GRANT SELECT,INSERT,UPDATE ON TABLE realtime.messages TO service_role;


--
-- Name: TABLE schema_migrations; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.schema_migrations TO postgres;
GRANT ALL ON TABLE realtime.schema_migrations TO dashboard_user;
GRANT SELECT ON TABLE realtime.schema_migrations TO anon;
GRANT SELECT ON TABLE realtime.schema_migrations TO authenticated;
GRANT SELECT ON TABLE realtime.schema_migrations TO service_role;
GRANT ALL ON TABLE realtime.schema_migrations TO supabase_realtime_admin;


--
-- Name: TABLE subscription; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.subscription TO postgres;
GRANT ALL ON TABLE realtime.subscription TO dashboard_user;
GRANT SELECT ON TABLE realtime.subscription TO anon;
GRANT SELECT ON TABLE realtime.subscription TO authenticated;
GRANT SELECT ON TABLE realtime.subscription TO service_role;
GRANT ALL ON TABLE realtime.subscription TO supabase_realtime_admin;


--
-- Name: SEQUENCE subscription_id_seq; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON SEQUENCE realtime.subscription_id_seq TO postgres;
GRANT ALL ON SEQUENCE realtime.subscription_id_seq TO dashboard_user;
GRANT USAGE ON SEQUENCE realtime.subscription_id_seq TO anon;
GRANT USAGE ON SEQUENCE realtime.subscription_id_seq TO authenticated;
GRANT USAGE ON SEQUENCE realtime.subscription_id_seq TO service_role;
GRANT ALL ON SEQUENCE realtime.subscription_id_seq TO supabase_realtime_admin;


--
-- Name: TABLE buckets; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

REVOKE ALL ON TABLE storage.buckets FROM supabase_storage_admin;
GRANT ALL ON TABLE storage.buckets TO supabase_storage_admin WITH GRANT OPTION;
GRANT ALL ON TABLE storage.buckets TO service_role;
GRANT ALL ON TABLE storage.buckets TO authenticated;
GRANT ALL ON TABLE storage.buckets TO anon;
GRANT ALL ON TABLE storage.buckets TO postgres WITH GRANT OPTION;


--
-- Name: TABLE buckets_analytics; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.buckets_analytics TO service_role;
GRANT ALL ON TABLE storage.buckets_analytics TO authenticated;
GRANT ALL ON TABLE storage.buckets_analytics TO anon;


--
-- Name: TABLE buckets_vectors; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT SELECT ON TABLE storage.buckets_vectors TO service_role;
GRANT SELECT ON TABLE storage.buckets_vectors TO authenticated;
GRANT SELECT ON TABLE storage.buckets_vectors TO anon;


--
-- Name: TABLE objects; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

REVOKE ALL ON TABLE storage.objects FROM supabase_storage_admin;
GRANT ALL ON TABLE storage.objects TO supabase_storage_admin WITH GRANT OPTION;
GRANT ALL ON TABLE storage.objects TO service_role;
GRANT ALL ON TABLE storage.objects TO authenticated;
GRANT ALL ON TABLE storage.objects TO anon;
GRANT ALL ON TABLE storage.objects TO postgres WITH GRANT OPTION;


--
-- Name: TABLE s3_multipart_uploads; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.s3_multipart_uploads TO service_role;
GRANT SELECT ON TABLE storage.s3_multipart_uploads TO authenticated;
GRANT SELECT ON TABLE storage.s3_multipart_uploads TO anon;


--
-- Name: TABLE s3_multipart_uploads_parts; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.s3_multipart_uploads_parts TO service_role;
GRANT SELECT ON TABLE storage.s3_multipart_uploads_parts TO authenticated;
GRANT SELECT ON TABLE storage.s3_multipart_uploads_parts TO anon;


--
-- Name: TABLE vector_indexes; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT SELECT ON TABLE storage.vector_indexes TO service_role;
GRANT SELECT ON TABLE storage.vector_indexes TO authenticated;
GRANT SELECT ON TABLE storage.vector_indexes TO anon;


--
-- Name: TABLE secrets; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE vault.secrets TO postgres WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE vault.secrets TO service_role;


--
-- Name: TABLE decrypted_secrets; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE vault.decrypted_secrets TO postgres WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE vault.decrypted_secrets TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON SEQUENCES TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON FUNCTIONS TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON TABLES TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON SEQUENCES TO postgres WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON FUNCTIONS TO postgres WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON TABLES TO postgres WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON SEQUENCES TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON FUNCTIONS TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON TABLES TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES TO service_role;


--
-- Name: issue_graphql_placeholder; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_graphql_placeholder ON sql_drop
         WHEN TAG IN ('DROP EXTENSION')
   EXECUTE FUNCTION extensions.set_graphql_placeholder();


ALTER EVENT TRIGGER issue_graphql_placeholder OWNER TO supabase_admin;

--
-- Name: issue_pg_cron_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_pg_cron_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_cron_access();


ALTER EVENT TRIGGER issue_pg_cron_access OWNER TO supabase_admin;

--
-- Name: issue_pg_graphql_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_pg_graphql_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_graphql_access();


ALTER EVENT TRIGGER issue_pg_graphql_access OWNER TO supabase_admin;

--
-- Name: issue_pg_net_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_pg_net_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_net_access();


ALTER EVENT TRIGGER issue_pg_net_access OWNER TO supabase_admin;

--
-- Name: pgrst_ddl_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER pgrst_ddl_watch ON ddl_command_end
   EXECUTE FUNCTION extensions.pgrst_ddl_watch();


ALTER EVENT TRIGGER pgrst_ddl_watch OWNER TO supabase_admin;

--
-- Name: pgrst_drop_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER pgrst_drop_watch ON sql_drop
   EXECUTE FUNCTION extensions.pgrst_drop_watch();


ALTER EVENT TRIGGER pgrst_drop_watch OWNER TO supabase_admin;

--
-- PostgreSQL database dump complete
--

\unrestrict atHaebenAvFUQ0aV8s8ZLvpRB1WOhhkbcRnpXcyetZKr6bBuZfk3ff4v3nUAG9o

