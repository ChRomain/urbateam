--
-- PostgreSQL database dump
--

\restrict bjjv4gxQgSFFManpRl8upBzS9tsUJJNh4H6gnTfwmIEGHI4ZSVYmyEz0hqwHeao

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.10 (Ubuntu 17.10-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA auth;


ALTER SCHEMA auth OWNER TO supabase_admin;

--
-- Name: extensions; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA extensions;


ALTER SCHEMA extensions OWNER TO postgres;

--
-- Name: graphql; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA graphql;


ALTER SCHEMA graphql OWNER TO supabase_admin;

--
-- Name: graphql_public; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA graphql_public;


ALTER SCHEMA graphql_public OWNER TO supabase_admin;

--
-- Name: pgbouncer; Type: SCHEMA; Schema: -; Owner: pgbouncer
--

CREATE SCHEMA pgbouncer;


ALTER SCHEMA pgbouncer OWNER TO pgbouncer;

--
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA realtime;


ALTER SCHEMA realtime OWNER TO supabase_admin;

--
-- Name: storage; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA storage;


ALTER SCHEMA storage OWNER TO supabase_admin;

--
-- Name: supabase_migrations; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA supabase_migrations;


ALTER SCHEMA supabase_migrations OWNER TO postgres;

--
-- Name: vault; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA vault;


ALTER SCHEMA vault OWNER TO supabase_admin;

--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA extensions;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA extensions;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: supabase_vault; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS supabase_vault WITH SCHEMA vault;


--
-- Name: EXTENSION supabase_vault; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION supabase_vault IS 'Supabase Vault Extension';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA extensions;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.aal_level AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


ALTER TYPE auth.aal_level OWNER TO supabase_auth_admin;

--
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.code_challenge_method AS ENUM (
    's256',
    'plain'
);


ALTER TYPE auth.code_challenge_method OWNER TO supabase_auth_admin;

--
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.factor_status AS ENUM (
    'unverified',
    'verified'
);


ALTER TYPE auth.factor_status OWNER TO supabase_auth_admin;

--
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.factor_type AS ENUM (
    'totp',
    'webauthn',
    'phone'
);


ALTER TYPE auth.factor_type OWNER TO supabase_auth_admin;

--
-- Name: oauth_authorization_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.oauth_authorization_status AS ENUM (
    'pending',
    'approved',
    'denied',
    'expired'
);


ALTER TYPE auth.oauth_authorization_status OWNER TO supabase_auth_admin;

--
-- Name: oauth_client_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.oauth_client_type AS ENUM (
    'public',
    'confidential'
);


ALTER TYPE auth.oauth_client_type OWNER TO supabase_auth_admin;

--
-- Name: oauth_registration_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.oauth_registration_type AS ENUM (
    'dynamic',
    'manual'
);


ALTER TYPE auth.oauth_registration_type OWNER TO supabase_auth_admin;

--
-- Name: oauth_response_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.oauth_response_type AS ENUM (
    'code'
);


ALTER TYPE auth.oauth_response_type OWNER TO supabase_auth_admin;

--
-- Name: one_time_token_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.one_time_token_type AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


ALTER TYPE auth.one_time_token_type OWNER TO supabase_auth_admin;

--
-- Name: action; Type: TYPE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TYPE realtime.action AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE',
    'TRUNCATE',
    'ERROR'
);


ALTER TYPE realtime.action OWNER TO supabase_realtime_admin;

--
-- Name: equality_op; Type: TYPE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TYPE realtime.equality_op AS ENUM (
    'eq',
    'neq',
    'lt',
    'lte',
    'gt',
    'gte',
    'in',
    'like',
    'ilike',
    'is',
    'match',
    'imatch',
    'isdistinct'
);


ALTER TYPE realtime.equality_op OWNER TO supabase_realtime_admin;

--
-- Name: user_defined_filter; Type: TYPE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TYPE realtime.user_defined_filter AS (
	column_name text,
	op realtime.equality_op,
	value text,
	negate boolean
);


ALTER TYPE realtime.user_defined_filter OWNER TO supabase_realtime_admin;

--
-- Name: wal_column; Type: TYPE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TYPE realtime.wal_column AS (
	name text,
	type_name text,
	type_oid oid,
	value jsonb,
	is_pkey boolean,
	is_selectable boolean
);


ALTER TYPE realtime.wal_column OWNER TO supabase_realtime_admin;

--
-- Name: wal_rls; Type: TYPE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TYPE realtime.wal_rls AS (
	wal jsonb,
	is_rls_enabled boolean,
	subscription_ids uuid[],
	errors text[]
);


ALTER TYPE realtime.wal_rls OWNER TO supabase_realtime_admin;

--
-- Name: buckettype; Type: TYPE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TYPE storage.buckettype AS ENUM (
    'STANDARD',
    'ANALYTICS',
    'VECTOR'
);


ALTER TYPE storage.buckettype OWNER TO supabase_storage_admin;

--
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.email() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


ALTER FUNCTION auth.email() OWNER TO supabase_auth_admin;

--
-- Name: FUNCTION email(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.email() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.jwt() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


ALTER FUNCTION auth.jwt() OWNER TO supabase_auth_admin;

--
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.role() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


ALTER FUNCTION auth.role() OWNER TO supabase_auth_admin;

--
-- Name: FUNCTION role(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.role() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.uid() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


ALTER FUNCTION auth.uid() OWNER TO supabase_auth_admin;

--
-- Name: FUNCTION uid(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.uid() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- Name: grant_pg_cron_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.grant_pg_cron_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_cron'
  )
  THEN
    grant usage on schema cron to postgres with grant option;

    alter default privileges in schema cron grant all on tables to postgres with grant option;
    alter default privileges in schema cron grant all on functions to postgres with grant option;
    alter default privileges in schema cron grant all on sequences to postgres with grant option;

    alter default privileges for user supabase_admin in schema cron grant all
        on sequences to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on tables to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on functions to postgres with grant option;

    grant all privileges on all tables in schema cron to postgres with grant option;
    revoke all on table cron.job from postgres;
    grant select on table cron.job to postgres with grant option;
  END IF;
END;
$$;


ALTER FUNCTION extensions.grant_pg_cron_access() OWNER TO supabase_admin;

--
-- Name: FUNCTION grant_pg_cron_access(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.grant_pg_cron_access() IS 'Grants access to pg_cron';


--
-- Name: grant_pg_graphql_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.grant_pg_graphql_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
begin
    if not exists (
        select 1
        from pg_event_trigger_ddl_commands() ev
        join pg_catalog.pg_extension e on ev.objid = e.oid
        where e.extname = 'pg_graphql'
    ) then
        return;
    end if;

    drop function if exists graphql_public.graphql;
    create or replace function graphql_public.graphql(
        "operationName" text default null,
        query text default null,
        variables jsonb default null,
        extensions jsonb default null
    )
        returns jsonb
        language sql
    as $$
        select graphql.resolve(
            query := query,
            variables := coalesce(variables, '{}'),
            "operationName" := "operationName",
            extensions := extensions
        );
    $$;

    -- Attach the wrapper to the extension so DROP EXTENSION cascades to it,
    -- which in turn triggers set_graphql_placeholder to reinstall the "not enabled" stub.
    alter extension pg_graphql add function graphql_public.graphql(text, text, jsonb, jsonb);

    grant usage on schema graphql to postgres, anon, authenticated, service_role;
    grant execute on function graphql.resolve to postgres, anon, authenticated, service_role;
    grant usage on schema graphql to postgres with grant option;
    grant usage on schema graphql_public to postgres with grant option;
end;
$_$;


ALTER FUNCTION extensions.grant_pg_graphql_access() OWNER TO supabase_admin;

--
-- Name: FUNCTION grant_pg_graphql_access(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.grant_pg_graphql_access() IS 'Grants access to pg_graphql';


--
-- Name: grant_pg_net_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.grant_pg_net_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_net'
  )
  THEN
    IF NOT EXISTS (
      SELECT 1
      FROM pg_roles
      WHERE rolname = 'supabase_functions_admin'
    )
    THEN
      CREATE USER supabase_functions_admin NOINHERIT CREATEROLE LOGIN NOREPLICATION;
    END IF;

    GRANT USAGE ON SCHEMA net TO supabase_functions_admin, postgres, anon, authenticated, service_role;

    IF EXISTS (
      SELECT FROM pg_extension
      WHERE extname = 'pg_net'
      -- all versions in use on existing projects as of 2025-02-20
      -- version 0.12.0 onwards don't need these applied
      AND extversion IN ('0.2', '0.6', '0.7', '0.7.1', '0.8', '0.10.0', '0.11.0')
    ) THEN
      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;

      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;

      REVOKE ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
      REVOKE ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;

      GRANT EXECUTE ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
      GRANT EXECUTE ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
    END IF;
  END IF;
END;
$$;


ALTER FUNCTION extensions.grant_pg_net_access() OWNER TO supabase_admin;

--
-- Name: FUNCTION grant_pg_net_access(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.grant_pg_net_access() IS 'Grants access to pg_net';


--
-- Name: pgrst_ddl_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.pgrst_ddl_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    IF cmd.command_tag IN (
      'CREATE SCHEMA', 'ALTER SCHEMA'
    , 'CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO', 'ALTER TABLE'
    , 'CREATE FOREIGN TABLE', 'ALTER FOREIGN TABLE'
    , 'CREATE VIEW', 'ALTER VIEW'
    , 'CREATE MATERIALIZED VIEW', 'ALTER MATERIALIZED VIEW'
    , 'CREATE FUNCTION', 'ALTER FUNCTION'
    , 'CREATE TRIGGER'
    , 'CREATE TYPE', 'ALTER TYPE'
    , 'CREATE RULE'
    , 'COMMENT'
    )
    -- don't notify in case of CREATE TEMP table or other objects created on pg_temp
    AND cmd.schema_name is distinct from 'pg_temp'
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION extensions.pgrst_ddl_watch() OWNER TO supabase_admin;

--
-- Name: pgrst_drop_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.pgrst_drop_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  obj record;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_dropped_objects()
  LOOP
    IF obj.object_type IN (
      'schema'
    , 'table'
    , 'foreign table'
    , 'view'
    , 'materialized view'
    , 'function'
    , 'trigger'
    , 'type'
    , 'rule'
    )
    AND obj.is_temporary IS false -- no pg_temp objects
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION extensions.pgrst_drop_watch() OWNER TO supabase_admin;

--
-- Name: set_graphql_placeholder(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.set_graphql_placeholder() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
    DECLARE
    graphql_is_dropped bool;
    BEGIN
    graphql_is_dropped = (
        SELECT ev.schema_name = 'graphql_public'
        FROM pg_event_trigger_dropped_objects() AS ev
        WHERE ev.schema_name = 'graphql_public'
    );

    IF graphql_is_dropped
    THEN
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language plpgsql
        as $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;
    END IF;

    END;
$_$;


ALTER FUNCTION extensions.set_graphql_placeholder() OWNER TO supabase_admin;

--
-- Name: FUNCTION set_graphql_placeholder(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.set_graphql_placeholder() IS 'Reintroduces placeholder function for graphql_public.graphql';


--
-- Name: graphql(text, text, jsonb, jsonb); Type: FUNCTION; Schema: graphql_public; Owner: supabase_admin
--

CREATE FUNCTION graphql_public.graphql("operationName" text DEFAULT NULL::text, query text DEFAULT NULL::text, variables jsonb DEFAULT NULL::jsonb, extensions jsonb DEFAULT NULL::jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;


ALTER FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) OWNER TO supabase_admin;

--
-- Name: get_auth(text); Type: FUNCTION; Schema: pgbouncer; Owner: supabase_admin
--

CREATE FUNCTION pgbouncer.get_auth(p_usename text) RETURNS TABLE(username text, password text)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $_$
  BEGIN
      RAISE DEBUG 'PgBouncer auth request: %', p_usename;

      RETURN QUERY
      SELECT
          rolname::text,
          CASE WHEN rolvaliduntil < now()
              THEN null
              ELSE rolpassword::text
          END
      FROM pg_authid
      WHERE rolname=$1 and rolcanlogin;
  END;
  $_$;


ALTER FUNCTION pgbouncer.get_auth(p_usename text) OWNER TO supabase_admin;

--
-- Name: apply_rls(jsonb, integer); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer DEFAULT (1024 * 1024)) RETURNS SETOF realtime.wal_rls
    LANGUAGE plpgsql
    AS $$
declare
    -- Regclass of the table e.g. public.notes
    entity_ regclass = (quote_ident(wal ->> 'schema') || '.' || quote_ident(wal ->> 'table'))::regclass;

    -- I, U, D, T: insert, update ...
    action realtime.action = (
        case wal ->> 'action'
            when 'I' then 'INSERT'
            when 'U' then 'UPDATE'
            when 'D' then 'DELETE'
            else 'ERROR'
        end
    );

    -- Is row level security enabled for the table
    is_rls_enabled bool = relrowsecurity from pg_class where oid = entity_;

    subscriptions realtime.subscription[] = array_agg(subs)
        from
            realtime.subscription subs
        where
            subs.entity = entity_
            -- Filter by action early - only get subscriptions interested in this action
            -- action_filter column can be: '*' (all), 'INSERT', 'UPDATE', or 'DELETE'
            and (subs.action_filter = '*' or subs.action_filter = action::text);

    -- Subscription vars
    working_role regrole;
    working_selected_columns text[];
    claimed_role regrole;
    claims jsonb;

    subscription_id uuid;
    subscription_has_access bool;
    visible_to_subscription_ids uuid[] = '{}';

    -- structured info for wal's columns
    columns realtime.wal_column[];
    -- previous identity values for update/delete
    old_columns realtime.wal_column[];

    error_record_exceeds_max_size boolean = octet_length(wal::text) > max_record_bytes;

    -- Primary jsonb output for record
    output jsonb;

    -- Loop record for iterating unique roles (outer loop)
    role_record record;
    -- Loop record for iterating unique selected_columns within a role (inner loop)
    cols_record record;
    -- Subscription ids visible at the role level (before fanning out by selected_columns)
    visible_role_sub_ids uuid[] = '{}';

begin
    perform set_config('role', null, true);

    columns =
        array_agg(
            (
                x->>'name',
                x->>'type',
                x->>'typeoid',
                realtime.cast(
                    (x->'value') #>> '{}',
                    coalesce(
                        (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                        (x->>'type')::regtype
                    )
                ),
                (pks ->> 'name') is not null,
                true
            )::realtime.wal_column
        )
        from
            jsonb_array_elements(wal -> 'columns') x
            left join jsonb_array_elements(wal -> 'pk') pks
                on (x ->> 'name') = (pks ->> 'name');

    old_columns =
        array_agg(
            (
                x->>'name',
                x->>'type',
                x->>'typeoid',
                realtime.cast(
                    (x->'value') #>> '{}',
                    coalesce(
                        (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                        (x->>'type')::regtype
                    )
                ),
                (pks ->> 'name') is not null,
                true
            )::realtime.wal_column
        )
        from
            jsonb_array_elements(wal -> 'identity') x
            left join jsonb_array_elements(wal -> 'pk') pks
                on (x ->> 'name') = (pks ->> 'name');

    for role_record in
        select claims_role
        from (select distinct claims_role from unnest(subscriptions)) t
        order by claims_role::text
    loop
        working_role := role_record.claims_role;

        -- Update `is_selectable` for columns and old_columns (once per role)
        columns =
            array_agg(
                (
                    c.name,
                    c.type_name,
                    c.type_oid,
                    c.value,
                    c.is_pkey,
                    pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                )::realtime.wal_column
            )
            from
                unnest(columns) c;

        old_columns =
                array_agg(
                    (
                        c.name,
                        c.type_name,
                        c.type_oid,
                        c.value,
                        c.is_pkey,
                        pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                    )::realtime.wal_column
                )
                from
                    unnest(old_columns) c;

        if action <> 'DELETE' and count(1) = 0 from unnest(columns) c where c.is_pkey then
            -- Fan out 400 error per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;
                return next (
                    jsonb_build_object(
                        'schema', wal ->> 'schema',
                        'table', wal ->> 'table',
                        'type', action
                    ),
                    is_rls_enabled,
                    (select array_agg(s.subscription_id) from unnest(subscriptions) as s where s.claims_role = working_role and (s.selected_columns is not distinct from working_selected_columns)),
                    array['Error 400: Bad Request, no primary key']
                )::realtime.wal_rls;
            end loop;

        -- The claims role does not have SELECT permission to the primary key of entity
        elsif action <> 'DELETE' and sum(c.is_selectable::int) <> count(1) from unnest(columns) c where c.is_pkey then
            -- Fan out 401 error per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;
                return next (
                    jsonb_build_object(
                        'schema', wal ->> 'schema',
                        'table', wal ->> 'table',
                        'type', action
                    ),
                    is_rls_enabled,
                    (select array_agg(s.subscription_id) from unnest(subscriptions) as s where s.claims_role = working_role and (s.selected_columns is not distinct from working_selected_columns)),
                    array['Error 401: Unauthorized']
                )::realtime.wal_rls;
            end loop;

        else
            -- Create the prepared statement (once per role)
            if is_rls_enabled and action <> 'DELETE' then
                if (select 1 from pg_prepared_statements where name = 'walrus_rls_stmt' limit 1) > 0 then
                    deallocate walrus_rls_stmt;
                end if;
                execute realtime.build_prepared_statement_sql('walrus_rls_stmt', entity_, columns);
            end if;

            -- Collect all visible subscription IDs for this role (filter check + RLS check)
            visible_role_sub_ids = '{}';

            for subscription_id, claims in (
                    select
                        subs.subscription_id,
                        subs.claims
                    from
                        unnest(subscriptions) subs
                    where
                        subs.entity = entity_
                        and subs.claims_role = working_role
                        and (
                            realtime.is_visible_through_filters(columns, subs.filters)
                            or (
                              action = 'DELETE'
                              and realtime.is_visible_through_filters(old_columns, subs.filters)
                            )
                        )
            ) loop

                if not is_rls_enabled or action = 'DELETE' then
                    visible_role_sub_ids = visible_role_sub_ids || subscription_id;
                else
                    -- Check if RLS allows the role to see the record
                    perform
                        -- Trim leading and trailing quotes from working_role because set_config
                        -- doesn't recognize the role as valid if they are included
                        set_config('role', trim(both '"' from working_role::text), true),
                        set_config('request.jwt.claims', claims::text, true);

                    execute 'execute walrus_rls_stmt' into subscription_has_access;

                    -- Reset the role on every FOR..LOOP batch execution.
                    -- The first batch of 10 rows is pre-fetched using the current connection role (PG internal behaviour)
                    -- then we have to reset it again otherwise it would use the role defined in the `set_config` above
                    -- to fetch the remaining rows when rows>10, which could be a user-defined role that lacks execution grants.
                    -- The flow is:
                    --   1. run batch with conn role
                    --   2. set_config working_role
                    --   3. execute walrus
                    --   4. reset role (revert)
                    --   5. repeat
                    perform set_config('role', null, true);

                    if subscription_has_access then
                        visible_role_sub_ids = visible_role_sub_ids || subscription_id;
                    end if;
                end if;
            end loop;

            perform set_config('role', null, true);

            -- Inner loop: per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;

                output = jsonb_build_object(
                    'schema', wal ->> 'schema',
                    'table', wal ->> 'table',
                    'type', action,
                    'commit_timestamp', to_char(
                        ((wal ->> 'timestamp')::timestamptz at time zone 'utc'),
                        'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'
                    ),
                    'columns', (
                        select
                            jsonb_agg(
                                jsonb_build_object(
                                    'name', pa.attname,
                                    'type', pt.typname
                                )
                                order by pa.attnum asc
                            )
                        from
                            pg_attribute pa
                            join pg_type pt
                                on pa.atttypid = pt.oid
                            left join (
                                select unnest(conkey) as pkey_attnum
                                from pg_constraint
                                where conrelid = entity_ and contype = 'p'
                            ) pk on pk.pkey_attnum = pa.attnum
                        where
                            attrelid = entity_
                            and attnum > 0
                            and pg_catalog.has_column_privilege(working_role, entity_, pa.attname, 'SELECT')
                            and (working_selected_columns is null or pa.attname = any(working_selected_columns) or pk.pkey_attnum is not null)
                    )
                )
                -- Add "record" key for insert and update
                || case
                    when action in ('INSERT', 'UPDATE') then
                        jsonb_build_object(
                            'record',
                            (
                                select
                                    jsonb_object_agg(
                                        -- if unchanged toast, get column name and value from old record
                                        coalesce((c).name, (oc).name),
                                        case
                                            when (c).name is null then (oc).value
                                            else (c).value
                                        end
                                    )
                                from
                                    unnest(columns) c
                                    full outer join unnest(old_columns) oc
                                        on (c).name = (oc).name
                                where
                                    coalesce((c).is_selectable, (oc).is_selectable)
                                    and (working_selected_columns is null or coalesce((c).name, (oc).name) = any(working_selected_columns) or coalesce((c).is_pkey, (oc).is_pkey))
                                    and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                            )
                        )
                    else '{}'::jsonb
                end
                -- Add "old_record" key for update and delete
                || case
                    when action = 'UPDATE' then
                        jsonb_build_object(
                                'old_record',
                                (
                                    select jsonb_object_agg((c).name, (c).value)
                                    from unnest(old_columns) c
                                    where
                                        (c).is_selectable
                                        and (working_selected_columns is null or (c).name = any(working_selected_columns) or (c).is_pkey)
                                        and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                                )
                            )
                    when action = 'DELETE' then
                        jsonb_build_object(
                            'old_record',
                            (
                                select jsonb_object_agg((c).name, (c).value)
                                from unnest(old_columns) c
                                where
                                    (c).is_selectable
                                    and (working_selected_columns is null or (c).name = any(working_selected_columns) or (c).is_pkey)
                                    and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                                    and ( not is_rls_enabled or (c).is_pkey ) -- if RLS enabled, we can't secure deletes so filter to pkey
                            )
                        )
                    else '{}'::jsonb
                end;

                -- Filter visible_role_sub_ids to those matching the current selected_columns group
                visible_to_subscription_ids = coalesce(
                    (
                        select array_agg(s.subscription_id)
                        from unnest(subscriptions) s
                        where s.claims_role = working_role
                          and (s.selected_columns is not distinct from working_selected_columns)
                          and s.subscription_id = any(visible_role_sub_ids)
                    ),
                    '{}'::uuid[]
                );

                return next (
                    output,
                    is_rls_enabled,
                    visible_to_subscription_ids,
                    case
                        when error_record_exceeds_max_size then array['Error 413: Payload Too Large']
                        else '{}'
                    end
                )::realtime.wal_rls;
            end loop;

        end if;
    end loop;

    perform set_config('role', null, true);
end;
$$;


ALTER FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) OWNER TO supabase_realtime_admin;

--
-- Name: broadcast_changes(text, text, text, text, text, record, record, text); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text DEFAULT 'ROW'::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    -- Declare a variable to hold the JSONB representation of the row
    row_data jsonb := '{}'::jsonb;
BEGIN
    IF level = 'STATEMENT' THEN
        RAISE EXCEPTION 'function can only be triggered for each row, not for each statement';
    END IF;
    -- Check the operation type and handle accordingly
    IF operation = 'INSERT' OR operation = 'UPDATE' OR operation = 'DELETE' THEN
        row_data := jsonb_build_object('old_record', OLD, 'record', NEW, 'operation', operation, 'table', table_name, 'schema', table_schema);
        PERFORM realtime.send (row_data, event_name, topic_name);
    ELSE
        RAISE EXCEPTION 'Unexpected operation type: %', operation;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Failed to process the row: %', SQLERRM;
END;

$$;


ALTER FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text) OWNER TO supabase_realtime_admin;

--
-- Name: build_prepared_statement_sql(text, regclass, realtime.wal_column[]); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) RETURNS text
    LANGUAGE sql
    AS $$
      /*
      Builds a sql string that, if executed, creates a prepared statement to
      tests retrive a row from *entity* by its primary key columns.
      Example
          select realtime.build_prepared_statement_sql('public.notes', '{"id"}'::text[], '{"bigint"}'::text[])
      */
          select
      'prepare ' || prepared_statement_name || ' as
          select
              exists(
                  select
                      1
                  from
                      ' || entity || '
                  where
                      ' || string_agg(quote_ident(pkc.name) || '=' || quote_nullable(pkc.value #>> '{}') , ' and ') || '
              )'
          from
              unnest(columns) pkc
          where
              pkc.is_pkey
          group by
              entity
      $$;


ALTER FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) OWNER TO supabase_realtime_admin;

--
-- Name: cast(text, regtype); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime."cast"(val text, type_ regtype) RETURNS jsonb
    LANGUAGE plpgsql IMMUTABLE
    AS $$
declare
  res jsonb;
begin
  if type_::text = 'bytea' then
    return to_jsonb(val);
  end if;
  execute format('select to_jsonb(%L::'|| type_::text || ')', val) into res;
  return res;
end
$$;


ALTER FUNCTION realtime."cast"(val text, type_ regtype) OWNER TO supabase_realtime_admin;

--
-- Name: check_equality_op(realtime.equality_op, regtype, text, text); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) RETURNS boolean
    LANGUAGE plpgsql IMMUTABLE
    AS $$
/*
Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
*/
declare
    op_symbol text = (
        case
            when op = 'eq' then '='
            when op = 'neq' then '!='
            when op = 'lt' then '<'
            when op = 'lte' then '<='
            when op = 'gt' then '>'
            when op = 'gte' then '>='
            when op = 'in' then '= any'
            else 'UNKNOWN OP'
        end
    );
    res boolean;
begin
    execute format(
        'select %L::'|| type_::text || ' ' || op_symbol
        || ' ( %L::'
        || (
            case
                when op = 'in' then type_::text || '[]'
                else type_::text end
        )
        || ')', val_1, val_2) into res;
    return res;
end;
$$;


ALTER FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) OWNER TO supabase_realtime_admin;

--
-- Name: check_equality_op(realtime.equality_op, regtype, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text, negate boolean) RETURNS boolean
    LANGUAGE plpgsql STABLE
    AS $$
declare
    op_symbol text;
    res boolean;
begin
    -- IS DISTINCT FROM / IS NOT DISTINCT FROM: infix, both sides typed literals
    if op = 'isdistinct' then
        execute format(
            'select %L::%s %s %L::%s',
            val_1,
            type_::text,
            case when negate then 'IS NOT DISTINCT FROM' else 'IS DISTINCT FROM' end,
            val_2,
            type_::text
        ) into res;
        return res;
    end if;

    -- IS requires a keyword RHS (NULL, TRUE, FALSE, UNKNOWN), not a typed literal
    if op = 'is' then
        if val_2 not in ('null', 'true', 'false', 'unknown') then
            raise exception 'invalid value for is filter: must be null, true, false, or unknown';
        end if;
        execute format(
            'select %L::%s %s %s',
            val_1,
            type_::text,
            case when negate then 'IS NOT' else 'IS' end,
            upper(val_2)
        ) into res;
        return res;
    end if;

    op_symbol = case
        when op = 'eq'    then '='
        when op = 'neq'   then '!='
        when op = 'lt'    then '<'
        when op = 'lte'   then '<='
        when op = 'gt'    then '>'
        when op = 'gte'   then '>='
        when op = 'in'    then '= any'
        when op = 'like'   then 'LIKE'
        when op = 'ilike'  then 'ILIKE'
        when op = 'match'  then '~'
        when op = 'imatch' then '~*'
        else null
    end;

    if op_symbol is null then
        raise exception 'unsupported equality operator: %', op::text;
    end if;

    execute format(
        'select %L::%s %s (%L::%s)',
        val_1,
        type_::text,
        op_symbol,
        val_2,
        case when op = 'in' then type_::text || '[]' else type_::text end
    ) into res;

    return case when negate then not res else res end;
end;
$$;


ALTER FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text, negate boolean) OWNER TO supabase_realtime_admin;

--
-- Name: is_visible_through_filters(realtime.wal_column[], realtime.user_defined_filter[]); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
    select
        filters is null
        or array_length(filters, 1) is null
        or coalesce(
            count(col.name) = count(1)
            and sum(
                realtime.check_equality_op(
                    op:=f.op,
                    type_:=coalesce(col.type_oid::regtype, col.type_name::regtype),
                    val_1:=col.value #>> '{}',
                    val_2:=f.value,
                    negate:=coalesce(f.negate, false)
                )::int
            ) filter (where col.name is not null) = count(col.name),
            false
        )
    from
        unnest(filters) f
        left join unnest(columns) col
            on f.column_name = col.name;
$$;


ALTER FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) OWNER TO supabase_realtime_admin;

--
-- Name: list_changes(name, name, integer, integer); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) RETURNS TABLE(wal jsonb, is_rls_enabled boolean, subscription_ids uuid[], errors text[], slot_changes_count bigint)
    LANGUAGE sql
    SET log_min_messages TO 'fatal'
    AS $$
  WITH pub AS (
    SELECT
      concat_ws(
        ',',
        CASE WHEN bool_or(pubinsert) THEN 'insert' ELSE NULL END,
        CASE WHEN bool_or(pubupdate) THEN 'update' ELSE NULL END,
        CASE WHEN bool_or(pubdelete) THEN 'delete' ELSE NULL END
      ) AS w2j_actions,
      coalesce(
        string_agg(
          realtime.quote_wal2json(format('%I.%I', schemaname, tablename)::regclass),
          ','
        ) filter (WHERE ppt.tablename IS NOT NULL),
        ''
      ) AS w2j_add_tables
    FROM pg_publication pp
    LEFT JOIN pg_publication_tables ppt ON pp.pubname = ppt.pubname
    WHERE pp.pubname = publication
    GROUP BY pp.pubname
    LIMIT 1
  ),
  -- MATERIALIZED ensures pg_logical_slot_get_changes is called exactly once
  w2j AS MATERIALIZED (
    SELECT x.*, pub.w2j_add_tables
    FROM pub,
         pg_logical_slot_get_changes(
           slot_name, null, max_changes,
           'include-pk', 'true',
           'include-transaction', 'false',
           'include-timestamp', 'true',
           'include-type-oids', 'true',
           'format-version', '2',
           'actions', pub.w2j_actions,
           'add-tables', pub.w2j_add_tables
         ) x
  ),
  slot_count AS (
    SELECT count(*)::bigint AS cnt
    FROM w2j
    WHERE w2j.w2j_add_tables <> ''
  ),
  rls_filtered AS (
    SELECT xyz.wal, xyz.is_rls_enabled, xyz.subscription_ids, xyz.errors
    FROM w2j,
         realtime.apply_rls(
           wal := w2j.data::jsonb,
           max_record_bytes := max_record_bytes
         ) xyz(wal, is_rls_enabled, subscription_ids, errors)
    WHERE w2j.w2j_add_tables <> ''
      AND xyz.subscription_ids[1] IS NOT NULL
  )
  SELECT rf.wal, rf.is_rls_enabled, rf.subscription_ids, rf.errors, sc.cnt
  FROM rls_filtered rf, slot_count sc

  UNION ALL

  SELECT null, null, null, null, sc.cnt
  FROM slot_count sc
  WHERE NOT EXISTS (SELECT 1 FROM rls_filtered)
$$;


ALTER FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) OWNER TO supabase_realtime_admin;

--
-- Name: quote_wal2json(regclass); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.quote_wal2json(entity regclass) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
  SELECT
    realtime.wal2json_escape_identifier(nsp.nspname::text)
    || '.'
    || realtime.wal2json_escape_identifier(pc.relname::text)
  FROM pg_class pc
  JOIN pg_namespace nsp ON pc.relnamespace = nsp.oid
  WHERE pc.oid = entity
$$;


ALTER FUNCTION realtime.quote_wal2json(entity regclass) OWNER TO supabase_realtime_admin;

--
-- Name: send(jsonb, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  generated_id uuid;
  final_payload jsonb;
BEGIN
  BEGIN
    generated_id := gen_random_uuid();

    -- Check if payload has an 'id' key, if not, add the generated UUID
    IF payload ? 'id' THEN
      final_payload := payload;
    ELSE
      final_payload := jsonb_set(payload, '{id}', to_jsonb(generated_id));
    END IF;

    -- Set the topic configuration
    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    INSERT INTO realtime.messages (id, payload, event, topic, private, extension)
    VALUES (generated_id, final_payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      RAISE WARNING 'WarnSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


ALTER FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean) OWNER TO supabase_realtime_admin;

--
-- Name: send_binary(bytea, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.send_binary(payload bytea, event text, topic text, private boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  generated_id uuid;
BEGIN
  BEGIN
    generated_id := gen_random_uuid();

    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    INSERT INTO realtime.messages (id, binary_payload, event, topic, private, extension)
    VALUES (generated_id, payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      RAISE WARNING 'WarnSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


ALTER FUNCTION realtime.send_binary(payload bytea, event text, topic text, private boolean) OWNER TO supabase_realtime_admin;

--
-- Name: subscription_check_filters(); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.subscription_check_filters() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
    col_names text[] = coalesce(
            array_agg(a.attname order by a.attnum),
            '{}'::text[]
        )
        from
            pg_catalog.pg_attribute a
        where
            a.attrelid = new.entity
            and a.attnum > 0
            and not a.attisdropped
            and pg_catalog.has_column_privilege(
                (new.claims ->> 'role'),
                a.attrelid,
                a.attnum,
                'SELECT'
            );
    filter realtime.user_defined_filter;
    col_type regtype;
    in_val jsonb;
    selected_col text;
begin
    for filter in select * from unnest(new.filters) loop
        if not filter.column_name = any(col_names) then
            raise exception 'invalid column for filter %', filter.column_name;
        end if;

        col_type = (
            select atttypid::regtype
            from pg_catalog.pg_attribute
            where attrelid = new.entity
                  and attname = filter.column_name
        );
        if col_type is null then
            raise exception 'failed to lookup type for column %', filter.column_name;
        end if;

        if filter.op = 'in'::realtime.equality_op then
            in_val = realtime.cast(filter.value, (col_type::text || '[]')::regtype);
            if coalesce(jsonb_array_length(in_val), 0) > 100 then
                raise exception 'too many values for `in` filter. Maximum 100';
            end if;
        elsif filter.op = 'is'::realtime.equality_op then
            -- `is` requires a keyword RHS rather than a typed literal
            if filter.value not in ('null', 'true', 'false', 'unknown') then
                raise exception 'invalid value for is filter: must be null, true, false, or unknown';
            end if;
            -- IS NULL works for any type, but IS TRUE/FALSE/UNKNOWN require a boolean
            -- operand. Reject the non-null keywords on non-boolean columns here so they
            -- don't abort apply_rls at WAL time.
            if filter.value <> 'null' and col_type <> 'boolean'::regtype then
                raise exception 'is % filter requires a boolean column, got %', filter.value, col_type::text;
            end if;
        elsif filter.op in ('like'::realtime.equality_op, 'ilike'::realtime.equality_op) then
            -- like/ilike apply the text pattern operator (~~); reject column types that
            -- have no such operator instead of failing at WAL time
            if not exists (
                select 1 from pg_catalog.pg_operator
                where oprname = '~~' and oprleft = col_type
            ) then
                raise exception 'operator % requires a text-compatible column type, got %', filter.op::text, col_type::text;
            end if;
        elsif filter.op in ('match'::realtime.equality_op, 'imatch'::realtime.equality_op) then
            -- match/imatch apply the regex operators ~ / ~*; reject column types that have
            -- no such operator (e.g. integer) instead of failing at WAL time, mirroring the
            -- like/ilike guard above.
            if not exists (
                select 1 from pg_catalog.pg_operator
                where oprname = case when filter.op = 'imatch'::realtime.equality_op then '~*' else '~' end
                  and oprleft = col_type
                  and oprright = col_type
                  and oprresult = 'boolean'::regtype
            ) then
                raise exception 'operator % requires a text-compatible column type, got %', filter.op::text, col_type::text;
            end if;
            -- validate the regex eagerly so a bad pattern is rejected here, not inside
            -- apply_rls where it would abort the WAL stream for the entity
            begin
                perform '' ~ filter.value;
            exception when others then
                raise exception 'invalid regular expression for % filter: %', filter.op::text, sqlerrm;
            end;
        else
            -- eq/neq/lt/lte/gt/gte: value must be coercable to the type
            perform realtime.cast(filter.value, col_type);
        end if;
    end loop;

    if new.selected_columns is not null then
        for selected_col in select * from unnest(new.selected_columns) loop
            if not selected_col = any(col_names) then
                raise exception 'invalid column for select %', selected_col;
            end if;
        end loop;
    end if;

    -- Apply consistent order to filters so the unique constraint can't be tricked by a
    -- different filter order. negate is part of the sort key.
    new.filters = coalesce(
        array_agg(f order by f.column_name, f.op, f.value, f.negate),
        '{}'
    ) from unnest(new.filters) f;

    new.selected_columns = (
        select array_agg(c order by c)
        from unnest(new.selected_columns) c
    );

    return new;
end;
$$;


ALTER FUNCTION realtime.subscription_check_filters() OWNER TO supabase_realtime_admin;

--
-- Name: to_regrole(text); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.to_regrole(role_name text) RETURNS regrole
    LANGUAGE sql IMMUTABLE
    AS $$ select role_name::regrole $$;


ALTER FUNCTION realtime.to_regrole(role_name text) OWNER TO supabase_realtime_admin;

--
-- Name: topic(); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.topic() RETURNS text
    LANGUAGE sql STABLE
    AS $$
select nullif(current_setting('realtime.topic', true), '')::text;
$$;


ALTER FUNCTION realtime.topic() OWNER TO supabase_realtime_admin;

--
-- Name: wal2json_escape_identifier(text); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.wal2json_escape_identifier(name text) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
  -- Prefix `\`, `,`, `.`, and any whitespace with `\`
  SELECT regexp_replace(name, '([\\,.[:space:]])', '\\\1', 'g')
$$;


ALTER FUNCTION realtime.wal2json_escape_identifier(name text) OWNER TO supabase_realtime_admin;

--
-- Name: allow_any_operation(text[]); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.allow_any_operation(expected_operations text[]) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT CASE
      WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
      ELSE raw_operation
    END AS current_operation
    FROM current_operation
  )
  SELECT EXISTS (
    SELECT 1
    FROM normalized n
    CROSS JOIN LATERAL unnest(expected_operations) AS expected_operation
    WHERE expected_operation IS NOT NULL
      AND expected_operation <> ''
      AND n.current_operation = CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END
  );
$$;


ALTER FUNCTION storage.allow_any_operation(expected_operations text[]) OWNER TO supabase_storage_admin;

--
-- Name: allow_only_operation(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.allow_only_operation(expected_operation text) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT
      CASE
        WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
        ELSE raw_operation
      END AS current_operation,
      CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END AS requested_operation
    FROM current_operation
  )
  SELECT CASE
    WHEN requested_operation IS NULL OR requested_operation = '' THEN FALSE
    ELSE COALESCE(current_operation = requested_operation, FALSE)
  END
  FROM normalized;
$$;


ALTER FUNCTION storage.allow_only_operation(expected_operation text) OWNER TO supabase_storage_admin;

--
-- Name: can_insert_object(text, text, uuid, jsonb); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


ALTER FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) OWNER TO supabase_storage_admin;

--
-- Name: enforce_bucket_name_length(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.enforce_bucket_name_length() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
    if length(new.name) > 100 then
        raise exception 'bucket name "%" is too long (% characters). Max is 100.', new.name, length(new.name);
    end if;
    return new;
end;
$$;


ALTER FUNCTION storage.enforce_bucket_name_length() OWNER TO supabase_storage_admin;

--
-- Name: extension(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.extension(name text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
    _filename text;
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Get the last path segment (the actual filename)
    SELECT _parts[array_length(_parts, 1)] INTO _filename;
    -- Extract extension: reverse, split on '.', then reverse again
    RETURN reverse(split_part(reverse(_filename), '.', 1));
END
$$;


ALTER FUNCTION storage.extension(name text) OWNER TO supabase_storage_admin;

--
-- Name: filename(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.filename(name text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[array_length(_parts,1)];
END
$$;


ALTER FUNCTION storage.filename(name text) OWNER TO supabase_storage_admin;

--
-- Name: foldername(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.foldername(name text) RETURNS text[]
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Return everything except the last segment
    RETURN _parts[1 : array_length(_parts,1) - 1];
END
$$;


ALTER FUNCTION storage.foldername(name text) OWNER TO supabase_storage_admin;

--
-- Name: get_common_prefix(text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.get_common_prefix(p_key text, p_prefix text, p_delimiter text) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $$
SELECT CASE
    WHEN position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)) > 0
    THEN left(p_key, length(p_prefix) + position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)))
    ELSE NULL
END;
$$;


ALTER FUNCTION storage.get_common_prefix(p_key text, p_prefix text, p_delimiter text) OWNER TO supabase_storage_admin;

--
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.get_size_by_bucket() RETURNS TABLE(size bigint, bucket_id text)
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::bigint)::bigint as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


ALTER FUNCTION storage.get_size_by_bucket() OWNER TO supabase_storage_admin;

--
-- Name: list_multipart_uploads_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, next_key_token text DEFAULT ''::text, next_upload_token text DEFAULT ''::text) RETURNS TABLE(key text, id text, created_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(key COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                        substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1)))
                    ELSE
                        key
                END AS key, id, created_at
            FROM
                storage.s3_multipart_uploads
            WHERE
                bucket_id = $5 AND
                key ILIKE $1 || ''%'' AND
                CASE
                    WHEN $4 != '''' AND $6 = '''' THEN
                        CASE
                            WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                                substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                key COLLATE "C" > $4
                            END
                    ELSE
                        true
                END AND
                CASE
                    WHEN $6 != '''' THEN
                        id COLLATE "C" > $6
                    ELSE
                        true
                    END
            ORDER BY
                key COLLATE "C" ASC, created_at ASC) as e order by key COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_key_token, bucket_id, next_upload_token;
END;
$_$;


ALTER FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer, next_key_token text, next_upload_token text) OWNER TO supabase_storage_admin;

--
-- Name: list_objects_with_delimiter(text, text, text, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.list_objects_with_delimiter(_bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, start_after text DEFAULT ''::text, next_token text DEFAULT ''::text, sort_order text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, metadata jsonb, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;

    -- Configuration
    v_is_asc BOOLEAN;
    v_prefix TEXT;
    v_start TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_is_asc := lower(coalesce(sort_order, 'asc')) = 'asc';
    v_prefix := coalesce(prefix_param, '');
    v_start := CASE WHEN coalesce(next_token, '') <> '' THEN next_token ELSE coalesce(start_after, '') END;
    v_file_batch_size := LEAST(GREATEST(max_keys * 2, 100), 1000);

    -- Calculate upper bound for prefix filtering (bytewise, using COLLATE "C")
    IF v_prefix = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix, 1) = delimiter_param THEN
        v_upper_bound := left(v_prefix, -1) || chr(ascii(delimiter_param) + 1);
    ELSE
        v_upper_bound := left(v_prefix, -1) || chr(ascii(right(v_prefix, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'AND o.name COLLATE "C" < $3 ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'AND o.name COLLATE "C" >= $3 ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- ========================================================================
    -- SEEK INITIALIZATION: Determine starting position
    -- ========================================================================
    IF v_start = '' THEN
        IF v_is_asc THEN
            v_next_seek := v_prefix;
        ELSE
            -- DESC without cursor: find the last item in range
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;

            IF v_next_seek IS NOT NULL THEN
                v_next_seek := v_next_seek || delimiter_param;
            ELSE
                RETURN;
            END IF;
        END IF;
    ELSE
        -- Cursor provided: determine if it refers to a folder or leaf
        IF EXISTS (
            SELECT 1 FROM storage.objects o
            WHERE o.bucket_id = _bucket_id
              AND o.name COLLATE "C" LIKE v_start || delimiter_param || '%'
            LIMIT 1
        ) THEN
            -- Cursor refers to a folder
            IF v_is_asc THEN
                v_next_seek := v_start || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_start || delimiter_param;
            END IF;
        ELSE
            -- Cursor refers to a leaf object
            IF v_is_asc THEN
                v_next_seek := v_start || delimiter_param;
            ELSE
                v_next_seek := v_start;
            END IF;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= max_keys;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(v_peek_name, v_prefix, delimiter_param);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Emit and skip to next folder (no heap access needed)
            name := rtrim(v_common_prefix, delimiter_param);
            id := NULL;
            updated_at := NULL;
            created_at := NULL;
            last_accessed_at := NULL;
            metadata := NULL;
            RETURN NEXT;
            v_count := v_count + 1;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := left(v_common_prefix, -1) || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_common_prefix;
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query USING _bucket_id, v_next_seek,
                CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix) ELSE v_prefix END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(v_current.name, v_prefix, delimiter_param);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := v_current.name;
                    EXIT;
                END IF;

                -- Emit file
                name := v_current.name;
                id := v_current.id;
                updated_at := v_current.updated_at;
                created_at := v_current.created_at;
                last_accessed_at := v_current.last_accessed_at;
                metadata := v_current.metadata;
                RETURN NEXT;
                v_count := v_count + 1;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := v_current.name || delimiter_param;
                ELSE
                    v_next_seek := v_current.name;
                END IF;

                EXIT WHEN v_count >= max_keys;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


ALTER FUNCTION storage.list_objects_with_delimiter(_bucket_id text, prefix_param text, delimiter_param text, max_keys integer, start_after text, next_token text, sort_order text) OWNER TO supabase_storage_admin;

--
-- Name: operation(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.operation() RETURNS text
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    RETURN current_setting('storage.operation', true);
END;
$$;


ALTER FUNCTION storage.operation() OWNER TO supabase_storage_admin;

--
-- Name: protect_delete(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.protect_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Check if storage.allow_delete_query is set to 'true'
    IF COALESCE(current_setting('storage.allow_delete_query', true), 'false') != 'true' THEN
        RAISE EXCEPTION 'Direct deletion from storage tables is not allowed. Use the Storage API instead.'
            USING HINT = 'This prevents accidental data loss from orphaned objects.',
                  ERRCODE = '42501';
    END IF;
    RETURN NULL;
END;
$$;


ALTER FUNCTION storage.protect_delete() OWNER TO supabase_storage_admin;

--
-- Name: search(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.search(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;
    v_delimiter CONSTANT TEXT := '/';

    -- Configuration
    v_limit INT;
    v_prefix TEXT;
    v_prefix_lower TEXT;
    v_is_asc BOOLEAN;
    v_order_by TEXT;
    v_sort_order TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;
    v_skipped INT := 0;
BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_limit := LEAST(coalesce(limits, 100), 1500);
    v_prefix := coalesce(prefix, '') || coalesce(search, '');
    v_prefix_lower := lower(v_prefix);
    v_is_asc := lower(coalesce(sortorder, 'asc')) = 'asc';
    v_file_batch_size := LEAST(GREATEST(v_limit * 2, 100), 1000);

    -- Validate sort column
    CASE lower(coalesce(sortcolumn, 'name'))
        WHEN 'name' THEN v_order_by := 'name';
        WHEN 'updated_at' THEN v_order_by := 'updated_at';
        WHEN 'created_at' THEN v_order_by := 'created_at';
        WHEN 'last_accessed_at' THEN v_order_by := 'last_accessed_at';
        ELSE v_order_by := 'name';
    END CASE;

    v_sort_order := CASE WHEN v_is_asc THEN 'asc' ELSE 'desc' END;

    -- ========================================================================
    -- NON-NAME SORTING: Use path_tokens approach (unchanged)
    -- ========================================================================
    IF v_order_by != 'name' THEN
        RETURN QUERY EXECUTE format(
            $sql$
            WITH folders AS (
                SELECT path_tokens[$1] AS folder
                FROM storage.objects
                WHERE objects.name ILIKE $2 || '%%'
                  AND bucket_id = $3
                  AND array_length(objects.path_tokens, 1) <> $1
                GROUP BY folder
                ORDER BY folder %s
            )
            (SELECT folder AS "name",
                   NULL::uuid AS id,
                   NULL::timestamptz AS updated_at,
                   NULL::timestamptz AS created_at,
                   NULL::timestamptz AS last_accessed_at,
                   NULL::jsonb AS metadata FROM folders)
            UNION ALL
            (SELECT path_tokens[$1] AS "name",
                   id, updated_at, created_at, last_accessed_at, metadata
             FROM storage.objects
             WHERE objects.name ILIKE $2 || '%%'
               AND bucket_id = $3
               AND array_length(objects.path_tokens, 1) = $1
             ORDER BY %I %s)
            LIMIT $4 OFFSET $5
            $sql$, v_sort_order, v_order_by, v_sort_order
        ) USING levels, v_prefix, bucketname, v_limit, offsets;
        RETURN;
    END IF;

    -- ========================================================================
    -- NAME SORTING: Hybrid skip-scan with batch optimization
    -- ========================================================================

    -- Calculate upper bound for prefix filtering
    IF v_prefix_lower = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix_lower, 1) = v_delimiter THEN
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(v_delimiter) + 1);
    ELSE
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(right(v_prefix_lower, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'AND lower(o.name) COLLATE "C" < $3 ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'AND lower(o.name) COLLATE "C" >= $3 ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- Initialize seek position
    IF v_is_asc THEN
        v_next_seek := v_prefix_lower;
    ELSE
        -- DESC: find the last item in range first (static SQL)
        IF v_upper_bound IS NOT NULL THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower AND lower(o.name) COLLATE "C" < v_upper_bound
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSIF v_prefix_lower <> '' THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSE
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        END IF;

        IF v_peek_name IS NOT NULL THEN
            v_next_seek := lower(v_peek_name) || v_delimiter;
        ELSE
            RETURN;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= v_limit;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek AND lower(o.name) COLLATE "C" < v_upper_bound
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix_lower <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(lower(v_peek_name), v_prefix_lower, v_delimiter);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Handle offset, emit if needed, skip to next folder
            IF v_skipped < offsets THEN
                v_skipped := v_skipped + 1;
            ELSE
                name := split_part(rtrim(storage.get_common_prefix(v_peek_name, v_prefix, v_delimiter), v_delimiter), v_delimiter, levels);
                id := NULL;
                updated_at := NULL;
                created_at := NULL;
                last_accessed_at := NULL;
                metadata := NULL;
                RETURN NEXT;
                v_count := v_count + 1;
            END IF;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := lower(left(v_common_prefix, -1)) || chr(ascii(v_delimiter) + 1);
            ELSE
                v_next_seek := lower(v_common_prefix);
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix_lower is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query
                USING bucketname, v_next_seek,
                    CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix_lower) ELSE v_prefix_lower END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(lower(v_current.name), v_prefix_lower, v_delimiter);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := lower(v_current.name);
                    EXIT;
                END IF;

                -- Handle offset skipping
                IF v_skipped < offsets THEN
                    v_skipped := v_skipped + 1;
                ELSE
                    -- Emit file
                    name := split_part(v_current.name, v_delimiter, levels);
                    id := v_current.id;
                    updated_at := v_current.updated_at;
                    created_at := v_current.created_at;
                    last_accessed_at := v_current.last_accessed_at;
                    metadata := v_current.metadata;
                    RETURN NEXT;
                    v_count := v_count + 1;
                END IF;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := lower(v_current.name) || v_delimiter;
                ELSE
                    v_next_seek := lower(v_current.name);
                END IF;

                EXIT WHEN v_count >= v_limit;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


ALTER FUNCTION storage.search(prefix text, bucketname text, limits integer, levels integer, offsets integer, search text, sortcolumn text, sortorder text) OWNER TO supabase_storage_admin;

--
-- Name: search_by_timestamp(text, text, integer, integer, text, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.search_by_timestamp(p_prefix text, p_bucket_id text, p_limit integer, p_level integer, p_start_after text, p_sort_order text, p_sort_column text, p_sort_column_after text) RETURNS TABLE(key text, name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_cursor_op text;
    v_query text;
    v_prefix text;
BEGIN
    v_prefix := coalesce(p_prefix, '');

    IF p_sort_order = 'asc' THEN
        v_cursor_op := '>';
    ELSE
        v_cursor_op := '<';
    END IF;

    v_query := format($sql$
        WITH raw_objects AS (
            SELECT
                o.name AS obj_name,
                o.id AS obj_id,
                o.updated_at AS obj_updated_at,
                o.created_at AS obj_created_at,
                o.last_accessed_at AS obj_last_accessed_at,
                o.metadata AS obj_metadata,
                storage.get_common_prefix(o.name, $1, '/') AS common_prefix
            FROM storage.objects o
            WHERE o.bucket_id = $2
              AND o.name COLLATE "C" LIKE $1 || '%%'
        ),
        -- Aggregate common prefixes (folders)
        -- Both created_at and updated_at use MIN(obj_created_at) to match the old prefixes table behavior
        aggregated_prefixes AS (
            SELECT
                rtrim(common_prefix, '/') AS name,
                NULL::uuid AS id,
                MIN(obj_created_at) AS updated_at,
                MIN(obj_created_at) AS created_at,
                NULL::timestamptz AS last_accessed_at,
                NULL::jsonb AS metadata,
                TRUE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NOT NULL
            GROUP BY common_prefix
        ),
        leaf_objects AS (
            SELECT
                obj_name AS name,
                obj_id AS id,
                obj_updated_at AS updated_at,
                obj_created_at AS created_at,
                obj_last_accessed_at AS last_accessed_at,
                obj_metadata AS metadata,
                FALSE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NULL
        ),
        combined AS (
            SELECT * FROM aggregated_prefixes
            UNION ALL
            SELECT * FROM leaf_objects
        ),
        filtered AS (
            SELECT *
            FROM combined
            WHERE (
                $5 = ''
                OR ROW(
                    date_trunc('milliseconds', %I),
                    name COLLATE "C"
                ) %s ROW(
                    COALESCE(NULLIF($6, '')::timestamptz, 'epoch'::timestamptz),
                    $5
                )
            )
        )
        SELECT
            split_part(name, '/', $3) AS key,
            name,
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
        FROM filtered
        ORDER BY
            COALESCE(date_trunc('milliseconds', %I), 'epoch'::timestamptz) %s,
            name COLLATE "C" %s
        LIMIT $4
    $sql$,
        p_sort_column,
        v_cursor_op,
        p_sort_column,
        p_sort_order,
        p_sort_order
    );

    RETURN QUERY EXECUTE v_query
    USING v_prefix, p_bucket_id, p_level, p_limit, p_start_after, p_sort_column_after;
END;
$_$;


ALTER FUNCTION storage.search_by_timestamp(p_prefix text, p_bucket_id text, p_limit integer, p_level integer, p_start_after text, p_sort_order text, p_sort_column text, p_sort_column_after text) OWNER TO supabase_storage_admin;

--
-- Name: search_v2(text, text, integer, integer, text, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.search_v2(prefix text, bucket_name text, limits integer DEFAULT 100, levels integer DEFAULT 1, start_after text DEFAULT ''::text, sort_order text DEFAULT 'asc'::text, sort_column text DEFAULT 'name'::text, sort_column_after text DEFAULT ''::text) RETURNS TABLE(key text, name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $$
DECLARE
    v_sort_col text;
    v_sort_ord text;
    v_limit int;
BEGIN
    -- Cap limit to maximum of 1500 records
    v_limit := LEAST(coalesce(limits, 100), 1500);

    -- Validate and normalize sort_order
    v_sort_ord := lower(coalesce(sort_order, 'asc'));
    IF v_sort_ord NOT IN ('asc', 'desc') THEN
        v_sort_ord := 'asc';
    END IF;

    -- Validate and normalize sort_column
    v_sort_col := lower(coalesce(sort_column, 'name'));
    IF v_sort_col NOT IN ('name', 'updated_at', 'created_at') THEN
        v_sort_col := 'name';
    END IF;

    -- Route to appropriate implementation
    IF v_sort_col = 'name' THEN
        -- Use list_objects_with_delimiter for name sorting (most efficient: O(k * log n))
        RETURN QUERY
        SELECT
            split_part(l.name, '/', levels) AS key,
            l.name AS name,
            l.id,
            l.updated_at,
            l.created_at,
            l.last_accessed_at,
            l.metadata
        FROM storage.list_objects_with_delimiter(
            bucket_name,
            coalesce(prefix, ''),
            '/',
            v_limit,
            start_after,
            '',
            v_sort_ord
        ) l;
    ELSE
        -- Use aggregation approach for timestamp sorting
        -- Not efficient for large datasets but supports correct pagination
        RETURN QUERY SELECT * FROM storage.search_by_timestamp(
            prefix, bucket_name, v_limit, levels, start_after,
            v_sort_ord, v_sort_col, sort_column_after
        );
    END IF;
END;
$$;


ALTER FUNCTION storage.search_v2(prefix text, bucket_name text, limits integer, levels integer, start_after text, sort_order text, sort_column text, sort_column_after text) OWNER TO supabase_storage_admin;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


ALTER FUNCTION storage.update_updated_at_column() OWNER TO supabase_storage_admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.audit_log_entries (
    instance_id uuid,
    id uuid NOT NULL,
    payload json,
    created_at timestamp with time zone,
    ip_address character varying(64) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE auth.audit_log_entries OWNER TO supabase_auth_admin;

--
-- Name: TABLE audit_log_entries; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.audit_log_entries IS 'Auth: Audit trail for user actions.';


--
-- Name: custom_oauth_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.custom_oauth_providers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider_type text NOT NULL,
    identifier text NOT NULL,
    name text NOT NULL,
    client_id text NOT NULL,
    client_secret text NOT NULL,
    acceptable_client_ids text[] DEFAULT '{}'::text[] NOT NULL,
    scopes text[] DEFAULT '{}'::text[] NOT NULL,
    pkce_enabled boolean DEFAULT true NOT NULL,
    attribute_mapping jsonb DEFAULT '{}'::jsonb NOT NULL,
    authorization_params jsonb DEFAULT '{}'::jsonb NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    email_optional boolean DEFAULT false NOT NULL,
    issuer text,
    discovery_url text,
    skip_nonce_check boolean DEFAULT false NOT NULL,
    cached_discovery jsonb,
    discovery_cached_at timestamp with time zone,
    authorization_url text,
    token_url text,
    userinfo_url text,
    jwks_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    custom_claims_allowlist text[] DEFAULT '{}'::text[] NOT NULL,
    CONSTRAINT custom_oauth_providers_authorization_url_https CHECK (((authorization_url IS NULL) OR (authorization_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_authorization_url_length CHECK (((authorization_url IS NULL) OR (char_length(authorization_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_client_id_length CHECK (((char_length(client_id) >= 1) AND (char_length(client_id) <= 512))),
    CONSTRAINT custom_oauth_providers_discovery_url_length CHECK (((discovery_url IS NULL) OR (char_length(discovery_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_identifier_format CHECK ((identifier ~ '^[a-z0-9][a-z0-9:-]{0,48}[a-z0-9]$'::text)),
    CONSTRAINT custom_oauth_providers_issuer_length CHECK (((issuer IS NULL) OR ((char_length(issuer) >= 1) AND (char_length(issuer) <= 2048)))),
    CONSTRAINT custom_oauth_providers_jwks_uri_https CHECK (((jwks_uri IS NULL) OR (jwks_uri ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_jwks_uri_length CHECK (((jwks_uri IS NULL) OR (char_length(jwks_uri) <= 2048))),
    CONSTRAINT custom_oauth_providers_name_length CHECK (((char_length(name) >= 1) AND (char_length(name) <= 100))),
    CONSTRAINT custom_oauth_providers_oauth2_requires_endpoints CHECK (((provider_type <> 'oauth2'::text) OR ((authorization_url IS NOT NULL) AND (token_url IS NOT NULL) AND (userinfo_url IS NOT NULL)))),
    CONSTRAINT custom_oauth_providers_oidc_discovery_url_https CHECK (((provider_type <> 'oidc'::text) OR (discovery_url IS NULL) OR (discovery_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_oidc_issuer_https CHECK (((provider_type <> 'oidc'::text) OR (issuer IS NULL) OR (issuer ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_oidc_requires_issuer CHECK (((provider_type <> 'oidc'::text) OR (issuer IS NOT NULL))),
    CONSTRAINT custom_oauth_providers_provider_type_check CHECK ((provider_type = ANY (ARRAY['oauth2'::text, 'oidc'::text]))),
    CONSTRAINT custom_oauth_providers_token_url_https CHECK (((token_url IS NULL) OR (token_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_token_url_length CHECK (((token_url IS NULL) OR (char_length(token_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_userinfo_url_https CHECK (((userinfo_url IS NULL) OR (userinfo_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_userinfo_url_length CHECK (((userinfo_url IS NULL) OR (char_length(userinfo_url) <= 2048)))
);


ALTER TABLE auth.custom_oauth_providers OWNER TO supabase_auth_admin;

--
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.flow_state (
    id uuid NOT NULL,
    user_id uuid,
    auth_code text,
    code_challenge_method auth.code_challenge_method,
    code_challenge text,
    provider_type text NOT NULL,
    provider_access_token text,
    provider_refresh_token text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    authentication_method text NOT NULL,
    auth_code_issued_at timestamp with time zone,
    invite_token text,
    referrer text,
    oauth_client_state_id uuid,
    linking_target_id uuid,
    email_optional boolean DEFAULT false NOT NULL
);


ALTER TABLE auth.flow_state OWNER TO supabase_auth_admin;

--
-- Name: TABLE flow_state; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.flow_state IS 'Stores metadata for all OAuth/SSO login flows';


--
-- Name: identities; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.identities (
    provider_id text NOT NULL,
    user_id uuid NOT NULL,
    identity_data jsonb NOT NULL,
    provider text NOT NULL,
    last_sign_in_at timestamp with time zone,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    email text GENERATED ALWAYS AS (lower((identity_data ->> 'email'::text))) STORED,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE auth.identities OWNER TO supabase_auth_admin;

--
-- Name: TABLE identities; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.identities IS 'Auth: Stores identities associated to a user.';


--
-- Name: COLUMN identities.email; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.identities.email IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- Name: instances; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.instances (
    id uuid NOT NULL,
    uuid uuid,
    raw_base_config text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE auth.instances OWNER TO supabase_auth_admin;

--
-- Name: TABLE instances; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.instances IS 'Auth: Manages users across multiple sites.';


--
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_amr_claims (
    session_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    authentication_method text NOT NULL,
    id uuid NOT NULL
);


ALTER TABLE auth.mfa_amr_claims OWNER TO supabase_auth_admin;

--
-- Name: TABLE mfa_amr_claims; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_amr_claims IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_challenges (
    id uuid NOT NULL,
    factor_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    verified_at timestamp with time zone,
    ip_address inet NOT NULL,
    otp_code text,
    web_authn_session_data jsonb
);


ALTER TABLE auth.mfa_challenges OWNER TO supabase_auth_admin;

--
-- Name: TABLE mfa_challenges; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_challenges IS 'auth: stores metadata about challenge requests made';


--
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_factors (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    friendly_name text,
    factor_type auth.factor_type NOT NULL,
    status auth.factor_status NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    secret text,
    phone text,
    last_challenged_at timestamp with time zone,
    web_authn_credential jsonb,
    web_authn_aaguid uuid,
    last_webauthn_challenge_data jsonb
);


ALTER TABLE auth.mfa_factors OWNER TO supabase_auth_admin;

--
-- Name: TABLE mfa_factors; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_factors IS 'auth: stores metadata about factors';


--
-- Name: COLUMN mfa_factors.last_webauthn_challenge_data; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.mfa_factors.last_webauthn_challenge_data IS 'Stores the latest WebAuthn challenge data including attestation/assertion for customer verification';


--
-- Name: oauth_authorizations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.oauth_authorizations (
    id uuid NOT NULL,
    authorization_id text NOT NULL,
    client_id uuid NOT NULL,
    user_id uuid,
    redirect_uri text NOT NULL,
    scope text NOT NULL,
    state text,
    resource text,
    code_challenge text,
    code_challenge_method auth.code_challenge_method,
    response_type auth.oauth_response_type DEFAULT 'code'::auth.oauth_response_type NOT NULL,
    status auth.oauth_authorization_status DEFAULT 'pending'::auth.oauth_authorization_status NOT NULL,
    authorization_code text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone DEFAULT (now() + '00:03:00'::interval) NOT NULL,
    approved_at timestamp with time zone,
    nonce text,
    CONSTRAINT oauth_authorizations_authorization_code_length CHECK ((char_length(authorization_code) <= 255)),
    CONSTRAINT oauth_authorizations_code_challenge_length CHECK ((char_length(code_challenge) <= 128)),
    CONSTRAINT oauth_authorizations_expires_at_future CHECK ((expires_at > created_at)),
    CONSTRAINT oauth_authorizations_nonce_length CHECK ((char_length(nonce) <= 255)),
    CONSTRAINT oauth_authorizations_redirect_uri_length CHECK ((char_length(redirect_uri) <= 2048)),
    CONSTRAINT oauth_authorizations_resource_length CHECK ((char_length(resource) <= 2048)),
    CONSTRAINT oauth_authorizations_scope_length CHECK ((char_length(scope) <= 4096)),
    CONSTRAINT oauth_authorizations_state_length CHECK ((char_length(state) <= 4096))
);


ALTER TABLE auth.oauth_authorizations OWNER TO supabase_auth_admin;

--
-- Name: oauth_client_states; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.oauth_client_states (
    id uuid NOT NULL,
    provider_type text NOT NULL,
    code_verifier text,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE auth.oauth_client_states OWNER TO supabase_auth_admin;

--
-- Name: TABLE oauth_client_states; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.oauth_client_states IS 'Stores OAuth states for third-party provider authentication flows where Supabase acts as the OAuth client.';


--
-- Name: oauth_clients; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.oauth_clients (
    id uuid NOT NULL,
    client_secret_hash text,
    registration_type auth.oauth_registration_type NOT NULL,
    redirect_uris text NOT NULL,
    grant_types text NOT NULL,
    client_name text,
    client_uri text,
    logo_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    client_type auth.oauth_client_type DEFAULT 'confidential'::auth.oauth_client_type NOT NULL,
    token_endpoint_auth_method text NOT NULL,
    CONSTRAINT oauth_clients_client_name_length CHECK ((char_length(client_name) <= 1024)),
    CONSTRAINT oauth_clients_client_uri_length CHECK ((char_length(client_uri) <= 2048)),
    CONSTRAINT oauth_clients_logo_uri_length CHECK ((char_length(logo_uri) <= 2048)),
    CONSTRAINT oauth_clients_token_endpoint_auth_method_check CHECK ((token_endpoint_auth_method = ANY (ARRAY['client_secret_basic'::text, 'client_secret_post'::text, 'none'::text])))
);


ALTER TABLE auth.oauth_clients OWNER TO supabase_auth_admin;

--
-- Name: oauth_consents; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.oauth_consents (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    client_id uuid NOT NULL,
    scopes text NOT NULL,
    granted_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    CONSTRAINT oauth_consents_revoked_after_granted CHECK (((revoked_at IS NULL) OR (revoked_at >= granted_at))),
    CONSTRAINT oauth_consents_scopes_length CHECK ((char_length(scopes) <= 2048)),
    CONSTRAINT oauth_consents_scopes_not_empty CHECK ((char_length(TRIM(BOTH FROM scopes)) > 0))
);


ALTER TABLE auth.oauth_consents OWNER TO supabase_auth_admin;

--
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.one_time_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_type auth.one_time_token_type NOT NULL,
    token_hash text NOT NULL,
    relates_to text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT one_time_tokens_token_hash_check CHECK ((char_length(token_hash) > 0))
);


ALTER TABLE auth.one_time_tokens OWNER TO supabase_auth_admin;

--
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.refresh_tokens (
    instance_id uuid,
    id bigint NOT NULL,
    token character varying(255),
    user_id character varying(255),
    revoked boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    parent character varying(255),
    session_id uuid
);


ALTER TABLE auth.refresh_tokens OWNER TO supabase_auth_admin;

--
-- Name: TABLE refresh_tokens; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.refresh_tokens IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: supabase_auth_admin
--

CREATE SEQUENCE auth.refresh_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE auth.refresh_tokens_id_seq OWNER TO supabase_auth_admin;

--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: supabase_auth_admin
--

ALTER SEQUENCE auth.refresh_tokens_id_seq OWNED BY auth.refresh_tokens.id;


--
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.saml_providers (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    entity_id text NOT NULL,
    metadata_xml text NOT NULL,
    metadata_url text,
    attribute_mapping jsonb,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    name_id_format text,
    CONSTRAINT "entity_id not empty" CHECK ((char_length(entity_id) > 0)),
    CONSTRAINT "metadata_url not empty" CHECK (((metadata_url = NULL::text) OR (char_length(metadata_url) > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK ((char_length(metadata_xml) > 0))
);


ALTER TABLE auth.saml_providers OWNER TO supabase_auth_admin;

--
-- Name: TABLE saml_providers; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.saml_providers IS 'Auth: Manages SAML Identity Provider connections.';


--
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.saml_relay_states (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    request_id text NOT NULL,
    for_email text,
    redirect_to text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    flow_state_id uuid,
    CONSTRAINT "request_id not empty" CHECK ((char_length(request_id) > 0))
);


ALTER TABLE auth.saml_relay_states OWNER TO supabase_auth_admin;

--
-- Name: TABLE saml_relay_states; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.saml_relay_states IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE auth.schema_migrations OWNER TO supabase_auth_admin;

--
-- Name: TABLE schema_migrations; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.schema_migrations IS 'Auth: Manages updates to the auth system.';


--
-- Name: sessions; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    factor_id uuid,
    aal auth.aal_level,
    not_after timestamp with time zone,
    refreshed_at timestamp without time zone,
    user_agent text,
    ip inet,
    tag text,
    oauth_client_id uuid,
    refresh_token_hmac_key text,
    refresh_token_counter bigint,
    scopes text,
    CONSTRAINT sessions_scopes_length CHECK ((char_length(scopes) <= 4096))
);


ALTER TABLE auth.sessions OWNER TO supabase_auth_admin;

--
-- Name: TABLE sessions; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sessions IS 'Auth: Stores session data associated to a user.';


--
-- Name: COLUMN sessions.not_after; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sessions.not_after IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- Name: COLUMN sessions.refresh_token_hmac_key; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sessions.refresh_token_hmac_key IS 'Holds a HMAC-SHA256 key used to sign refresh tokens for this session.';


--
-- Name: COLUMN sessions.refresh_token_counter; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sessions.refresh_token_counter IS 'Holds the ID (counter) of the last issued refresh token.';


--
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sso_domains (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    domain text NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK ((char_length(domain) > 0))
);


ALTER TABLE auth.sso_domains OWNER TO supabase_auth_admin;

--
-- Name: TABLE sso_domains; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sso_domains IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sso_providers (
    id uuid NOT NULL,
    resource_id text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    disabled boolean,
    CONSTRAINT "resource_id not empty" CHECK (((resource_id = NULL::text) OR (char_length(resource_id) > 0)))
);


ALTER TABLE auth.sso_providers OWNER TO supabase_auth_admin;

--
-- Name: TABLE sso_providers; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sso_providers IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- Name: COLUMN sso_providers.resource_id; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sso_providers.resource_id IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- Name: users; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.users (
    instance_id uuid,
    id uuid NOT NULL,
    aud character varying(255),
    role character varying(255),
    email character varying(255),
    encrypted_password character varying(255),
    email_confirmed_at timestamp with time zone,
    invited_at timestamp with time zone,
    confirmation_token character varying(255),
    confirmation_sent_at timestamp with time zone,
    recovery_token character varying(255),
    recovery_sent_at timestamp with time zone,
    email_change_token_new character varying(255),
    email_change character varying(255),
    email_change_sent_at timestamp with time zone,
    last_sign_in_at timestamp with time zone,
    raw_app_meta_data jsonb,
    raw_user_meta_data jsonb,
    is_super_admin boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    phone text DEFAULT NULL::character varying,
    phone_confirmed_at timestamp with time zone,
    phone_change text DEFAULT ''::character varying,
    phone_change_token character varying(255) DEFAULT ''::character varying,
    phone_change_sent_at timestamp with time zone,
    confirmed_at timestamp with time zone GENERATED ALWAYS AS (LEAST(email_confirmed_at, phone_confirmed_at)) STORED,
    email_change_token_current character varying(255) DEFAULT ''::character varying,
    email_change_confirm_status smallint DEFAULT 0,
    banned_until timestamp with time zone,
    reauthentication_token character varying(255) DEFAULT ''::character varying,
    reauthentication_sent_at timestamp with time zone,
    is_sso_user boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    is_anonymous boolean DEFAULT false NOT NULL,
    CONSTRAINT users_email_change_confirm_status_check CHECK (((email_change_confirm_status >= 0) AND (email_change_confirm_status <= 2)))
);


ALTER TABLE auth.users OWNER TO supabase_auth_admin;

--
-- Name: TABLE users; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.users IS 'Auth: Stores user login data within a secure schema.';


--
-- Name: COLUMN users.is_sso_user; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.users.is_sso_user IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- Name: webauthn_challenges; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.webauthn_challenges (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    challenge_type text NOT NULL,
    session_data jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    CONSTRAINT webauthn_challenges_challenge_type_check CHECK ((challenge_type = ANY (ARRAY['signup'::text, 'registration'::text, 'authentication'::text])))
);


ALTER TABLE auth.webauthn_challenges OWNER TO supabase_auth_admin;

--
-- Name: webauthn_credentials; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.webauthn_credentials (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    credential_id bytea NOT NULL,
    public_key bytea NOT NULL,
    attestation_type text DEFAULT ''::text NOT NULL,
    aaguid uuid,
    sign_count bigint DEFAULT 0 NOT NULL,
    transports jsonb DEFAULT '[]'::jsonb NOT NULL,
    backup_eligible boolean DEFAULT false NOT NULL,
    backed_up boolean DEFAULT false NOT NULL,
    friendly_name text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    last_used_at timestamp with time zone
);


ALTER TABLE auth.webauthn_credentials OWNER TO supabase_auth_admin;

--
-- Name: articles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.articles (
    id bigint NOT NULL,
    status text DEFAULT 'published'::text,
    sort integer,
    slug text NOT NULL,
    title text NOT NULL,
    excerpt text,
    content text,
    featured_image text,
    author text,
    tags jsonb DEFAULT '[]'::jsonb,
    category text,
    date_published timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT articles_status_check CHECK ((status = ANY (ARRAY['published'::text, 'draft'::text])))
);


ALTER TABLE public.articles OWNER TO postgres;

--
-- Name: articles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.articles ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.articles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: clients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clients (
    id bigint NOT NULL,
    status text DEFAULT 'published'::text,
    sort integer,
    name text NOT NULL,
    logo text,
    tags jsonb DEFAULT '[]'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    in_carousel boolean DEFAULT false,
    CONSTRAINT clients_status_check CHECK ((status = ANY (ARRAY['published'::text, 'draft'::text])))
);


ALTER TABLE public.clients OWNER TO postgres;

--
-- Name: clients_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.clients ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.clients_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: faq; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.faq (
    id bigint NOT NULL,
    status text DEFAULT 'published'::text,
    sort integer,
    question_fr text NOT NULL,
    answer_fr text,
    question_en text,
    answer_en text,
    question_br text,
    answer_br text,
    category text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT faq_status_check CHECK ((status = ANY (ARRAY['published'::text, 'draft'::text])))
);


ALTER TABLE public.faq OWNER TO postgres;

--
-- Name: faq_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.faq ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.faq_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: glossaire; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.glossaire (
    id bigint NOT NULL,
    status text DEFAULT 'published'::text,
    sort integer,
    term_fr text NOT NULL,
    definition_fr text,
    term_en text,
    definition_en text,
    term_br text,
    definition_br text,
    related_expertise text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT glossaire_status_check CHECK ((status = ANY (ARRAY['published'::text, 'draft'::text])))
);


ALTER TABLE public.glossaire OWNER TO postgres;

--
-- Name: glossaire_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.glossaire ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.glossaire_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: partenaires; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.partenaires (
    id bigint NOT NULL,
    status text DEFAULT 'published'::text,
    sort integer,
    name text NOT NULL,
    logo text,
    role text,
    website text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT partenaires_status_check CHECK ((status = ANY (ARRAY['published'::text, 'draft'::text])))
);


ALTER TABLE public.partenaires OWNER TO postgres;

--
-- Name: partenaires_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.partenaires ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.partenaires_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: projets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.projets (
    id bigint NOT NULL,
    status text DEFAULT 'published'::text,
    sort integer,
    slug text NOT NULL,
    title text NOT NULL,
    description text,
    location text,
    category text,
    client text,
    missions jsonb DEFAULT '[]'::jsonb,
    technical_details text,
    image_before text,
    image_after text,
    images_gallery jsonb DEFAULT '[]'::jsonb,
    latitude double precision,
    longitude double precision,
    date timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    documents jsonb DEFAULT '[]'::jsonb,
    CONSTRAINT projets_status_check CHECK ((status = ANY (ARRAY['published'::text, 'draft'::text])))
);


ALTER TABLE public.projets OWNER TO postgres;

--
-- Name: projets_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.projets ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.projets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: simulations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.simulations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    address text NOT NULL,
    parcel_ref text,
    total_surface text,
    lot_a_surface text,
    lot_b_surface text,
    client_name text NOT NULL,
    client_email text NOT NULL,
    client_phone text,
    client_message text,
    status text DEFAULT 'new'::text NOT NULL
);


ALTER TABLE public.simulations OWNER TO postgres;

--
-- Name: site_texts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.site_texts (
    key text NOT NULL,
    fr text NOT NULL,
    en text,
    br text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.site_texts OWNER TO postgres;

--
-- Name: social_posts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.social_posts (
    id bigint NOT NULL,
    status text DEFAULT 'published'::text,
    sort integer,
    url text NOT NULL,
    caption text,
    date timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT social_posts_status_check CHECK ((status = ANY (ARRAY['published'::text, 'draft'::text])))
);


ALTER TABLE public.social_posts OWNER TO postgres;

--
-- Name: social_posts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.social_posts ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.social_posts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: team_header; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.team_header (
    id integer DEFAULT 1 NOT NULL,
    title_fr text,
    subtitle_fr text,
    title_en text,
    subtitle_en text,
    title_br text,
    subtitle_br text,
    team_photo text,
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT only_one_row CHECK ((id = 1))
);


ALTER TABLE public.team_header OWNER TO postgres;

--
-- Name: team_members; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.team_members (
    id bigint NOT NULL,
    status text DEFAULT 'published'::text,
    sort integer,
    slug text,
    image text,
    linkedin text,
    generic boolean DEFAULT false,
    email text,
    phone text,
    name_fr text,
    role_fr text,
    desc_fr text,
    name_en text,
    role_en text,
    desc_en text,
    name_br text,
    role_br text,
    desc_br text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT team_members_status_check CHECK ((status = ANY (ARRAY['published'::text, 'draft'::text])))
);


ALTER TABLE public.team_members OWNER TO postgres;

--
-- Name: team_members_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.team_members ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.team_members_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: visits; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.visits (
    id bigint NOT NULL,
    path text NOT NULL,
    is_article boolean DEFAULT false,
    device text DEFAULT 'Desktop'::text,
    browser text DEFAULT 'Autre'::text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.visits OWNER TO postgres;

--
-- Name: visits_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.visits ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.visits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: messages; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE realtime.messages (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    binary_payload bytea
)
PARTITION BY RANGE (inserted_at);


ALTER TABLE realtime.messages OWNER TO supabase_realtime_admin;

--
-- Name: schema_migrations; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.schema_migrations (
    version bigint NOT NULL,
    inserted_at timestamp(0) without time zone
);


ALTER TABLE realtime.schema_migrations OWNER TO supabase_admin;

--
-- Name: subscription; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE realtime.subscription (
    id bigint NOT NULL,
    subscription_id uuid NOT NULL,
    entity regclass NOT NULL,
    filters realtime.user_defined_filter[] DEFAULT '{}'::realtime.user_defined_filter[] NOT NULL,
    claims jsonb NOT NULL,
    claims_role regrole GENERATED ALWAYS AS (realtime.to_regrole((claims ->> 'role'::text))) STORED NOT NULL,
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    action_filter text DEFAULT '*'::text,
    selected_columns text[],
    CONSTRAINT subscription_action_filter_check CHECK ((action_filter = ANY (ARRAY['*'::text, 'INSERT'::text, 'UPDATE'::text, 'DELETE'::text])))
);


ALTER TABLE realtime.subscription OWNER TO supabase_realtime_admin;

--
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE realtime.subscription ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME realtime.subscription_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: buckets; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.buckets (
    id text NOT NULL,
    name text NOT NULL,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    public boolean DEFAULT false,
    avif_autodetection boolean DEFAULT false,
    file_size_limit bigint,
    allowed_mime_types text[],
    owner_id text,
    type storage.buckettype DEFAULT 'STANDARD'::storage.buckettype NOT NULL
);


ALTER TABLE storage.buckets OWNER TO supabase_storage_admin;

--
-- Name: COLUMN buckets.owner; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN storage.buckets.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: buckets_analytics; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.buckets_analytics (
    name text NOT NULL,
    type storage.buckettype DEFAULT 'ANALYTICS'::storage.buckettype NOT NULL,
    format text DEFAULT 'ICEBERG'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE storage.buckets_analytics OWNER TO supabase_storage_admin;

--
-- Name: buckets_vectors; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.buckets_vectors (
    id text NOT NULL,
    type storage.buckettype DEFAULT 'VECTOR'::storage.buckettype NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE storage.buckets_vectors OWNER TO supabase_storage_admin;

--
-- Name: migrations; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.migrations (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    hash character varying(40) NOT NULL,
    executed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE storage.migrations OWNER TO supabase_storage_admin;

--
-- Name: objects; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.objects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id text,
    name text,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_accessed_at timestamp with time zone DEFAULT now(),
    metadata jsonb,
    path_tokens text[] GENERATED ALWAYS AS (string_to_array(name, '/'::text)) STORED,
    version text,
    owner_id text,
    user_metadata jsonb
);


ALTER TABLE storage.objects OWNER TO supabase_storage_admin;

--
-- Name: COLUMN objects.owner; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN storage.objects.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: s3_multipart_uploads; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.s3_multipart_uploads (
    id text NOT NULL,
    in_progress_size bigint DEFAULT 0 NOT NULL,
    upload_signature text NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    version text NOT NULL,
    owner_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    user_metadata jsonb,
    metadata jsonb
);


ALTER TABLE storage.s3_multipart_uploads OWNER TO supabase_storage_admin;

--
-- Name: s3_multipart_uploads_parts; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.s3_multipart_uploads_parts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    upload_id text NOT NULL,
    size bigint DEFAULT 0 NOT NULL,
    part_number integer NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    etag text NOT NULL,
    owner_id text,
    version text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE storage.s3_multipart_uploads_parts OWNER TO supabase_storage_admin;

--
-- Name: vector_indexes; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.vector_indexes (
    id text DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    bucket_id text NOT NULL,
    data_type text NOT NULL,
    dimension integer NOT NULL,
    distance_metric text NOT NULL,
    metadata_configuration jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE storage.vector_indexes OWNER TO supabase_storage_admin;

--
-- Name: schema_migrations; Type: TABLE; Schema: supabase_migrations; Owner: postgres
--

CREATE TABLE supabase_migrations.schema_migrations (
    version text NOT NULL,
    statements text[],
    name text
);


ALTER TABLE supabase_migrations.schema_migrations OWNER TO postgres;

--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('auth.refresh_tokens_id_seq'::regclass);


--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.audit_log_entries (instance_id, id, payload, created_at, ip_address) FROM stdin;
\.


--
-- Data for Name: custom_oauth_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.custom_oauth_providers (id, provider_type, identifier, name, client_id, client_secret, acceptable_client_ids, scopes, pkce_enabled, attribute_mapping, authorization_params, enabled, email_optional, issuer, discovery_url, skip_nonce_check, cached_discovery, discovery_cached_at, authorization_url, token_url, userinfo_url, jwks_uri, created_at, updated_at, custom_claims_allowlist) FROM stdin;
\.


--
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.flow_state (id, user_id, auth_code, code_challenge_method, code_challenge, provider_type, provider_access_token, provider_refresh_token, created_at, updated_at, authentication_method, auth_code_issued_at, invite_token, referrer, oauth_client_state_id, linking_target_id, email_optional) FROM stdin;
\.


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at, id) FROM stdin;
d997a92e-2df1-4660-b542-91c9968be7d8	d997a92e-2df1-4660-b542-91c9968be7d8	{"sub": "d997a92e-2df1-4660-b542-91c9968be7d8", "email": "admin@urbateam.fr", "email_verified": false, "phone_verified": false}	email	2026-06-02 03:08:53.760425+00	2026-06-02 03:08:53.760503+00	2026-06-02 03:08:53.760503+00	c0f05a0d-94dc-4f37-97bd-0fbc1a86bf03
\.


--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.instances (id, uuid, raw_base_config, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) FROM stdin;
eacd801c-2fa3-4f3e-be7c-ac96cc5378b0	2026-06-02 03:26:40.736171+00	2026-06-02 03:26:40.736171+00	password	4aa28525-6d28-435b-b598-edffb3df7bcd
40607303-3761-4c0f-9641-b880df7e2158	2026-06-02 03:36:14.257501+00	2026-06-02 03:36:14.257501+00	password	475c8502-4e76-48f9-9388-c200dbefa2e5
384e8392-bafd-4f49-a1e9-5ecd03373a6a	2026-06-02 03:39:19.023688+00	2026-06-02 03:39:19.023688+00	password	4faa0f10-e9db-4d8f-b698-6e167554c74e
68437c3c-372d-42da-98b2-bfea62e151d1	2026-06-02 15:27:46.355798+00	2026-06-02 15:27:46.355798+00	password	bd707fd5-d019-4135-88bb-726524f89273
8110ed04-a736-4ec6-bc06-6c26fdeda78b	2026-06-02 16:30:40.943059+00	2026-06-02 16:30:40.943059+00	password	293fe72d-2694-4573-97cf-afa30c73c7fc
6639f289-fa50-4961-b9df-c6e259afaa62	2026-06-03 15:20:52.626027+00	2026-06-03 15:20:52.626027+00	password	ff33e893-0e4b-4175-8c69-9233806da9c8
32509832-9ad8-44fe-866d-0f50959f3296	2026-06-03 15:21:10.405853+00	2026-06-03 15:21:10.405853+00	password	e1ba4925-d452-4749-a4f9-cb884bdc92d8
3d373496-9663-45e4-9a3c-bf772f99837b	2026-06-04 14:46:13.724428+00	2026-06-04 14:46:13.724428+00	password	d85ec7a1-5a52-41b1-9852-44355d939c17
fdd82c06-cd01-428e-b1ac-37a392fd960b	2026-06-04 15:37:43.476927+00	2026-06-04 15:37:43.476927+00	password	2f8447d0-6b30-440a-98da-778b59b6f398
a1d5e5d4-297b-4d66-851f-4a77be676910	2026-06-19 13:28:38.19562+00	2026-06-19 13:28:38.19562+00	password	35aa8358-f659-47da-9ef6-8ef5b87372e0
15251f06-6e20-4911-8a4f-a06e2e165b78	2026-06-19 14:36:46.776773+00	2026-06-19 14:36:46.776773+00	password	64c29e52-e342-4b45-a118-95289fded678
749a0226-ea70-4bde-9082-e4bfb3e79ed5	2026-06-19 14:49:39.226565+00	2026-06-19 14:49:39.226565+00	password	d346608f-9208-4a35-9d13-7d666efc748f
50255756-f09d-4eec-8e1a-c23e5b60e0a3	2026-06-22 12:18:36.430271+00	2026-06-22 12:18:36.430271+00	password	2a0554fc-def8-4388-928f-e4c76dc71739
78191201-b250-47be-9ec6-b6ff60a657b2	2026-06-22 13:18:46.272047+00	2026-06-22 13:18:46.272047+00	password	2420705a-29df-4ba1-b994-0b74a6fab068
598f2b9e-a84a-46b3-914b-0166e4284f0a	2026-06-22 14:47:33.70183+00	2026-06-22 14:47:33.70183+00	password	f02f4ab9-f216-466a-bfbe-270dea44d4fa
c581539c-5599-40bb-a6c9-c70d50a14b2e	2026-06-22 15:47:40.092566+00	2026-06-22 15:47:40.092566+00	password	014fd264-e092-4c9a-a592-e0c9c2b3e885
f51e1674-de29-4f8a-9bba-9461f497c6fc	2026-06-22 15:53:52.859246+00	2026-06-22 15:53:52.859246+00	password	fffa9272-1e39-46b3-98f8-2b3398f2c3ad
6c182147-24e9-437c-bd10-8c9253ce7389	2026-06-26 08:05:42.304267+00	2026-06-26 08:05:42.304267+00	password	efddd0de-b3c9-4b85-858b-16297533e196
f0818a8f-e4db-445b-a392-a8b08b7d8a87	2026-07-20 15:52:11.547993+00	2026-07-20 15:52:11.547993+00	password	90b4679b-ed3e-4798-a43e-872b15efed43
22d2767e-67cc-4135-a7ef-1a956e005401	2026-07-20 17:43:11.661337+00	2026-07-20 17:43:11.661337+00	password	27005d61-9046-46f0-aa5c-90efe1ee3691
a8c9e255-3c0f-4233-ad20-b35fd5ccf646	2026-07-20 17:43:28.389442+00	2026-07-20 17:43:28.389442+00	password	16fb591f-6b52-4dba-ab37-e9a94f21ea4d
c4a9f9ca-d1da-4c40-bbc3-21eb5f15cac5	2026-07-20 17:44:20.086166+00	2026-07-20 17:44:20.086166+00	password	367faaeb-81c4-4d9b-88ef-b3727fa5db44
42b7d871-fde4-4aa3-8cb2-dcaa825c178a	2026-07-20 17:51:02.251682+00	2026-07-20 17:51:02.251682+00	password	f429267a-834e-4610-8e2f-fd730c337978
31c1b148-226e-4bde-8ed2-f0e0bb044e78	2026-07-20 17:55:01.259606+00	2026-07-20 17:55:01.259606+00	password	1a366530-3003-4dc5-bc2e-1d8757837d65
a860cfa9-2e06-4069-9ae6-7f2e9a193537	2026-07-20 18:13:38.852743+00	2026-07-20 18:13:38.852743+00	password	8456b2ca-51f3-4b0e-80ab-7b6c22a80a61
f474db8b-b7ba-4e3a-9f44-edac80a2d926	2026-07-20 19:10:11.144442+00	2026-07-20 19:10:11.144442+00	password	c180a063-6144-4fe3-b864-95c5df9625d2
8fc84baa-e0e4-4136-886f-00878021607f	2026-07-20 19:11:24.535774+00	2026-07-20 19:11:24.535774+00	password	5d7e82c6-a921-4054-b351-83e6c1d5c3aa
4e611bc5-7779-4bde-a163-46c0f6db163e	2026-07-20 19:12:02.915735+00	2026-07-20 19:12:02.915735+00	password	d6f5461e-8887-4dee-898e-f904b51e3d07
567c05be-06db-441e-8912-3d2901687659	2026-07-21 17:12:52.15962+00	2026-07-21 17:12:52.15962+00	password	649cebd8-03c2-4ea6-8e00-76e767e5a20c
2556fa92-972d-453d-9655-fbf39a4c1ccc	2026-07-21 17:18:46.558394+00	2026-07-21 17:18:46.558394+00	password	23cc3b2f-6d13-42ff-9819-a52c11f12c7d
6bed7ae6-e939-47d0-a872-ae6e71b4a4ed	2026-07-21 17:22:29.423299+00	2026-07-21 17:22:29.423299+00	password	9bad8aa6-ad18-42e4-b179-a1c2a5aca25d
acc7ed7e-ac7c-48d5-b618-5f4238d49fac	2026-07-21 17:27:13.721197+00	2026-07-21 17:27:13.721197+00	password	1dd11fec-f762-4957-adba-6d0571792ffe
88e9fcab-8335-4705-9c95-28c16e5ecac0	2026-07-21 18:07:44.201988+00	2026-07-21 18:07:44.201988+00	password	e1df9110-7dac-4775-9a50-14fb50ec1973
8c177554-3898-4f3b-bfa8-4608b14804e9	2026-07-21 18:21:22.034978+00	2026-07-21 18:21:22.034978+00	password	42de9c35-670c-4d0e-8a13-f369085da8ba
1d95a5c9-b567-4767-a441-d3948948e57e	2026-07-21 18:56:40.344073+00	2026-07-21 18:56:40.344073+00	password	d1d06df0-30a3-409f-9f18-6d89ff25147a
2abfef84-4850-4c09-9d91-0070e8a09f13	2026-07-28 06:59:47.213014+00	2026-07-28 06:59:47.213014+00	password	158b551f-4b02-4666-9587-d643bf2890b5
8e72ac89-430d-4880-989d-ab50881096d6	2026-07-28 07:27:19.652357+00	2026-07-28 07:27:19.652357+00	password	fd1c914a-c0cc-446f-8d5d-1d50ede28e50
8b2082ea-159c-4088-b5ff-1a120bdc1937	2026-07-28 08:30:18.646776+00	2026-07-28 08:30:18.646776+00	password	0f4205eb-077e-4fd1-b5dc-542f121062a2
1b9400da-9479-4ee4-93d0-59280b142424	2026-07-28 08:32:46.789224+00	2026-07-28 08:32:46.789224+00	password	2525970b-8611-499e-86b4-766c85612cff
4eb1b993-0f50-4eca-840a-85f73543bf4f	2026-07-29 07:04:05.778663+00	2026-07-29 07:04:05.778663+00	password	b7870d94-0f85-4447-8af0-0f75e54be4bc
080a98fc-bd2a-41b0-9734-3096194e7725	2026-07-29 09:03:10.501409+00	2026-07-29 09:03:10.501409+00	password	8a6b3e02-4072-4ac5-b1b4-0e86ea18da1d
9cc84f84-b066-4bdc-8500-e7b4535c08a8	2026-07-29 09:48:32.279789+00	2026-07-29 09:48:32.279789+00	password	e7540c82-006a-4196-89a1-0a8f85894cf6
fa5cf7e7-519a-49ce-a43c-f59119f04adf	2026-07-29 12:21:38.239739+00	2026-07-29 12:21:38.239739+00	password	df7e5e86-ec55-4163-b183-a06719ec0775
72f65bb8-1076-4852-bedd-48588563d6fd	2026-07-29 13:33:08.190085+00	2026-07-29 13:33:08.190085+00	password	be034630-10e5-4453-b8bb-106645e1f0d5
\.


--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_challenges (id, factor_id, created_at, verified_at, ip_address, otp_code, web_authn_session_data) FROM stdin;
\.


--
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_factors (id, user_id, friendly_name, factor_type, status, created_at, updated_at, secret, phone, last_challenged_at, web_authn_credential, web_authn_aaguid, last_webauthn_challenge_data) FROM stdin;
\.


--
-- Data for Name: oauth_authorizations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.oauth_authorizations (id, authorization_id, client_id, user_id, redirect_uri, scope, state, resource, code_challenge, code_challenge_method, response_type, status, authorization_code, created_at, expires_at, approved_at, nonce) FROM stdin;
\.


--
-- Data for Name: oauth_client_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.oauth_client_states (id, provider_type, code_verifier, created_at) FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.oauth_clients (id, client_secret_hash, registration_type, redirect_uris, grant_types, client_name, client_uri, logo_uri, created_at, updated_at, deleted_at, client_type, token_endpoint_auth_method) FROM stdin;
\.


--
-- Data for Name: oauth_consents; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.oauth_consents (id, user_id, client_id, scopes, granted_at, revoked_at) FROM stdin;
\.


--
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.one_time_tokens (id, user_id, token_type, token_hash, relates_to, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) FROM stdin;
00000000-0000-0000-0000-000000000000	1	rqk4lhjg42an	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-06-02 03:26:40.723079+00	2026-06-02 03:26:40.723079+00	\N	eacd801c-2fa3-4f3e-be7c-ac96cc5378b0
00000000-0000-0000-0000-000000000000	2	kf4nrwtcyehe	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-06-02 03:36:14.253222+00	2026-06-02 03:36:14.253222+00	\N	40607303-3761-4c0f-9641-b880df7e2158
00000000-0000-0000-0000-000000000000	3	rpczbvep6w2f	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-06-02 03:39:19.017834+00	2026-06-02 03:39:19.017834+00	\N	384e8392-bafd-4f49-a1e9-5ecd03373a6a
00000000-0000-0000-0000-000000000000	4	cujf3vic3cr4	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-06-02 15:27:46.324624+00	2026-06-02 15:27:46.324624+00	\N	68437c3c-372d-42da-98b2-bfea62e151d1
00000000-0000-0000-0000-000000000000	5	s4cnoxpq6547	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-06-02 16:30:40.92631+00	2026-06-02 16:30:40.92631+00	\N	8110ed04-a736-4ec6-bc06-6c26fdeda78b
00000000-0000-0000-0000-000000000000	6	4yumy737hqwz	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-06-03 15:20:52.59781+00	2026-06-03 15:20:52.59781+00	\N	6639f289-fa50-4961-b9df-c6e259afaa62
00000000-0000-0000-0000-000000000000	7	pzqqvyro2ju7	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-06-03 15:21:10.397432+00	2026-06-03 15:21:10.397432+00	\N	32509832-9ad8-44fe-866d-0f50959f3296
00000000-0000-0000-0000-000000000000	8	vm55yto25rho	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-06-04 14:46:13.68519+00	2026-06-04 14:46:13.68519+00	\N	3d373496-9663-45e4-9a3c-bf772f99837b
00000000-0000-0000-0000-000000000000	9	x3uhermilgzq	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-06-04 15:37:43.462848+00	2026-06-04 15:37:43.462848+00	\N	fdd82c06-cd01-428e-b1ac-37a392fd960b
00000000-0000-0000-0000-000000000000	10	n5e7k5kaqhft	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-06-19 13:28:38.169625+00	2026-06-19 13:28:38.169625+00	\N	a1d5e5d4-297b-4d66-851f-4a77be676910
00000000-0000-0000-0000-000000000000	11	au43ev254zoi	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-06-19 14:36:46.76361+00	2026-06-19 14:36:46.76361+00	\N	15251f06-6e20-4911-8a4f-a06e2e165b78
00000000-0000-0000-0000-000000000000	12	3m7n75s4n5ad	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-06-19 14:49:39.222796+00	2026-06-19 14:49:39.222796+00	\N	749a0226-ea70-4bde-9082-e4bfb3e79ed5
00000000-0000-0000-0000-000000000000	13	wz2hdyqqhzrt	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-06-22 12:18:36.402598+00	2026-06-22 12:18:36.402598+00	\N	50255756-f09d-4eec-8e1a-c23e5b60e0a3
00000000-0000-0000-0000-000000000000	14	now2ts6yt3se	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-06-22 13:18:46.261182+00	2026-06-22 13:18:46.261182+00	\N	78191201-b250-47be-9ec6-b6ff60a657b2
00000000-0000-0000-0000-000000000000	15	q2kddpvlotcx	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-06-22 14:47:33.667757+00	2026-06-22 14:47:33.667757+00	\N	598f2b9e-a84a-46b3-914b-0166e4284f0a
00000000-0000-0000-0000-000000000000	16	3ndaby2d4xoa	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-06-22 15:47:40.067351+00	2026-06-22 15:47:40.067351+00	\N	c581539c-5599-40bb-a6c9-c70d50a14b2e
00000000-0000-0000-0000-000000000000	17	qgfnv4sg74tq	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-06-22 15:53:52.845401+00	2026-06-22 15:53:52.845401+00	\N	f51e1674-de29-4f8a-9bba-9461f497c6fc
00000000-0000-0000-0000-000000000000	18	lpesa3ghyagq	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-06-26 08:05:42.290531+00	2026-06-26 08:05:42.290531+00	\N	6c182147-24e9-437c-bd10-8c9253ce7389
00000000-0000-0000-0000-000000000000	19	zcriiwcqcpkx	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-07-20 15:52:11.513247+00	2026-07-20 15:52:11.513247+00	\N	f0818a8f-e4db-445b-a392-a8b08b7d8a87
00000000-0000-0000-0000-000000000000	20	5fjvbekfedhc	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-07-20 17:43:11.656301+00	2026-07-20 17:43:11.656301+00	\N	22d2767e-67cc-4135-a7ef-1a956e005401
00000000-0000-0000-0000-000000000000	21	tdckgmao56od	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-07-20 17:43:28.383529+00	2026-07-20 17:43:28.383529+00	\N	a8c9e255-3c0f-4233-ad20-b35fd5ccf646
00000000-0000-0000-0000-000000000000	22	6j3xho656yja	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-07-20 17:44:20.076463+00	2026-07-20 17:44:20.076463+00	\N	c4a9f9ca-d1da-4c40-bbc3-21eb5f15cac5
00000000-0000-0000-0000-000000000000	23	siggivtcz2zd	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-07-20 17:51:02.246448+00	2026-07-20 17:51:02.246448+00	\N	42b7d871-fde4-4aa3-8cb2-dcaa825c178a
00000000-0000-0000-0000-000000000000	24	dslmionrx2qi	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-07-20 17:55:01.253765+00	2026-07-20 17:55:01.253765+00	\N	31c1b148-226e-4bde-8ed2-f0e0bb044e78
00000000-0000-0000-0000-000000000000	25	e4ca6bc6zhwh	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-07-20 18:13:38.803131+00	2026-07-20 18:13:38.803131+00	\N	a860cfa9-2e06-4069-9ae6-7f2e9a193537
00000000-0000-0000-0000-000000000000	26	yfwtnsubxpjd	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-07-20 19:10:11.123033+00	2026-07-20 19:10:11.123033+00	\N	f474db8b-b7ba-4e3a-9f44-edac80a2d926
00000000-0000-0000-0000-000000000000	27	qjxhjbda6rqp	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-07-20 19:11:24.532759+00	2026-07-20 19:11:24.532759+00	\N	8fc84baa-e0e4-4136-886f-00878021607f
00000000-0000-0000-0000-000000000000	28	lr5jx4qr3k5d	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-07-20 19:12:02.914262+00	2026-07-20 19:12:02.914262+00	\N	4e611bc5-7779-4bde-a163-46c0f6db163e
00000000-0000-0000-0000-000000000000	29	2mhfeabcyj2q	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-07-21 17:12:52.125275+00	2026-07-21 17:12:52.125275+00	\N	567c05be-06db-441e-8912-3d2901687659
00000000-0000-0000-0000-000000000000	30	l25fktlrwhvv	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-07-21 17:18:46.555289+00	2026-07-21 17:18:46.555289+00	\N	2556fa92-972d-453d-9655-fbf39a4c1ccc
00000000-0000-0000-0000-000000000000	31	4njw5ksecaab	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-07-21 17:22:29.41859+00	2026-07-21 17:22:29.41859+00	\N	6bed7ae6-e939-47d0-a872-ae6e71b4a4ed
00000000-0000-0000-0000-000000000000	32	7t6biuipi5b3	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-07-21 17:27:13.717402+00	2026-07-21 17:27:13.717402+00	\N	acc7ed7e-ac7c-48d5-b618-5f4238d49fac
00000000-0000-0000-0000-000000000000	33	rpykvos6666s	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-07-21 18:07:44.179155+00	2026-07-21 18:07:44.179155+00	\N	88e9fcab-8335-4705-9c95-28c16e5ecac0
00000000-0000-0000-0000-000000000000	34	65vsq456zbng	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-07-21 18:21:22.027496+00	2026-07-21 18:21:22.027496+00	\N	8c177554-3898-4f3b-bfa8-4608b14804e9
00000000-0000-0000-0000-000000000000	35	z7uacmt4dkri	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-07-21 18:56:40.327575+00	2026-07-21 18:56:40.327575+00	\N	1d95a5c9-b567-4767-a441-d3948948e57e
00000000-0000-0000-0000-000000000000	36	yivobersvg6a	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-07-28 06:59:47.192198+00	2026-07-28 06:59:47.192198+00	\N	2abfef84-4850-4c09-9d91-0070e8a09f13
00000000-0000-0000-0000-000000000000	37	r3wvbtg43znr	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-07-28 07:27:19.629358+00	2026-07-28 07:27:19.629358+00	\N	8e72ac89-430d-4880-989d-ab50881096d6
00000000-0000-0000-0000-000000000000	38	6uivagaj6l2g	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-07-28 08:30:18.63379+00	2026-07-28 08:30:18.63379+00	\N	8b2082ea-159c-4088-b5ff-1a120bdc1937
00000000-0000-0000-0000-000000000000	39	t5iqgezyr7ie	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-07-28 08:32:46.784178+00	2026-07-28 08:32:46.784178+00	\N	1b9400da-9479-4ee4-93d0-59280b142424
00000000-0000-0000-0000-000000000000	40	hfa2ghk7qqvv	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-07-29 07:04:05.742287+00	2026-07-29 07:04:05.742287+00	\N	4eb1b993-0f50-4eca-840a-85f73543bf4f
00000000-0000-0000-0000-000000000000	41	hd6ty74j4qrk	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-07-29 09:03:10.471255+00	2026-07-29 09:03:10.471255+00	\N	080a98fc-bd2a-41b0-9734-3096194e7725
00000000-0000-0000-0000-000000000000	42	d5i54thyxy3u	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-07-29 09:48:32.261391+00	2026-07-29 09:48:32.261391+00	\N	9cc84f84-b066-4bdc-8500-e7b4535c08a8
00000000-0000-0000-0000-000000000000	43	fv2udhgflxw5	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-07-29 12:21:38.22134+00	2026-07-29 12:21:38.22134+00	\N	fa5cf7e7-519a-49ce-a43c-f59119f04adf
00000000-0000-0000-0000-000000000000	44	a6mucngt6q3l	d997a92e-2df1-4660-b542-91c9968be7d8	f	2026-07-29 13:33:08.164575+00	2026-07-29 13:33:08.164575+00	\N	72f65bb8-1076-4852-bedd-48588563d6fd
\.


--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.saml_providers (id, sso_provider_id, entity_id, metadata_xml, metadata_url, attribute_mapping, created_at, updated_at, name_id_format) FROM stdin;
\.


--
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.saml_relay_states (id, sso_provider_id, request_id, for_email, redirect_to, created_at, updated_at, flow_state_id) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.schema_migrations (version) FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
00
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
20220811173540
20221003041349
20221003041400
20221011041400
20221020193600
20221021073300
20221021082433
20221027105023
20221114143122
20221114143410
20221125140132
20221208132122
20221215195500
20221215195800
20221215195900
20230116124310
20230116124412
20230131181311
20230322519590
20230402418590
20230411005111
20230508135423
20230523124323
20230818113222
20230914180801
20231027141322
20231114161723
20231117164230
20240115144230
20240214120130
20240306115329
20240314092811
20240427152123
20240612123726
20240729123726
20240802193726
20240806073726
20241009103726
20250717082212
20250731150234
20250804100000
20250901200500
20250903112500
20250904133000
20250925093508
20251007112900
20251104100000
20251111201300
20251201000000
20260115000000
20260121000000
20260219120000
20260302000000
20260625000000
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag, oauth_client_id, refresh_token_hmac_key, refresh_token_counter, scopes) FROM stdin;
eacd801c-2fa3-4f3e-be7c-ac96cc5378b0	d997a92e-2df1-4660-b542-91c9968be7d8	2026-06-02 03:26:40.702622+00	2026-06-02 03:26:40.702622+00	\N	aal1	\N	\N	node	44.211.74.12	\N	\N	\N	\N	\N
40607303-3761-4c0f-9641-b880df7e2158	d997a92e-2df1-4660-b542-91c9968be7d8	2026-06-02 03:36:14.240725+00	2026-06-02 03:36:14.240725+00	\N	aal1	\N	\N	node	3.236.162.232	\N	\N	\N	\N	\N
384e8392-bafd-4f49-a1e9-5ecd03373a6a	d997a92e-2df1-4660-b542-91c9968be7d8	2026-06-02 03:39:19.007275+00	2026-06-02 03:39:19.007275+00	\N	aal1	\N	\N	node	54.226.101.95	\N	\N	\N	\N	\N
68437c3c-372d-42da-98b2-bfea62e151d1	d997a92e-2df1-4660-b542-91c9968be7d8	2026-06-02 15:27:46.288806+00	2026-06-02 15:27:46.288806+00	\N	aal1	\N	\N	node	3.239.120.240	\N	\N	\N	\N	\N
8110ed04-a736-4ec6-bc06-6c26fdeda78b	d997a92e-2df1-4660-b542-91c9968be7d8	2026-06-02 16:30:40.903665+00	2026-06-02 16:30:40.903665+00	\N	aal1	\N	\N	node	100.31.199.114	\N	\N	\N	\N	\N
6639f289-fa50-4961-b9df-c6e259afaa62	d997a92e-2df1-4660-b542-91c9968be7d8	2026-06-03 15:20:52.566798+00	2026-06-03 15:20:52.566798+00	\N	aal1	\N	\N	node	100.26.100.38	\N	\N	\N	\N	\N
32509832-9ad8-44fe-866d-0f50959f3296	d997a92e-2df1-4660-b542-91c9968be7d8	2026-06-03 15:21:10.39289+00	2026-06-03 15:21:10.39289+00	\N	aal1	\N	\N	node	100.26.100.38	\N	\N	\N	\N	\N
3d373496-9663-45e4-9a3c-bf772f99837b	d997a92e-2df1-4660-b542-91c9968be7d8	2026-06-04 14:46:13.642663+00	2026-06-04 14:46:13.642663+00	\N	aal1	\N	\N	node	13.220.28.4	\N	\N	\N	\N	\N
fdd82c06-cd01-428e-b1ac-37a392fd960b	d997a92e-2df1-4660-b542-91c9968be7d8	2026-06-04 15:37:43.447901+00	2026-06-04 15:37:43.447901+00	\N	aal1	\N	\N	node	100.26.107.216	\N	\N	\N	\N	\N
a1d5e5d4-297b-4d66-851f-4a77be676910	d997a92e-2df1-4660-b542-91c9968be7d8	2026-06-19 13:28:38.133849+00	2026-06-19 13:28:38.133849+00	\N	aal1	\N	\N	node	54.92.154.185	\N	\N	\N	\N	\N
15251f06-6e20-4911-8a4f-a06e2e165b78	d997a92e-2df1-4660-b542-91c9968be7d8	2026-06-19 14:36:46.744005+00	2026-06-19 14:36:46.744005+00	\N	aal1	\N	\N	node	44.199.192.119	\N	\N	\N	\N	\N
749a0226-ea70-4bde-9082-e4bfb3e79ed5	d997a92e-2df1-4660-b542-91c9968be7d8	2026-06-19 14:49:39.21288+00	2026-06-19 14:49:39.21288+00	\N	aal1	\N	\N	node	44.203.167.84	\N	\N	\N	\N	\N
50255756-f09d-4eec-8e1a-c23e5b60e0a3	d997a92e-2df1-4660-b542-91c9968be7d8	2026-06-22 12:18:36.3662+00	2026-06-22 12:18:36.3662+00	\N	aal1	\N	\N	node	100.53.245.153	\N	\N	\N	\N	\N
78191201-b250-47be-9ec6-b6ff60a657b2	d997a92e-2df1-4660-b542-91c9968be7d8	2026-06-22 13:18:46.239251+00	2026-06-22 13:18:46.239251+00	\N	aal1	\N	\N	node	54.87.229.182	\N	\N	\N	\N	\N
598f2b9e-a84a-46b3-914b-0166e4284f0a	d997a92e-2df1-4660-b542-91c9968be7d8	2026-06-22 14:47:33.628881+00	2026-06-22 14:47:33.628881+00	\N	aal1	\N	\N	node	34.229.169.236	\N	\N	\N	\N	\N
c581539c-5599-40bb-a6c9-c70d50a14b2e	d997a92e-2df1-4660-b542-91c9968be7d8	2026-06-22 15:47:40.035594+00	2026-06-22 15:47:40.035594+00	\N	aal1	\N	\N	node	54.210.30.49	\N	\N	\N	\N	\N
f51e1674-de29-4f8a-9bba-9461f497c6fc	d997a92e-2df1-4660-b542-91c9968be7d8	2026-06-22 15:53:52.823516+00	2026-06-22 15:53:52.823516+00	\N	aal1	\N	\N	node	54.146.45.0	\N	\N	\N	\N	\N
6c182147-24e9-437c-bd10-8c9253ce7389	d997a92e-2df1-4660-b542-91c9968be7d8	2026-06-26 08:05:42.267019+00	2026-06-26 08:05:42.267019+00	\N	aal1	\N	\N	node	18.207.247.6	\N	\N	\N	\N	\N
f0818a8f-e4db-445b-a392-a8b08b7d8a87	d997a92e-2df1-4660-b542-91c9968be7d8	2026-07-20 15:52:11.48097+00	2026-07-20 15:52:11.48097+00	\N	aal1	\N	\N	node	3.239.20.201	\N	\N	\N	\N	\N
22d2767e-67cc-4135-a7ef-1a956e005401	d997a92e-2df1-4660-b542-91c9968be7d8	2026-07-20 17:43:11.636167+00	2026-07-20 17:43:11.636167+00	\N	aal1	\N	\N	node	35.173.50.144	\N	\N	\N	\N	\N
a8c9e255-3c0f-4233-ad20-b35fd5ccf646	d997a92e-2df1-4660-b542-91c9968be7d8	2026-07-20 17:43:28.382444+00	2026-07-20 17:43:28.382444+00	\N	aal1	\N	\N	node	35.173.50.144	\N	\N	\N	\N	\N
c4a9f9ca-d1da-4c40-bbc3-21eb5f15cac5	d997a92e-2df1-4660-b542-91c9968be7d8	2026-07-20 17:44:20.048071+00	2026-07-20 17:44:20.048071+00	\N	aal1	\N	\N	node	98.93.54.54	\N	\N	\N	\N	\N
42b7d871-fde4-4aa3-8cb2-dcaa825c178a	d997a92e-2df1-4660-b542-91c9968be7d8	2026-07-20 17:51:02.229464+00	2026-07-20 17:51:02.229464+00	\N	aal1	\N	\N	node	54.152.97.106	\N	\N	\N	\N	\N
31c1b148-226e-4bde-8ed2-f0e0bb044e78	d997a92e-2df1-4660-b542-91c9968be7d8	2026-07-20 17:55:01.238051+00	2026-07-20 17:55:01.238051+00	\N	aal1	\N	\N	node	54.152.97.106	\N	\N	\N	\N	\N
a860cfa9-2e06-4069-9ae6-7f2e9a193537	d997a92e-2df1-4660-b542-91c9968be7d8	2026-07-20 18:13:38.726214+00	2026-07-20 18:13:38.726214+00	\N	aal1	\N	\N	node	13.223.186.140	\N	\N	\N	\N	\N
f474db8b-b7ba-4e3a-9f44-edac80a2d926	d997a92e-2df1-4660-b542-91c9968be7d8	2026-07-20 19:10:11.088725+00	2026-07-20 19:10:11.088725+00	\N	aal1	\N	\N	node	18.234.180.241	\N	\N	\N	\N	\N
8fc84baa-e0e4-4136-886f-00878021607f	d997a92e-2df1-4660-b542-91c9968be7d8	2026-07-20 19:11:24.524767+00	2026-07-20 19:11:24.524767+00	\N	aal1	\N	\N	node	44.223.36.68	\N	\N	\N	\N	\N
4e611bc5-7779-4bde-a163-46c0f6db163e	d997a92e-2df1-4660-b542-91c9968be7d8	2026-07-20 19:12:02.913124+00	2026-07-20 19:12:02.913124+00	\N	aal1	\N	\N	node	18.213.115.128	\N	\N	\N	\N	\N
567c05be-06db-441e-8912-3d2901687659	d997a92e-2df1-4660-b542-91c9968be7d8	2026-07-21 17:12:52.097303+00	2026-07-21 17:12:52.097303+00	\N	aal1	\N	\N	node	3.95.179.101	\N	\N	\N	\N	\N
2556fa92-972d-453d-9655-fbf39a4c1ccc	d997a92e-2df1-4660-b542-91c9968be7d8	2026-07-21 17:18:46.543881+00	2026-07-21 17:18:46.543881+00	\N	aal1	\N	\N	node	100.58.246.55	\N	\N	\N	\N	\N
6bed7ae6-e939-47d0-a872-ae6e71b4a4ed	d997a92e-2df1-4660-b542-91c9968be7d8	2026-07-21 17:22:29.404126+00	2026-07-21 17:22:29.404126+00	\N	aal1	\N	\N	node	54.242.156.27	\N	\N	\N	\N	\N
acc7ed7e-ac7c-48d5-b618-5f4238d49fac	d997a92e-2df1-4660-b542-91c9968be7d8	2026-07-21 17:27:13.696084+00	2026-07-21 17:27:13.696084+00	\N	aal1	\N	\N	node	3.218.150.89	\N	\N	\N	\N	\N
88e9fcab-8335-4705-9c95-28c16e5ecac0	d997a92e-2df1-4660-b542-91c9968be7d8	2026-07-21 18:07:44.153916+00	2026-07-21 18:07:44.153916+00	\N	aal1	\N	\N	node	54.91.107.144	\N	\N	\N	\N	\N
8c177554-3898-4f3b-bfa8-4608b14804e9	d997a92e-2df1-4660-b542-91c9968be7d8	2026-07-21 18:21:22.014141+00	2026-07-21 18:21:22.014141+00	\N	aal1	\N	\N	node	32.192.217.190	\N	\N	\N	\N	\N
1d95a5c9-b567-4767-a441-d3948948e57e	d997a92e-2df1-4660-b542-91c9968be7d8	2026-07-21 18:56:40.318255+00	2026-07-21 18:56:40.318255+00	\N	aal1	\N	\N	node	54.236.87.63	\N	\N	\N	\N	\N
2abfef84-4850-4c09-9d91-0070e8a09f13	d997a92e-2df1-4660-b542-91c9968be7d8	2026-07-28 06:59:47.168098+00	2026-07-28 06:59:47.168098+00	\N	aal1	\N	\N	node	3.234.182.217	\N	\N	\N	\N	\N
8e72ac89-430d-4880-989d-ab50881096d6	d997a92e-2df1-4660-b542-91c9968be7d8	2026-07-28 07:27:19.612225+00	2026-07-28 07:27:19.612225+00	\N	aal1	\N	\N	node	98.92.21.132	\N	\N	\N	\N	\N
8b2082ea-159c-4088-b5ff-1a120bdc1937	d997a92e-2df1-4660-b542-91c9968be7d8	2026-07-28 08:30:18.610301+00	2026-07-28 08:30:18.610301+00	\N	aal1	\N	\N	node	13.217.226.99	\N	\N	\N	\N	\N
1b9400da-9479-4ee4-93d0-59280b142424	d997a92e-2df1-4660-b542-91c9968be7d8	2026-07-28 08:32:46.775123+00	2026-07-28 08:32:46.775123+00	\N	aal1	\N	\N	node	13.217.226.99	\N	\N	\N	\N	\N
4eb1b993-0f50-4eca-840a-85f73543bf4f	d997a92e-2df1-4660-b542-91c9968be7d8	2026-07-29 07:04:05.714312+00	2026-07-29 07:04:05.714312+00	\N	aal1	\N	\N	node	3.80.73.18	\N	\N	\N	\N	\N
080a98fc-bd2a-41b0-9734-3096194e7725	d997a92e-2df1-4660-b542-91c9968be7d8	2026-07-29 09:03:10.446602+00	2026-07-29 09:03:10.446602+00	\N	aal1	\N	\N	node	18.207.163.44	\N	\N	\N	\N	\N
9cc84f84-b066-4bdc-8500-e7b4535c08a8	d997a92e-2df1-4660-b542-91c9968be7d8	2026-07-29 09:48:32.241827+00	2026-07-29 09:48:32.241827+00	\N	aal1	\N	\N	node	34.202.166.150	\N	\N	\N	\N	\N
fa5cf7e7-519a-49ce-a43c-f59119f04adf	d997a92e-2df1-4660-b542-91c9968be7d8	2026-07-29 12:21:38.198218+00	2026-07-29 12:21:38.198218+00	\N	aal1	\N	\N	node	3.239.198.99	\N	\N	\N	\N	\N
72f65bb8-1076-4852-bedd-48588563d6fd	d997a92e-2df1-4660-b542-91c9968be7d8	2026-07-29 13:33:08.13221+00	2026-07-29 13:33:08.13221+00	\N	aal1	\N	\N	node	98.92.24.151	\N	\N	\N	\N	\N
\.


--
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sso_domains (id, sso_provider_id, domain, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sso_providers (id, resource_id, created_at, updated_at, disabled) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, invited_at, confirmation_token, confirmation_sent_at, recovery_token, recovery_sent_at, email_change_token_new, email_change, email_change_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, is_super_admin, created_at, updated_at, phone, phone_confirmed_at, phone_change, phone_change_token, phone_change_sent_at, email_change_token_current, email_change_confirm_status, banned_until, reauthentication_token, reauthentication_sent_at, is_sso_user, deleted_at, is_anonymous) FROM stdin;
00000000-0000-0000-0000-000000000000	d997a92e-2df1-4660-b542-91c9968be7d8	authenticated	authenticated	admin@urbateam.fr	$2a$10$r3zWXR6GbCS1v.9Sjjn2uuWPNCfl5B8PICJa9Mgc1jXY/WH/LX4iW	2026-06-02 03:08:53.76634+00	\N		\N		\N			\N	2026-07-29 13:33:08.129758+00	{"provider": "email", "providers": ["email"]}	{"email_verified": true}	\N	2026-06-02 03:08:53.740268+00	2026-07-29 13:33:08.176752+00	\N	\N			\N		0	\N		\N	f	\N	f
\.


--
-- Data for Name: webauthn_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.webauthn_challenges (id, user_id, challenge_type, session_data, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: webauthn_credentials; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.webauthn_credentials (id, user_id, credential_id, public_key, attestation_type, aaguid, sign_count, transports, backup_eligible, backed_up, friendly_name, created_at, updated_at, last_used_at) FROM stdin;
\.


--
-- Data for Name: articles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.articles (id, status, sort, slug, title, excerpt, content, featured_image, author, tags, category, date_published, created_at, updated_at) FROM stdin;
1	published	\N	division-parcellaire-valorisez-patrimoine-foncier	Division Parcellaire : Valorisez votre patrimoine foncier avec URBATEAM	Vous possédez un grand terrain et souhaitez en détacher une parcelle à bâtir ? Découvrez comment la division parcellaire peut valoriser votre patrimoine immobilier.	<h2>Optimiser le potentiel de votre terrain : La division foncière</h2><p>Dans un contexte de forte demande immobilière en Bretagne, posséder un grand jardin ou un terrain sous-exploité à <strong>Quimper</strong>, <strong>Lorient</strong> ou <strong>Brest</strong> représente une opportunité financière majeure. La <strong>division parcellaire</strong> (ou détachement de lot à bâtir) est une opération qui permet de créer un ou plusieurs nouveaux terrains constructibles à partir d'une propriété existante. Chez <strong>URBATEAM</strong>, nous accompagnons les particuliers et les professionnels pour transformer ce potentiel en réalité concrète.</p><p><img src="/uploads/blog/division-parcellaire.png" style="max-width:100%; height:auto; margin: 1.5rem 0; border-radius: 12px; display: block; box-shadow: 0 4px 12px rgba(0,0,0,0.1);" alt="Division parcellaire URBATEAM Bretagne"></p><h2>Pourquoi diviser son terrain ? Les avantages d'une stratégie foncière intelligente</h2><p>Vendre une partie de sa propriété peut répondre à plusieurs objectifs :</p><ul><li><strong>Se constituer un capital :</strong> La vente d'un terrain à bâtir permet souvent de financer des travaux de rénovation sur la maison principale ou de réaliser un nouvel investissement.</li><li><strong>Réduire l'entretien :</strong> Un jardin trop vaste devient parfois une charge. Diviser permet de conserver une surface gérable tout en valorisant l'excédent.</li><li><strong>Favoriser la densification urbaine :</strong> En créant de nouveaux logements en centre-ville de <strong>Landerneau</strong> ou <strong>Douarnenez</strong>, vous participez à la lutte contre l'étalement urbain, un enjeu écologique majeur soutenu par les PLU (Plan Local d'Urbanisme).</li></ul><h2>Le rôle crucial du Géomètre-Expert dans votre projet de division</h2><p>La division foncière n'est pas qu'une question de dessin sur un plan. C'est une opération juridique et technique complexe qui nécessite l'intervention exclusive du <strong>Géomètre-Expert</strong>. URBATEAM vous apporte une expertise à chaque étape :</p><ol><li><strong>Étude de faisabilité :</strong> Nous analysons les règles d'urbanisme de votre commune (PLU de <strong>Brest Métropole</strong> ou <strong>Quimper Bretagne Occidentale</strong>) pour vérifier les possibilités de construction (emprise au sol, hauteur, accès).</li><li><strong>Le relevé topographique :</strong> Nous mesurons précisément l'état actuel de votre propriété (limites, bâtiments, réseaux, arbres).</li><li><strong>La conception du projet :</strong> Nous dessinons les nouvelles limites en veillant à la qualité de vie des futurs occupants et à la préservation de la valeur de votre maison actuelle.</li><li><strong>Les démarches administratives :</strong> Nous préparons et déposons pour vous la <strong>Déclaration Préalable</strong> ou le <strong>Permis d'Aménager</strong> en mairie.</li><li><strong>Le bornage :</strong> Nous fixons juridiquement les nouvelles limites et posons les bornes pour garantir la sécurité de la transaction.</li></ol><h2>Éviter les pièges de la division foncière</h2><p>Une division mal préparée peut entraîner des litiges de voisinage ou des refus en mairie. URBATEAM veille sur des points critiques souvent négligés : la gestion des eaux pluviales, la création d'accès sécurisés, ou encore le respect des servitudes (passage, vue). Que vous soyez à <strong>Concarneau</strong>, <strong>Morlaix</strong> ou <strong>Fouesnant</strong>, notre connaissance du tissu local breton est votre meilleur atout pour réussir votre projet.</p><p>Faire appel à URBATEAM, c'est choisir la sérénité pour valoriser votre patrimoine foncier de manière durable et conforme à la loi.</p>	division-parcellaire.png	URBATEAM	["Foncier", "Division", "Expertise", "Urbanisme"]	Actualité	2026-05-15 10:00:00+00	2026-06-02 02:48:26.719751+00	2026-06-02 02:48:26.719751+00
2	published	\N	ingenierie-sportive-haute-precision-performance-athletique	Ingénierie Sportive : Quand la haute précision rencontre la performance athlétique	La conception d'un complexe sportif est un défi de précision millimétrique. Découvrez comment URBATEAM accompagne les collectivités dans la création d'équipements homologués.	<h2>L'expertise invisible derrière le record : L'ingénierie sportive par URBATEAM</h2><p>Le spectateur voit un stade, l'athlète voit une performance, mais pour <strong>URBATEAM</strong>, un complexe sportif est avant tout un chef-d'œuvre de précision technique. Que ce soit pour une piste d'athlétisme à <strong>Brest</strong>, un terrain de football synthétique à <strong>Quimper</strong> ou un complexe multisports à <strong>Concarneau</strong>, l'ingénierie sportive exige une rigueur que seuls quelques bureaux d'études spécialisés maîtrisent en Bretagne.</p><p><img src="/uploads/blog/ingenierie-sportive.png" style="max-width:100%; height:auto; margin: 1.5rem 0; border-radius: 12px; display: block; box-shadow: 0 4px 12px rgba(0,0,0,0.1);" alt="Ingénierie Sportive URBATEAM Bretagne"></p><h2>Le défi des pentes : Le millimètre au service du drainage et de la performance</h2><p>Le secret d'un bon terrain de sport, qu'il soit en gazon naturel ou synthétique, réside dans sa capacité à gérer les eaux météoriques. Pour qu'un match puisse se jouer sous une pluie battante à <strong>Morlaix</strong> ou <strong>Landerneau</strong>, la conception du drainage et des pentes doit être d'une précision chirurgicale.</p><p>Chez <strong>URBATEAM</strong>, nous ne nous contentons pas d'appliquer des pentes standards. Nous calculons des modèles de ruissellement complexes :</p><ul><li><strong>Précision Laser :</strong> Nous utilisons des stations totales robotisées pour garantir que les pentes de 0,5% à 1% sont respectées au millimètre près sur toute la surface du terrain.</li><li><strong>Drainage de pointe :</strong> Nous concevons des réseaux de drainage en "arête de poisson" ou en nappes drainantes, dimensionnés selon la pluviométrie spécifique du <strong>Finistère</strong>.</li><li><strong>Zéro stagnation :</strong> L'objectif est d'évacuer l'eau instantanément pour préserver la structure du sol et la sécurité des appuis des sportifs.</li></ul><p>Sur une piste d'athlétisme, comme celles que l'on peut trouver à <strong>Douarnenez</strong> ou <strong>Fouesnant</strong>, la tolérance est quasi nulle. Un faux-plat trop prononcé ou une stagnation d'eau, et la piste n'est plus homologuée par la Fédération Française d'Athlétisme (FFA) pour les records officiels. Notre rôle de <strong>Géomètre-Expert</strong> et d'Ingénieur VRD est de garantir cette conformité absolue par un contrôle rigoureux durant toute la phase de chantier.</p><h2>Une maîtrise complète du cycle de vie des équipements sportifs</h2><p>Notre accompagnement pour les collectivités du <strong>Pays de Brest</strong> et de <strong>Cornouaille</strong> va bien au-delà du simple tracé :</p><ul><li><strong>Études de faisabilité technique :</strong> Nous analysons la nature des sols et les contraintes topographiques pour optimiser les terrassements.</li><li><strong>Conception VRD Durable :</strong> Nous intégrons des solutions de récupération des eaux de pluie pour l'arrosage des terrains, réduisant ainsi l'empreinte écologique des installations.</li><li><strong>Maîtrise d'œuvre experte :</strong> Nous supervisons les entreprises spécialisées lors de la pose des revêtements techniques (enrobés poreux, résines athlétiques, gazons hybrides).</li><li><strong>Dossiers d'Homologation :</strong> URBATEAM prépare les plans de récolement et les certificats de pentes nécessaires pour obtenir les labels fédéraux indispensables aux compétitions régionales et nationales.</li></ul><h2>URBATEAM : Le partenaire technique des collectivités bretonnes</h2><p>L'aménagement d'un complexe sportif est un investissement majeur et structurant pour une ville. En choisissant l'expertise d'<strong>URBATEAM</strong>, les mairies et intercommunalités s'assurent d'un équipement qui durera dans le temps, avec des coûts de maintenance maîtrisés. Un terrain parfaitement nivelé et drainé, c'est l'assurance d'une pratique sportive sécurisée et de haute performance pour tous les clubs locaux.</p><p>Parce que chaque millimètre compte dans la quête de l'excellence, URBATEAM met son expertise de pointe au service du rayonnement sportif de notre territoire.</p>	ingenierie-sportive.png	URBATEAM	["Sport", "Ingénierie", "Précision", "VRD"]	Actualité	2026-04-20 10:00:00+00	2026-06-02 02:48:26.719751+00	2026-06-02 02:48:26.719751+00
3	published	\N	scanner-3d-jumeau-numerique-innovation-connaissance-batiment	Scanner 3D et Jumeau Numérique : Comment l'innovation transforme la connaissance du bâtiment	Découvrez comment URBATEAM utilise la lasergrammétrie pour transformer des structures physiques complexes en jumeaux numériques intelligents. Plongez dans l'univers du nuage de points et du Scan-to-BIM.	<h2>L'ère du jumeau numérique : Au-delà du simple plan 2D</h2><p>Dans un monde où la précision et la donnée sont devenues les clés de voûte de tout projet d'aménagement réussi, le <strong>Scanner 3D laser</strong> s'impose comme une révolution technologique majeure. Chez <strong>URBATEAM</strong>, nous ne nous contentons plus de dessiner des plans ; nous créons des <strong>jumeaux numériques</strong>, véritables doubles virtuels de vos bâtiments, capables de porter une intelligence technique sans précédent.</p><p><img src="/uploads/blog/scanner-3d-innovation.png" style="max-width:100%; height:auto; margin: 1.5rem 0; border-radius: 12px; display: block; box-shadow: 0 4px 12px rgba(0,0,0,0.1);" alt="Innovation Scanner 3D URBATEAM"></p><h2>Qu'est-ce qu'un nuage de points ? La capture millimétrique du réel</h2><p>Le point de départ de toute numérisation est le <strong>nuage de points</strong>. Imaginez des millions de points (souvent plusieurs centaines de millions pour un seul bâtiment) capturés en quelques minutes par un laser tournant à haute vitesse. Chaque point possède ses propres coordonnées X, Y, Z dans l'espace, ainsi qu'une information de couleur ou d'intensité.</p><p>Le résultat ? Une "photographie 3D" ultra-précise où chaque élément est mesurable au millimètre près. Cette base de données brute est l'archive la plus fidèle qui puisse exister d'un état des lieux à un instant T. Finies les omissions de relevés sur le terrain ou les cotes oubliées : tout est là, dans le nuage.</p><h2>Du nuage de points au modèle BIM : Le Scan-to-BIM</h2><p>Le nuage de points n'est que la matière première. La véritable valeur ajoutée d'URBATEAM réside dans sa capacité à transformer ces données brutes en une <strong>maquette numérique intelligente</strong> (BIM - Building Information Modeling). C'est ce qu'on appelle le processus <strong>Scan-to-BIM</strong>.</p><p>Contrairement à un dessin classique, chaque élément de la maquette (mur, fenêtre, poutre, réseau) possède des propriétés sémantiques. On ne dessine pas simplement un rectangle, on définit une paroi avec sa composition, sa résistance thermique ou son historique de maintenance. Le jumeau numérique devient alors un outil d'aide à la décision tout au long de la vie du bâtiment.</p><h2>Pourquoi investir dans un relevé 3D haute définition ?</h2><ul><li><strong>Précision absolue :</strong> Sécurisez vos études architecturales en travaillant sur une base dont la marge d'erreur est inférieure à 5mm.</li><li><strong>Gain de temps majeur :</strong> Un seul passage sur site suffit pour capturer l'intégralité des détails complexes (moulures, réseaux apparents, déformations de charpente).</li><li><strong>Anticipation des conflits :</strong> En phase de rénovation, le modèle 3D permet de détecter les collisions entre les réseaux existants et les nouveaux projets avant même le premier coup de pioche.</li><li><strong>Support de communication puissant :</strong> Visualisez vos projets de manière immersive et facilitez l'adhésion des parties prenantes (mairies, riverains, investisseurs).</li></ul><h2>L'innovation au service du patrimoine et de l'aménagement</h2><p>Que ce soit pour la réhabilitation d'un bâtiment historique en centre-ville de Brest ou pour la mise en copropriété d'un ensemble immobilier complexe à Douarnenez, le scanner 3D est votre meilleur allié. Chez URBATEAM, nous investissons continuellement dans les dernières technologies (Scanners Leica, Faro, Drones RTK) pour vous offrir une vision claire, précise et durable de vos actifs immobiliers.</p><p>Le jumeau numérique n'est plus une option futuriste, c'est aujourd'hui le standard de l'aménagement responsable et intelligent.</p>	scanner-3d-innovation.png	URBATEAM	["Innovation", "Scanner 3D", "Jumeau Numérique", "BIM"]	Actualité	2026-03-15 09:00:00+00	2026-06-02 02:48:26.719751+00	2026-06-02 02:48:26.719751+00
4	published	\N	le-bornage-de-propriete-pourquoi-est-ce-une-etape-cruciale	Le Bornage de Propriété : Pourquoi est-ce une étape cruciale pour votre terrain ?	Définir les limites exactes de son terrain est bien plus qu'une simple formalité. Découvrez les enjeux juridiques et techniques du bornage pour sécuriser votre patrimoine.	<h2>Le bornage : Bien plus qu'une simple pose de bornes</h2><p>Trop souvent confondu avec une simple clôture, le <strong>bornage</strong> est l'unique opération permettant de fixer juridiquement et de manière définitive la limite séparative entre deux propriétés privées contigües. C'est une mission fondamentale et exclusive du <strong>Géomètre-Expert</strong>, qui agit ici en tant que tiers de confiance pour garantir l'équité entre les voisins.</p><p><img src="/uploads/blog/bornage.jpg" style="max-width:100%; height:auto; margin: 1.5rem 0; border-radius: 12px; display: block; box-shadow: 0 4px 12px rgba(0,0,0,0.1);" alt="Bornage de propriété"></p><h2>Pourquoi le bornage est-il indispensable ?</h2><p>Que vous soyez sur le point de vendre, d'acheter ou de construire, le bornage répond à plusieurs impératifs majeurs :</p><ul><li><strong>La protection juridique :</strong> Seul le bornage garantit que votre voisin n'empiète pas sur votre terrain (et inversement). Un plan de cadastre, bien qu'utile, n'a qu'une valeur fiscale et ne définit pas précisément les limites de propriété.</li><li><strong>La sécurité des constructions :</strong> Avant d'ériger une clôture, un mur de soutènement ou une extension, connaître sa limite au centimètre près évite des litiges coûteux et des obligations de démolition.</li><li><strong>La valorisation du patrimoine :</strong> Un terrain borné offre une transparence totale lors d'une transaction immobilière, rassurant ainsi l'acquéreur et le notaire sur la consistance exacte du bien vendu.</li></ul><h2>Le déroulement d'une mission de bornage chez URBATEAM</h2><p>Notre cabinet suit une méthodologie rigoureuse pour assurer un résultat incontestable :</p><ol><li><strong>L'analyse documentaire :</strong> Nous étudions les titres de propriété, les plans de division anciens et les archives disponibles (notaires, cadastre).</li><li><strong>Le relevé sur le terrain :</strong> Nous mesurons l'état des lieux actuel, en relevant les clôtures, murs et fossés existants.</li><li><strong>La réunion de bornage :</strong> Nous convoquons tous les riverains pour une réunion contradictoire où nous exposons nos conclusions.</li><li><strong>Le Procès-Verbal (PV) :</strong> Une fois l'accord trouvé, nous rédigeons un PV de bornage et de reconnaissance de limites qui, une fois signé par tous, devient définitif et opposable à tous.</li></ol><h2>Et en cas de désaccord ?</h2><p>Si un voisin refuse de signer ou conteste la limite, on passe du bornage <em>amiable</em> au bornage <em>judiciaire</em>. Dans ce cas, le tribunal nomme un Géomètre-Expert en tant qu'expert judiciaire pour trancher le litige sur la base d'éléments techniques et juridiques. Chez URBATEAM, nous privilégions toujours la médiation pour parvenir à une solution pérenne et pacifiée.</p>	bornage.jpg	URBATEAM	["Bornage", "Foncier", "Expertise"]	Actualité	2026-02-05 14:00:00+00	2026-06-02 02:48:26.719751+00	2026-06-02 02:48:26.719751+00
5	published	\N	le-scanner-3d-la-revolution-numerique-pour-la-copropriete	Le Scanner 3D : La révolution numérique au service de la Copropriété	La technologie laser 3D transforme radicalement la gestion et la connaissance des bâtiments. Découvrez comment elle optimise la mise en copropriété et les projets de rénovation.	<h2>De la mesure traditionnelle au jumeau numérique</h2><p>Longtemps, le relevé de bâtiment s'est limité au mètre ruban ou au télémètre laser point par point. Aujourd'hui, <strong>URBATEAM</strong> déploie la technologie du <strong>Scanner 3D</strong> (lasergrammétrie) pour capturer la réalité avec une exhaustivité et une précision inégalées.</p><p><img src="/uploads/blog/scanner-3d.jpg" style="max-width:100%; height:auto; margin: 1.5rem 0; border-radius: 12px; display: block; box-shadow: 0 4px 12px rgba(0,0,0,0.1);" alt="Scanner 3D et Copropriété"></p><h2>Le nuage de points : Une archive vivante de votre immeuble</h2><p>Le scanner projette des millions de points laser par seconde pour créer un <strong>nuage de points</strong>. Cette copie numérique exacte de l'immeuble permet de :</p><ul><li><strong>Générer des plans 2D parfaits :</strong> Coupes, façades, plans d'étages et surfaces Carrez sont produits avec une marge d'erreur quasi nulle.</li><li><strong>Modéliser en 3D (BIM) :</strong> Nous créons des maquettes numériques qui servent de base de travail collaborative pour les architectes, les bureaux d'études et les syndics.</li><li><strong>Détecter les pathologies :</strong> Le relevé haute résolution permet d'identifier des fissures, des déformations de charpente ou des problèmes de verticalité invisibles à l'œil nu.</li></ul><h2>Un atout majeur pour la mise en copropriété</h2><p>Lors de la création ou de la modification d'une copropriété, la définition des tantièmes et des parties privatives/communes est cruciale. Le relevé 3D garantit :</p><ul><li>Une <strong>équité totale</strong> entre les copropriétaires grâce à des mesures de surfaces incontestables.</li><li>Une <strong>gestion simplifiée</strong> des futurs travaux : grâce à la maquette 3D, le syndic peut simuler l'impact d'une isolation par l'extérieur ou d'un remplacement de toiture.</li><li>Une <strong>valorisation du patrimoine</strong> : disposer d'un carnet de santé numérique complet est un argument fort lors de la vente de lots.</li></ul><p>En choisissant URBATEAM pour vos relevés 3D, vous investissez dans la connaissance durable de votre bâtiment, réduisant ainsi les risques d'erreurs lors des phases de conception et de travaux.</p>	scanner-3d.jpg	URBATEAM	["Scanner 3D", "Copropriété", "Innovation"]	Actualité	2026-01-06 09:00:00+00	2026-06-02 02:48:26.719751+00	2026-06-02 02:48:26.719751+00
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.clients (id, status, sort, name, logo, tags, created_at, in_carousel) FROM stdin;
4	published	2	Groupe François Léon	1784569894593-francoisleon.png	["Architecte"]	2026-06-22 15:30:01.860142+00	f
11	published	9	Angevin Personnic	1784570265077-angevin-personnic.jpeg	["Architecte"]	2026-06-22 15:37:00.863606+00	t
6	published	4	Trecobat	1784569944347-logo-trecobat.jpg	["Architecte"]	2026-06-22 15:30:41.662053+00	t
10	published	8	Aiguillon Construction	1784570234236-logo-aiguillon-construction.png	["Aménageur"]	2026-06-22 15:36:24.721786+00	t
17	published	15	Bouygues Immobilier	1785319753340-bouygues-immobilier.png	["Aménageur"]	2026-06-22 15:40:32.445327+00	f
19	published	17	Maisons Georges Menez	1785319604664-maisons-georges-menez.png	["Architecte"]	2026-06-22 15:41:46.782168+00	t
20	published	18	Perco Constructions	1784570609241-logo-perco-constructions.png	["Architecte"]	2026-06-22 15:42:14.854823+00	t
27	published	25	Conservatoire du Littoral	1784570865747-conservatoire-du-littoral.png	["Collectivite"]	2026-06-22 15:45:42.351991+00	f
21	published	19	Brest Métropole Habitat	1785319904984-bmg.png	["Aménageur"]	2026-06-22 15:42:45.984396+00	f
22	published	20	Primo Construction	1784570741271-primo-construction-logo.png	["Architecte"]	2026-06-22 15:43:08.199956+00	t
28	published	26	Douarnenez Habitat	1784570891935-douarnenez-habitat.jpeg	["Aménageur"]	2026-06-22 15:46:00.05309+00	f
29	published	27	Douarnenez Communauté	1785320209070-douarnenez-communuate.png	["Collectivite"]	2026-06-22 15:46:23.892106+00	f
13	published	11	123 Web Immo	1785319516143-123webimmo.png	["Collectivite"]	2026-06-22 15:38:10.467286+00	t
30	published	28	Etablissement Public Foncier de Bretagne	1784570978254-etablissement-public-foncier-de-bretagne.png	["Collectivite"]	2026-06-22 15:47:19.677515+00	f
31	published	29	Brest Métropole Aménagement	1785320253060-bma.png	["Aménageur"]	2026-07-20 18:10:07.264586+00	f
16	published	14	Human Immobilier	1785319679152-human-immobilier.png	["Collectivite"]	2026-06-22 15:39:30.213187+00	t
32	published	30	Groupe SOFT	1785319856744-groupe-soft.png	["Aménageur"]	2026-07-29 10:10:57.333097+00	f
8	published	6	Aménatys	1785319357640-amenatys.png	["Aménageur"]	2026-06-22 15:31:06.445325+00	f
25	published	23	CCPA	1785319970477-ccpa.png	["Collectivite"]	2026-06-22 15:44:18.209536+00	f
23	published	21	Département du Finistère	1785320016668-departement-finistere.png	["Collectivite"]	2026-06-22 15:43:44.556276+00	f
5	published	3	Barraine Immo	1784569921397-logo-barraine-immo.jpg	["Collectivite"]	2026-06-22 15:30:23.483446+00	t
14	published	12	Mairie de Saint-Renan	1784570380658-mairie-de-saint-renan-image.jpeg	["Collectivite"]	2026-06-22 15:38:42.616989+00	t
24	published	22	CCPI	1785320059290-capture-d-ecran-2026-07-29-121405.png	["Collectivite"]	2026-06-22 15:44:15.594962+00	t
15	published	13	Floch Réalisations	1785319643419-capture-d-ecran-2026-07-29-120712.png	["Architecte"]	2026-06-22 15:39:17.092498+00	f
2	published	1	Maisons Le Masson	1785319159439-maisons-le-masson.png	["Architecte"]	2026-06-22 15:27:01.289155+00	t
1	published	0	Brest Metropole Oceane	1785319092820-bm.png	["Aménageur"]	2026-06-02 02:48:27.347707+00	t
\.


--
-- Data for Name: faq; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.faq (id, status, sort, question_fr, answer_fr, question_en, answer_en, question_br, answer_br, category, created_at) FROM stdin;
1	published	0	Le bornage est-il obligatoire ?	Le bornage n'est pas systématiquement obligatoire, mais il devient indispensable dès que vous souhaitez garantir les limites de votre propriété ou si vous envisagez une vente. Que votre terrain soit situé à Saint-Renan, Brest ou Douarnenez, c'est le seul acte qui définit juridiquement votre limite de propriété de manière définitive.	What is contradictory boundary marking and is it mandatory?	Boundary marking allows for the legal and definitive fixing of your land's property lines. In France (Article 646 of the Civil Code), any owner can compel their neighbor to boundary marking. This is also legally mandatory in the case of land division for building (subdivision). Only a Chartered Land Surveyor registered with the Order is authorized to carry it out and place official markers.	Petra eo ar bonnañ ha ret eo ober anezhañ ?	Ar bonnañ a sikour da lakaat un harz ofisiel etre ho touar hag hini hoc'h amezeien (Kod sivil gall Art. 646). Ret eo d'ober pa vez krouet ur lodenn douar nevez da sevel un ti. Un Douaroner-Barnour nemetken a c'hell ober an dra-se.	\N	2026-06-02 02:48:27.661696+00
2	published	1	Quelle est la différence entre un plan topographique et un plan de bornage ?	Un plan topographique est un relevé précis de l'existant (relief, murs, arbres, voirie). Il est indispensable pour l'architecte ou le maître d'œuvre, mais n'a aucune valeur juridique concernant la limite de propriété. Le plan de bornage, en revanche, détermine la limite juridique foncière garantie après analyse des actes notariés et accord contradictoire des voisins.	What is the difference between a topographic plan and a boundary plan?	A topographic plan is a precise survey of the existing situation (relief, walls, trees, roads). It is essential for the architect or project manager but has no legal value concerning the property line. The boundary plan, however, determines the guaranteed legal land boundary after analysis of notarized deeds and contradictory agreement from neighbors.	Petra eo ar cheñchamant etre un tres topografek hag un tres bonnañ ?	Un tres topografek a ziskouez an douar evel m'emañ (mogerioù, gwez, h.a...). N'en deus ket talvoudegezh lezennel evit an harzoù. Un tres bonnañ a laka an harz ofisiel gant asant an amezeien.	\N	2026-06-02 02:48:27.661696+00
3	published	2	Puis-je diviser mon terrain situé dans mon jardin pour le vendre ?	Oui, mais cette opération (détachement de parcelle) nécessite de s'assurer que le projet est conforme au PLU/PLUi (Plan Local d'Urbanisme). Le Géomètre-Expert vérifie la constructibilité, réalise le plan de division, borne la nouvelle limite créée et constitue le dossier d'urbanisme obligatoire (Déclaration Préalable de division) en Mairie.	Can I divide my garden land to sell it?	Yes, but this operation (parcel detachment) requires ensuring the project complies with the local urban plan (PLU/PLUi). The Land Surveyor verifies buildability, creates the division plan, marks the new created boundary and constitutes the mandatory urban planning file (Preliminary Declaration of division) at the City Hall.	Gallout a ran rannañ ma liorzh evit gwerzhañ un lodenn ?	Ya, met ret eo gwelet ma 'z eo a-du gant reolennoù an ti-kêr (PLU). An Douaroner a sikour ac'hanoc'h gant an deuliad melestradurel (DP).	\N	2026-06-02 02:48:27.661696+00
4	published	3	Le plan cadastral fait-il foi pour connaître la limite de mon terrain ?	Non. Contrairement aux idées reçues, le <a class="wiki-link" href="/lexique?search=Cadastre">cadastre</a> est un document à vocation purement fiscale (pour le calcul des impôts fonciers) et n'a aucune valeur probante de propriété foncière. En cas de litige, seul un Procès-Verbal de <a class="wiki-link" href="/lexique?search=Bornage">bornage</a> rédigé par un Géomètre-Expert fait foi.	Is the cadastral plan proof of my land's boundary?	No. Contrary to popular belief, the <a class="wiki-link" href="/lexique?search=Cadastre">cadastre</a> is a document with a purely fiscal vocation (for calculating property taxes) and has no probative value of land ownership. In case of dispute, only a <a class="wiki-link" href="/lexique?search=Boundary">boundary marking</a> minutes drafted by a Chartered Surveyor is authentic.	Ha talvoudegezh ofisiel en deus ar c'hadastr evit an harzoù ?	Nann. Ar c'hadastr a zo un teuliad evit an tailhoù (impôts). N'eo ket evit lakaat an harz ofisiel. Ar PV bonnañ nemetken a dalvez evit an harzoù.	\N	2026-06-02 02:48:27.661696+00
5	published	4	Comment faire corriger une erreur sur le plan cadastral ?	Si le cadastre public indique une limite erronée, vous devez solliciter un Géomètre-Expert. Après avoir effectué la recherche d'anciens actes et le relevé sur le terrain, notre équipe rédigera un plan de délimitation amiable et mettra à jour la documentation cadastrale (<a class="wiki-link" href="/lexique?search=DMPC">DMPC</a>) transmise aux impôts.	How can I correct an error on the cadastral plan?	If the public cadastre indicates an incorrect boundary, you must request a Chartered Surveyor. After researching old deeds and surveying the land, our team will draft an amicable delimitation plan and update the cadastral documentation (<a class="wiki-link" href="/lexique?search=DMPC">DMPC</a>) sent to the tax authorities.	Penaos reizhañ ur vioù er c'hadastr ?	Ret eo goulenn gant un Douaroner-Barnour evit sevel un tres bonnañ hag un teuliad DMPC evit kemmañ ar c'hadastr ofisiel.	\N	2026-06-02 02:48:27.661696+00
6	published	5	Qui paie les frais de bornage ?	Selon l'Article 646 du Code civil, les frais de bornage se font à frais communs entre les deux propriétaires voisins, bien que la répartition puisse être négociée différemment lors de la conciliation amiable.	Who pays for boundary marking costs?	According to Article 646 of the Civil Code, boundary marking costs are shared between the two neighboring owners, although the distribution can be negotiated differently during amicable conciliation.	Piv a bae evit ar bonnañ ?	Hervez an Art. 646 eus ar C'hod Sivil, ar mizioù a vez rannet etre an daou amezeg, met gallout a reer kemmañ an dra-se ma 'z int a-du.	\N	2026-06-02 02:48:27.661696+00
7	published	6	Pourquoi faire appel à un Géomètre-Expert pour une mise en copropriété ?	Le Géomètre-Expert est le seul professionnel qualifié pour garantir la précision des plans d'intérieurs et le calcul des millièmes (tantièmes) de copropriété. Son intervention sécurise juridiquement l'acte de vente et prévient les litiges futurs entre copropriétaires sur la répartition des charges.	Why hire a Chartered Surveyor for a co-ownership setup?	The Chartered Surveyor is the only qualified professional to guarantee the accuracy of interior plans and the calculation of co-ownership shares (tantièmes). Their intervention legally secures the sale deed and prevents future disputes between co-owners regarding charge distribution.			\N	2026-06-02 02:48:27.661696+00
8	published	7	Qu'est-ce qu'un modificatif de règlement de copropriété ?	Il s'agit d'une mise à jour du règlement suite à un changement dans l'immeuble (division d'un lot, changement d'usage, annexion de parties communes). Le Géomètre-Expert réalise les nouveaux plans et calcule la nouvelle répartition des tantièmes pour publication au fichier immobilier.	What is a co-ownership regulation amendment?	It is an update to the regulations following a change in the building (lot division, change of use, annexation of common areas). The Surveyor creates new plans and calculates the new share distribution for publication in the real estate file.			\N	2026-06-02 02:48:27.661696+00
9	published	8	Qu'est-ce qu'un relevé par Scanner Laser 3D ?	C'est une technologie qui permet de capturer des millions de points en quelques secondes pour créer une 'image 3D' millimétrée de l'existant. Cela permet de relever des structures complexes (monuments, usines, charpentes) avec une exhaustivité impossible à atteindre avec des méthodes classiques.	What is 3D Laser Scanning?	It is a technology that captures millions of points in seconds to create a millimeter-accurate '3D image' of the existing structure. This allows for surveying complex structures (monuments, factories, frameworks) with an exhaustiveness impossible to achieve with traditional methods.			\N	2026-06-02 02:48:27.661696+00
10	published	9	Comment utilisez-vous les drones dans vos missions ?	Le drone nous permet de réaliser des orthophotographies haute résolution et des modèles numériques de terrain (MNT) sur de grandes surfaces ou des zones d'accès difficile. C'est un outil précieux pour le suivi de chantier, le <a class="wiki-link" href="/lexique?search=Cubature">calcul de cubatures</a> (volumes de terre) et l'inspection d'ouvrages.	How do you use drones in your missions?	The drone allows us to produce high-resolution orthophotographs and digital terrain models (DTM) over large surfaces or difficult access areas. It is a valuable tool for site monitoring, <a class="wiki-link" href="/lexique?search=Cubature">cubature calculations</a> (earth volumes), and structure inspections.			\N	2026-06-02 02:48:27.661696+00
11	published	10	Quelle est la durée de validité d'un bornage ?	Un bornage contradictoire signé et archivé est définitif et immuable. Il 'suit le terrain' : même si les propriétaires changent, la limite fixée reste la même pour les générations futures. C'est la garantie de sérénité la plus forte pour votre patrimoine foncier.	How long is a boundary marking valid?	A signed and archived contradictory boundary marking is definitive and immutable. It 'follows the land': even if owners change, the set boundary remains the same for future generations. It is the strongest guarantee of peace of mind for your land heritage.			\N	2026-06-02 02:48:27.661696+00
12	published	11	Quels sont les documents nécessaires pour déposer un permis d'aménager ?	Le dossier type comprend un <a class="wiki-link" href="/lexique?search=Situation">plan de situation</a>, un plan de l'état initial du terrain, un plan de composition d'ensemble, ainsi qu'une <a class="wiki-link" href="/lexique?search=Notice">notice descriptive</a> expliquant l'insertion du projet dans son environnement. URBATEAM se charge de la constitution complète de ce dossier technique et administratif.	What documents are required to apply for a development permit?	The typical file includes a <a class="wiki-link" href="/lexique?search=Location">location plan</a>, a plan of the initial state of the land, a general composition plan, as well as a <a class="wiki-link" href="/lexique?search=Descriptive">descriptive notice</a> explaining the project's insertion into its environment. URBATEAM takes care of the complete technical and administrative constitution of this file.			\N	2026-06-02 02:48:27.661696+00
13	published	12	Qu'est-ce qu'une servitude et comment la vérifier ?	Une servitude est une contrainte imposée à un terrain (fonds servant) au profit d'un autre (fonds dominant), comme un <a class="wiki-link" href="/lexique?search=Passage">droit de passage</a> ou le passage de réseaux (<a class="wiki-link" href="/lexique?search=Tréfonds">servitude de tréfonds</a>). Elles sont mentionnées dans votre titre de propriété. Le Géomètre-Expert peut les identifier précisément sur le terrain et vérifier leur conformité.	What is an easement and how can it be verified?	An easement is a constraint imposed on land (servient estate) for the benefit of another (dominant estate), such as a <a class="wiki-link" href="/lexique?search=Passage">right of way</a> or the passage of networks (<a class="wiki-link" href="/lexique?search=Underground">underground easement</a>). They are mentioned in your property title. The Chartered Surveyor can identify them precisely on the ground and verify their compliance.			\N	2026-06-02 02:48:27.661696+00
14	published	13	Intervenez-vous pour la création de terrains de sport ?	Oui, URBATEAM possède une expertise spécifique en ingénierie sportive. Nous concevons des complexes sportifs (stades, pistes d'athlétisme, terrains synthétiques) en respectant les normes fédérales et les exigences de drainage et de nivellement de haute précision.	Do you intervene for the creation of sports fields?	Yes, URBATEAM has specific expertise in sports engineering. We design sports complexes (stadiums, athletics tracks, synthetic fields) respecting federal standards and high-precision drainage and leveling requirements.			\N	2026-06-02 02:48:27.661696+00
15	published	14	Comment sont calculés les honoraires d'un Géomètre-Expert ?	Chaque dossier est unique. Nos honoraires dépendent de la complexité technique de la mission, du temps de recherche en archives, du nombre de voisins à convoquer pour un bornage, et de la superficie du terrain. Nous fournissons systématiquement un devis détaillé et gratuit avant toute intervention.	How are a Land Surveyor's fees calculated?	Each case is unique. Our fees depend on the technical complexity of the mission, search time in archives, the number of neighbors to be summoned for boundary marking, and the land area. We systematically provide a free, detailed quote before any intervention.			\N	2026-06-02 02:48:27.661696+00
16	published	15	Quelle est la différence entre un bornage amiable et un bornage judiciaire ?	Le bornage amiable est le fruit d'un accord entre voisins avec l'aide d'un Géomètre-Expert. Si un accord est impossible, le juge peut ordonner un bornage judiciaire. Dans ce cas, un Géomètre-Expert est désigné comme expert judiciaire pour proposer une limite que le juge validera par un jugement.	What is the difference between amicable and judicial boundary marking?	Amicable boundary marking results from an agreement between neighbors with the help of a Land Surveyor. If agreement is impossible, a judge can order judicial boundary marking. In this case, a Land Surveyor is appointed as a judicial expert to propose a boundary that the judge will validate by a ruling.			\N	2026-06-02 02:48:27.661696+00
17	published	16	Pourquoi faire réaliser son mesurage Loi Carrez par un Géomètre-Expert ?	Bien que non obligatoire, l'intervention d'un Géomètre-Expert offre une garantie de responsabilité civile professionnelle. En cas d'erreur de mesure supérieure à 5%, l'acquéreur peut demander une baisse de prix. Notre précision et notre expertise juridique sécurisent votre transaction immobilière.	Why have a Land Surveyor perform your Carrez Law measurement?	While not mandatory, a Land Surveyor's intervention offers a professional civil liability guarantee. In case of a measurement error greater than 5%, the buyer can request a price reduction. Our precision and legal expertise secure your real estate transaction.			\N	2026-06-02 02:48:27.661696+00
18	published	17	Quelle est la différence entre une copropriété et une division en volumes ?	La copropriété s'applique généralement aux bâtiments simples avec des parties communes partagées. La division en volumes est utilisée pour des ensembles immobiliers complexes (ex: commerces au rez-de-chaussée et habitations au-dessus) afin de dissocier juridiquement des éléments sans parties communes, souvent gérés par une AFUL ou une ASL.	What is the difference between co-ownership and volume division?	Co-ownership usually applies to simple buildings with shared common areas. Volume division is used for complex real estate complexes (e.g., shops on the ground floor and housing above) to legally dissociate elements without common areas, often managed by a homeowner association (AFUL or ASL).			\N	2026-06-02 02:48:27.661696+00
19	published	18	Qu'est-ce que le processus Scan-to-BIM ?	C'est la transformation d'un nuage de points issu d'un scanner 3D en une maquette numérique intelligente (BIM). Cette maquette contient non seulement la géométrie du bâtiment, mais aussi des données sur les matériaux, les réseaux et les équipements, facilitant la gestion ultérieure du bâti.	What is the Scan-to-BIM process?	It is the transformation of a point cloud from a 3D scanner into an intelligent digital model (BIM). This model contains not only the building's geometry but also data on materials, networks, and equipment, facilitating subsequent building management.			\N	2026-06-02 02:48:27.661696+00
20	published	19	Proposez-vous des prestations d'auscultation d'ouvrages ?	Oui, nous réalisons des mesures de haute précision pour surveiller la stabilité de bâtiments, de ponts ou de soutènements via l'<a class="wiki-link" href="/lexique?search=Auscultation">auscultation d'ouvrages</a>. Grâce à des capteurs et des relevés périodiques, nous détectons les moindres mouvements ou tassements millimétriques pour garantir la sécurité des infrastructures.	Do you offer structural monitoring services?	Yes, we perform high-precision measurements to monitor the stability of buildings, bridges, or retaining walls via <a class="wiki-link" href="/lexique?search=Monitoring">structural monitoring</a>. Using sensors and periodic surveys, we detect the slightest movements or millimeter settlements to guarantee infrastructure security.			\N	2026-06-02 02:48:27.661696+00
21	published	20	Réalisez-vous des plans d'intérieurs et des coupes de bâtiments existants ?	Absolument. Nous intervenons pour relever des immeubles complets afin de produire des <a class="wiki-link" href="/lexique?search=Intérieurs">plans d'intérieurs</a>, des <a class="wiki-link" href="/lexique?search=Coupe">coupes</a> transversales et des plans de façades. Ces documents sont indispensables pour les architectes dans le cadre de projets de rénovation ou de réhabilitation.	Do you produce interior plans and sections of existing buildings?	Absolutely. We intervene to survey entire buildings to produce <a class="wiki-link" href="/lexique?search=Interior">interior plans</a>, transversal <a class="wiki-link" href="/lexique?search=Section">sections</a>, and facade plans. These documents are essential for architects in renovation or rehabilitation projects.			\N	2026-06-02 02:48:27.661696+00
22	published	21	Comment savoir si un Géomètre-Expert est déjà intervenu sur mon terrain ?	Toutes les interventions foncières des Géomètres-Experts sont enregistrées sur le portail GéoFoncier. Nous pouvons consulter cet historique pour retrouver d'anciens procès-verbaux de bornage ou des plans de division, ce qui permet de sécuriser votre projet en vous appuyant sur des données certifiées.	How can I know if a Land Surveyor has already intervened on my land?	All land interventions by Chartered Surveyors are recorded on the GéoFoncier portal. We can consult this history to find old boundary marking minutes or division plans, securing your project by relying on certified data.			\N	2026-06-02 02:48:27.661696+00
23	published	22	Comment se déroule une division parcellaire ?	La division consiste à détacher une ou plusieurs parcelles d'un terrain d'origine. URBATEAM vous accompagne de l'étude de faisabilité à la déclaration préalable en mairie (comme à Plouzané ou Landerneau), jusqu'au document d'arpentage et au bornage des nouveaux lots.	How does a land division work?	Division involves detaching one or more parcels from an original plot. URBATEAM supports you from the feasibility study to the preliminary declaration at the town hall (as in Plouzané or Landerneau), up to the surveying document and the boundary marking of new lots.			\N	2026-06-02 02:48:27.661696+00
24	published	23	Quelle est la garantie offerte par un Géomètre-Expert ?	Le Géomètre-Expert est un professionnel libéral dont le titre est protégé. Nous avons une obligation d'assurance et de formation continue. En cas d'erreur dans nos missions de bornage ou de conception, notre responsabilité civile professionnelle vous protège, offrant une sécurité bien supérieure à celle d'un simple prestataire non régulé.	What is the guarantee offered by a Chartered Surveyor?	The Chartered Surveyor is a professional whose title is protected by law. We have a professional indemnity insurance and continuous training obligations. In case of errors in our boundary or design missions, our civil liability protects you, offering security far superior to that of a simple unregulated service provider.			\N	2026-06-02 02:48:27.661696+00
\.


--
-- Data for Name: glossaire; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.glossaire (id, status, sort, term_fr, definition_fr, term_en, definition_en, term_br, definition_br, related_expertise, created_at) FROM stdin;
1	published	0	Bornage Contradictoire	Opération consistant à définir juridiquement et à matérialiser sur le terrain (au moyen de bornes) les limites physiques séparant des propriétés privées contiguës.	Contradictory Boundary Marking	Operation consisting of legally defining and materializing on the ground (using boundary markers) the physical limits separating contiguous private properties.	Bonnañ (Bornage)	Lakaat harzoù ofisiel gant bonnoù etre div dachenn douar.	\N	2026-06-02 02:48:27.983417+00
2	published	1	Cadastre	Ensemble de documents dressant l'état de la propriété foncière à des fins essentiellement fiscales. Le cadastre ne garantit pas la limite de propriété juridique exacte.	Cadastre	Set of documents establishing the state of land ownership for essentially fiscal purposes. The cadastre does not guarantee the exact legal property boundary.	Cadastre	Teuliad evit an tailhoù douar, n'eo ket un teuliad perc'henniezh ofisiel evit an harzoù.	\N	2026-06-02 02:48:27.983417+00
3	published	2	DMPC (Document d'Arpentage)	Document de Modification du Parcellaire Cadastral. Il est obligatoirement dressé par un Géomètre-Expert pour mettre à jour le plan cadastral suite à un changement de limites.	DMPC (Surveying Document)	Document for Modification of the Cadastral Parcel. It must be prepared by a Land Surveyor to update the cadastral map following a change in boundaries.	DMPC	Teuliad ofisiel evit cheñch ar c'hadastr pa vez rannet un douar.	\N	2026-06-02 02:48:27.983417+00
4	published	3	Détachement de parcelle	Action foncière visant à diviser une unité foncière en plusieurs entités distinctes, très souvent en vue de créer un nouveau terrain à bâtir.	Parcel detachment	Land action aimed at dividing a land unit into several distinct entities, very often with a view to creating a new building lot.	Lodennañ (Division)	Rannañ un douar e meur a lodenn nevez.	\N	2026-06-02 02:48:27.983417+00
5	published	4	PLU / PLUi	Plan Local d'Urbanisme (Intercommunal). Document de planification qui fixe les règles générales d'utilisation des sols sur le territoire d'une ou plusieurs communes.	PLU / PLUi	Local Urban Planning Map (Inter-municipal). Planning document that sets the general rules for land use in the territory of one or more municipalities.	PLU / PLUi	Reolennoù an ti-kêr evit implijout an douaroù (lakaat e tres pelec'h e c'heller sevel tiez).	\N	2026-06-02 02:48:27.983417+00
6	published	5	Servitude	Charge pesant sur une propriété foncière au bénéfice d'une autre propriété foncière (droit de passage, réseaux...).	Easement	Charge weighing on a land property for the benefit of another land property (right of way, networks...).	Sklent (Servitude)	Ur gwir o tremen war un douar evit un douar all (hent tremen, rouedadoù...).	\N	2026-06-02 02:48:27.983417+00
7	published	6	VRD (Voirie et Réseaux Divers)	Ensemble des ouvrages et des aménagements d'infrastructures permettant de viabiliser un terrain (routes, évacuation des eaux, électricité...).	VRD (Roads and Utilities)	Set of works and infrastructure developments for site servicing (roads, water evacuation, electricity, etc.).	VRD	Al labourioù evit an hentoù hag ar rouedadoù (dour, tredan, h.a...).	\N	2026-06-02 02:48:27.983417+00
8	published	7	ZAC (Zone d'Aménagement Concerté)	Opération d'urbanisme publique d'envergure par laquelle une collectivité aménage des terrains pour les céder à des constructeurs.	ZAC (Concerted Development Zone)	Large-scale public urban planning operation by which a local authority develops land to sell it to builders.	ZAC	Ur raktres aozañ bras renet gant ur strollad publik.	\N	2026-06-02 02:48:27.983417+00
9	published	8	Loi Carrez / Loi Boutin	Mesurage de la superficie privative (Carrez) pour la vente ou habitable (Boutin) pour la location.	Carrez / Boutin Laws	Measurement of private area (Carrez) for sale or habitable area (Boutin) for rental.	Lezenn Carrez	Muzuliañ gorread un ti ofisiel evit ur gwerzh pe ur feurm.	\N	2026-06-02 02:48:27.983417+00
10	published	9	HQE (Haute Qualité Environnementale)	Démarche d'aménagement visant à maîtriser les impacts environnementaux d'une opération urbaine ou immobilière.	HQE (High Environmental Quality)	Development approach aiming to master the environmental impacts of an urban or real estate operation.	HQE	Kalite uhel evit an natur en ur raktres sevel.	\N	2026-06-02 02:48:27.983417+00
11	published	10	Maîtrise d'œuvre (MOE)	Personne ou entité chargée par le maître d'ouvrage de concevoir, d'étudier et de diriger l'exécution des travaux.	Project Management (MOE)	Person or entity appointed by the project owner to design, study and direct the execution of works.	Mestroniezh-ober (MOE)	An hini a rener al labourioù hag a sevel an tresoù teknikel.	\N	2026-06-02 02:48:27.983417+00
12	published	11	Ordre des Géomètres-Experts (OGE)	L'institution nationale qui garantit la compétence, l'indépendance et la déontologie du Géomètre-Expert.	Order of Chartered Surveyors (OGE)	The national institution that guarantees the competence, independence and ethics of the Land Surveyor.	OGE	Urzh an Douaronerien-Varnourien a warant kalite an douaroner.	\N	2026-06-02 02:48:27.983417+00
13	published	12	AFUL (Association Foncière Urbaine Libre)	Groupement de propriétaires fonciers permettant la gestion commune d'ouvrages ou la réalisation de travaux de restructuration urbaine.	AFUL (Urban Land Association)	A group of landowners allowing for the joint management of works or the completion of urban restructuring projects.			\N	2026-06-02 02:48:27.983417+00
14	published	13	Alignement individuel	Acte par lequel l'administration fixe la limite de la voie publique au droit d'une propriété riveraine.	Individual Alignment	An act by which the administration sets the boundary of the public highway along a riparian property.			\N	2026-06-02 02:48:27.983417+00
15	published	14	ASL (Association Syndicale Libre)	Structure juridique regroupant des propriétaires au sein d'un lotissement ou d'une copropriété horizontale pour gérer les espaces et équipements communs.	ASL (Free Syndicate Association)	A legal structure grouping owners within a subdivision or horizontal co-ownership to manage common spaces and equipment.			\N	2026-06-02 02:48:27.983417+00
16	published	15	BIM (Building Information Modeling)	Maquette numérique intelligente regroupant l'ensemble des données techniques d'un bâtiment tout au long de son cycle de vie.	BIM (Building Information Modeling)	Intelligent digital model grouping all the technical data of a building throughout its life cycle.			\N	2026-06-02 02:48:27.983417+00
17	published	16	Bornage judiciaire	Procédure engagée devant le tribunal lorsque les propriétaires ne parviennent pas à un accord amiable sur la limite de leurs terrains.	Judicial Boundary Marking	A procedure initiated before the court when owners fail to reach an amicable agreement on the boundary of their land.			\N	2026-06-02 02:48:27.983417+00
18	published	17	Certificat d'Urbanisme (CU)	Document informant sur les règles d'urbanisme applicables à un terrain et sur la faisabilité d'un projet précis.	Planning Certificate (CU)	A document providing information on the urban planning rules applicable to a land and the feasibility of a specific project.			\N	2026-06-02 02:48:27.983417+00
19	published	18	Copropriété horizontale	Forme de copropriété s'appliquant à des maisons individuelles bâties sur un terrain commun, par opposition à la copropriété verticale (immeubles).	Horizontal Co-ownership	A form of co-ownership applying to detached houses built on common land, as opposed to vertical co-ownership (buildings).			\N	2026-06-02 02:48:27.983417+00
20	published	19	Cubature	Calcul du volume de matériaux (terre, gravats) à déplacer lors de travaux de terrassement, réalisé à partir de levés topographiques précis.	Earthwork Volume (Cubature)	Calculation of the volume of materials (soil, rubble) to be moved during earthworks, based on precise topographic surveys.			\N	2026-06-02 02:48:27.983417+00
21	published	20	Déclaration Préalable (DP)	Autorisation d'urbanisme obligatoire pour des travaux de faible importance ou des divisions de terrains sans création d'espaces communs.	Prior Declaration (DP)	A mandatory urban planning authorization for minor works or land divisions without the creation of common spaces.			\N	2026-06-02 02:48:27.983417+00
22	published	21	Division en volumes	Technique juridique complexe permettant de découper un ensemble immobilier en lots de propriété sans aucune partie commune.	Volume Division	A complex legal technique allowing for the splitting of a real estate complex into ownership lots without any common areas.			\N	2026-06-02 02:48:27.983417+00
23	published	22	Emprise au sol	Projection verticale au sol du volume de la construction, incluant les débords et surplombs.	Footprint (Emprise au sol)	The vertical projection on the ground of the building's volume, including overhangs and projections.			\N	2026-06-02 02:48:27.983417+00
24	published	23	GéoFoncier	Portail officiel de l'Ordre des Géomètres-Experts centralisant l'ensemble des interventions foncières réalisées sur le territoire.	GéoFoncier	The official portal of the Order of Chartered Surveyors centralizing all land interventions carried out in the territory.			\N	2026-06-02 02:48:27.983417+00
25	published	24	Implantation	Opération consistant à matérialiser sur le terrain la position exacte d'une future construction selon les plans de l'architecte.	Layout / Staking (Implantation)	The operation of materializing on the ground the exact position of a future construction according to the architect's plans.			\N	2026-06-02 02:48:27.983417+00
26	published	25	MNT (Modèle Numérique de Terrain)	Représentation 3D de la surface du sol permettant de réaliser des études hydrauliques, de visibilité ou des calculs de volumes.	DTM (Digital Terrain Model)	A 3D representation of the ground surface allowing for hydraulic, visibility studies, or volume calculations.			\N	2026-06-02 02:48:27.983417+00
27	published	26	Nivellement	Mesure des altitudes de différents points du sol par rapport à un système de référence (souvent le NGF - Nivellement Général de la France).	Leveling (Nivellement)	Measurement of the altitudes of different points on the ground relative to a reference system (often NGF in France).			\N	2026-06-02 02:48:27.983417+00
28	published	27	Nuage de points	Ensemble de millions de coordonnées 3D capturées par un scanner laser, formant une image numérique fidèle de l'existant.	Point Cloud	Set of millions of 3D coordinates captured by a laser scanner, forming a faithful digital image of the existing condition.			\N	2026-06-02 02:48:27.983417+00
29	published	28	Orthophotographie	Image aérienne rectifiée géométriquement pour obtenir une échelle uniforme, combinant la richesse d'une photo et la précision d'un plan.	Orthophotograph	An aerial image geometrically rectified to obtain a uniform scale, combining the richness of a photo and the precision of a plan.			\N	2026-06-02 02:48:27.983417+00
30	published	29	Plan de masse	Plan présentant le projet de construction dans sa totalité, indiquant l'emprise au sol, les accès et les raccordements aux réseaux.	Site Plan (Plan de masse)	A plan showing the entire construction project, indicating the footprint, access, and network connections.			\N	2026-06-02 02:48:27.983417+00
31	published	30	Récolement	Levé topographique réalisé après travaux pour vérifier la conformité des ouvrages (réseaux, voirie) par rapport au projet initial.	As-built Survey (Récolement)	A topographic survey carried out after works to verify the compliance of structures (networks, roads) with the initial project.			\N	2026-06-02 02:48:27.983417+00
32	published	31	Tantièmes / Millièmes	Quote-part de propriété des parties communes attribuée à chaque lot de copropriété, servant de base au calcul des charges.	Shares (Tantièmes / Millièmes)	Ownership share of the common areas attributed to each co-ownership lot, used as the basis for calculating charges.			\N	2026-06-02 02:48:27.983417+00
33	published	32	Aménagement foncier	Ensemble des opérations visant à améliorer la structure des exploitations agricoles ou le développement des territoires ruraux.	Land Consolidation	A set of operations aimed at improving the structure of agricultural holdings or the development of rural territories.			\N	2026-06-02 02:48:27.983417+00
34	published	33	Arpentage	Technique historique de mesure de la superficie des terres, aujourd'hui intégrée aux missions globales du Géomètre-Expert.	Land Surveying (Arpentage)	Historical technique for measuring land area, today integrated into the global missions of the Chartered Surveyor.			\N	2026-06-02 02:48:27.983417+00
35	published	34	Canevas	Réseau de points de référence aux coordonnées connues, servant d'ossature pour l'ensemble des levés topographiques d'un projet.	Survey Control Network (Canevas)	A network of reference points with known coordinates, serving as the backbone for all topographic surveys of a project.			\N	2026-06-02 02:48:27.983417+00
36	published	35	Coefficient d'Emprise au Sol (CES)	Rapport permettant de mesurer la surface maximale qu'une construction peut occuper sur un terrain.	Footprint Coefficient (CES)	A ratio used to measure the maximum surface area a building can occupy on a land.			\N	2026-06-02 02:48:27.983417+00
37	published	36	Condition suspensive	Clause d'un contrat (ex: vente de terrain) dont dépend l'exécution de l'acte, comme l'obtention d'un permis d'aménager.	Condition Precedent	A clause in a contract (e.g., land sale) on which the execution of the act depends, such as obtaining a development permit.			\N	2026-06-02 02:48:27.983417+00
38	published	37	Droit de passage	Type de servitude permettant à un propriétaire dont le terrain est enclavé de traverser la propriété de son voisin pour accéder à la voie publique.	Right of Way	A type of easement allowing a owner whose land is landlocked to cross their neighbor's property to access the public highway.			\N	2026-06-02 02:48:27.983417+00
39	published	38	Expropriation	Procédure permettant à une personne publique d'acquérir une propriété privée pour cause d'utilité publique, souvent avec l'expertise du géomètre pour l'évaluation.	Expropriation	A procedure allowing a public entity to acquire private property for public utility purposes, often involving surveyor expertise for valuation.			\N	2026-06-02 02:48:27.983417+00
40	published	39	Géodésie	Science qui étudie la forme de la Terre et permet de définir les systèmes de coordonnées utilisés par les GPS et les outils de mesure.	Geodesy	The science that studies the Earth's shape and allows for the definition of coordinate systems used by GPS and measuring tools.			\N	2026-06-02 02:48:27.983417+00
41	published	40	Géoréférencement	Opération consistant à attribuer des coordonnées géographiques précises (X, Y, Z) à un objet ou à un plan dans un système de référence national.	Georeferencing	The operation of assigning precise geographical coordinates (X, Y, Z) to an object or plan in a national reference system.			\N	2026-06-02 02:48:27.983417+00
42	published	41	Lot	Unité foncière issue d'une division (lotissement) ou unité de propriété dans un immeuble en copropriété.	Lot	A land unit resulting from a division (subdivision) or an ownership unit in a co-ownership building.			\N	2026-06-02 02:48:27.983417+00
43	published	42	NGF (Nivellement Général de la France)	Système de référence altimétrique officiel permettant d'exprimer les altitudes par rapport au niveau moyen de la mer.	NGF (General Leveling of France)	The official altimetric reference system used to express altitudes relative to mean sea level.			\N	2026-06-02 02:48:27.983417+00
44	published	43	Parcelle	Unité de base du plan cadastral, identifiée par une section et un numéro, représentant une étendue de terrain d'un seul tenant.	Parcel	The basic unit of the cadastral plan, identified by a section and number, representing a continuous stretch of land.			\N	2026-06-02 02:48:27.983417+00
45	published	44	Plan de bornage	Document graphique dressé par le Géomètre-Expert à l'issue d'une mission de bornage, identifiant les limites et les points de repère (bornes).	Boundary Plan	A graphic document drawn up by the Chartered Surveyor following a boundary marking mission, identifying boundaries and reference points (markers).			\N	2026-06-02 02:48:27.983417+00
46	published	45	Procès-Verbal (PV) de Bornage	Acte juridique signé par les propriétaires voisins qui consacre leur accord définitif sur la limite de leurs propriétés.	Boundary Marking Minutes (PV)	A legal act signed by neighboring owners that formalizes their final agreement on the boundary of their properties.			\N	2026-06-02 02:48:27.983417+00
47	published	46	Référentiel Lambert 93	Système de projection officiel utilisé en France métropolitaine pour l'ensemble des cartes et des levés topographiques.	Lambert 93 Reference	The official projection system used in metropolitan France for all maps and topographic surveys.			\N	2026-06-02 02:48:27.983417+00
48	published	47	Station totale	Instrument de mesure combinant un théodolite électronique et un télémètre laser pour mesurer des angles et des distances avec une extrême précision.	Total Station	A measuring instrument combining an electronic theodolite and a laser rangefinder to measure angles and distances with extreme precision.			\N	2026-06-02 02:48:27.983417+00
49	published	48	Talutage	Action de donner une pente inclinée (talus) aux terres lors d'un terrassement pour assurer la stabilité du terrain.	Batters / Sloping (Talutage)	The action of giving an inclined slope (batter) to soil during earthworks to ensure land stability.			\N	2026-06-02 02:48:27.983417+00
50	published	49	Topométrie	Art de la mesure des dimensions de la Terre sur une zone limitée, permettant la réalisation de plans à grande échelle.	Topometry	The art of measuring dimensions of the Earth on a limited area, allowing the creation of large-scale plans.			\N	2026-06-02 02:48:27.983417+00
51	published	50	Permis d'aménager	Autorisation d'urbanisme permettant à l'administration de contrôler les aménagements affectant l'utilisation du sol (lotissement, camping, etc.).	Development Permit	Urban planning authorization allowing the administration to control developments affecting land use (housing estates, camping, etc.).			\N	2026-06-02 02:48:27.983417+00
52	published	51	Notice descriptive	Document technique détaillant les caractéristiques d'un projet d'aménagement et son insertion dans le paysage.	Descriptive Notice	Technical document detailing the characteristics of a development project and its integration into the landscape.			\N	2026-06-02 02:48:27.983417+00
53	published	52	Calcul de cubatures	Évaluation précise des volumes de terrassement (déblais et remblais) à partir de levés topographiques comparatifs.	Cubature Calculation	Precise evaluation of earthwork volumes (excavation and embankment) based on comparative topographic surveys.			\N	2026-06-02 02:48:27.983417+00
54	published	53	Auscultation d'ouvrages	Mesures de précision répétées dans le temps pour surveiller la stabilité et les éventuelles déformations d'un bâtiment ou d'une infrastructure.	Structural Monitoring	Repeated precision measurements over time to monitor the stability and any potential deformations of a building or infrastructure.			\N	2026-06-02 02:48:27.983417+00
55	published	54	Plans d'intérieurs	Représentation graphique détaillée de chaque niveau d'un bâtiment, incluant les murs, cloisons, ouvertures et équipements.	Interior Plans	Detailed graphic representation of each level of a building, including walls, partitions, openings, and equipment.			\N	2026-06-02 02:48:27.983417+00
56	published	55	Coupe de bâtiment	Représentation d'une section verticale d'un édifice permettant d'en comprendre les hauteurs et la structure interne.	Building Section	Representation of a vertical section of a building to understand its heights and internal structure.			\N	2026-06-02 02:48:27.983417+00
57	published	56	Mitoyenneté	Droit de propriété partagé sur une clôture, un mur ou une haie séparant deux propriétés contiguës.	Joint Ownership	Shared property right on a fence, wall, or hedge separating two contiguous properties.			\N	2026-06-02 02:48:27.983417+00
58	published	57	Servitude de tréfonds	Droit permettant le passage de canalisations ou de réseaux souterrains sous la propriété d'autrui.	Underground Easement	Right allowing the passage of pipes or underground networks beneath another person's property.			\N	2026-06-02 02:48:27.983417+00
59	published	58	Lotissement	Division d'une unité foncière en plusieurs lots destinés à être bâtis, impliquant souvent la création d'espaces communs.	Housing Estate	Division of a land unit into several lots intended for building, often involving the creation of common spaces.			\N	2026-06-02 02:48:27.983417+00
60	published	59	Altidimétrie	Partie de la topographie traitant de la mesure des altitudes et de la représentation du relief.	Altimetry	Part of topography dealing with the measurement of altitudes and the representation of relief.			\N	2026-06-02 02:48:27.983417+00
61	published	60	Planimétrie	Représentation sur un plan horizontal des détails naturels et artificiels de la surface de la Terre, sans tenir compte du relief.	Planimetry	Representation on a horizontal plane of natural and artificial details of the Earth's surface, without regard to relief.			\N	2026-06-02 02:48:27.983417+00
62	published	61	Théodolite	Instrument de précision utilisé par le géomètre pour mesurer les angles horizontaux et verticaux.	Theodolite	Precision instrument used by the surveyor to measure horizontal and vertical angles.			\N	2026-06-02 02:48:27.983417+00
63	published	62	Règlement de copropriété	Document contractuel qui définit les règles de fonctionnement d'un immeuble et les droits et devoirs des copropriétaires.	Co-ownership Regulations	Contractual document defining the operating rules of a building and the rights and duties of co-owners.			\N	2026-06-02 02:48:27.983417+00
64	published	63	Plan de situation	Plan permettant de localiser précisément un terrain dans sa commune et son environnement global.	Location Plan	Plan used to precisely locate a piece of land within its municipality and its global environment.			\N	2026-06-02 02:48:27.983417+00
65	published	64	Droit de surplomb	Droit de faire passer une isolation thermique par l'extérieur au-dessus de la propriété voisine, sous certaines conditions légales.	Overhang Right	Right to pass external thermal insulation over the neighbor's property, under certain legal conditions.			\N	2026-06-02 02:48:27.983417+00
\.


--
-- Data for Name: partenaires; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.partenaires (id, status, sort, name, logo, role, website, created_at) FROM stdin;
\.


--
-- Data for Name: projets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.projets (id, status, sort, slug, title, description, location, category, client, missions, technical_details, image_before, image_after, images_gallery, latitude, longitude, date, created_at, updated_at, documents) FROM stdin;
1	published	\N	eco-quartier-de-la-vallee	Éco-quartier de la Vallée	Création d'un nouveau quartier résidentiel durable privilégiant les mobilités douces et la gestion alternative des eaux pluviales. Le projet intègre 45 logements dans un cadre paysager préservé.	Saint-Renan (29)	urbanisme	Ville de Saint-Renan	["Maîtrise d'œuvre urbaine", "Conception paysagère", "VRD"]	45 lots, 3 hectares, 1.5km de pistes cyclables	vallee-before.webp	vallee-after.webp	[]	\N	\N	2026-05-01 02:22:44+00	2026-06-02 02:48:27.050417+00	2026-06-02 02:48:27.050417+00	[]
2	published	\N	requalification-dune-place-creation-dune-aire-de-jeux-dune-aire-de-camping-car-et-maillage-pieton	Requalification d’une place, création d’une aire de jeux, d’une aire de camping-car et maillage piéton	Étude multisectorielle de requalification urbaine et paysagère dans le centre-bourg de Plouézec.\r\n\r\n### Qualité environnementale & paysagère :\r\n* **Préservation de la biodiversité :** Préservation des arbres existants à l’appui du diagnostic effectué par l’ONF.\r\n* **Éco-matériaux :** Emploi de matériaux locaux ou réemploi pour les revêtements de surface.\r\n* **Économie locale :** Mobilier urbain de fabrication bretonne (hors accro-branche).\r\n* **Gestion durable :** Gestion différenciée des espaces verts.\r\n\r\n### Fonctionnement & Usages :\r\n* **Aires de loisirs :** Réponse à la demande des jeunes d’avoir des aires de jeux et de sport à proximité (l’ancienne était située à 2 km).\r\n* **Place des Droits de l’Homme :** Requalification globale pour répondre aux enjeux de stationnement près de la salle multifonction (espace culturel), impliquant le déplacement de l’aire de camping-car au sud.\r\n* **Sport local :** Intégration d’une aire de boules bretonnes avec son bâtiment afférent.\r\n* **Liaisons douces :** Confortement des chemins piétons existants et création d’un maillage à l’appui des voies existantes pour placer le centre-bourg à seulement 2 minutes à pied.	Plouézec (22)	urbanisme	Commune de Plouézec	["Mission de maîtrise d’œuvre complète"]		1784660429646-capture-d-ecran-2026-07-21-a-14.59.49.png	1784660431905-capture-d-ecran-2026-07-21-a-14.59.57.png	[]	48.749732	-2.984227	2026-06-19 00:00:00+00	2026-07-21 17:19:53.206743+00	2026-07-21 17:19:53.206743+00	[{"url": "1784660174799-presentation-urbateam.pdf", "name": "Présentation Urbateam.pdf"}]
\.


--
-- Data for Name: simulations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.simulations (id, created_at, address, parcel_ref, total_surface, lot_a_surface, lot_b_surface, client_name, client_email, client_phone, client_message, status) FROM stdin;
\.


--
-- Data for Name: site_texts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.site_texts (key, fr, en, br, created_at, updated_at) FROM stdin;
stats.collaborators.number	13	\N	\N	2026-06-22 12:31:52.002819+00	2026-06-22 12:31:51.533+00
stats.collaborators.label	Collaborateurs dédiés	Dedicated collaborators	Kenlabourerien	2026-06-22 12:31:55.477012+00	2026-06-22 12:31:55.405+00
stats.collaborators.desc	Géomètres, urbanistes, paysagiste et ingénieurs pluridisciplinaires.	Pluridisciplinary surveyors, planners and engineers.	Douaronerien, kêraourien ha dornourien liesplegek.	2026-06-22 12:32:09.647158+00	2026-06-22 12:32:09.587+00
hero.title_part1	Concrétisez vos projets d'aménagement	Materialize your development projects	Kasit ho raktresoù d'ober	2026-06-22 12:32:43.665634+00	2026-06-22 12:32:43.431+00
hero.title_part2	dans le Finistère	in Western Brittany	e Breizh-Izel	2026-06-22 12:32:46.612755+00	2026-06-22 12:32:46.556+00
hero.description	URBATEAM est basé à Saint-Renan et Douarnenez. Géomètre-Expert, urbanisme, paysage et VRD : une expertise complète au service de vos projets. 	URBATEAM accompanies you from design to completion. Land Surveying cabinet, urban planners and infrastructure engineering (VRD) based in Saint-Renan (Brest) and Douarnenez.	URBATEAM a ambroug ac'hanoc'h adalek ar meizad betek an ober. Burev Douaronerien-Varnourien, kêraourien ha gwazourien frammoù (VRD) e Lokournan (Brest) ha Douarnenez.	2026-06-22 12:32:50.547019+00	2026-06-22 12:32:50.482+00
stats.projects.desc	De la parcelle individuelle aux opérations d'aménagement d'envergure.	From individual housing to regional eco-neighborhoods.	Adalek an ti hiniennel betek karterioù ekologel.	2026-06-22 12:35:38.77118+00	2026-06-22 12:35:38.284+00
stats.projects.label	Dossiers traités	Large-scale projects	Raktresoù meur	2026-06-22 12:39:07.587548+00	2026-06-22 12:39:07.498+00
stats.projects.number	500	\N	\N	2026-06-22 12:39:10.089123+00	2026-06-22 12:39:09.858+00
expertise.items.copropriete.longDesc	Grâce au relevé scanner laser 3D, URBATEAM intervient sur l’ensemble des missions de copropriété et de division en volumes : état descriptif de division, règlement de copropriété et organisation juridique des ensembles immobiliers. 	URBATEAM excels in capturing and modeling existing structures. We transform your physical buildings into intelligent digital twins (<a class="wiki-link" href="/lexique?search=BIM">BIM</a>), centralizing all technical data.	URBATEAM a oar ober e-barzh lakaat ha meizañ ar savadurioù. Cheñch a reomp ho savadurioù da gevelled niverel speredek (<a class="wiki-link" href="/lexique?search=BIM">BIM</a>).	2026-06-22 12:53:34.379748+00	2026-07-29 09:48:00.935+00
references.subtitle	Collectivités, promoteurs et donneurs d'ordres institutionnels nous confient leurs projets d'aménagement.	Local authorities, developers and institutional clients entrust us with their development projects.	Strolladoù tiriadel, saverien ha mestrourien a fiz o raktresoù aozañ ennomp.	2026-06-22 12:58:18.513323+00	2026-06-22 12:58:18.296+00
about.header.subtitle	Votre cabinet de référence pour l’aménagement et le développement des territoires dans le Finistère.	Your privileged partner for land planning in Western Brittany.	Ho kenoberour pennañ evit aozañ an diriadoù e Breizh-Izel.	2026-06-22 13:00:08.651162+00	2026-06-22 13:00:08.386+00
about.society.title	Notre Cabinet	Our Company	Hor Sosiete	2026-06-22 13:00:18.214448+00	2026-06-22 13:00:18.121+00
stats.creation.number	1983	\N	\N	2026-06-19 14:49:51.628722+00	2026-07-21 17:13:10.538+00
expertise.subtitle	Une approche globale et pluridisciplinaire pour répondre aux enjeux de vos projets fonciers, d'aménagement et de développement territorial.	A comprehensive and multidisciplinary approach to meet the requirements of your urban, land and infrastructure development projects.	Ur sell hollek ha liesplegek evit respont da ezhommoù ho raktresoù kêraozerezh, douar ha frammoù.	2026-06-22 12:37:30.480628+00	2026-07-29 09:48:00.942+00
expertise.items.topographie.longDesc	La précision est au cœur de notre métier. Grâce à des outils de haute technologie, nous capturons l'existant avec une fidélité absolue pour servir de base à vos projets.	Precision is at the heart of our business. Using high-tech tools (<a class="wiki-link" href="/lexique?search=Scanner">3D Scanner</a>, <a class="wiki-link" href="/lexique?search=Drone">Drone</a>, GPS), we capture existing conditions with absolute fidelity to serve as a basis for your projects.	Ar resisted eo hor micher. A-drugarez d'hon dafar teknologel (<a class="wiki-link" href="/lexique?search=Scanner">Scanner 3D</a>, <a class="wiki-link" href="/lexique?search=Drone">Dron</a>, GPS), lakaat a reomp e tres pep tra gant ur resisted a-feson evit sikour ho raktresoù.	2026-06-22 12:49:27.270097+00	2026-07-29 09:48:00.967+00
about.society.p1	Depuis plus de 40 ans, URBATEAM accompagne les collectivités, les professionnels et les particuliers dans leurs projets fonciers et d’aménagement du territoire.	URBATEAM accompanies you throughout your development projects in Western Brittany through our two local offices located in Saint-Renan (near Brest) and Douarnenez.	URBATEAM a ambroug ac'hanoc'h e-pad ho raktresoù aozañ e Breizh-Izel a-drugarez d'hon div ajañs e Lokournan (kostez Brest) ha Douarnenez.	2026-06-22 13:01:53.11387+00	2026-06-22 13:01:52.868+00
expertise.items.bornage.image	https://sdpfyiiwmtlhkgffhaao.supabase.co/storage/v1/object/public/urbateam-media/1785308958365-1776844514439.jpg	\N	\N	2026-07-29 07:09:24.993217+00	2026-07-29 09:48:00.926+00
about.society.p3	Les valeurs qui guident notre action :\n\nL’éthique professionnelle :\nNeutralité, impartialité, transparence et respect du cadre réglementaire guident notre manière d’exercer nos métiers au quotidien.\n\nLe conseil :\nComprendre les besoins, accompagner les décisions et orienter vers les bonnes solutions font partie intégrante de notre métier.\n\nLa précision :\nParce que nos métiers exigent rigueur et fiabilité, nous accordons une attention particulière à la qualité des études, des mesures et des réalisations.\n\nL’esprit d’équipe :\nLa diversité des compétences et le travail collectif sont au cœur du fonctionnement d’Urbateam.	We are committed to mastering, enhancing and guaranteeing the quality of the services offered, while scrupulously respecting the needs of our clients.	Gouestlañ a reomp da vestroniañ ha da warantiñ kalite hor servijoù, en ur doujañ d'an ezhommoù ho peus.	2026-06-22 13:01:55.092152+00	2026-06-22 16:05:11.933+00
expertise.items.urbanisme.longDesc	URBATEAM accompagne les collectivités et les aménageurs privés dans la conception de cadres de vie durables et harmonieux. Notre approche mêle vision stratégique urbaine et sensibilité paysagère pour créer des espaces qui font sens, en intégrant les enjeux du <a class="wiki-link" href="/lexique?search=PLU">PLU</a> et du développement durable.\nNotre savoir-faire permet d’intégrer chaque projet dans son environnement et de créer des lieux de vie qualitatifs, durables et agréables à vivre, adaptés aux enjeux des territoires.	URBATEAM supports local authorities and private developers in the design of sustainable and harmonious living environments. Our approach combines strategic urban vision and landscape sensitivity to create meaningful spaces, integrating <a class="wiki-link" href="/lexique?search=PLU">PLU</a> requirements and sustainable development goals.	URBATEAM a ambroug ar strollegezhioù hag an aozourien prevez evit meizañ karterioù padus ha plijus. Meskañ a reomp strategiezh kêr ha gweledva evit krouiñ takadoù a ra ster, en ur doujañ da ezhommoù ar <a class="wiki-link" href="/lexique?search=PLU">PLU</a> hag an diorren padus.	2026-06-22 15:57:29.819076+00	2026-07-29 09:48:00.936+00
expertise.items.urbanisme.title	Urbanisme et Paysage	Urban Planning & Landscape	Kêraozerezh & Gweledva	2026-07-29 07:09:35.408494+00	2026-07-29 09:48:00.97+00
expertise.items.copropriete.image	https://sdpfyiiwmtlhkgffhaao.supabase.co/storage/v1/object/public/urbateam-media/1785317696031-img_20260428_112803.png	\N	\N	2026-07-29 07:09:35.082451+00	2026-07-29 09:48:01.109+00
expertise.items.lotissement.image	https://sdpfyiiwmtlhkgffhaao.supabase.co/storage/v1/object/public/urbateam-media/1785316912381-1784544422617.jpg	\N	\N	2026-07-29 07:09:35.457003+00	2026-07-29 09:48:01.104+00
expertise.items.vrd.longDesc	Études techniques, conception de réseaux d’assainissement, d’eau potable et de gestion des eaux pluviales, aménagement de voiries, suivi de travaux…\nNos ingénieurs et techniciens assurent la conception et le pilotage technique des aménagements jusqu’à leur réalisation.	Our engineers and technicians design the essential technical infrastructure for project servicing. We favor innovative solutions for <a class="wiki-link" href="/lexique?search=VRD">roads and utilities</a> and sustainable water management.	Hon dornourien a veiz ar frammoù a zo ezhomm evit ur raktres (dour, hentoù, h.a). Dibab a reomp diskoulmoù nevez evit ar <a class="wiki-link" href="/lexique?search=VRD">rouedadoù</a> ha mestroniañ an dour e mod padus.	2026-06-22 15:55:28.07805+00	2026-07-29 09:48:00.99+00
expertise.items.division.longDesc	URBATEAM vous accompagne dans toutes les étapes de la division parcellaire. De l'étude de faisabilité à la déclaration préalable en mairie, jusqu'au document d'arpentage et au bornage des nouveaux lots.	URBATEAM supports you in all stages of land division. From feasibility studies to municipal declarations, up to cadastral updates and lot boundary staking.	URBATEAM a ambroug ac'hanoc'h evit rannañ ho touaroù. Eus ar studi gentañ d'an teuliadoù evit an ti-kêr, hag an tresoù arpentage.	2026-07-29 07:09:35.226961+00	2026-07-29 09:48:01.022+00
about.society.p2	Implantée à Saint-Renan et à Douarnenez, notre équipe pluridisciplinaire réunit des géomètres-experts ainsi que des compétences en urbanisme, paysage et VRD (voiries et réseaux divers), afin de proposer un accompagnement global, de l’étude jusqu’à la réalisation. Notre force : associer l’ensemble de ces compétences pour concevoir des projets cohérents, durables et adaptés aux usages de demain.\nNous nous engageons à maîtriser, valoriser et garantir la qualité des services offerts, tout en respectant scrupuleusement les besoins de nos maîtres d'ouvrage.	Our missions cover the traditional fields of activity of Chartered Land Surveyors (boundary marking, divisions, building land creation, co-ownerships, site layouts, expertise, topography), but also historically urban planning, landscape and infrastructure engineering (VRD).	Hor c'hefridioù a denn da dachennoù boas an Douaronerien-Varnourien (bonnañ, rannañ, sevel lodennoù da sevel tiez, kenperc'henniezh, topografiezh), met ivez da geriaozerezh, gweledva ha dornouriezh frammoù (VRD).	2026-06-22 13:01:50.681847+00	2026-06-22 16:04:47.98+00
tools.cadastre_map.visible	false	false	false	2026-06-22 16:08:33.551317+00	2026-06-22 16:08:33.295+00
tools.sun_simulator.visible	false	false	false	2026-06-22 16:08:35.310226+00	2026-06-22 16:08:35.226+00
tools.profil_long.visible	false	false	false	2026-06-22 16:08:38.072931+00	2026-06-22 16:08:38.005+00
technical.sections	[{"id":"infra","title":"Nos bureaux","icon":"building","list":["Un bureau à Saint-Renan (29)","Un bureau à Douarnenez (29)"]},{"id":"field","title":"Équipements Terrain","icon":"map-pin","list":["1 scanner Trimble X9","3 stations totales (Trimble S3 et S5)","2 récepteurs GNSS Teria PYX"],"showFieldImages":true},{"id":"software","title":"Environnement Logiciel","icon":"software","desc":"Dessin assisté par ordinateur, conception 3D et modélisation logicielle :\\n12 postes informatiques équipés de licences","showSoftwareImages":true}]	\N	\N	2026-06-22 16:06:35.030547+00	2026-07-28 08:50:17.659+00
expertise.items.bornage.longDesc	Seul professionnel habilité à fixer les limites des biens fonciers, le Géomètre-Expert URBATEAM garantit la sécurité juridique de votre patrimoine. Le bornage contradictoire définit physiquement et juridiquement les limites de propriété en accord avec les riverains.	As the only professional authorized to define property limits, the URBATEAM Chartered Surveyor guarantees the legal security of your assets. Boundary marking defines physical and legal boundaries in agreement with neighbors.	An Douaroner-Barnour eo an den nemetañ a c'hell lakaat harzoù ofisiel d'ho touar, gwarantiñ a ra URBATEAM surentez ho madoù. Labourat a reomp war holl gudennoù gwir an douar gant teuliadoù bonnañ resis.	2026-07-29 07:09:35.003852+00	2026-07-29 09:48:00.928+00
expertise.items.division.desc	Création de nouvelles parcelles foncières en vue de bâtir ou de vendre.	Creation of new land parcels for building or selling.	Krouiñ lodennoù douar nevez evit sevel tiez pe gwerzhañ.	2026-07-29 07:09:35.460317+00	2026-07-29 09:48:00.931+00
expertise.items.bornage.desc	Définition juridique et physique des limites séparatives de votre propriété.	Legal and physical definition of property boundaries.	Lakaat ofisiel ha war an dachenn harzoù ho perc'henniezh.	2026-07-29 07:09:35.390984+00	2026-07-29 09:48:00.939+00
expertise.title	Nos Domaines d'Expertise	Our Areas of Expertise	Hor Barregezhioù	2026-07-29 07:09:34.492295+00	2026-07-29 09:48:00.941+00
expertise.items.geometre.desc	Matérialisation précise sur le terrain de l'emplacement de votre future construction, conformément aux plans validés, avant le démarrage des travaux.	Land studies office: boundary marking, parcel divisions, co-ownerships, amicable property delimitations.	Burev studial douar : bonnañ, rannañ lodennoù, kenperc'henniezh ha lakaat harzoù d'an douaroù.	2026-06-22 12:41:21.183948+00	2026-07-29 09:48:00.97+00
expertise.items.urbanisme.image	/pictures/urbanisme-bureau.png	\N	\N	2026-07-29 07:09:35.394586+00	2026-07-29 09:48:00.942+00
expertise.items.sport.image	/pictures/sport-ingenierie.png	\N	\N	2026-07-29 07:09:35.196296+00	2026-07-29 09:48:01.102+00
expertise.items.topographie.title	Topographie	Topography	Topografiezh	2026-07-29 07:09:35.45488+00	2026-07-29 09:48:00.97+00
expertise.cta_title	Un projet spécifique ?	A specific project?	Ur raktres ispisial ?	2026-07-29 07:09:35.226161+00	2026-07-29 09:48:00.937+00
expertise.items.geometre.title	Implantation	Chartered Land Surveyor	Douaroner-Barnour	2026-07-29 07:09:35.228964+00	2026-07-29 09:48:01.228+00
expertise.items.division.image	https://sdpfyiiwmtlhkgffhaao.supabase.co/storage/v1/object/public/urbateam-media/1785309014834-img_20260428_112805.jpg	\N	\N	2026-07-29 07:09:34.357122+00	2026-07-29 09:48:00.926+00
expertise.items.urbanisme.desc	ZAC, éco-quartiers, parcs d'activités, entrées de ville, réaménagement urbain, aménagement de quartiers et d'espaces publics, aménagement de rues, conception de lotissements.	Development studies office: ZAC, eco-neighborhoods, city sections, activity parks, town entrances, and urban redevelopment.	Burev studial an aozañ : ZAC, karterioù ekologel, lodennoù kêr, takadoù obererezh ha reneveziñ kêr.	2026-06-22 15:55:42.475973+00	2026-07-29 09:48:00.933+00
expertise.items.topographie.desc	Opérations topographiques : plans topographiques de précision, relevés de terrain et d'architecture.	Topographic studies office: precision topographic plans, land and architectural surveys, site layouts.	Burev studial topografiezh : tresoù topografek resis, kempenn an douar hag ar savouriezh.	2026-06-22 12:49:02.596019+00	2026-07-29 09:48:00.941+00
expertise.items.geometre.image	https://sdpfyiiwmtlhkgffhaao.supabase.co/storage/v1/object/public/urbateam-media/1785318128745-img_20260429_170838.jpg	\N	\N	2026-07-29 07:09:35.458755+00	2026-07-29 09:48:00.96+00
expertise.items.vrd.desc	Bureau d'études en voirie, réseaux divers, assainissement, traitement des eaux pluviales, parkings, giratoires.	Infrastructure studies office: roads, diverse networks, sanitation, rainwater treatment, parking lots, roundabouts.	Burev studial frammoù : hentoù, rouedadoù liesseurt, dour-lous ha dour-glav, parkingoù.	2026-06-22 15:54:59.178234+00	2026-07-29 09:48:00.97+00
expertise.items.sport.title	Ingénierie Sportive	Sports Engineering	Dornouriezh Sport	2026-07-29 07:09:35.093084+00	2026-07-29 09:48:00.988+00
expertise.items.geometre.longDesc	L'implantation consiste à matérialiser sur le terrain l'emplacement exact de votre future construction avant le démarrage des travaux. À partir des plans validés, le Géomètre-Expert positionne avec précision les axes, angles et niveaux nécessaires à la réalisation du projet, garantissant une implantation conforme aux autorisations d'urbanisme et aux limites de propriété.	As the only professional authorized to set property boundaries, the URBATEAM Chartered Surveyor guarantees the legal security of your assets. We intervene on all land-related issues, from <a class="wiki-link" href="/lexique?search=Boundary">boundary marking</a> to <a class="wiki-link" href="/lexique?search=Easement">easement</a> management.	An Douaroner-Barnour eo an den nemetañ a c'hell lakaat harzoù ofisiel d'ho touar, gwarantiñ a ra URBATEAM surentez ho madoù. Labourat a reomp war holl gudennoù gwir an douar, adalek ar <a class="wiki-link" href="/lexique?search=Bornage">bonnañ</a> betek ar <a class="wiki-link" href="/lexique?search=Servitude">sklentoù</a>.	2026-06-22 12:48:00.361324+00	2026-07-29 09:48:00.963+00
expertise.items.sport.longDesc	Spécialiste des équipements sportifs, URBATEAM conçoit des installations performantes répondant aux normes des fédérations. Nous accompagnons les clubs et mairies dans la création de complexes modernes.	Specializing in sports equipment, URBATEAM designs high-performance installations meeting federation standards. We support clubs and town halls in creating modern complexes.	URBATEAM a zo ur mailh war an tachennoù sport hag a zeu a-benn da veizañ tachennoù a zouj ouzh reolennoù ar c'hevreadoù. Sikour a reomp ar c'hluboù hag an tiez-kêr da sevel stadioù modern.	2026-07-29 07:09:35.28073+00	2026-07-29 09:48:00.965+00
references.items	["LOCMARIA-PLOUZANE (29) : Réaménagement total de la place de la Mairie ","SAINT-FREGANT (29) : Requalification de la rue du bourg et place de la mairie - continuité cycle et chemin piéton, sécurisation de l’accès à l’école et mise aux normes des arrêts de cars.","PLOUEZEC (22) : Réaménagement de la place des Droits de l’Homme","SAINT-RENAN (29) : Réaménagement de la place Saint-Antoine","PORSPODER (29) : Aménagement et étude paysagère du camping municipal","PLOMODIERN (29) : Aménagement de la route de Chateaulin – Longueur : 800 m","COAT-MEAL (29) : Aménagement de la rue de Kerbiquet sur 600 m Aménagement paysager, zone 30 et cheminements doux","LANRIVOARE (29) : Réaménagement du centre bourg – Longueur de voies : 500 m","BREST (29) : ZAC du Port de Commerce à BREST","PLABENNEC (29) : Refonte complète de la route départementale rue Maréchal Leclerc sur 750 m (voirie, aménagement urbain, réseaux)","LOCMARIA-PLOUZANE (29) : Réaménagement du front de mer de Trégana à Portez","GUILERS (29) : ZAC de Pen Ar C’hoat à GUILERS"]	["PLOUEZEC Eco-neighborhood (22) - Sketch competition","SQUIFFIEC (22): New sustainable district 'Le Hameau de la Vallée'","BRELES: Eco-village in the heart of the village","ZAC & Land divisions: PLOUDALMEZEAU, GUILERS, LAMPAUL-PLOUARZEL","GOUESNOU and CHATEAULIN: New HQE neighborhoods","Village center development: LANILDUT, IRVILLAC, PLOMODIERN","LANNION: Kervouric-Servel Eco-neighborhood","Urban redevelopment: PORSPODER, LAMPAUL-PLOUARZEL","TREBEURDEN (22): Pierre MARZIN Eco-neighborhood","POULLAN-SUR-MER: Park ar Leur sustainable district"]	["Karter ekologel PLEUZEG (22) - Kevezadeg tresañ","SQUIFFIEC (22) : Karter padus nevez 'Le Hameau de la Vallée'","BRELES : Ekodrebi e kreiz-kêr","Lotissemantoù : PLOUDALMEZEAU, GUILERS, LAMPAUL-PLOUARZEL","GOUESNOU ha CHATEAULIN : Karterioù HQE nevez","Aozañ keriadennoù : LANILDUT, IRVILLAC, PLOMODIERN","LANNION : Karter ekologel Kervouric-Servel","Adkempenn kêrioù : PORSPODER, LAMPAUL-PLOUARZEL","TREBEURDEN (22) : Karter ekologel Pierre MARZIN","POULLAN-SUR-MER : Karter padus Park ar Leur"]	2026-07-20 17:43:19.065635+00	2026-07-28 08:40:40.114+00
tools.eco_diagnostic.visible	false	false	false	2026-07-28 08:48:38.253857+00	2026-07-28 08:48:44.165+00
contact.info.title	Nos Coordonnées	Contact Details	Hore Titouroù	2026-07-28 08:57:23.255441+00	2026-07-28 08:57:22.956+00
contact.info.hours.closed	Fermé	Closed	Serr	2026-07-28 08:57:23.310456+00	2026-07-28 08:57:23.058+00
contact.header.title	Contactez-nous	Contact Us	Deuit e darempred	2026-07-28 08:57:23.310495+00	2026-07-28 08:57:22.949+00
contact.info.hours_label	Horaires d'ouverture	Opening Hours	Eurioù digor	2026-07-28 08:57:23.3404+00	2026-07-28 08:57:23.074+00
contact.info.email_label	Adresse Électronique	Email Address	Postel	2026-07-28 08:57:23.311499+00	2026-07-28 08:57:22.964+00
contact.info.hours.fri	Vendredi :	Friday:	Gwener :	2026-07-28 08:57:23.336589+00	2026-07-28 08:57:23.056+00
contact.info.hours.tue	Mardi :	Tuesday:	Meurzh :	2026-07-28 08:57:23.329333+00	2026-07-28 08:57:23.055+00
contact.info.douarnenez	Cabinet de Douarnenez	Douarnenez Office	Ajañs Douarnenez	2026-07-28 08:57:23.264758+00	2026-07-28 08:57:22.955+00
contact.info.hours.mon	Lundi :	Monday:	Lun :	2026-07-28 08:57:23.336563+00	2026-07-28 08:57:22.95+00
contact.info.hours.wed	Mercredi :	Wednesday:	Merc'her :	2026-07-28 08:57:23.34137+00	2026-07-28 08:57:23.03+00
contact.info.hours.thu	Jeudi :	Thursday:	Yaou :	2026-07-28 08:57:23.336778+00	2026-07-28 08:57:22.949+00
contact.info.renan	Cabinet de Saint-Renan	Saint-Renan Office	Ajañs Lokournan	2026-07-28 08:57:23.345334+00	2026-07-28 08:57:23.068+00
contact.header.subtitle	Que ce soit pour un projet d'aménagement, un relevé topographique ou une division foncière, notre équipe est à votre écoute.	Whether for a development project, a topographic survey or a land division, our team is at your service.	Evit ur raktres aozañ, un tres topografek pe ur rann douar, hor skipailh a zo ouzh ho selaou.	2026-07-28 08:57:23.355184+00	2026-07-28 08:57:23.062+00
contact.info.hours.sat_sun	Samedi - Dimanche :	Saturday - Sunday:	Sadorn - Sul :	2026-07-28 08:57:23.749823+00	2026-07-28 08:57:23.093+00
expertise.items.bornage.title	Bornage	Boundary Marking	Bonnañ	2026-07-29 07:09:35.277793+00	2026-07-29 09:48:00.945+00
expertise.items.copropriete.desc	Relevés par scanner 3D, mise en copropriété, division en volumes, état descriptif de division et règlement de copropriété.	Expertise in building surveys, co-ownership setup, and BIM modeling for intelligent building management.	Varregezh war muzuliañ savadurioù, lakaat e kenperc'henniezh ha diskouez e 3D.	2026-06-22 12:52:33.126463+00	2026-07-29 09:48:01.1+00
expertise.items.lotissement.title	Lotissements	Subdivisions	Lodennaouegoù	2026-07-29 07:09:35.100157+00	2026-07-29 09:48:00.937+00
expertise.cta_desc	Découvrez comment notre équipe peut vous aider.	Discover how our team can help you.	Sellit penaos e c'hell hor skipailh sikour ac'hanoc'h.	2026-07-29 07:09:34.980469+00	2026-07-29 09:48:01.118+00
expertise.cta_btn	Nous contacter	Contact us	Darempred	2026-07-29 07:09:35.089175+00	2026-07-29 09:48:00.965+00
expertise.items.lotissement.desc	Aménagement d'ensemble, création de terrains à bâtir et gestion des espaces communs.	Comprehensive design, creation of building plots, and management of shared spaces.	Meizañ lodennaouegoù, krouiñ douaroù da sevel tiez ha mestroniañ al labourioù.	2026-07-29 07:09:34.95927+00	2026-07-29 09:48:00.971+00
expertise.items.copropriete.title	Copropriété et division en volumes	Co-ownership & volume division	Kenperc'henniezh & Rannañ e volumoù	2026-07-29 07:09:34.523938+00	2026-07-29 09:48:00.986+00
expertise.items.lotissement.longDesc	De la conception à la réception des travaux, URBATEAM vous accompagne dans la réalisation de lotissements et d'éco-quartiers. Nous assurons la maîtrise d'œuvre complète des aménagements, des voiries et des réseaux divers (VRD).	From design to final delivery, URBATEAM supports you in the creation of subdivisions and eco-neighborhoods. We handle the complete engineering of roads and utility networks (VRD).	Eus an tres kentañ da fin al labourioù, URBATEAM a ambroug ac'hanoc'h evit sevel lodennaouegoù ha karterioù ekologel. Prientet e vez ganeomp al labourioù hentoù ha rouedadoù (VRD).	2026-07-29 07:09:35.200878+00	2026-07-29 09:48:00.967+00
expertise.items.division.title	Division	Land Division	Rannañ	2026-07-29 07:09:34.502358+00	2026-07-29 09:48:00.921+00
expertise.items.vrd.image	/pictures/vrd-ingenierie.png	\N	\N	2026-07-29 07:09:34.948446+00	2026-07-29 09:48:00.933+00
expertise.items.topographie.image	https://sdpfyiiwmtlhkgffhaao.supabase.co/storage/v1/object/public/urbateam-media/1785309690993-img_20260414_094629_554.jpg	\N	\N	2026-07-29 07:09:34.901861+00	2026-07-29 09:48:00.934+00
expertise.items.sport.desc	Aménagement de complexes sportifs : stades d'athlétisme, terrains de sports, installations de gazon synthétique.	Development of sports complexes: athletics stadiums, sports fields, synthetic grass installations.	Aozañ takadoù sport : stadioù atleterezh, tachennoù sport ha paviadurioù teuzet.	2026-07-29 07:09:34.541549+00	2026-07-29 09:48:01.101+00
expertise.items.vrd.title	Maîtrise d’œuvre et VRD	Project Management & VRD	Mestroniezh-ober & VRD	2026-07-29 07:09:35.382354+00	2026-07-29 09:48:00.971+00
\.


--
-- Data for Name: social_posts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.social_posts (id, status, sort, url, caption, date, created_at) FROM stdin;
1	published	0	/uploads/social/1777520111868-IMG_0478.jpg	Conseil d'Expert : Division de terrain en zone constructible. Comprendre la différence entre Déclaration Préalable (DP) et Permis d'Aménager (PA) pour sécuriser votre projet foncier.	2026-04-30 03:35:11.871+00	2026-06-02 02:48:29.015882+00
2	published	1	/uploads/social/1777520102568-IMG_0477.jpg	Sur le terrain avec nos partenaires curieux ! 🐮 Relevé topographique de précision en zone rurale. L'expertise foncière au plus près de la nature.	2026-04-30 03:35:02.571+00	2026-06-02 02:48:29.015882+00
3	published	2	/uploads/social/1777520095758-IMG_0476.jpg	Intervention à Douarnenez : relevé de corps de rue et bornage de propriété. URBATEAM se déplace partout en Bretagne-Ouest pour vos projets immobiliers.	2026-04-30 03:34:55.761+00	2026-06-02 02:48:29.015882+00
4	published	3	/uploads/social/1777520090386-IMG_0475.jpg	Vue aérienne d'un lotissement conçu par URBATEAM. Maîtrise d'œuvre urbaine et ingénierie VRD pour des quartiers durables et optimisés.	2026-04-30 03:34:50.391+00	2026-06-02 02:48:29.015882+00
5	published	4	/uploads/social/1777520086084-IMG_0474.jpg	Phase de conception : plan de composition d'un futur éco-quartier. De l'étude de faisabilité à la division parcellaire, nous dessinons demain.	2026-04-30 03:34:46.087+00	2026-06-02 02:48:29.015882+00
6	published	5	/uploads/social/1777520079022-IMG_0472.jpg	Relevé topographique de corps de rue pour un projet d'aménagement urbain. La précision millimétrée au service des collectivités.	2026-04-30 03:34:39.024+00	2026-06-02 02:48:29.015882+00
7	published	6	/uploads/social/1777520072885-IMG_0471.jpg	Litiges de voisinage : que faire en cas d'empiètement ? URBATEAM vous conseille et réalise le bornage contradictoire pour définir vos limites de propriété de manière incontestable.	2026-04-30 03:34:32.888+00	2026-06-02 02:48:29.015882+00
8	published	7	/uploads/social/1777520023211-IMG_0470.jpg	Quand faire appel à un Géomètre-Expert ? Que ce soit pour une mise en copropriété, un bornage, une division de terrain ou une implantation, URBATEAM vous apporte son expertise légale et technique.	2026-04-30 03:33:43.213+00	2026-06-02 02:48:29.015882+00
\.


--
-- Data for Name: team_header; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.team_header (id, title_fr, subtitle_fr, title_en, subtitle_en, title_br, subtitle_br, team_photo, updated_at) FROM stdin;
1	Notre Équipe	Depuis sa création en 1983, Urbateam met à disposition de ses clients une équipe pluridisciplinaire qualifiée de 13 collaborateurs.	Our Team	A friendly, dynamic and multidisciplinary team of about 10 collaborators bringing together Land Surveyors, urban planners, engineers and surveying technicians at the service of your projects' success.	Hor Skipailh	Ur skipailh plijus, oberiant ha liesplegek gant war-dro 10 kenlabourer (Douaronerien, kêraourien, dornourien) evit sevel ho raktresoù.	\N	2026-06-02 02:48:28.148291+00
\.


--
-- Data for Name: team_members; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.team_members (id, status, sort, slug, image, linkedin, generic, email, phone, name_fr, role_fr, desc_fr, name_en, role_en, desc_en, name_br, role_br, desc_br, created_at) FROM stdin;
1	published	0	frank	1784574779809-webp-to-jpg-conversion.jpg	\N	f	franck.legall@urbateam.fr	02 98 84 29 65	M. Frank Le Gall	Géomètre-Expert, Co-Gérant	Maîtrise d'œuvre & Direction	Frank Le Gall	Co-Manager	Project management, urban planning & infrastructure.	Frank Le Gall	Kenrener	Mestroniezh-ober, kêraaozerezh ha frammoù.	2026-06-02 02:48:28.444603+00
2	published	1	laura	1784574799833-webp-to-jpg-conversion-(1).jpg	https://www.linkedin.com/in/laura-charretteur/	f	laura.charretteur@urbateam.fr	02 98 84 29 65	Mme Laura Charretteur	Géomètre-Expert, Co-Gérante	Foncier & Direction	Laura Charretteur	Co-Manager	Land issues, topography & management.	Laura Charretteur	Kenrenerez	Kudennoù douar, topografiezh ha renerezh.	2026-06-02 02:48:28.444603+00
3	published	2	yves	\N	\N	f	yves.jegot@urbateam.fr	02 98 84 29 65	M. Yves. J	Chargé de projets VRD	Maîtrise d'œuvre VRD	Yves Jégot	Infrastructure Project Manager	Expert in road design and diverse networks.	Yves Jégot	Mestroniezh-ober VRD	Arberigour war an hentoù hag ar roudadoù.	2026-06-02 02:48:28.444603+00
4	published	3	trang	\N	\N	f	trang.stephan@urbateam.fr	02 98 84 29 65	Mme Trang S.	Chargée de projets VRD	Maîtrise d'œuvre VRD	Trang Stephan	Infrastructure Project Manager	Specialist in technical design and infrastructure monitoring.	Trang Stephan	Mestroniezh-ober VRD	Ispisialour war ar meizañ teknikel hag an heuliañ frammoù.	2026-06-02 02:48:28.444603+00
5	published	4	camille	\N	\N	f	camille.lormeteau@urbateam.fr	02 98 84 29 65	Mme Camille L.	Paysagiste-Conceptrice Urbaniste	Conception paysagère et intégration environnementale.	Camille Lormeteau	Landscape Designer	Landscape design and environmental integration.	Camille Lormeteau	Gweledvaourez-Meizerez	Meizañ gweledvaoù hag enframmañ en natur.	2026-06-02 02:48:28.444603+00
41	published	5	\N	\N	\N	f	pierre.prie@urbateam.fr	02 98 84 29 65	M. Pierre P.	Géomètre-Expert	Foncier, chargé de projets VRD							2026-07-28 07:20:22.234571+00
42	published	6	\N	\N	\N	f	camille.cossec@urbateam.fr	02 98 84 29 65	Mme Camille C.	Ingénieure géomètre	Foncier							2026-07-28 07:20:22.33593+00
43	published	7	\N	\N	\N	f	emmanuel.grenet@urbateam.fr	02 98 84 29 65	M. Emmanuel G.	Technicien supérieur	Foncier							2026-07-28 07:20:22.436766+00
44	published	8	\N	\N	\N	f	fabrice.beaumanoir@urbateam.fr	02 98 84 29 65	M. Fabrice B.	Technicien supérieur	Foncier							2026-07-28 07:20:22.537687+00
45	published	9	\N	\N	\N	f	camille.poudoulec@urbateam.fr	02 98 84 29 65	Mme Camille P.	Technicienne supérieure	Foncier							2026-07-28 07:20:22.641417+00
46	published	10	\N	\N	\N	f	baptiste.rivier@urbateam.fr	02 98 92 07 56	M. Baptiste R.	Technicien supérieur	Foncier							2026-07-28 07:20:22.746541+00
47	published	11	\N	\N	\N	f	contact@urbateam.fr	02 98 84 29 65	Mme Sarah L.V.	Assistante administrative bureau de Saint-Renan	Gestion administrative							2026-07-28 07:20:22.84941+00
48	published	12	\N	\N	\N	f	douarnenez@urbateam.fr	02 98 92 07 56	Mme Hélène T.	Assistante administrative bureau de Douarnenez	Gestion administrative							2026-07-28 07:20:22.95459+00
\.


--
-- Data for Name: visits; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.visits (id, path, is_article, device, browser, created_at) FROM stdin;
1	/	f	Desktop	Chrome	2026-06-02 03:35:51.917866+00
2	/projets	f	Desktop	Chrome	2026-06-02 03:35:55.227405+00
3	/projets/eco-quartier-de-la-vallee	f	Desktop	Chrome	2026-06-02 03:36:01.29981+00
4	/	f	Desktop	Chrome	2026-06-02 03:38:34.184994+00
5	/blog	f	Desktop	Chrome	2026-06-02 03:39:11.619317+00
6	/	f	Desktop	Chrome	2026-06-02 03:39:28.782839+00
7	/	f	Desktop	Chrome	2026-06-02 13:12:19.041539+00
8	/profil-long	f	Desktop	Chrome	2026-06-02 13:12:21.304584+00
9	/carte-cadastre	f	Desktop	Chrome	2026-06-02 13:12:25.415241+00
10	/simulateur-ensoleillement	f	Desktop	Chrome	2026-06-02 13:12:27.261651+00
11	/simulateur-division	f	Desktop	Chrome	2026-06-02 13:12:30.300416+00
12	/apropos	f	Mobile	Chrome	2026-06-02 13:12:57.093684+00
13	/	f	Mobile	Chrome	2026-06-02 13:13:09.553923+00
14	/	f	Mobile	Safari	2026-06-02 13:14:09.53819+00
15	/	f	Desktop	Chrome	2026-06-02 13:14:33.670324+00
16	/	f	Desktop	Chrome	2026-06-02 13:49:40.677812+00
17	/	f	Mobile	Safari	2026-06-02 14:13:33.242901+00
18	/	f	Mobile	Safari	2026-06-02 14:33:39.455612+00
19	/	f	Mobile	Safari	2026-06-02 14:34:06.1411+00
20	/	f	Mobile	Safari	2026-06-02 15:00:00.052426+00
21	/	f	Mobile	Safari	2026-06-02 15:13:24.568269+00
22	/	f	Desktop	Chrome	2026-06-02 15:28:18.962774+00
23	/	f	Desktop	Chrome	2026-06-02 15:32:33.967568+00
24	/expertise/topographie	f	Desktop	Chrome	2026-06-02 15:33:11.133327+00
25	/	f	Desktop	Chrome	2026-06-02 15:33:20.138712+00
26	/lexique	f	Desktop	Chrome	2026-06-02 15:33:29.150423+00
27	/apropos	f	Desktop	Chrome	2026-06-02 15:34:09.329376+00
28	/simulateur-ensoleillement	f	Desktop	Chrome	2026-06-02 15:34:23.926297+00
29	/eco-diagnostic	f	Desktop	Chrome	2026-06-02 15:36:30.398928+00
30	/simulateur-division	f	Desktop	Chrome	2026-06-02 15:36:37.566901+00
31	/mon-projet	f	Desktop	Chrome	2026-06-02 15:37:44.796493+00
32	/moyens-techniques	f	Desktop	Chrome	2026-06-02 15:37:54.163155+00
33	/projets	f	Desktop	Chrome	2026-06-02 15:38:49.624662+00
34	/apropos	f	Desktop	Chrome	2026-06-02 15:39:03.622375+00
35	/faq	f	Desktop	Chrome	2026-06-02 15:39:18.429439+00
36	/nous-suivre	f	Desktop	Chrome	2026-06-02 15:39:23.272329+00
37	/profil-long	f	Desktop	Chrome	2026-06-02 15:39:29.859657+00
38	/mon-projet	f	Desktop	Chrome	2026-06-02 15:40:55.248846+00
39	/blog	f	Desktop	Chrome	2026-06-02 15:41:00.959216+00
40	/	f	Desktop	Chrome	2026-06-02 15:42:49.222646+00
41	/vieprivee	f	Desktop	Chrome	2026-06-02 15:44:57.568807+00
42	/	f	Desktop	Chrome	2026-06-02 15:45:00.547678+00
43	/apropos	f	Desktop	Chrome	2026-06-02 15:45:37.610596+00
44	/nous-suivre	f	Desktop	Chrome	2026-06-02 15:46:01.693236+00
45	/	f	Desktop	Chrome	2026-06-02 15:48:45.776893+00
46	/expertise/urbanisme	f	Desktop	Chrome	2026-06-02 15:49:17.939106+00
47	/apropos	f	Desktop	Chrome	2026-06-02 15:49:33.608714+00
48	/	f	Desktop	Chrome	2026-06-02 15:51:00.401091+00
49	/apropos	f	Desktop	Chrome	2026-06-02 15:51:05.676833+00
50	/	f	Desktop	Chrome	2026-06-02 15:51:07.981665+00
51	/blog	f	Desktop	Chrome	2026-06-02 15:51:23.496041+00
52	/	f	Desktop	Chrome	2026-06-02 15:51:32.170912+00
53	/blog	f	Desktop	Chrome	2026-06-02 15:51:39.717667+00
54	/	f	Desktop	Chrome	2026-06-02 15:51:53.411896+00
55	/nous-suivre	f	Desktop	Chrome	2026-06-02 15:53:49.057503+00
56	/vieprivee	f	Desktop	Chrome	2026-06-02 15:54:04.304552+00
57	/mentions-legales	f	Desktop	Chrome	2026-06-02 15:57:23.517368+00
58	/vieprivee	f	Desktop	Chrome	2026-06-02 15:57:28.09618+00
59	/mentions-legales	f	Desktop	Chrome	2026-06-02 15:57:35.824101+00
60	/privacy	f	Desktop	Chrome	2026-06-02 15:58:08.007245+00
61	/vieprivee	f	Desktop	Chrome	2026-06-02 15:58:25.885221+00
62	/blog	f	Desktop	Chrome	2026-06-02 15:59:04.110038+00
63	/apropos	f	Desktop	Chrome	2026-06-02 15:59:06.871723+00
64	/rse	f	Desktop	Chrome	2026-06-02 15:59:15.776229+00
65	/simulateur-division	f	Desktop	Chrome	2026-06-02 15:59:54.353151+00
66	/simulateur-ensoleillement	f	Desktop	Chrome	2026-06-02 16:03:07.258334+00
67	/eco-diagnostic	f	Desktop	Chrome	2026-06-02 16:05:55.6359+00
68	/carte-cadastre	f	Desktop	Chrome	2026-06-02 16:17:47.374351+00
69	/profil-long	f	Desktop	Chrome	2026-06-02 16:19:12.082011+00
70	/mon-projet	f	Desktop	Chrome	2026-06-02 16:21:38.769097+00
71	/contact	f	Desktop	Chrome	2026-06-02 16:23:57.617275+00
72	/eco-diagnostic	f	Desktop	Chrome	2026-06-02 18:14:47.178052+00
73	/	f	Mobile	Safari	2026-06-02 23:03:30.77082+00
74	/eco-diagnostic	f	Desktop	Chrome	2026-06-03 01:01:59.413326+00
75	/	f	Desktop	Chrome	2026-06-03 01:03:11.80095+00
76	/	f	Mobile	Safari	2026-06-03 01:32:53.684335+00
77	/eco-diagnostic	f	Mobile	Safari	2026-06-03 01:32:59.723257+00
78	/eco-diagnostic	f	Mobile	Safari	2026-06-03 01:43:01.136883+00
79	/	f	Mobile	Safari	2026-06-03 03:55:06.342136+00
80	/br	f	Mobile	Safari	2026-06-03 03:55:08.916869+00
81	/	f	Mobile	Safari	2026-06-03 03:55:10.766982+00
82	/br	f	Mobile	Safari	2026-06-03 03:55:13.744378+00
83	/	f	Mobile	Safari	2026-06-03 03:55:21.714679+00
84	/br	f	Mobile	Safari	2026-06-03 03:55:23.450752+00
85	/	f	Mobile	Safari	2026-06-03 03:55:25.81366+00
86	/br	f	Mobile	Safari	2026-06-03 03:55:27.215826+00
87	/	f	Mobile	Safari	2026-06-03 03:55:29.116062+00
88	/	f	Mobile	Safari	2026-06-03 04:20:35.012896+00
89	/	f	Desktop	Chrome	2026-06-03 13:05:05.849406+00
90	/en	f	Desktop	Chrome	2026-06-03 13:05:11.685512+00
91	/br	f	Desktop	Chrome	2026-06-03 13:05:16.792337+00
92	/	f	Desktop	Chrome	2026-06-03 13:05:19.955755+00
93	/	f	Mobile	Safari	2026-06-03 13:05:37.949063+00
94	/	f	Mobile	Safari	2026-06-03 13:05:38.024205+00
95	/br	f	Mobile	Safari	2026-06-03 13:05:50.628112+00
96	/	f	Mobile	Safari	2026-06-03 13:05:52.922527+00
97	/br	f	Mobile	Safari	2026-06-03 13:05:55.643555+00
98	/	f	Mobile	Safari	2026-06-03 13:05:58.873538+00
99	/br	f	Mobile	Safari	2026-06-03 13:06:03.658864+00
100	/	f	Mobile	Safari	2026-06-03 13:06:18.438169+00
101	/	f	Mobile	Safari	2026-06-03 13:06:27.343859+00
102	/br	f	Mobile	Safari	2026-06-03 13:06:28.638408+00
103	/	f	Mobile	Safari	2026-06-03 13:06:30.052914+00
104	/br	f	Mobile	Safari	2026-06-03 13:06:30.472683+00
105	/	f	Mobile	Safari	2026-06-03 13:06:31.089271+00
106	/br	f	Mobile	Safari	2026-06-03 13:06:31.241226+00
107	/	f	Mobile	Safari	2026-06-03 13:06:32.091798+00
108	/	f	Mobile	Safari	2026-06-03 13:06:34.180766+00
109	/	f	Mobile	Safari	2026-06-03 13:06:53.252187+00
110	/br	f	Mobile	Safari	2026-06-03 13:07:06.879031+00
111	/en	f	Mobile	Safari	2026-06-03 13:08:02.657516+00
112	/en	f	Mobile	Safari	2026-06-03 13:09:30.403216+00
113	/br	f	Mobile	Safari	2026-06-03 13:09:31.5054+00
114	/	f	Mobile	Safari	2026-06-03 13:09:33.786881+00
115	/en	f	Mobile	Safari	2026-06-03 13:09:35.552503+00
116	/br	f	Mobile	Safari	2026-06-03 13:14:17.721027+00
117	/	f	Mobile	Safari	2026-06-03 13:14:21.010332+00
118	/	f	Mobile	Safari	2026-06-03 13:14:24.631084+00
119	/br	f	Mobile	Safari	2026-06-03 13:14:27.14213+00
120	/	f	Mobile	Safari	2026-06-03 13:14:29.106655+00
121	/	f	Mobile	Safari	2026-06-03 13:14:31.264372+00
122	/	f	Mobile	Safari	2026-06-03 13:16:50.902286+00
123	/	f	Mobile	Safari	2026-06-03 13:16:55.260256+00
124	/en	f	Mobile	Safari	2026-06-03 13:16:58.493287+00
125	/br	f	Mobile	Safari	2026-06-03 13:17:00.173333+00
126	/	f	Desktop	Chrome	2026-06-03 13:17:44.636259+00
127	/	f	Desktop	Chrome	2026-06-03 13:17:44.963786+00
128	/	f	Desktop	Chrome	2026-06-03 13:38:59.475631+00
129	/mentions-legales	f	Desktop	Chrome	2026-06-03 13:44:26.229608+00
130	/contact	f	Desktop	Chrome	2026-06-03 13:44:48.041216+00
131	/mentions-legales	f	Desktop	Chrome	2026-06-03 13:47:52.397636+00
132	/	f	Desktop	Chrome	2026-06-03 13:50:21.202644+00
133	/	f	Desktop	Chrome	2026-06-03 14:57:47.673026+00
134	/	f	Desktop	Chrome	2026-06-03 15:18:30.535868+00
135	/	f	Desktop	Chrome	2026-06-03 15:18:55.635903+00
136	/	f	Desktop	Chrome	2026-06-03 15:19:11.874898+00
137	/	f	Desktop	Chrome	2026-06-03 15:19:57.953124+00
138	/	f	Desktop	Chrome	2026-06-03 15:21:49.966906+00
139	/	f	Desktop	Chrome	2026-06-03 15:22:18.618968+00
140	/	f	Desktop	Chrome	2026-06-03 15:22:42.108988+00
141	/lexique	f	Desktop	Chrome	2026-06-03 15:23:16.536002+00
142	/	f	Desktop	Chrome	2026-06-03 15:23:18.873411+00
143	/projets	f	Desktop	Chrome	2026-06-03 15:23:35.231784+00
144	/projets	f	Desktop	Chrome	2026-06-03 15:23:37.771811+00
145	/projets/eco-quartier-de-la-vallee	f	Desktop	Chrome	2026-06-03 15:23:56.646895+00
146	/projets/eco-quartier-de-la-vallee	f	Desktop	Chrome	2026-06-03 15:24:04.559617+00
147	/simulateur-division	f	Desktop	Chrome	2026-06-03 15:25:05.32215+00
148	/simulateur-division	f	Desktop	Chrome	2026-06-03 15:25:09.472365+00
149	/simulateur-ensoleillement	f	Desktop	Chrome	2026-06-03 15:27:01.345673+00
150	/simulateur-ensoleillement	f	Desktop	Chrome	2026-06-03 15:27:01.665522+00
151	/eco-diagnostic	f	Desktop	Chrome	2026-06-03 15:28:56.994354+00
152	/eco-diagnostic	f	Desktop	Chrome	2026-06-03 15:28:59.258819+00
153	/carte-cadastre	f	Desktop	Chrome	2026-06-03 15:31:30.5088+00
154	/carte-cadastre	f	Desktop	Chrome	2026-06-03 15:31:35.614204+00
155	/profil-long	f	Desktop	Chrome	2026-06-03 15:33:49.160401+00
156	/profil-long	f	Desktop	Chrome	2026-06-03 15:33:52.584695+00
157	/mon-projet	f	Desktop	Chrome	2026-06-03 15:36:18.100088+00
158	/mon-projet	f	Desktop	Chrome	2026-06-03 15:36:35.805403+00
159	/apropos	f	Desktop	Chrome	2026-06-03 15:37:01.265636+00
160	/simulateur-division	f	Desktop	Chrome	2026-06-03 15:37:03.851008+00
161	/	f	Mobile	Safari	2026-06-03 15:39:31.500739+00
162	/br/simulateur-division	f	Desktop	Chrome	2026-06-03 15:39:41.165879+00
163	/en/simulateur-division	f	Desktop	Chrome	2026-06-03 15:40:06.561387+00
164	/simulateur-division	f	Desktop	Chrome	2026-06-03 15:40:12.716984+00
165	/	f	Desktop	Chrome	2026-06-03 15:43:39.998576+00
166	/	f	Desktop	Chrome	2026-06-03 15:43:40.395358+00
167	/simulateur-division	f	Desktop	Chrome	2026-06-03 15:44:03.186861+00
168	/simulateur-division	f	Desktop	Chrome	2026-06-03 15:47:40.47693+00
169	/simulateur-division	f	Desktop	Chrome	2026-06-03 15:47:48.611255+00
170	/eco-diagnostic	f	Desktop	Chrome	2026-06-03 15:48:18.636622+00
171	/simulateur-ensoleillement	f	Desktop	Chrome	2026-06-03 15:48:25.841719+00
172	/eco-diagnostic	f	Desktop	Chrome	2026-06-03 15:48:33.646679+00
173	/apropos	f	Desktop	Chrome	2026-06-03 15:49:34.068316+00
174	/	f	Desktop	Chrome	2026-06-03 15:49:53.946966+00
175	/simulateur-division	f	Desktop	Chrome	2026-06-03 15:50:12.983648+00
176	/apropos	f	Desktop	Chrome	2026-06-03 15:52:19.9785+00
177	/eco-diagnostic	f	Desktop	Chrome	2026-06-03 16:04:25.030187+00
178	/simulateur-ensoleillement	f	Desktop	Chrome	2026-06-03 17:02:51.742565+00
179	/eco-diagnostic	f	Desktop	Chrome	2026-06-03 17:02:57.978438+00
180	/	f	Mobile	Safari	2026-06-04 13:03:03.252355+00
181	/	f	Mobile	Safari	2026-06-04 13:03:06.239711+00
182	/	f	Desktop	Chrome	2026-06-04 13:38:11.02003+00
183	/	f	Mobile	Safari	2026-06-04 14:29:33.535873+00
184	/simulateur-division	f	Desktop	Chrome	2026-06-04 14:29:59.255864+00
185	/apropos	f	Desktop	Chrome	2026-06-04 14:30:16.89158+00
186	/	f	Desktop	Chrome	2026-06-04 14:35:05.153569+00
187	/projets	f	Desktop	Chrome	2026-06-04 14:35:54.047505+00
188	/projets/eco-quartier-de-la-vallee	f	Desktop	Chrome	2026-06-04 14:36:04.74537+00
189	/moyens-techniques	f	Desktop	Chrome	2026-06-04 14:36:32.296145+00
190	/simulateur-division	f	Desktop	Chrome	2026-06-04 14:38:34.403807+00
191	/apropos	f	Desktop	Chrome	2026-06-04 14:42:18.097136+00
192	/br/simulateur-division	f	Desktop	Chrome	2026-06-04 14:43:23.08381+00
193	/simulateur-division	f	Desktop	Chrome	2026-06-04 14:43:26.751312+00
194	/simulateur-ensoleillement	f	Desktop	Chrome	2026-06-04 14:43:29.277522+00
195	/eco-diagnostic	f	Desktop	Chrome	2026-06-04 14:48:04.603931+00
196	/contact	f	Desktop	Chrome	2026-06-04 14:54:51.491008+00
197	/eco-diagnostic	f	Desktop	Chrome	2026-06-04 15:16:56.364639+00
198	/contact	f	Desktop	Chrome	2026-06-04 15:19:59.687054+00
199	/carte-cadastre	f	Desktop	Chrome	2026-06-04 15:20:48.997225+00
200	/profil-long	f	Desktop	Chrome	2026-06-04 15:22:04.067503+00
201	/mon-projet	f	Desktop	Chrome	2026-06-04 15:23:55.177578+00
202	/nous-suivre	f	Desktop	Chrome	2026-06-04 15:26:12.216049+00
203	/faq	f	Desktop	Chrome	2026-06-04 15:26:54.05067+00
204	/rse	f	Desktop	Chrome	2026-06-04 15:27:16.715911+00
205	/lexique	f	Desktop	Chrome	2026-06-04 15:27:30.994441+00
206	/apropos	f	Desktop	Chrome	2026-06-04 15:28:18.68619+00
207	/clients	f	Desktop	Chrome	2026-06-04 15:29:10.46861+00
208	/projets	f	Desktop	Chrome	2026-06-04 15:29:14.292939+00
209	/partenaires	f	Desktop	Chrome	2026-06-04 15:29:46.771749+00
210	/apropos	f	Desktop	Chrome	2026-06-04 15:29:53.064775+00
211	/projets	f	Desktop	Chrome	2026-06-04 15:30:02.294924+00
212	/partenaires	f	Desktop	Chrome	2026-06-04 15:30:20.571112+00
213	/moyens-techniques	f	Desktop	Chrome	2026-06-04 15:30:35.570547+00
214	/apropos	f	Desktop	Chrome	2026-06-04 15:30:57.170136+00
215	/expertise/urbanisme	f	Desktop	Chrome	2026-06-04 15:31:57.214539+00
216	/moyens-techniques	f	Desktop	Chrome	2026-06-04 15:32:26.768783+00
217	/projets	f	Desktop	Chrome	2026-06-04 15:32:36.105155+00
218	/moyens-techniques	f	Desktop	Chrome	2026-06-04 15:32:41.843011+00
219	/faq	f	Desktop	Chrome	2026-06-04 15:33:21.876382+00
220	/expertise/geometre	f	Desktop	Chrome	2026-06-04 15:33:24.442518+00
221	/contact	f	Desktop	Chrome	2026-06-04 15:33:29.966285+00
222	/nous-suivre	f	Desktop	Chrome	2026-06-04 15:35:23.427945+00
223	/blog	f	Desktop	Chrome	2026-06-04 15:36:00.114982+00
224	/nous-suivre	f	Desktop	Chrome	2026-06-04 15:36:15.270676+00
225	/lexique	f	Desktop	Chrome	2026-06-04 15:36:55.387159+00
226	/faq	f	Desktop	Chrome	2026-06-04 15:37:03.555404+00
227	/faq	f	Desktop	Chrome	2026-06-04 15:37:31.082657+00
228	/	f	Desktop	Chrome	2026-06-04 15:42:15.765816+00
229	/	f	Desktop	Chrome	2026-06-04 15:42:38.730096+00
230	/	f	Desktop	Chrome	2026-06-04 15:42:42.887381+00
231	/br	f	Desktop	Chrome	2026-06-04 15:42:50.140062+00
232	/	f	Desktop	Chrome	2026-06-04 15:42:55.126456+00
233	/simulateur-division	f	Desktop	Chrome	2026-06-04 15:43:31.789714+00
234	/	f	Desktop	Chrome	2026-06-04 15:44:36.483548+00
235	/moyens-techniques	f	Desktop	Chrome	2026-06-04 15:45:10.465629+00
236	/contact	f	Desktop	Chrome	2026-06-04 15:46:45.488997+00
237	/expertise/urbanisme	f	Desktop	Chrome	2026-06-04 15:46:54.8083+00
238	/contact	f	Desktop	Chrome	2026-06-04 15:47:01.736764+00
239	/mon-projet	f	Desktop	Chrome	2026-06-04 15:47:21.20214+00
240	/contact	f	Desktop	Chrome	2026-06-04 15:47:46.597927+00
241	/mon-projet	f	Desktop	Chrome	2026-06-04 15:47:54.397785+00
242	/contact	f	Desktop	Chrome	2026-06-04 15:48:17.760972+00
243	/mon-projet	f	Desktop	Chrome	2026-06-04 15:48:46.086915+00
244	/contact	f	Desktop	Chrome	2026-06-04 15:49:12.839709+00
245	/	f	Desktop	Chrome	2026-06-04 15:49:32.09738+00
246	/simulateur-division	f	Desktop	Chrome	2026-06-04 15:50:10.624715+00
247	/projets	f	Desktop	Chrome	2026-06-04 15:53:38.075754+00
248	/apropos	f	Desktop	Chrome	2026-06-04 15:54:00.512497+00
249	/expertise/urbanisme	f	Desktop	Chrome	2026-06-04 15:57:24.301942+00
250	/apropos	f	Desktop	Chrome	2026-06-04 15:57:40.157513+00
251	/apropos	f	Desktop	Chrome	2026-06-04 16:03:33.877111+00
252	/	f	Desktop	Chrome	2026-06-04 16:04:44.86151+00
253	/	f	Desktop	Chrome	2026-06-04 16:12:14.828754+00
254	/	f	Desktop	Chrome	2026-06-05 15:41:47.787864+00
255	/apropos	f	Desktop	Chrome	2026-06-05 15:41:50.366108+00
256	/expertise/urbanisme	f	Desktop	Chrome	2026-06-05 15:42:04.791738+00
257	/expertise/copropriete	f	Desktop	Chrome	2026-06-05 15:42:06.500012+00
258	/	f	Desktop	Chrome	2026-06-05 15:42:25.493275+00
259	/mon-projet	f	Desktop	Chrome	2026-06-05 15:42:31.834471+00
260	/moyens-techniques	f	Desktop	Chrome	2026-06-05 15:42:39.682055+00
261	/partenaires	f	Desktop	Chrome	2026-06-05 15:48:29.523045+00
262	/apropos	f	Desktop	Chrome	2026-06-05 15:49:34.139003+00
263	/rse	f	Desktop	Chrome	2026-06-05 15:50:39.838756+00
264	/apropos	f	Desktop	Chrome	2026-06-05 15:50:43.181982+00
265	/	f	Desktop	Chrome	2026-06-05 18:50:38.492146+00
266	/	f	Desktop	Chrome	2026-06-05 18:50:43.990356+00
267	/mentions-legales	f	Desktop	Chrome	2026-06-05 18:52:32.180663+00
268	/expertise/urbanisme	f	Desktop	Chrome	2026-06-05 18:52:41.743018+00
269	/contact	f	Desktop	Chrome	2026-06-05 18:52:46.805356+00
270	/projets	f	Desktop	Chrome	2026-06-05 18:53:12.324188+00
271	/clients	f	Desktop	Chrome	2026-06-05 18:53:28.227514+00
272	/moyens-techniques	f	Desktop	Chrome	2026-06-05 18:53:35.937844+00
273	/simulateur-division	f	Desktop	Chrome	2026-06-05 18:53:56.00129+00
274	/simulateur-ensoleillement	f	Desktop	Chrome	2026-06-05 18:55:15.303501+00
275	/eco-diagnostic	f	Desktop	Chrome	2026-06-05 18:55:23.677273+00
276	/contact	f	Desktop	Chrome	2026-06-05 18:56:22.342868+00
277	/br/contact	f	Desktop	Chrome	2026-06-05 18:56:30.025598+00
278	/	f	Desktop	Chrome	2026-06-10 14:42:04.024107+00
279	/en	f	Desktop	Chrome	2026-06-10 14:42:15.088874+00
280	/	f	Desktop	Chrome	2026-06-10 14:42:18.519115+00
281	/apropos	f	Desktop	Chrome	2026-06-10 14:42:47.488268+00
282	/clients	f	Desktop	Chrome	2026-06-10 14:44:20.581044+00
283	/projets	f	Desktop	Chrome	2026-06-10 14:44:21.415499+00
284	/apropos	f	Desktop	Chrome	2026-06-10 14:44:24.175116+00
285	/expertise/urbanisme	f	Desktop	Chrome	2026-06-10 14:51:48.977014+00
286	/expertise/geometre	f	Desktop	Chrome	2026-06-10 14:51:51.643084+00
287	/projets	f	Desktop	Chrome	2026-06-10 14:52:06.954799+00
288	/projets/eco-quartier-de-la-vallee	f	Desktop	Chrome	2026-06-10 14:52:12.113735+00
289	/partenaires	f	Desktop	Chrome	2026-06-10 14:52:39.618523+00
290	/moyens-techniques	f	Desktop	Chrome	2026-06-10 14:52:41.542043+00
291	/apropos	f	Desktop	Chrome	2026-06-10 14:52:45.970753+00
292	/eco-diagnostic	f	Desktop	Chrome	2026-06-10 14:53:20.6292+00
293	/	f	Desktop	Chrome	2026-06-10 14:53:23.835323+00
294	/apropos	f	Desktop	Chrome	2026-06-10 14:53:28.061629+00
295	/	f	Desktop	Chrome	2026-06-18 14:15:22.126262+00
296	/expertise/urbanisme	f	Desktop	Chrome	2026-06-18 14:16:38.070402+00
297	/projets	f	Desktop	Chrome	2026-06-18 14:16:51.988211+00
298	/	f	Desktop	Chrome	2026-06-18 14:20:28.319662+00
299	/	f	Desktop	Chrome	2026-06-19 13:28:47.562328+00
300	/	f	Desktop	Chrome	2026-06-19 13:29:17.577301+00
301	/	f	Desktop	Chrome	2026-06-19 14:41:49.905388+00
302	/	f	Desktop	Chrome	2026-06-19 14:41:51.265356+00
303	/	f	Desktop	Chrome	2026-06-19 14:45:58.722275+00
304	/	f	Desktop	Chrome	2026-06-19 14:45:59.162975+00
305	/	f	Desktop	Chrome	2026-06-19 14:49:15.887967+00
306	/	f	Desktop	Chrome	2026-06-19 14:49:16.271855+00
307	/	f	Desktop	Chrome	2026-06-19 14:49:33.918259+00
308	/	f	Desktop	Chrome	2026-06-19 16:02:10.81529+00
309	/	f	Desktop	Chrome	2026-06-19 16:05:58.61806+00
310	/apropos	f	Desktop	Chrome	2026-06-19 16:06:01.910364+00
311	/	f	Desktop	Chrome	2026-06-19 16:06:09.649193+00
312	/moyens-techniques	f	Desktop	Chrome	2026-06-19 16:07:00.930413+00
313	/contact	f	Desktop	Chrome	2026-06-19 16:07:52.298206+00
314	/moyens-techniques	f	Desktop	Chrome	2026-06-19 16:07:55.082663+00
315	/	f	Desktop	Edge	2026-06-22 12:07:24.674416+00
316	/	f	Desktop	Chrome	2026-06-22 12:07:31.838091+00
317	/	f	Desktop	Chrome	2026-06-22 12:08:32.749027+00
318	/	f	Desktop	Chrome	2026-06-22 12:08:53.884402+00
319	/	f	Desktop	Chrome	2026-06-22 12:09:16.141639+00
320	/	f	Desktop	Chrome	2026-06-22 12:11:05.088131+00
321	/	f	Mobile	Safari	2026-06-22 12:14:42.305372+00
322	/	f	Mobile	Safari	2026-06-22 12:15:38.214029+00
323	/	f	Desktop	Chrome	2026-06-22 12:18:08.436172+00
324	/	f	Desktop	Chrome	2026-06-22 12:18:49.130393+00
325	/contact	f	Desktop	Chrome	2026-06-22 12:29:51.368926+00
326	/apropos	f	Desktop	Chrome	2026-06-22 12:29:57.71888+00
327	/	f	Desktop	Chrome	2026-06-22 12:32:27.567947+00
328	/	f	Desktop	Chrome	2026-06-22 12:32:31.901136+00
329	/	f	Desktop	Chrome	2026-06-22 12:33:09.827344+00
330	/	f	Desktop	Chrome	2026-06-22 12:39:14.036378+00
331	/	f	Desktop	Chrome	2026-06-22 12:41:22.698232+00
332	/	f	Desktop	Chrome	2026-06-22 12:48:04.453093+00
333	/	f	Desktop	Chrome	2026-06-22 12:49:29.765237+00
334	/	f	Desktop	Chrome	2026-06-22 12:53:39.772532+00
335	/contact	f	Desktop	Chrome	2026-06-22 12:53:59.753054+00
336	/apropos	f	Desktop	Chrome	2026-06-22 12:58:11.323717+00
337	/apropos	f	Desktop	Chrome	2026-06-22 13:00:27.294516+00
338	/apropos	f	Desktop	Chrome	2026-06-22 13:01:58.972426+00
339	/rse	f	Desktop	Chrome	2026-06-22 13:22:15.700074+00
340	/	f	Desktop	Chrome	2026-06-22 13:36:36.975654+00
341	/apropos	f	Desktop	Chrome	2026-06-22 13:36:57.499744+00
342	/	f	Desktop	Chrome	2026-06-22 13:37:00.561805+00
343	/expertise/urbanisme	f	Desktop	Chrome	2026-06-22 13:41:07.852367+00
344	/simulateur-division	f	Desktop	Chrome	2026-06-22 13:44:00.748351+00
345	/eco-diagnostic	f	Desktop	Chrome	2026-06-22 13:45:01.52896+00
346	/mon-projet	f	Desktop	Chrome	2026-06-22 13:46:22.000171+00
347	/rse	f	Desktop	Chrome	2026-06-22 13:46:42.76496+00
348	/apropos	f	Desktop	Chrome	2026-06-22 13:47:10.634492+00
349	/moyens-techniques	f	Desktop	Chrome	2026-06-22 13:51:48.476015+00
350	/br/moyens-techniques	f	Desktop	Chrome	2026-06-22 13:53:16.648211+00
351	/moyens-techniques	f	Desktop	Chrome	2026-06-22 13:53:19.050229+00
352	/eco-diagnostic	f	Desktop	Chrome	2026-06-22 13:59:00.386696+00
353	/mon-projet	f	Desktop	Chrome	2026-06-22 14:06:20.692149+00
354	/expertise/urbanisme	f	Desktop	Chrome	2026-06-22 14:06:34.901557+00
355	/contact	f	Desktop	Chrome	2026-06-22 14:07:05.084247+00
356	/nous-suivre	f	Desktop	Chrome	2026-06-22 14:10:45.771076+00
357	/partenaires	f	Desktop	Chrome	2026-06-22 14:16:42.689891+00
358	/apropos	f	Desktop	Chrome	2026-06-22 14:42:06.085423+00
359	/expertise/urbanisme	f	Desktop	Chrome	2026-06-22 14:42:25.605323+00
360	/apropos	f	Desktop	Chrome	2026-06-22 14:42:32.256017+00
361	/expertise/urbanisme	f	Desktop	Chrome	2026-06-22 14:42:40.813076+00
362	/projets	f	Desktop	Chrome	2026-06-22 14:42:48.122313+00
363	/partenaires	f	Desktop	Chrome	2026-06-22 14:44:09.103662+00
364	/projets	f	Desktop	Chrome	2026-06-22 14:46:42.911039+00
365	/	f	Desktop	Chrome	2026-06-22 14:49:14.653422+00
366	/apropos	f	Desktop	Chrome	2026-06-22 14:52:46.915548+00
367	/partenaires	f	Desktop	Chrome	2026-06-22 15:25:13.364368+00
368	/partenaires	f	Desktop	Chrome	2026-06-22 15:27:04.772803+00
369	/clients	f	Desktop	Chrome	2026-06-22 15:27:06.997867+00
370	/clients	f	Desktop	Chrome	2026-06-22 15:27:41.30096+00
371	/clients	f	Desktop	Chrome	2026-06-22 15:27:56.36675+00
372	/clients	f	Desktop	Chrome	2026-06-22 15:28:11.79014+00
373	/clients	f	Desktop	Chrome	2026-06-22 15:28:52.0041+00
374	/clients	f	Desktop	Chrome	2026-06-22 15:29:25.648593+00
375	/clients	f	Desktop	Chrome	2026-06-22 15:31:23.400265+00
376	/partenaires	f	Desktop	Chrome	2026-06-22 15:32:26.470234+00
377	/clients	f	Desktop	Chrome	2026-06-22 15:32:30.151535+00
378	/clients	f	Desktop	Chrome	2026-06-22 15:38:53.245934+00
379	/clients	f	Desktop	Chrome	2026-06-22 15:43:58.099669+00
380	/clients	f	Desktop	Chrome	2026-06-22 15:44:21.715608+00
381	/clients	f	Desktop	Chrome	2026-06-22 15:47:22.823172+00
382	/apropos	f	Desktop	Chrome	2026-06-22 15:50:08.163809+00
383	/blog	f	Desktop	Chrome	2026-06-22 15:50:12.778195+00
384	/nous-suivre	f	Desktop	Chrome	2026-06-22 15:50:26.214805+00
385	/apropos	f	Desktop	Chrome	2026-06-22 15:57:35.900047+00
386	/faq	f	Desktop	Chrome	2026-06-22 15:57:48.729043+00
387	/lexique	f	Desktop	Chrome	2026-06-22 15:57:50.246311+00
388	/blog	f	Desktop	Chrome	2026-06-22 15:57:51.255856+00
389	/apropos	f	Desktop	Chrome	2026-06-22 15:57:52.741452+00
390	/rse	f	Desktop	Chrome	2026-06-22 15:57:56.79118+00
391	/apropos	f	Desktop	Chrome	2026-06-22 15:58:05.908343+00
392	/	f	Desktop	Chrome	2026-06-22 15:58:08.939955+00
393	/expertise/vrd	f	Desktop	Chrome	2026-06-22 15:58:21.744059+00
394	/expertise/urbanisme	f	Desktop	Chrome	2026-06-22 15:58:56.895808+00
395	/	f	Desktop	Chrome	2026-06-22 15:59:54.707425+00
396	/	f	Desktop	Chrome	2026-06-22 16:02:00.819611+00
397	/expertise/urbanisme	f	Desktop	Chrome	2026-06-22 16:03:10.096755+00
398	/apropos	f	Desktop	Chrome	2026-06-22 16:04:25.932924+00
399	/apropos	f	Desktop	Chrome	2026-06-22 16:04:28.704044+00
400	/apropos	f	Desktop	Chrome	2026-06-22 16:04:53.775844+00
401	/apropos	f	Desktop	Chrome	2026-06-22 16:05:37.507769+00
402	/moyens-techniques	f	Desktop	Chrome	2026-06-22 16:06:42.14836+00
403	/moyens-techniques	f	Desktop	Chrome	2026-06-22 16:07:44.637302+00
404	/moyens-techniques	f	Desktop	Chrome	2026-06-22 16:08:10.704225+00
405	/moyens-techniques	f	Desktop	Chrome	2026-06-22 16:08:42.761951+00
406	/mon-projet	f	Desktop	Chrome	2026-06-22 16:08:59.439015+00
407	/	f	Desktop	Chrome	2026-06-26 08:05:16.740523+00
408	/	f	Desktop	Chrome	2026-06-26 08:13:16.901316+00
409	/expertise/urbanisme	f	Desktop	Chrome	2026-06-26 08:32:43.654141+00
410	/apropos	f	Desktop	Chrome	2026-06-26 08:32:54.01609+00
411	/	f	Desktop	Chrome	2026-06-26 08:32:57.48805+00
412	/expertise/urbanisme	f	Desktop	Chrome	2026-06-26 08:33:30.579334+00
413	/expertise/geometre	f	Desktop	Chrome	2026-06-26 08:33:33.774659+00
414	/	f	Desktop	Chrome	2026-06-26 08:33:36.072363+00
415	/projets	f	Desktop	Chrome	2026-06-26 08:34:26.512551+00
416	/	f	Desktop	Chrome	2026-06-26 08:34:42.303428+00
417	/clients	f	Desktop	Chrome	2026-06-26 08:34:59.795361+00
418	/apropos	f	Desktop	Chrome	2026-06-26 08:39:24.89627+00
419	/	f	Desktop	Chrome	2026-06-26 08:39:34.68332+00
420	/contact	f	Desktop	Chrome	2026-06-26 08:39:39.89676+00
421	/	f	Desktop	Chrome	2026-06-26 08:39:48.598337+00
422	/contact	f	Desktop	Chrome	2026-06-26 08:39:49.764944+00
423	/simulateur-division	f	Desktop	Chrome	2026-06-26 08:40:05.23374+00
424	/contact	f	Desktop	Chrome	2026-06-26 08:40:08.256832+00
425	/	f	Desktop	Chrome	2026-06-26 08:41:05.735992+00
426	/expertise/geometre	f	Desktop	Chrome	2026-06-26 08:43:13.52166+00
427	/	f	Desktop	Chrome	2026-06-26 08:43:37.235351+00
428	/expertise/vrd	f	Desktop	Chrome	2026-06-26 08:47:01.652826+00
429	/	f	Desktop	Chrome	2026-06-26 08:47:03.578649+00
430	/expertise/geometre	f	Desktop	Chrome	2026-06-26 08:49:55.849581+00
431	/	f	Desktop	Chrome	2026-06-26 08:50:00.129335+00
432	/lexique	f	Desktop	Chrome	2026-06-26 08:51:24.505201+00
433	/	f	Desktop	Chrome	2026-06-26 08:51:28.710135+00
434	/lexique	f	Desktop	Chrome	2026-06-26 08:51:35.922494+00
435	/	f	Desktop	Chrome	2026-06-26 08:51:38.991593+00
436	/lexique	f	Desktop	Chrome	2026-06-26 08:51:52.230241+00
437	/	f	Desktop	Chrome	2026-06-26 08:51:54.183511+00
438	/lexique	f	Desktop	Chrome	2026-06-26 08:52:44.479407+00
439	/	f	Desktop	Chrome	2026-06-26 08:52:46.110918+00
442	/expertise/vrd	f	Desktop	Chrome	2026-06-26 08:53:20.409818+00
440	/lexique	f	Desktop	Chrome	2026-06-26 08:53:08.572978+00
441	/	f	Desktop	Chrome	2026-06-26 08:53:19.653661+00
443	/	f	Desktop	Chrome	2026-06-26 08:53:22.135466+00
444	/expertise/urbanisme	f	Desktop	Chrome	2026-06-26 08:57:31.032578+00
445	/apropos	f	Desktop	Chrome	2026-06-26 08:57:55.207223+00
446	/	f	Desktop	Chrome	2026-06-26 08:57:55.851825+00
447	/expertise/urbanisme	f	Desktop	Chrome	2026-06-26 08:58:34.208833+00
448	/	f	Desktop	Chrome	2026-06-26 08:58:41.917758+00
449	/expertise/urbanisme	f	Desktop	Chrome	2026-06-26 09:00:05.058421+00
450	/	f	Desktop	Chrome	2026-06-26 09:01:00.428106+00
451	/contact	f	Desktop	Chrome	2026-06-26 09:06:49.179369+00
452	/	f	Desktop	Chrome	2026-06-26 09:06:56.538254+00
453	/contact	f	Desktop	Chrome	2026-06-26 09:07:00.248769+00
454	/apropos	f	Desktop	Chrome	2026-06-26 09:07:45.014526+00
455	/	f	Desktop	Chrome	2026-06-26 09:07:50.478609+00
456	/partenaires	f	Desktop	Chrome	2026-06-26 09:09:17.427654+00
457	/	f	Desktop	Chrome	2026-06-26 09:09:22.487003+00
458	/partenaires	f	Desktop	Chrome	2026-06-26 09:09:30.807497+00
459	/	f	Desktop	Chrome	2026-06-26 09:09:32.223194+00
460	/partenaires	f	Desktop	Chrome	2026-06-26 09:09:34.401092+00
461	/	f	Desktop	Chrome	2026-06-26 09:09:36.463122+00
462	/partenaires	f	Desktop	Chrome	2026-06-26 09:11:03.225417+00
463	/	f	Desktop	Chrome	2026-06-26 09:11:08.355068+00
464	/apropos	f	Desktop	Chrome	2026-06-26 09:11:35.269048+00
465	/	f	Desktop	Chrome	2026-06-26 09:11:37.659763+00
466	/apropos	f	Desktop	Chrome	2026-06-26 09:12:20.81103+00
467	/	f	Desktop	Chrome	2026-06-26 09:12:23.425917+00
468	/contact	f	Desktop	Chrome	2026-06-26 09:14:43.476073+00
469	/	f	Desktop	Chrome	2026-06-26 09:14:44.992763+00
470	/apropos	f	Desktop	Chrome	2026-06-26 09:14:51.79237+00
471	/	f	Desktop	Chrome	2026-06-26 09:14:53.414078+00
472	/expertise/urbanisme	f	Desktop	Chrome	2026-06-26 09:14:59.433706+00
473	/	f	Desktop	Chrome	2026-06-26 09:15:02.621877+00
474	/expertise/urbanisme	f	Desktop	Chrome	2026-06-26 09:16:50.385508+00
475	/	f	Desktop	Chrome	2026-06-26 09:16:52.163328+00
476	/projets	f	Desktop	Chrome	2026-06-26 09:20:15.002485+00
477	/nous-suivre	f	Desktop	Chrome	2026-06-26 09:20:55.242437+00
478	/nous-suivre	f	Desktop	Chrome	2026-06-26 09:21:47.228914+00
479	/blog	f	Desktop	Chrome	2026-06-26 09:22:00.098609+00
480	/plan-du-site	f	Desktop	Chrome	2026-06-26 09:24:49.613896+00
481	/	f	Desktop	Chrome	2026-06-26 09:24:51.91036+00
482	/nous-suivre	f	Desktop	Chrome	2026-06-26 09:25:26.011915+00
483	/	f	Desktop	Chrome	2026-06-26 09:25:34.429145+00
484	/nous-suivre	f	Desktop	Chrome	2026-06-26 09:26:21.874451+00
485	/	f	Desktop	Chrome	2026-06-26 09:26:33.283576+00
486	/nous-suivre	f	Desktop	Chrome	2026-06-26 09:27:20.206025+00
487	/	f	Desktop	Chrome	2026-06-26 09:27:39.322282+00
488	/nous-suivre	f	Desktop	Chrome	2026-06-26 09:27:45.173549+00
489	/	f	Desktop	Chrome	2026-06-26 09:27:48.76788+00
490	/expertise/urbanisme	f	Desktop	Chrome	2026-06-26 09:28:33.653174+00
491	/	f	Desktop	Chrome	2026-06-26 09:28:39.514837+00
492	/expertise/urbanisme	f	Desktop	Chrome	2026-06-26 09:28:42.000953+00
493	/apropos	f	Desktop	Chrome	2026-06-26 09:29:08.432174+00
494	/projets	f	Desktop	Chrome	2026-06-26 09:34:02.803597+00
495	/	f	Desktop	Chrome	2026-06-26 09:34:09.243057+00
496	/apropos	f	Desktop	Chrome	2026-06-26 09:37:04.116217+00
497	/rse	f	Desktop	Chrome	2026-06-26 09:37:59.258363+00
498	/apropos	f	Desktop	Chrome	2026-06-26 09:38:06.226778+00
499	/rse	f	Desktop	Chrome	2026-06-26 09:38:09.124173+00
500	/apropos	f	Desktop	Chrome	2026-06-26 09:38:20.811761+00
501	/rse	f	Desktop	Chrome	2026-06-26 09:39:24.094199+00
502	/apropos	f	Desktop	Chrome	2026-06-26 09:39:56.987584+00
503	/contact	f	Desktop	Chrome	2026-06-26 09:41:01.694489+00
504	/faq	f	Desktop	Chrome	2026-06-26 09:41:42.500199+00
505	/	f	Desktop	Chrome	2026-06-26 09:41:53.673407+00
506	/faq	f	Desktop	Chrome	2026-06-26 09:41:55.37581+00
507	/expertise/geometre	f	Desktop	Chrome	2026-06-26 09:42:12.928822+00
508	/	f	Desktop	Chrome	2026-07-02 09:07:13.821033+00
509	/	f	Desktop	Chrome	2026-07-16 15:16:32.85461+00
510	/apropos	f	Desktop	Chrome	2026-07-16 15:17:02.267813+00
511	/moyens-techniques	f	Desktop	Chrome	2026-07-16 15:17:29.268694+00
512	/	f	Desktop	Chrome	2026-07-17 07:32:47.906359+00
513	/lexique	f	Desktop	Chrome	2026-07-17 07:44:20.150232+00
514	/apropos	f	Desktop	Chrome	2026-07-17 07:57:04.895972+00
515	/apropos	f	Desktop	Chrome	2026-07-17 08:43:52.915142+00
516	/	f	Desktop	Chrome	2026-07-17 08:45:37.113722+00
517	/apropos	f	Desktop	Chrome	2026-07-17 08:47:11.109722+00
518	/	f	Desktop	Chrome	2026-07-17 08:48:37.840887+00
519	/apropos	f	Desktop	Chrome	2026-07-17 08:48:43.396741+00
520	/moyens-techniques	f	Desktop	Chrome	2026-07-17 08:49:46.215194+00
521	/apropos	f	Desktop	Chrome	2026-07-17 08:50:41.07399+00
522	/rse	f	Desktop	Chrome	2026-07-17 08:50:55.958749+00
523	/simulateur-division	f	Desktop	Chrome	2026-07-17 08:54:03.039015+00
524	/contact	f	Desktop	Chrome	2026-07-17 08:54:52.517675+00
525	/	f	Desktop	Chrome	2026-07-17 16:47:31.223357+00
526	/	f	Desktop	Chrome	2026-07-20 15:35:09.046498+00
527	/	f	Desktop	Chrome	2026-07-20 17:42:02.868102+00
528	/	f	Desktop	Chrome	2026-07-20 17:42:07.758564+00
529	/	f	Desktop	Chrome	2026-07-20 17:42:09.929156+00
530	/	f	Desktop	Chrome	2026-07-20 17:42:12.128535+00
531	/	f	Desktop	Chrome	2026-07-20 17:42:15.636465+00
532	/	f	Desktop	Chrome	2026-07-20 17:42:42.709788+00
533	/	f	Desktop	Chrome	2026-07-20 17:42:43.618512+00
534	/	f	Desktop	Chrome	2026-07-20 17:42:56.111653+00
535	/	f	Desktop	Chrome	2026-07-20 17:43:22.006391+00
536	/	f	Desktop	Chrome	2026-07-20 17:43:35.774972+00
537	/projets	f	Desktop	Chrome	2026-07-20 17:43:56.447118+00
538	/	f	Desktop	Chrome	2026-07-20 17:43:58.975433+00
539	/clients-et-partenaires	f	Desktop	Chrome	2026-07-20 17:44:03.126601+00
540	/	f	Desktop	Chrome	2026-07-20 17:44:16.300642+00
541	/	f	Desktop	Chrome	2026-07-20 17:50:16.791686+00
542	/	f	Desktop	Chrome	2026-07-20 17:50:17.582761+00
543	/	f	Desktop	Chrome	2026-07-20 17:50:40.837886+00
544	/clients-et-partenaires	f	Desktop	Chrome	2026-07-20 17:50:52.680726+00
545	/	f	Desktop	Chrome	2026-07-20 17:54:43.798392+00
546	/clients-et-partenaires	f	Desktop	Chrome	2026-07-20 17:54:46.665672+00
547	/	f	Desktop	Chrome	2026-07-20 17:54:57.131614+00
548	/	f	Desktop	Chrome	2026-07-20 18:00:26.163979+00
549	/	f	Desktop	Chrome	2026-07-20 18:00:26.721893+00
550	/	f	Desktop	Chrome	2026-07-20 18:00:28.102267+00
551	/	f	Desktop	Chrome	2026-07-20 18:00:28.440532+00
552	/	f	Desktop	Chrome	2026-07-20 18:12:55.384278+00
553	/clients-et-partenaires	f	Desktop	Chrome	2026-07-20 18:13:05.30312+00
554	/	f	Desktop	Chrome	2026-07-20 18:13:16.67826+00
555	/apropos	f	Desktop	Chrome	2026-07-20 18:13:18.545007+00
556	/	f	Desktop	Chrome	2026-07-20 18:23:16.95039+00
557	/	f	Desktop	Chrome	2026-07-20 18:23:17.647773+00
558	/	f	Desktop	Chrome	2026-07-20 18:26:13.588295+00
559	/apropos	f	Desktop	Chrome	2026-07-20 18:26:15.280454+00
560	/apropos	f	Desktop	Chrome	2026-07-20 18:26:19.379811+00
561	/apropos	f	Desktop	Chrome	2026-07-20 18:26:54.162227+00
562	/	f	Desktop	Chrome	2026-07-20 18:26:58.921941+00
563	/clients-et-partenaires	f	Desktop	Chrome	2026-07-20 18:27:01.780606+00
564	/	f	Desktop	Chrome	2026-07-20 18:27:13.515059+00
565	/apropos	f	Desktop	Chrome	2026-07-20 18:36:16.688398+00
566	/	f	Desktop	Chrome	2026-07-20 19:10:52.386989+00
567	/apropos	f	Desktop	Chrome	2026-07-20 19:10:54.177925+00
568	/apropos	f	Desktop	Chrome	2026-07-20 19:10:58.766699+00
569	/apropos	f	Desktop	Chrome	2026-07-20 19:11:05.615155+00
570	/	f	Desktop	Chrome	2026-07-20 19:11:52.759794+00
571	/apropos	f	Desktop	Chrome	2026-07-20 19:11:54.133431+00
572	/	f	Desktop	Chrome	2026-07-20 19:13:27.747665+00
573	/apropos	f	Desktop	Chrome	2026-07-20 19:13:30.537038+00
574	/	f	Mobile	Safari	2026-07-20 19:34:19.365391+00
575	/clients-et-partenaires	f	Mobile	Safari	2026-07-20 19:34:29.578162+00
576	/	f	Mobile	Safari	2026-07-20 19:34:32.27029+00
577	/apropos	f	Mobile	Safari	2026-07-20 19:34:40.812575+00
578	/projets	f	Mobile	Safari	2026-07-20 19:34:52.646399+00
579	/contact	f	Mobile	Safari	2026-07-20 19:34:58.962827+00
580	/	f	Mobile	Safari	2026-07-20 23:48:01.714431+00
581	/clients-et-partenaires	f	Mobile	Safari	2026-07-20 23:48:12.629396+00
582	/	f	Mobile	Safari	2026-07-20 23:48:16.402191+00
583	/apropos	f	Mobile	Safari	2026-07-20 23:48:21.435644+00
584	/	f	Desktop	Chrome	2026-07-21 06:39:01.981649+00
585	/	f	Desktop	Edge	2026-07-21 06:52:02.412237+00
586	/apropos	f	Desktop	Edge	2026-07-21 06:54:41.190094+00
587	/	f	Desktop	Chrome	2026-07-21 06:54:56.901634+00
588	/projets	f	Desktop	Edge	2026-07-21 06:55:03.26105+00
589	/contact	f	Desktop	Edge	2026-07-21 06:55:11.129125+00
590	/	f	Desktop	Edge	2026-07-21 06:55:15.254705+00
591	/apropos	f	Desktop	Edge	2026-07-21 06:55:18.978037+00
592	/	f	Desktop	Edge	2026-07-21 06:55:20.697297+00
593	/projets	f	Desktop	Edge	2026-07-21 06:55:22.479204+00
594	/	f	Desktop	Edge	2026-07-21 06:55:24.174871+00
595	/	f	Desktop	Edge	2026-07-21 06:55:26.564917+00
596	/apropos	f	Desktop	Edge	2026-07-21 06:55:45.59559+00
597	/apropos	f	Desktop	Edge	2026-07-21 06:56:53.438094+00
598	/	f	Desktop	Edge	2026-07-21 06:56:55.018123+00
599	/expertise/copropriete	f	Desktop	Edge	2026-07-21 06:57:03.027247+00
600	/	f	Desktop	Edge	2026-07-21 06:57:06.539596+00
601	/clients-et-partenaires	f	Desktop	Edge	2026-07-21 06:57:26.066337+00
602	/	f	Desktop	Edge	2026-07-21 06:57:32.456469+00
603	/lexique	f	Desktop	Edge	2026-07-21 06:58:40.429463+00
604	/	f	Desktop	Chrome	2026-07-21 08:43:14.721401+00
605	/apropos	f	Desktop	Chrome	2026-07-21 08:43:18.441524+00
606	/	f	Desktop	Chrome	2026-07-21 08:43:19.010925+00
607	/apropos	f	Desktop	Chrome	2026-07-21 08:43:22.795773+00
608	/	f	Desktop	Chrome	2026-07-21 08:43:39.658342+00
609	/projets	f	Desktop	Chrome	2026-07-21 08:43:40.781746+00
610	/	f	Desktop	Chrome	2026-07-21 08:44:41.189624+00
611	/contact	f	Desktop	Chrome	2026-07-21 08:44:43.101392+00
612	/	f	Desktop	Chrome	2026-07-21 17:12:36.142306+00
613	/apropos	f	Desktop	Chrome	2026-07-21 17:12:40.502651+00
614	/	f	Desktop	Chrome	2026-07-21 17:12:41.904978+00
615	/	f	Desktop	Chrome	2026-07-21 17:13:15.270938+00
616	/apropos	f	Desktop	Chrome	2026-07-21 17:13:19.812652+00
617	/	f	Desktop	Chrome	2026-07-21 17:13:23.213203+00
618	/expertise/bornage	f	Desktop	Chrome	2026-07-21 17:13:51.12989+00
619	/projets	f	Desktop	Chrome	2026-07-21 17:13:57.714727+00
620	/	f	Desktop	Chrome	2026-07-21 17:21:39.711715+00
621	/projets	f	Desktop	Chrome	2026-07-21 17:21:41.005733+00
622	/projets/requalification-place-plouezec	f	Desktop	Chrome	2026-07-21 17:21:51.419139+00
623	/projets	f	Desktop	Chrome	2026-07-21 17:22:22.575198+00
624	/	f	Desktop	Chrome	2026-07-21 17:26:42.877076+00
625	/	f	Desktop	Chrome	2026-07-21 17:26:44.395846+00
626	/	f	Desktop	Chrome	2026-07-21 17:26:44.777438+00
627	/	f	Desktop	Chrome	2026-07-21 17:26:44.998213+00
628	/	f	Desktop	Chrome	2026-07-21 17:27:01.044628+00
629	/projets	f	Desktop	Chrome	2026-07-21 17:27:02.772598+00
630	/projets/requalification-place-plouezec	f	Desktop	Chrome	2026-07-21 17:27:05.699119+00
631	/	f	Desktop	Chrome	2026-07-21 17:27:09.148268+00
632	/	f	Desktop	Chrome	2026-07-21 17:33:48.63556+00
633	/projets	f	Desktop	Chrome	2026-07-21 17:33:51.109811+00
634	/projets/requalification-dune-place-creation-dune-aire-de-jeux-dune-aire-de-camping-car-et-maillage-pieton	f	Desktop	Chrome	2026-07-21 17:33:55.912106+00
635	/projets/requalification-dune-place-creation-dune-aire-de-jeux-dune-aire-de-camping-car-et-maillage-pieton	f	Desktop	Chrome	2026-07-21 17:34:15.828198+00
636	/	f	Desktop	Chrome	2026-07-21 18:06:43.712498+00
637	/	f	Desktop	Chrome	2026-07-21 18:13:09.026346+00
638	/	f	Desktop	Chrome	2026-07-21 18:13:09.114784+00
639	/	f	Desktop	Chrome	2026-07-21 18:15:24.180977+00
640	/projets	f	Desktop	Chrome	2026-07-21 18:15:25.899882+00
641	/projets/requalification-dune-place-creation-dune-aire-de-jeux-dune-aire-de-camping-car-et-maillage-pieton	f	Desktop	Chrome	2026-07-21 18:15:29.927452+00
642	/	f	Desktop	Chrome	2026-07-21 18:21:10.717805+00
643	/	f	Desktop	Chrome	2026-07-21 18:21:10.926151+00
644	/projets/requalification-dune-place-creation-dune-aire-de-jeux-dune-aire-de-camping-car-et-maillage-pieton	f	Desktop	Chrome	2026-07-21 18:21:19.194467+00
645	/	f	Desktop	Chrome	2026-07-21 18:43:14.86144+00
646	/	f	Desktop	Chrome	2026-07-21 18:43:15.54285+00
647	/	f	Desktop	Chrome	2026-07-21 18:56:22.630671+00
648	/projets	f	Desktop	Chrome	2026-07-21 18:56:25.104409+00
649	/projets/requalification-dune-place-creation-dune-aire-de-jeux-dune-aire-de-camping-car-et-maillage-pieton	f	Desktop	Chrome	2026-07-21 18:56:29.292167+00
650	/	f	Desktop	Chrome	2026-07-21 18:56:35.641917+00
651	/	f	Desktop	Chrome	2026-07-21 19:00:37.146054+00
652	/projets	f	Desktop	Chrome	2026-07-21 19:00:40.134175+00
653	/projets/requalification-dune-place-creation-dune-aire-de-jeux-dune-aire-de-camping-car-et-maillage-pieton	f	Desktop	Chrome	2026-07-21 19:00:45.607337+00
654	/projets	f	Desktop	Chrome	2026-07-21 19:00:54.896626+00
655	/	f	Desktop	Chrome	2026-07-21 19:01:03.346607+00
656	/	f	Mobile	Safari	2026-07-21 22:40:42.835903+00
657	/projets	f	Mobile	Safari	2026-07-21 22:41:00.380214+00
658	/	f	Desktop	Chrome	2026-07-22 15:36:37.968684+00
659	/	f	Desktop	Chrome	2026-07-22 15:43:29.638087+00
660	/projets	f	Desktop	Chrome	2026-07-22 15:44:05.138945+00
661	/contact	f	Desktop	Chrome	2026-07-22 15:44:09.571593+00
662	/apropos	f	Desktop	Chrome	2026-07-22 15:44:34.789037+00
663	/apropos	f	Desktop	Chrome	2026-07-22 15:45:09.121008+00
664	/	f	Desktop	Chrome	2026-07-22 15:45:16.561044+00
665	/clients-et-partenaires	f	Desktop	Chrome	2026-07-22 15:45:20.587001+00
666	/projets	f	Desktop	Chrome	2026-07-22 15:45:22.468888+00
667	/contact	f	Desktop	Chrome	2026-07-22 15:45:27.247436+00
668	/lexique	f	Desktop	Chrome	2026-07-22 15:45:38.599255+00
669	/apropos	f	Desktop	Chrome	2026-07-22 15:45:40.762771+00
670	/	f	Desktop	Chrome	2026-07-22 15:45:47.394822+00
671	/apropos	f	Desktop	Chrome	2026-07-22 15:46:00.281736+00
672	/	f	Desktop	Chrome	2026-07-22 15:46:06.734568+00
673	/expertise/division	f	Desktop	Chrome	2026-07-22 15:46:15.135366+00
674	/	f	Desktop	Chrome	2026-07-22 15:46:25.019253+00
675	/projets	f	Desktop	Chrome	2026-07-22 15:46:48.86245+00
676	/apropos	f	Desktop	Chrome	2026-07-22 15:47:01.219172+00
677	/	f	Desktop	Chrome	2026-07-22 15:48:59.398856+00
678	/expertise/lotissement	f	Desktop	Chrome	2026-07-22 15:49:07.424159+00
679	/	f	Desktop	Chrome	2026-07-27 15:52:15.16004+00
680	/projets	f	Desktop	Chrome	2026-07-27 16:39:01.905418+00
681	/	f	Desktop	Chrome	2026-07-27 16:39:16.327227+00
682	/expertise/bornage	f	Desktop	Chrome	2026-07-27 16:39:23.275912+00
683	/apropos	f	Desktop	Chrome	2026-07-27 16:39:29.147171+00
684	/	f	Desktop	Chrome	2026-07-28 06:56:18.323586+00
685	/apropos	f	Desktop	Chrome	2026-07-28 06:56:42.910362+00
686	/	f	Desktop	Chrome	2026-07-28 06:59:57.060017+00
687	/	f	Desktop	Chrome	2026-07-28 07:02:58.565546+00
688	/contact	f	Desktop	Chrome	2026-07-28 07:03:01.143211+00
689	/apropos	f	Desktop	Chrome	2026-07-28 07:03:15.912495+00
690	/apropos	f	Desktop	Chrome	2026-07-28 07:09:23.519276+00
691	/apropos	f	Desktop	Chrome	2026-07-28 07:16:10.045541+00
692	/apropos	f	Desktop	Chrome	2026-07-28 07:20:23.904967+00
693	/	f	Desktop	Chrome	2026-07-28 07:20:45.434168+00
694	/expertise/bornage	f	Desktop	Chrome	2026-07-28 07:20:51.380219+00
695	/	f	Desktop	Chrome	2026-07-28 07:20:55.350154+00
696	/projets	f	Desktop	Chrome	2026-07-28 07:21:06.678995+00
697	/	f	Desktop	Chrome	2026-07-28 07:24:08.892981+00
698	/apropos	f	Desktop	Chrome	2026-07-28 07:24:27.741324+00
699	/projets	f	Desktop	Chrome	2026-07-28 07:26:16.43933+00
700	/projets	f	Desktop	Chrome	2026-07-28 07:27:30.490006+00
701	/lexique	f	Desktop	Chrome	2026-07-28 07:27:37.129118+00
702	/apropos	f	Desktop	Chrome	2026-07-28 07:27:56.739721+00
703	/	f	Desktop	Chrome	2026-07-28 07:27:57.638993+00
704	/expertise/bornage	f	Desktop	Chrome	2026-07-28 07:28:06.6154+00
705	/	f	Desktop	Chrome	2026-07-28 07:28:12.187061+00
706	/projets	f	Desktop	Chrome	2026-07-28 07:29:50.909611+00
707	/contact	f	Desktop	Chrome	2026-07-28 07:29:51.001175+00
708	/	f	Desktop	Chrome	2026-07-28 07:30:50.142494+00
709	/projets	f	Desktop	Chrome	2026-07-28 07:33:21.382104+00
710	/	f	Desktop	Chrome	2026-07-28 07:37:33.574917+00
711	/expertise/bornage	f	Desktop	Chrome	2026-07-28 07:43:33.254563+00
712	/expertise/bornage	f	Desktop	Chrome	2026-07-28 07:45:24.523193+00
713	/contact	f	Desktop	Chrome	2026-07-28 07:49:31.185968+00
714	/apropos	f	Desktop	Chrome	2026-07-28 07:53:38.948262+00
715	/	f	Desktop	Chrome	2026-07-28 07:53:49.015265+00
716	/projets	f	Desktop	Chrome	2026-07-28 07:53:50.218416+00
717	/apropos	f	Desktop	Chrome	2026-07-28 07:55:28.942686+00
718	/	f	Desktop	Chrome	2026-07-28 07:58:27.203888+00
719	/projets	f	Desktop	Chrome	2026-07-28 07:58:44.305588+00
720	/contact	f	Desktop	Chrome	2026-07-28 08:29:59.09102+00
721	/	f	Desktop	Chrome	2026-07-28 08:30:24.81699+00
722	/	f	Desktop	Chrome	2026-07-28 08:30:25.715079+00
723	/apropos	f	Desktop	Chrome	2026-07-28 08:30:30.310604+00
724	/projets	f	Desktop	Chrome	2026-07-28 08:30:39.107025+00
725	/plan-du-site	f	Desktop	Chrome	2026-07-28 08:30:45.11075+00
726	/apropos	f	Desktop	Chrome	2026-07-28 08:30:58.573342+00
727	/	f	Desktop	Chrome	2026-07-28 08:30:59.499244+00
728	/	f	Desktop	Chrome	2026-07-28 08:33:44.494004+00
729	/	f	Desktop	Chrome	2026-07-28 08:38:48.655345+00
730	/	f	Desktop	Chrome	2026-07-28 08:39:26.619509+00
731	/	f	Desktop	Chrome	2026-07-28 08:39:47.246283+00
732	/	f	Desktop	Chrome	2026-07-28 08:40:43.674709+00
733	/projets	f	Desktop	Chrome	2026-07-28 08:41:05.966917+00
734	/	f	Desktop	Chrome	2026-07-28 08:41:43.534354+00
735	/projets	f	Desktop	Chrome	2026-07-28 08:43:04.547874+00
736	/lexique	f	Desktop	Chrome	2026-07-28 08:43:31.912127+00
737	/clients-et-partenaires	f	Desktop	Chrome	2026-07-28 08:44:20.75333+00
738	/projets	f	Desktop	Chrome	2026-07-28 08:48:55.460872+00
739	/apropos	f	Desktop	Chrome	2026-07-28 08:48:56.729045+00
740	/apropos	f	Desktop	Chrome	2026-07-28 08:50:20.49176+00
741	/	f	Desktop	Chrome	2026-07-28 08:55:36.10605+00
742	/apropos	f	Desktop	Chrome	2026-07-28 08:55:45.483788+00
743	/contact	f	Desktop	Chrome	2026-07-28 08:57:27.182257+00
744	/contact	f	Desktop	Chrome	2026-07-28 08:57:30.209502+00
745	/	f	Desktop	Chrome	2026-07-28 08:58:57.920034+00
746	/apropos	f	Desktop	Chrome	2026-07-28 08:59:07.380715+00
747	/	f	Desktop	Chrome	2026-07-28 08:59:12.395745+00
748	/apropos	f	Desktop	Chrome	2026-07-28 09:00:04.765288+00
749	/	f	Desktop	Chrome	2026-07-28 09:02:36.285374+00
750	/lexique	f	Desktop	Chrome	2026-07-28 09:03:19.611136+00
751	/	f	Desktop	Chrome	2026-07-28 09:03:51.941011+00
752	/contact	f	Desktop	Chrome	2026-07-28 09:04:07.369189+00
753	/	f	Desktop	Chrome	2026-07-28 18:34:02.196383+00
754	/	f	Desktop	Chrome	2026-07-28 21:06:50.893576+00
755	/expertise/bornage	f	Desktop	Chrome	2026-07-28 21:07:08.928216+00
756	/expertise	f	Desktop	Chrome	2026-07-28 21:07:12.654448+00
757	/	f	Desktop	Chrome	2026-07-28 21:07:26.716074+00
758	/	f	Desktop	Chrome	2026-07-29 06:47:54.894974+00
759	/clients-et-partenaires	f	Desktop	Chrome	2026-07-29 06:48:20.176931+00
760	/apropos	f	Desktop	Chrome	2026-07-29 06:49:35.088379+00
761	/expertise	f	Desktop	Chrome	2026-07-29 06:49:36.762779+00
762	/projets	f	Desktop	Chrome	2026-07-29 06:49:55.436339+00
763	/contact	f	Desktop	Chrome	2026-07-29 06:49:57.501226+00
764	/apropos	f	Desktop	Chrome	2026-07-29 06:50:35.945739+00
765	/	f	Desktop	Chrome	2026-07-29 07:02:11.517828+00
766	/expertise	f	Desktop	Chrome	2026-07-29 07:02:28.562771+00
767	/projets	f	Desktop	Chrome	2026-07-29 07:03:26.34168+00
768	/expertise	f	Desktop	Chrome	2026-07-29 07:03:31.048965+00
769	/apropos	f	Desktop	Chrome	2026-07-29 07:03:32.190231+00
770	/	f	Desktop	Chrome	2026-07-29 07:03:33.312998+00
771	/expertise	f	Desktop	Chrome	2026-07-29 07:03:45.022918+00
772	/	f	Desktop	Chrome	2026-07-29 07:04:15.760016+00
773	/	f	Desktop	Chrome	2026-07-29 07:09:27.014757+00
774	/	f	Desktop	Chrome	2026-07-29 07:09:29.859888+00
775	/	f	Desktop	Chrome	2026-07-29 07:09:38.786712+00
776	/expertise	f	Desktop	Chrome	2026-07-29 07:09:44.516121+00
777	/	f	Desktop	Chrome	2026-07-29 07:09:50.95767+00
778	/	f	Desktop	Chrome	2026-07-29 07:10:30.424693+00
779	/expertise/division	f	Desktop	Chrome	2026-07-29 07:10:33.825899+00
780	/expertise/division	f	Desktop	Chrome	2026-07-29 07:13:18.266408+00
781	/expertise	f	Desktop	Chrome	2026-07-29 07:13:20.023136+00
782	/expertise/bornage	f	Desktop	Chrome	2026-07-29 07:13:35.535194+00
783	/expertise	f	Desktop	Chrome	2026-07-29 07:13:38.207281+00
784	/expertise/copropriete	f	Desktop	Chrome	2026-07-29 07:13:54.946126+00
785	/expertise	f	Desktop	Chrome	2026-07-29 07:13:58.361147+00
786	/	f	Desktop	Chrome	2026-07-29 07:14:38.269123+00
787	/expertise	f	Desktop	Chrome	2026-07-29 07:15:31.784359+00
788	/expertise/geometre	f	Desktop	Chrome	2026-07-29 07:15:50.485103+00
789	/apropos	f	Desktop	Chrome	2026-07-29 07:15:59.224401+00
790	/projets	f	Desktop	Chrome	2026-07-29 07:16:11.499279+00
791	/	f	Desktop	Chrome	2026-07-29 07:16:20.930469+00
792	/expertise	f	Desktop	Chrome	2026-07-29 07:22:33.849804+00
793	/	f	Desktop	Chrome	2026-07-29 07:22:41.589069+00
794	/expertise	f	Desktop	Chrome	2026-07-29 07:24:09.351726+00
795	/	f	Desktop	Chrome	2026-07-29 07:25:54.052397+00
796	/	f	Desktop	Chrome	2026-07-29 07:26:29.970928+00
797	/expertise	f	Desktop	Chrome	2026-07-29 07:27:15.721025+00
798	/expertise/geometre	f	Desktop	Chrome	2026-07-29 07:27:47.625629+00
799	/apropos	f	Desktop	Chrome	2026-07-29 07:28:01.801162+00
800	/	f	Desktop	Chrome	2026-07-29 07:28:16.902641+00
801	/expertise/division	f	Desktop	Chrome	2026-07-29 07:28:22.143132+00
802	/expertise	f	Desktop	Chrome	2026-07-29 07:28:28.972436+00
803	/	f	Desktop	Chrome	2026-07-29 07:28:41.460384+00
804	/expertise/bornage	f	Desktop	Chrome	2026-07-29 07:28:52.899397+00
805	/	f	Desktop	Chrome	2026-07-29 07:28:57.085344+00
806	/	f	Desktop	Chrome	2026-07-29 07:29:56.292925+00
807	/clients-et-partenaires	f	Desktop	Chrome	2026-07-29 07:30:07.895421+00
808	/	f	Desktop	Chrome	2026-07-29 07:30:33.982507+00
809	/clients-et-partenaires	f	Desktop	Chrome	2026-07-29 07:30:35.40691+00
810	/	f	Desktop	Chrome	2026-07-29 07:31:36.548492+00
811	/projets	f	Desktop	Chrome	2026-07-29 07:31:48.252033+00
812	/	f	Desktop	Chrome	2026-07-29 07:33:38.598406+00
813	/br	f	Desktop	Chrome	2026-07-29 07:37:57.013535+00
814	/	f	Desktop	Chrome	2026-07-29 07:37:58.931225+00
815	/expertise	f	Desktop	Chrome	2026-07-29 07:39:36.321065+00
816	/apropos	f	Desktop	Chrome	2026-07-29 07:40:21.71397+00
817	/	f	Desktop	Chrome	2026-07-29 07:40:21.814029+00
818	/apropos	f	Desktop	Chrome	2026-07-29 07:40:31.954069+00
819	/projets	f	Desktop	Chrome	2026-07-29 08:19:23.497331+00
820	/	f	Desktop	Chrome	2026-07-29 08:19:24.139532+00
821	/contact	f	Desktop	Chrome	2026-07-29 08:21:33.232678+00
822	/plan-du-site	f	Desktop	Chrome	2026-07-29 08:23:55.728325+00
823	/nous-suivre	f	Desktop	Chrome	2026-07-29 08:23:58.717042+00
824	/plan-du-site	f	Desktop	Chrome	2026-07-29 08:24:02.306725+00
825	/lexique	f	Desktop	Chrome	2026-07-29 08:24:03.789217+00
826	/plan-du-site	f	Desktop	Chrome	2026-07-29 08:24:06.010156+00
827	/expertise	f	Desktop	Chrome	2026-07-29 08:24:08.87222+00
828	/apropos	f	Desktop	Chrome	2026-07-29 08:24:10.410085+00
829	/	f	Desktop	Chrome	2026-07-29 08:24:11.923468+00
830	/apropos	f	Desktop	Chrome	2026-07-29 08:57:39.179235+00
831	/	f	Desktop	Chrome	2026-07-29 08:57:59.313107+00
832	/clients-et-partenaires	f	Desktop	Chrome	2026-07-29 08:58:34.049971+00
833	/apropos	f	Desktop	Chrome	2026-07-29 08:59:35.022789+00
834	/expertise	f	Desktop	Chrome	2026-07-29 09:01:24.209169+00
835	/expertise/bornage	f	Desktop	Chrome	2026-07-29 09:03:26.668871+00
836	/expertise	f	Desktop	Chrome	2026-07-29 09:03:32.926926+00
837	/expertise	f	Desktop	Chrome	2026-07-29 09:03:44.119897+00
838	/	f	Desktop	Chrome	2026-07-29 09:03:46.425249+00
839	/contact	f	Desktop	Chrome	2026-07-29 09:04:56.937561+00
840	/	f	Desktop	Chrome	2026-07-29 09:04:58.284589+00
841	/expertise/bornage	f	Desktop	Chrome	2026-07-29 09:04:59.119589+00
842	/	f	Desktop	Chrome	2026-07-29 09:05:07.389873+00
843	/contact	f	Desktop	Chrome	2026-07-29 09:08:47.647257+00
844	/expertise	f	Desktop	Chrome	2026-07-29 09:09:35.364735+00
845	/lexique	f	Desktop	Chrome	2026-07-29 09:10:26.635991+00
846	/projets	f	Desktop	Chrome	2026-07-29 09:12:04.322835+00
847	/projets/requalification-dune-place-creation-dune-aire-de-jeux-dune-aire-de-camping-car-et-maillage-pieton	f	Desktop	Chrome	2026-07-29 09:12:53.322013+00
848	/projets	f	Desktop	Chrome	2026-07-29 09:13:00.857791+00
849	/	f	Desktop	Chrome	2026-07-29 09:17:06.481682+00
850	/expertise/bornage	f	Desktop	Chrome	2026-07-29 09:18:34.209518+00
851	/	f	Desktop	Chrome	2026-07-29 09:18:36.131867+00
852	/expertise/bornage	f	Desktop	Chrome	2026-07-29 09:19:29.510491+00
853	/	f	Desktop	Chrome	2026-07-29 09:22:03.201158+00
854	/expertise/lotissement	f	Desktop	Chrome	2026-07-29 09:22:08.383604+00
855	/expertise/lotissement	f	Desktop	Chrome	2026-07-29 09:22:14.091934+00
856	/expertise	f	Desktop	Chrome	2026-07-29 09:35:10.492539+00
857	/expertise	f	Desktop	Chrome	2026-07-29 09:35:19.716754+00
858	/expertise/geometre	f	Desktop	Chrome	2026-07-29 09:36:07.594967+00
859	/expertise/geometre	f	Desktop	Chrome	2026-07-29 09:41:38.468805+00
860	/expertise/geometre	f	Desktop	Chrome	2026-07-29 09:41:48.470883+00
861	/expertise/geometre	f	Desktop	Chrome	2026-07-29 09:42:21.669528+00
862	/expertise/geometre	f	Desktop	Chrome	2026-07-29 09:42:31.030787+00
863	/	f	Desktop	Chrome	2026-07-29 09:42:47.694201+00
864	/expertise	f	Desktop	Chrome	2026-07-29 09:42:52.067854+00
865	/expertise	f	Desktop	Chrome	2026-07-29 09:46:40.966914+00
866	/projets	f	Desktop	Chrome	2026-07-29 09:46:54.875923+00
867	/expertise	f	Desktop	Chrome	2026-07-29 09:46:57.255964+00
868	/expertise/geometre	f	Desktop	Chrome	2026-07-29 09:47:30.884762+00
869	/expertise/geometre	f	Desktop	Chrome	2026-07-29 09:47:55.959535+00
870	/expertise/geometre	f	Desktop	Chrome	2026-07-29 09:48:05.460102+00
871	/	f	Desktop	Chrome	2026-07-29 09:48:08.708041+00
872	/expertise/bornage	f	Desktop	Chrome	2026-07-29 09:48:11.500826+00
873	/expertise	f	Desktop	Chrome	2026-07-29 09:48:14.815735+00
874	/expertise/geometre	f	Desktop	Chrome	2026-07-29 09:48:23.694785+00
875	/	f	Desktop	Chrome	2026-07-29 09:48:52.379969+00
876	/expertise	f	Desktop	Chrome	2026-07-29 09:48:53.297897+00
877	/	f	Desktop	Chrome	2026-07-29 09:49:55.8178+00
878	/clients-et-partenaires	f	Desktop	Chrome	2026-07-29 09:58:19.852451+00
879	/clients-et-partenaires	f	Desktop	Chrome	2026-07-29 09:59:22.651698+00
880	/clients-et-partenaires	f	Desktop	Chrome	2026-07-29 10:05:43.501848+00
881	/clients-et-partenaires	f	Desktop	Chrome	2026-07-29 10:07:26.019073+00
882	/clients-et-partenaires	f	Desktop	Chrome	2026-07-29 10:08:02.957134+00
883	/clients-et-partenaires	f	Desktop	Chrome	2026-07-29 10:12:03.545355+00
884	/clients-et-partenaires	f	Desktop	Chrome	2026-07-29 10:13:39.056847+00
885	/clients-et-partenaires	f	Desktop	Chrome	2026-07-29 10:15:07.680202+00
886	/clients-et-partenaires	f	Desktop	Chrome	2026-07-29 10:23:04.384968+00
887	/clients-et-partenaires	f	Desktop	Chrome	2026-07-29 10:25:45.908359+00
888	/	f	Desktop	Chrome	2026-07-29 12:18:57.058799+00
889	/apropos	f	Desktop	Chrome	2026-07-29 12:19:05.193745+00
890	/	f	Desktop	Chrome	2026-07-29 12:19:29.915309+00
891	/expertise	f	Desktop	Chrome	2026-07-29 12:19:33.283801+00
892	/projets	f	Desktop	Chrome	2026-07-29 12:19:44.562319+00
893	/contact	f	Desktop	Chrome	2026-07-29 12:19:45.716224+00
894	/	f	Desktop	Chrome	2026-07-29 12:19:49.384529+00
895	/br	f	Desktop	Chrome	2026-07-29 12:19:52.613629+00
896	/	f	Desktop	Chrome	2026-07-29 12:19:54.492888+00
897	/clients-et-partenaires	f	Desktop	Chrome	2026-07-29 12:21:28.793736+00
898	/clients-et-partenaires	f	Desktop	Chrome	2026-07-29 12:22:38.114947+00
899	/	f	Desktop	Chrome	2026-07-29 12:31:30.448125+00
900	/br	f	Desktop	Chrome	2026-07-29 12:31:43.261036+00
901	/	f	Desktop	Chrome	2026-07-29 12:31:46.264189+00
902	/expertise/bornage	f	Desktop	Chrome	2026-07-29 12:32:33.242182+00
903	/expertise	f	Desktop	Chrome	2026-07-29 12:32:36.751214+00
904	/apropos	f	Desktop	Chrome	2026-07-29 12:34:24.210955+00
905	/expertise	f	Desktop	Chrome	2026-07-29 12:36:34.371493+00
906	/contact	f	Desktop	Chrome	2026-07-29 12:36:42.7267+00
907	/clients-et-partenaires	f	Desktop	Chrome	2026-07-29 12:37:07.268273+00
908	/	f	Desktop	Chrome	2026-07-29 12:37:22.599073+00
909	/apropos	f	Desktop	Chrome	2026-07-29 12:41:39.195297+00
910	/	f	Desktop	Chrome	2026-07-29 12:43:11.66043+00
911	/expertise	f	Desktop	Chrome	2026-07-29 12:43:29.16479+00
912	/apropos	f	Desktop	Chrome	2026-07-29 12:43:42.128451+00
913	/expertise	f	Desktop	Chrome	2026-07-29 12:43:43.197346+00
914	/projets	f	Desktop	Chrome	2026-07-29 12:43:46.241236+00
915	/br/projets	f	Desktop	Chrome	2026-07-29 12:43:54.680586+00
916	/br	f	Desktop	Chrome	2026-07-29 12:43:56.723354+00
917	/	f	Desktop	Chrome	2026-07-29 12:43:58.461296+00
918	/br	f	Desktop	Chrome	2026-07-29 12:44:00.388021+00
919	/	f	Desktop	Chrome	2026-07-29 12:44:02.863015+00
920	/clients-et-partenaires	f	Desktop	Chrome	2026-07-29 12:45:39.391915+00
921	/clients-et-partenaires	f	Desktop	Chrome	2026-07-29 12:53:11.29246+00
922	/clients-et-partenaires	f	Desktop	Chrome	2026-07-29 12:53:32.5255+00
923	/clients-et-partenaires	f	Desktop	Chrome	2026-07-29 12:55:03.360103+00
924	/	f	Desktop	Chrome	2026-07-29 13:31:35.496565+00
925	/apropos	f	Desktop	Chrome	2026-07-29 13:32:09.14421+00
926	/apropos	f	Desktop	Chrome	2026-07-29 13:36:24.402038+00
927	/	f	Desktop	Chrome	2026-07-29 22:52:44.500348+00
928	/expertise	f	Desktop	Chrome	2026-07-29 22:53:05.881194+00
929	/projets	f	Desktop	Chrome	2026-07-29 22:53:11.009223+00
930	/expertise	f	Desktop	Chrome	2026-07-29 22:53:11.616105+00
931	/projets	f	Desktop	Chrome	2026-07-29 22:53:13.415693+00
932	/projets	f	Desktop	Chrome	2026-07-30 01:53:40.392295+00
933	/projets	f	Desktop	Chrome	2026-07-30 01:54:36.312253+00
934	/	f	Desktop	Chrome	2026-07-30 02:36:36.208187+00
935	/	f	Desktop	Chrome	2026-07-30 02:36:36.213011+00
936	/	f	Desktop	Chrome	2026-07-30 02:37:24.962469+00
937	/	f	Desktop	Chrome	2026-07-30 02:37:25.366182+00
938	/projets	f	Desktop	Chrome	2026-07-30 02:37:29.647987+00
939	/	f	Desktop	Chrome	2026-07-30 02:37:33.900772+00
940	/projets/requalification-dune-place-creation-dune-aire-de-jeux-dune-aire-de-camping-car-et-maillage-pieton	f	Desktop	Chrome	2026-07-30 02:37:34.819903+00
941	/projets	f	Desktop	Chrome	2026-07-30 02:37:43.855536+00
942	/	f	Desktop	Chrome	2026-07-30 02:37:46.524749+00
943	/apropos	f	Desktop	Chrome	2026-07-30 02:37:48.995359+00
944	/	f	Desktop	Chrome	2026-07-30 02:38:20.036177+00
945	/br	f	Desktop	Chrome	2026-07-30 02:39:06.003387+00
946	/	f	Desktop	Chrome	2026-07-30 02:39:11.871266+00
947	/clients-et-partenaires	f	Desktop	Chrome	2026-07-30 02:42:01.883367+00
948	/	f	Desktop	Chrome	2026-07-30 02:42:24.413941+00
949	/projets	f	Desktop	Chrome	2026-07-30 02:42:27.772514+00
950	/projets/requalification-dune-place-creation-dune-aire-de-jeux-dune-aire-de-camping-car-et-maillage-pieton	f	Desktop	Chrome	2026-07-30 02:42:41.264901+00
951	/projets	f	Desktop	Chrome	2026-07-30 02:42:53.248236+00
952	/projets/eco-quartier-de-la-vallee	f	Desktop	Chrome	2026-07-30 02:42:54.63299+00
953	/projets	f	Desktop	Chrome	2026-07-30 02:43:11.931512+00
954	/expertise	f	Desktop	Chrome	2026-07-30 02:43:15.453882+00
955	/contact	f	Desktop	Chrome	2026-07-30 02:44:01.199693+00
956	/apropos	f	Desktop	Chrome	2026-07-30 02:46:37.131581+00
957	/expertise	f	Desktop	Chrome	2026-07-30 02:54:58.117403+00
958	/projets	f	Desktop	Chrome	2026-07-30 02:55:01.056423+00
959	/contact	f	Desktop	Chrome	2026-07-30 02:56:26.348131+00
960	/	f	Desktop	Chrome	2026-07-30 02:59:08.990929+00
961	/clients-et-partenaires	f	Desktop	Chrome	2026-07-30 02:59:22.367055+00
962	/clients-et-partenaires	f	Desktop	Chrome	2026-07-30 03:00:17.706169+00
963	/clients-et-partenaires	f	Desktop	Chrome	2026-07-30 03:00:21.408082+00
964	/clients-et-partenaires	f	Desktop	Chrome	2026-07-30 03:00:28.880735+00
965	/clients-et-partenaires	f	Desktop	Chrome	2026-07-30 03:00:35.708996+00
966	/expertise	f	Desktop	Chrome	2026-07-30 03:10:14.409095+00
967	/apropos	f	Desktop	Chrome	2026-07-30 03:10:15.148957+00
968	/apropos	f	Desktop	Chrome	2026-07-30 03:12:05.342884+00
969	/apropos	f	Desktop	Chrome	2026-07-30 03:13:16.376845+00
970	/apropos	f	Desktop	Chrome	2026-07-30 03:13:26.288301+00
971	/apropos	f	Desktop	Chrome	2026-07-30 03:13:30.515922+00
972	/apropos	f	Desktop	Chrome	2026-07-30 03:13:34.131845+00
973	/	f	Desktop	Chrome	2026-07-30 03:26:20.790497+00
974	/clients-et-partenaires	f	Desktop	Chrome	2026-07-30 03:27:17.125494+00
975	/clients-et-partenaires	f	Desktop	Chrome	2026-07-30 03:33:43.29704+00
976	/contact	f	Desktop	Chrome	2026-07-30 03:34:00.192441+00
977	/contact	f	Desktop	Chrome	2026-07-30 03:34:13.953003+00
978	/	f	Desktop	Chrome	2026-07-30 03:34:19.404594+00
979	/expertise	f	Desktop	Chrome	2026-07-30 03:34:28.680185+00
980	/contact	f	Desktop	Chrome	2026-07-30 03:34:49.165239+00
981	/clients-et-partenaires	f	Desktop	Chrome	2026-07-30 03:34:56.198265+00
982	/lexique	f	Desktop	Chrome	2026-07-30 03:34:59.43295+00
983	/plan-du-site	f	Desktop	Chrome	2026-07-30 03:35:04.77672+00
984	/mentions-legales	f	Desktop	Chrome	2026-07-30 03:35:08.085178+00
985	/vieprivee	f	Desktop	Chrome	2026-07-30 03:36:27.568699+00
986	/privacy	f	Desktop	Chrome	2026-07-30 03:36:30.032893+00
987	/vieprivee	f	Desktop	Chrome	2026-07-30 03:36:54.775508+00
988	/mentions-legales	f	Desktop	Chrome	2026-07-30 03:37:05.927888+00
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.schema_migrations (version, inserted_at) FROM stdin;
20211116024918	2026-06-02 02:45:51
20211116045059	2026-06-02 02:45:51
20211116050929	2026-06-02 02:45:51
20211116051442	2026-06-02 02:45:51
20211116212300	2026-06-02 02:45:51
20211116213355	2026-06-02 02:45:51
20211116213934	2026-06-02 02:45:51
20211116214523	2026-06-02 02:45:52
20211122062447	2026-06-02 02:45:52
20211124070109	2026-06-02 02:45:52
20211202204204	2026-06-02 02:45:52
20211202204605	2026-06-02 02:45:52
20211210212804	2026-06-02 02:45:52
20211228014915	2026-06-02 02:45:52
20220107221237	2026-06-02 02:45:52
20220228202821	2026-06-02 02:45:52
20220312004840	2026-06-02 02:45:53
20220603231003	2026-06-02 02:45:53
20220603232444	2026-06-02 02:45:53
20220615214548	2026-06-02 02:45:53
20220712093339	2026-06-02 02:45:53
20220908172859	2026-06-02 02:45:53
20220916233421	2026-06-02 02:45:53
20230119133233	2026-06-02 02:45:53
20230128025114	2026-06-02 02:45:53
20230128025212	2026-06-02 02:45:53
20230227211149	2026-06-02 02:45:53
20230228184745	2026-06-02 02:45:54
20230308225145	2026-06-02 02:45:54
20230328144023	2026-06-02 02:45:54
20231018144023	2026-06-02 02:45:54
20231204144023	2026-06-02 02:45:54
20231204144024	2026-06-02 02:45:54
20231204144025	2026-06-02 02:45:54
20240108234812	2026-06-02 02:45:54
20240109165339	2026-06-02 02:45:54
20240227174441	2026-06-02 02:45:54
20240311171622	2026-06-02 02:45:55
20240321100241	2026-06-02 02:45:55
20240401105812	2026-06-02 02:45:55
20240418121054	2026-06-02 02:45:55
20240523004032	2026-06-02 02:45:55
20240618124746	2026-06-02 02:45:55
20240801235015	2026-06-02 02:45:56
20240805133720	2026-06-02 02:45:56
20240827160934	2026-06-02 02:45:56
20240919163303	2026-06-02 02:45:56
20240919163305	2026-06-02 02:45:56
20241019105805	2026-06-02 02:45:56
20241030150047	2026-06-02 02:45:56
20241108114728	2026-06-02 02:45:56
20241121104152	2026-06-02 02:45:57
20241130184212	2026-06-02 02:45:57
20241220035512	2026-06-02 02:45:57
20241220123912	2026-06-02 02:45:57
20241224161212	2026-06-02 02:45:57
20250107150512	2026-06-02 02:45:57
20250110162412	2026-06-02 02:45:57
20250123174212	2026-06-02 02:45:57
20250128220012	2026-06-02 02:45:57
20250506224012	2026-06-02 02:45:57
20250523164012	2026-06-02 02:45:57
20250714121412	2026-06-02 02:45:57
20250905041441	2026-06-02 02:45:58
20251103001201	2026-06-02 02:45:58
20251120212548	2026-06-02 02:45:58
20251120215549	2026-06-02 02:45:58
20260218120000	2026-06-02 02:45:58
20260326120000	2026-06-02 02:45:58
20260514120000	2026-06-04 03:00:29
20260527120000	2026-06-04 03:00:29
20260528120000	2026-06-04 03:00:29
20260603120000	2026-06-04 03:00:30
20260605120000	2026-06-19 14:02:49
20260606110000	2026-06-19 14:02:49
20260616120000	2026-07-20 17:48:39
20260624120000	2026-07-20 17:48:39
20260626120000	2026-07-20 17:48:39
20260706120000	2026-07-20 17:48:39
20260707120000	2026-07-20 17:48:40
20260709120000	2026-07-20 17:48:40
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY realtime.subscription (id, subscription_id, entity, filters, claims, created_at, action_filter, selected_columns) FROM stdin;
\.


--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.buckets (id, name, owner, created_at, updated_at, public, avif_autodetection, file_size_limit, allowed_mime_types, owner_id, type) FROM stdin;
urbateam-media	urbateam-media	\N	2026-06-02 02:49:33.596208+00	2026-06-02 02:49:33.596208+00	t	f	\N	\N	\N	STANDARD
\.


--
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.buckets_analytics (name, type, format, created_at, updated_at, id, deleted_at) FROM stdin;
\.


--
-- Data for Name: buckets_vectors; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.buckets_vectors (id, type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.migrations (id, name, hash, executed_at) FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2026-06-01 21:36:35.407219
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2026-06-01 21:36:35.443951
2	storage-schema	f6a1fa2c93cbcd16d4e487b362e45fca157a8dbd	2026-06-01 21:36:35.450423
3	pathtoken-column	2cb1b0004b817b29d5b0a971af16bafeede4b70d	2026-06-01 21:36:35.474044
4	add-migrations-rls	427c5b63fe1c5937495d9c635c263ee7a5905058	2026-06-01 21:36:35.486223
5	add-size-functions	79e081a1455b63666c1294a440f8ad4b1e6a7f84	2026-06-01 21:36:35.493777
6	change-column-name-in-get-size	ded78e2f1b5d7e616117897e6443a925965b30d2	2026-06-01 21:36:35.49977
7	add-rls-to-buckets	e7e7f86adbc51049f341dfe8d30256c1abca17aa	2026-06-01 21:36:35.505332
8	add-public-to-buckets	fd670db39ed65f9d08b01db09d6202503ca2bab3	2026-06-01 21:36:35.51085
9	fix-search-function	af597a1b590c70519b464a4ab3be54490712796b	2026-06-01 21:36:35.516103
10	search-files-search-function	b595f05e92f7e91211af1bbfe9c6a13bb3391e16	2026-06-01 21:36:35.521601
11	add-trigger-to-auto-update-updated_at-column	7425bdb14366d1739fa8a18c83100636d74dcaa2	2026-06-01 21:36:35.529193
12	add-automatic-avif-detection-flag	8e92e1266eb29518b6a4c5313ab8f29dd0d08df9	2026-06-01 21:36:35.534564
13	add-bucket-custom-limits	cce962054138135cd9a8c4bcd531598684b25e7d	2026-06-01 21:36:35.539747
14	use-bytes-for-max-size	941c41b346f9802b411f06f30e972ad4744dad27	2026-06-01 21:36:35.54471
15	add-can-insert-object-function	934146bc38ead475f4ef4b555c524ee5d66799e5	2026-06-01 21:36:35.569695
16	add-version	76debf38d3fd07dcfc747ca49096457d95b1221b	2026-06-01 21:36:35.574763
17	drop-owner-foreign-key	f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101	2026-06-01 21:36:35.579622
18	add_owner_id_column_deprecate_owner	e7a511b379110b08e2f214be852c35414749fe66	2026-06-01 21:36:35.584383
19	alter-default-value-objects-id	02e5e22a78626187e00d173dc45f58fa66a4f043	2026-06-01 21:36:35.590656
20	list-objects-with-delimiter	cd694ae708e51ba82bf012bba00caf4f3b6393b7	2026-06-01 21:36:35.595774
21	s3-multipart-uploads	8c804d4a566c40cd1e4cc5b3725a664a9303657f	2026-06-01 21:36:35.602657
22	s3-multipart-uploads-big-ints	9737dc258d2397953c9953d9b86920b8be0cdb73	2026-06-01 21:36:35.618303
23	optimize-search-function	9d7e604cddc4b56a5422dc68c9313f4a1b6f132c	2026-06-01 21:36:35.629682
24	operation-function	8312e37c2bf9e76bbe841aa5fda889206d2bf8aa	2026-06-01 21:36:35.634716
25	custom-metadata	d974c6057c3db1c1f847afa0e291e6165693b990	2026-06-01 21:36:35.640371
26	objects-prefixes	215cabcb7f78121892a5a2037a09fedf9a1ae322	2026-06-01 21:36:35.645451
27	search-v2	859ba38092ac96eb3964d83bf53ccc0b141663a6	2026-06-01 21:36:35.650495
28	object-bucket-name-sorting	c73a2b5b5d4041e39705814fd3a1b95502d38ce4	2026-06-01 21:36:35.655334
29	create-prefixes	ad2c1207f76703d11a9f9007f821620017a66c21	2026-06-01 21:36:35.660115
30	update-object-levels	2be814ff05c8252fdfdc7cfb4b7f5c7e17f0bed6	2026-06-01 21:36:35.664713
31	objects-level-index	b40367c14c3440ec75f19bbce2d71e914ddd3da0	2026-06-01 21:36:35.670039
32	backward-compatible-index-on-objects	e0c37182b0f7aee3efd823298fb3c76f1042c0f7	2026-06-01 21:36:35.674853
33	backward-compatible-index-on-prefixes	b480e99ed951e0900f033ec4eb34b5bdcb4e3d49	2026-06-01 21:36:35.68023
34	optimize-search-function-v1	ca80a3dc7bfef894df17108785ce29a7fc8ee456	2026-06-01 21:36:35.685665
35	add-insert-trigger-prefixes	458fe0ffd07ec53f5e3ce9df51bfdf4861929ccc	2026-06-01 21:36:35.690263
36	optimise-existing-functions	6ae5fca6af5c55abe95369cd4f93985d1814ca8f	2026-06-01 21:36:35.694813
37	add-bucket-name-length-trigger	3944135b4e3e8b22d6d4cbb568fe3b0b51df15c1	2026-06-01 21:36:35.699564
38	iceberg-catalog-flag-on-buckets	02716b81ceec9705aed84aa1501657095b32e5c5	2026-06-01 21:36:35.706664
39	add-search-v2-sort-support	6706c5f2928846abee18461279799ad12b279b78	2026-06-01 21:36:35.720578
40	fix-prefix-race-conditions-optimized	7ad69982ae2d372b21f48fc4829ae9752c518f6b	2026-06-01 21:36:35.725066
41	add-object-level-update-trigger	07fcf1a22165849b7a029deed059ffcde08d1ae0	2026-06-01 21:36:35.73032
42	rollback-prefix-triggers	771479077764adc09e2ea2043eb627503c034cd4	2026-06-01 21:36:35.735145
43	fix-object-level	84b35d6caca9d937478ad8a797491f38b8c2979f	2026-06-01 21:36:35.740398
44	vector-bucket-type	99c20c0ffd52bb1ff1f32fb992f3b351e3ef8fb3	2026-06-01 21:36:35.745213
45	vector-buckets	049e27196d77a7cb76497a85afae669d8b230953	2026-06-01 21:36:35.751074
46	buckets-objects-grants	fedeb96d60fefd8e02ab3ded9fbde05632f84aed	2026-06-01 21:36:35.762377
47	iceberg-table-metadata	649df56855c24d8b36dd4cc1aeb8251aa9ad42c2	2026-06-01 21:36:35.767706
48	iceberg-catalog-ids	e0e8b460c609b9999ccd0df9ad14294613eed939	2026-06-01 21:36:35.772618
49	buckets-objects-grants-postgres	072b1195d0d5a2f888af6b2302a1938dd94b8b3d	2026-06-01 21:36:35.788862
50	search-v2-optimised	6323ac4f850aa14e7387eb32102869578b5bd478	2026-06-01 21:36:35.794226
51	index-backward-compatible-search	2ee395d433f76e38bcd3856debaf6e0e5b674011	2026-06-01 21:36:36.536242
52	drop-not-used-indexes-and-functions	5cc44c8696749ac11dd0dc37f2a3802075f3a171	2026-06-01 21:36:36.538588
53	drop-index-lower-name	d0cb18777d9e2a98ebe0bc5cc7a42e57ebe41854	2026-06-01 21:36:36.55059
54	drop-index-object-level	6289e048b1472da17c31a7eba1ded625a6457e67	2026-06-01 21:36:36.554811
55	prevent-direct-deletes	262a4798d5e0f2e7c8970232e03ce8be695d5819	2026-06-01 21:36:36.556963
56	fix-optimized-search-function	b823ed1e418101032fa01374edc9a436e54e3ed4	2026-06-01 21:36:36.564658
57	s3-multipart-uploads-metadata	f127886e00d1b374fadbc7c6b31e09336aad5287	2026-06-01 21:36:36.571247
58	operation-ergonomics	00ca5d483b3fe0d522133d9002ccc5df98365120	2026-06-01 21:36:36.578566
59	drop-unused-functions	38456f13e39691c2bbb4b5151d0d1cdbabd4a8c4	2026-06-01 21:36:36.587097
60	optimize-existing-functions-again	db35e1c91a9201e59f4fef8d972c2f277d68b157	2026-06-01 21:36:36.592496
\.


--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.objects (id, bucket_id, name, owner, created_at, updated_at, last_accessed_at, metadata, version, owner_id, user_metadata) FROM stdin;
61ea60b9-55e6-487d-aa3a-51b643e4526e	urbateam-media	1777520926226-IMG_0470.jpg	\N	2026-06-02 03:37:44.284138+00	2026-06-02 03:37:44.284138+00	2026-06-02 03:37:44.284138+00	{"eTag": "\\"c3c62b571ab4bd75446b07c1fca18976\\"", "size": 123438, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:45.000Z", "contentLength": 123438, "httpStatusCode": 200}	b93f5e0e-21ce-4ad8-9fd1-a6d57e01c384	\N	{}
a2b7229d-6d53-4d72-8e3c-7c5f7174d03a	urbateam-media	1785309014834-img_20260428_112805.jpg	\N	2026-07-29 07:10:15.534908+00	2026-07-29 07:10:15.534908+00	2026-07-29 07:10:15.534908+00	{"eTag": "\\"54d673ca83aa937ea5b109dc622e4523\\"", "size": 900549, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-07-29T07:10:16.000Z", "contentLength": 900549, "httpStatusCode": 200}	d9033095-733f-44a3-996a-43c5cd14e88d	\N	{}
ae68dc36-32fe-4a0f-bac1-ade8a5033543	urbateam-media	1777520989702-IMG_0470.jpg	\N	2026-06-02 03:37:45.289864+00	2026-06-02 03:37:45.289864+00	2026-06-02 03:37:45.289864+00	{"eTag": "\\"c3c62b571ab4bd75446b07c1fca18976\\"", "size": 123438, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:46.000Z", "contentLength": 123438, "httpStatusCode": 200}	93a6392f-5dfe-4b29-897a-39f11bd50dc1	\N	{}
c5cfb049-262b-42ec-8781-2d27f228e564	urbateam-media	1777521002237-IMG_0474.jpg	\N	2026-06-02 03:37:45.760465+00	2026-06-02 03:37:45.760465+00	2026-06-02 03:37:45.760465+00	{"eTag": "\\"2edfb95c474330ea8cfa9cc9ff82d789\\"", "size": 222541, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:46.000Z", "contentLength": 222541, "httpStatusCode": 200}	278ef626-35d5-4003-92fe-d3b57cf00ba7	\N	{}
a0800be6-1d80-484e-bb75-2232add2247a	urbateam-media	1777521191768-IMG_0471.jpg	\N	2026-06-02 03:37:46.158743+00	2026-06-02 03:37:46.158743+00	2026-06-02 03:37:46.158743+00	{"eTag": "\\"937be74cbd4d6c56abe1b7861bb3d303\\"", "size": 110185, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:47.000Z", "contentLength": 110185, "httpStatusCode": 200}	838bb015-2d9c-4869-b6d0-857f385f28b6	\N	{}
9e079b7f-6729-4a4a-aa48-392cda4eb39e	urbateam-media	1777917028929-Gemini_Generated_Image_ti5w5xti5w5xti5w.png	\N	2026-06-02 03:37:47.412528+00	2026-06-02 03:37:47.412528+00	2026-06-02 03:37:47.412528+00	{"eTag": "\\"6f904b1bb073197340e3319de8e32b13\\"", "size": 2199634, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:48.000Z", "contentLength": 2199634, "httpStatusCode": 200}	a8b99c2d-19d1-4fcc-8d22-4b741f41b4f1	\N	{}
f6fc067b-02e5-42a8-9bc9-2c5842f399f9	urbateam-media	bornage.jpg	\N	2026-06-02 03:37:47.86491+00	2026-06-02 03:37:47.86491+00	2026-06-02 03:37:47.86491+00	{"eTag": "\\"937be74cbd4d6c56abe1b7861bb3d303\\"", "size": 110185, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:48.000Z", "contentLength": 110185, "httpStatusCode": 200}	631d262d-cdc0-46df-8916-f732f4d39c7f	\N	{}
1c955797-79d3-4f5c-a88e-b6d0b39574ac	urbateam-media	division-parcellaire.png	\N	2026-06-02 03:37:48.637612+00	2026-06-02 03:37:48.637612+00	2026-06-02 03:37:48.637612+00	{"eTag": "\\"3c482b6ce8718b18252744ee78cf0bfd\\"", "size": 1040147, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:49.000Z", "contentLength": 1040147, "httpStatusCode": 200}	fb79ef75-e02c-44cb-b33b-5f0184b40eeb	\N	{}
0b9f47ea-a830-474e-9c51-732147be1ebe	urbateam-media	ingenierie-sportive.png	\N	2026-06-02 03:37:49.870058+00	2026-06-02 03:37:49.870058+00	2026-06-02 03:37:49.870058+00	{"eTag": "\\"3c8a624b4f3de482e2cc276dd58b3b55\\"", "size": 1047385, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:50.000Z", "contentLength": 1047385, "httpStatusCode": 200}	d8dd837e-02df-4f40-85aa-47990d34a507	\N	{}
c126fdb4-28db-4564-a78c-ddaec18161b0	urbateam-media	scanner-3d-innovation.png	\N	2026-06-02 03:37:50.642539+00	2026-06-02 03:37:50.642539+00	2026-06-02 03:37:50.642539+00	{"eTag": "\\"564a39983f3741410608a142c76752fa\\"", "size": 894811, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:51.000Z", "contentLength": 894811, "httpStatusCode": 200}	06386e31-1fe0-4979-b448-de642ebf60d7	\N	{}
a59fdd85-c601-4f67-b184-4f37a1639876	urbateam-media	scanner-3d.jpg	\N	2026-06-02 03:37:51.003754+00	2026-06-02 03:37:51.003754+00	2026-06-02 03:37:51.003754+00	{"eTag": "\\"c3c62b571ab4bd75446b07c1fca18976\\"", "size": 123438, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:51.000Z", "contentLength": 123438, "httpStatusCode": 200}	b0536ce0-af67-4737-af3c-9998531be1c7	\N	{}
784c2267-bea0-45a6-8a4e-00ed2726f1ea	urbateam-media	vallee-after.webp	\N	2026-06-02 03:37:51.592991+00	2026-06-02 03:37:51.592991+00	2026-06-02 03:37:51.592991+00	{"eTag": "\\"7a067d4bab802bf85cdbc849a563fa85\\"", "size": 969024, "mimetype": "image/webp", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:52.000Z", "contentLength": 969024, "httpStatusCode": 200}	f07394c3-31d0-4972-824c-054b4d1e7e1b	\N	{}
72bc5b00-4f13-4c33-86b2-fff69ec158c9	urbateam-media	vallee-before.webp	\N	2026-06-02 03:37:52.358699+00	2026-06-02 03:37:52.358699+00	2026-06-02 03:37:52.358699+00	{"eTag": "\\"32c942860858a54da9b49f5d03919bfd\\"", "size": 1040668, "mimetype": "image/webp", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:53.000Z", "contentLength": 1040668, "httpStatusCode": 200}	4818985c-cc55-483e-8837-e14031ac4382	\N	{}
9de18732-0134-45fb-895d-d0730da43867	urbateam-media	bmo.webp	\N	2026-06-02 03:37:52.93894+00	2026-06-02 03:37:52.93894+00	2026-06-02 03:37:52.93894+00	{"eTag": "\\"36b545247916b24caf37fad04aefc88e\\"", "size": 9492, "mimetype": "image/webp", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:53.000Z", "contentLength": 9492, "httpStatusCode": 200}	967f93a3-4e95-4b4f-8d3b-91273d99ef77	\N	{}
e1c92da5-4515-43f6-b028-db190691e4a3	urbateam-media	1785309690993-img_20260414_094629_554.jpg	\N	2026-07-29 07:21:31.431446+00	2026-07-29 07:21:31.431446+00	2026-07-29 07:21:31.431446+00	{"eTag": "\\"961209d22a0a909b5273f51d7aac6fe3\\"", "size": 424969, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-07-29T07:21:32.000Z", "contentLength": 424969, "httpStatusCode": 200}	5e2d772c-d5cf-4712-90df-42d014931b77	\N	{}
1a08d2ea-9406-44cc-8b68-3a04ff3db800	urbateam-media	1777520023211-IMG_0470.jpg	\N	2026-06-02 03:37:53.524814+00	2026-06-02 03:37:53.524814+00	2026-06-02 03:37:53.524814+00	{"eTag": "\\"c3c62b571ab4bd75446b07c1fca18976\\"", "size": 123438, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:54.000Z", "contentLength": 123438, "httpStatusCode": 200}	98019ce7-5fda-4888-b3d5-68b5051168ba	\N	{}
ba691b39-16ee-42e2-8497-be83708b4e74	urbateam-media	1777520072885-IMG_0471.jpg	\N	2026-06-02 03:37:54.133499+00	2026-06-02 03:37:54.133499+00	2026-06-02 03:37:54.133499+00	{"eTag": "\\"937be74cbd4d6c56abe1b7861bb3d303\\"", "size": 110185, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:55.000Z", "contentLength": 110185, "httpStatusCode": 200}	71916148-5275-4a82-9226-a0802db72ba0	\N	{}
cd720b90-c42f-4282-9678-de713de2d4ac	urbateam-media	1785309745893-ge.png	\N	2026-07-29 07:22:26.088267+00	2026-07-29 07:22:26.088267+00	2026-07-29 07:22:26.088267+00	{"eTag": "\\"821fdfedf5751798b5046667a97d87e9\\"", "size": 54397, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-07-29T07:22:27.000Z", "contentLength": 54397, "httpStatusCode": 200}	a27bb1d2-d361-42c6-a578-68fa652d6aa8	\N	{}
7286c43f-d011-4ed4-80f0-12a18cc4e551	urbateam-media	1777520079022-IMG_0472.jpg	\N	2026-06-02 03:37:54.540147+00	2026-06-02 03:37:54.540147+00	2026-06-02 03:37:54.540147+00	{"eTag": "\\"9696718d679e26ad07bcbffd60b1c42a\\"", "size": 379606, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:55.000Z", "contentLength": 379606, "httpStatusCode": 200}	28f30746-ee29-463b-9afe-5335f2e3dc12	\N	{}
087d4bb9-5828-4728-99b4-a30396aaef92	urbateam-media	1777520086084-IMG_0474.jpg	\N	2026-06-02 03:37:55.079787+00	2026-06-02 03:37:55.079787+00	2026-06-02 03:37:55.079787+00	{"eTag": "\\"2edfb95c474330ea8cfa9cc9ff82d789\\"", "size": 222541, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:56.000Z", "contentLength": 222541, "httpStatusCode": 200}	0e18f87d-5860-4050-881d-c7beec5af119	\N	{}
0463b113-66da-4665-9947-02907a9efe31	urbateam-media	1785310189701-img_20260416_111256.jpg	\N	2026-07-29 07:29:50.226176+00	2026-07-29 07:29:50.226176+00	2026-07-29 07:29:50.226176+00	{"eTag": "\\"aa8d0c6907b0410fcc93bbd7dcdaca04\\"", "size": 207267, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-07-29T07:29:51.000Z", "contentLength": 207267, "httpStatusCode": 200}	4a9c1736-33d1-4412-8638-451d1e7bca6c	\N	{}
de3f180b-d874-4d7c-861a-2428dce6f198	urbateam-media	1777520090386-IMG_0475.jpg	\N	2026-06-02 03:37:55.544942+00	2026-06-02 03:37:55.544942+00	2026-06-02 03:37:55.544942+00	{"eTag": "\\"1f6ed59c7f7391e4ac3bb20499ac3bb0\\"", "size": 220543, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:56.000Z", "contentLength": 220543, "httpStatusCode": 200}	49d5d5c3-b8d2-42ab-902c-1c55d7ae063d	\N	{}
fd076d11-167c-4510-b651-1dc595b1088a	urbateam-media	1777520095758-IMG_0476.jpg	\N	2026-06-02 03:37:56.341044+00	2026-06-02 03:37:56.341044+00	2026-06-02 03:37:56.341044+00	{"eTag": "\\"d25a1856d223ebc1828f187fda65c4bb\\"", "size": 420968, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:57.000Z", "contentLength": 420968, "httpStatusCode": 200}	b05532fb-a08b-4a80-8b3c-dc808e5765e3	\N	{}
d05130db-4bc2-4db7-bc8e-4fab25fb67c7	urbateam-media	1777520102568-IMG_0477.jpg	\N	2026-06-02 03:37:56.953677+00	2026-06-02 03:37:56.953677+00	2026-06-02 03:37:56.953677+00	{"eTag": "\\"768ce84f32210d761ee1cee19ebaed61\\"", "size": 519832, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:57.000Z", "contentLength": 519832, "httpStatusCode": 200}	7907fc3a-21d1-4c94-8882-844d640bdebb	\N	{}
61be886b-a790-47c9-9124-159527f14e86	urbateam-media	1777520111868-IMG_0478.jpg	\N	2026-06-02 03:37:57.525352+00	2026-06-02 03:37:57.525352+00	2026-06-02 03:37:57.525352+00	{"eTag": "\\"2e7af75e66c75b7c9bf95f0cceaae3a6\\"", "size": 164502, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-06-02T03:37:58.000Z", "contentLength": 164502, "httpStatusCode": 200}	2d43b600-1902-4cea-9854-91d2c542e651	\N	{}
e227d6b1-542a-4f37-8a75-db5bc853ded9	urbateam-media	1784569835045-masson.jpeg	\N	2026-07-20 17:50:35.212588+00	2026-07-20 17:50:35.212588+00	2026-07-20 17:50:35.212588+00	{"eTag": "\\"39918c3941846805fbd65e84eddee0a1\\"", "size": 16134, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-07-20T17:50:36.000Z", "contentLength": 16134, "httpStatusCode": 200}	9550f9bc-7d73-4832-9fae-9ed3442cc80f	\N	{}
ff854c17-3b05-4697-8518-49f8cf0f02d0	urbateam-media	1784569894593-francoisleon.png	\N	2026-07-20 17:51:34.894296+00	2026-07-20 17:51:34.894296+00	2026-07-20 17:51:34.894296+00	{"eTag": "\\"9c921efc9fd481edc226320b6ca6fedb\\"", "size": 10448, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-07-20T17:51:35.000Z", "contentLength": 10448, "httpStatusCode": 200}	ba8cb076-5518-4c18-b2e4-8540d5987c3c	\N	{}
e5b1f283-4530-4613-8ac8-2f003bcb5ae9	urbateam-media	1784569921397-logo-barraine-immo.jpg	\N	2026-07-20 17:52:01.782925+00	2026-07-20 17:52:01.782925+00	2026-07-20 17:52:01.782925+00	{"eTag": "\\"54c274f8ee86aded3a78d6c56dc970bd\\"", "size": 71046, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-07-20T17:52:02.000Z", "contentLength": 71046, "httpStatusCode": 200}	727cb9b8-2da6-4d1a-8962-4876e2d5c818	\N	{}
e1f92186-2823-4c17-8f35-ecb240f63f58	urbateam-media	1785316912381-1784544422617.jpg	\N	2026-07-29 09:21:53.398005+00	2026-07-29 09:21:53.398005+00	2026-07-29 09:21:53.398005+00	{"eTag": "\\"5e868cbb20d7d65c1590408b9f176c2d\\"", "size": 3216972, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-07-29T09:21:54.000Z", "contentLength": 3216972, "httpStatusCode": 200}	ff8996a5-163e-4b83-a4b5-1c66bc203208	\N	{}
ca3b013b-37c1-4be6-a403-3caaebc529f8	urbateam-media	1784570190111-logo-cap-architecture.png	\N	2026-07-20 17:56:30.2701+00	2026-07-20 17:56:30.2701+00	2026-07-20 17:56:30.2701+00	{"eTag": "\\"d65ce8d762bcc39ac2e51a8b2ff1f5b0\\"", "size": 9047, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-07-20T17:56:31.000Z", "contentLength": 9047, "httpStatusCode": 200}	1cdd44f8-365f-4d2f-ba67-832fb8f5063a	\N	{}
1dec931f-df9a-40ee-a9e7-8d7d9e61a7f8	urbateam-media	1784569944347-logo-trecobat.jpg	\N	2026-07-20 17:52:24.645141+00	2026-07-20 17:52:24.645141+00	2026-07-20 17:52:24.645141+00	{"eTag": "\\"e0bc6c75221032cf6a803c731caecdb6\\"", "size": 19347, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-07-20T17:52:25.000Z", "contentLength": 19347, "httpStatusCode": 200}	82d4b541-3b22-4ca3-bae8-6ff569164a63	\N	{}
854370a3-6953-44ea-ab71-57a8b91ac342	urbateam-media	1784570234236-logo-aiguillon-construction.png	\N	2026-07-20 17:57:14.382661+00	2026-07-20 17:57:14.382661+00	2026-07-20 17:57:14.382661+00	{"eTag": "\\"2fc4d4b853b25bcba3a69eb0d3990b93\\"", "size": 6640, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-07-20T17:57:15.000Z", "contentLength": 6640, "httpStatusCode": 200}	171ce00d-6e32-41aa-ba66-62d1315a068d	\N	{}
bb5656d5-65bb-471c-b877-6245af660a37	urbateam-media	1785317696031-img_20260428_112803.png	\N	2026-07-29 09:34:56.896395+00	2026-07-29 09:34:56.896395+00	2026-07-29 09:34:56.896395+00	{"eTag": "\\"246119b41a0e447ae9277ba656d12b5a\\"", "size": 3147559, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-07-29T09:34:57.000Z", "contentLength": 3147559, "httpStatusCode": 200}	0923dee6-5b26-4d56-b1b7-7509da1e51d0	\N	{}
fa96738a-f247-46c5-b4e6-456a96c6d003	urbateam-media	1784570265077-angevin-personnic.jpeg	\N	2026-07-20 17:57:45.230624+00	2026-07-20 17:57:45.230624+00	2026-07-20 17:57:45.230624+00	{"eTag": "\\"b44f1855c6dc3a1747e3d61995ab0773\\"", "size": 24215, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-07-20T17:57:46.000Z", "contentLength": 24215, "httpStatusCode": 200}	80d68719-2083-4d23-836b-9b0338cc1173	\N	{}
390902ab-9fb7-42e4-9100-44755bd2c395	urbateam-media	1784570302480-maisons-de-l'avenir.jpg	\N	2026-07-20 17:58:22.868139+00	2026-07-20 17:58:22.868139+00	2026-07-20 17:58:22.868139+00	{"eTag": "\\"fab492b00a08309a75f77f610774e74d\\"", "size": 83861, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-07-20T17:58:23.000Z", "contentLength": 83861, "httpStatusCode": 200}	64360ed7-5434-4e48-bd6d-910d1896c112	\N	{}
9e934f55-b2a0-4ca4-ad1d-aebc46b25ff5	urbateam-media	1785318091262-img_20260429_170840.jpg	\N	2026-07-29 09:41:32.037338+00	2026-07-29 09:41:32.037338+00	2026-07-29 09:41:32.037338+00	{"eTag": "\\"8585d6971f60c0fdfa5eff77ae481697\\"", "size": 750532, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-07-29T09:41:32.000Z", "contentLength": 750532, "httpStatusCode": 200}	3e61ed3e-2eb0-4b3f-9ea1-82ed74ff9e52	\N	{}
311eab91-ecc2-4fb7-af15-abcc2c5a3a4d	urbateam-media	1784570344655-123-web-immo-images.png	\N	2026-07-20 17:59:04.941218+00	2026-07-20 17:59:04.941218+00	2026-07-20 17:59:04.941218+00	{"eTag": "\\"ea5c5c534cb6f771bfddd9fc602bb018\\"", "size": 12037, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-07-20T17:59:05.000Z", "contentLength": 12037, "httpStatusCode": 200}	3cc15ddd-ac27-4ddc-af85-cee46e3e9111	\N	{}
71cf9ff3-d204-4e73-a114-4474c507388e	urbateam-media	1784570380658-mairie-de-saint-renan-image.jpeg	\N	2026-07-20 17:59:41.006823+00	2026-07-20 17:59:41.006823+00	2026-07-20 17:59:41.006823+00	{"eTag": "\\"d0d3ef8b1778202c9b24ad7e8ddf0db6\\"", "size": 27817, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-07-20T17:59:41.000Z", "contentLength": 27817, "httpStatusCode": 200}	5cdb336f-e6bd-4016-b2a1-e5045a113bce	\N	{}
f042b57d-967f-41da-9dc2-4de7853d6579	urbateam-media	1785318128745-img_20260429_170838.jpg	\N	2026-07-29 09:42:09.426204+00	2026-07-29 09:42:09.426204+00	2026-07-29 09:42:09.426204+00	{"eTag": "\\"01e168618820fd0c18f6a18a0ce7b75a\\"", "size": 604817, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-07-29T09:42:10.000Z", "contentLength": 604817, "httpStatusCode": 200}	7fa20da3-f54f-4df5-8d71-9f74e2df6871	\N	{}
de1896bc-bf71-420f-9009-8c70b4d28c7b	urbateam-media	1784570499197-human-immobilier.avif	\N	2026-07-20 18:01:40.290729+00	2026-07-20 18:01:40.290729+00	2026-07-20 18:01:40.290729+00	{"eTag": "\\"a9fb5feba2b6b2605e913461cec2194a\\"", "size": 7628, "mimetype": "image/avif", "cacheControl": "max-age=3600", "lastModified": "2026-07-20T18:01:41.000Z", "contentLength": 7628, "httpStatusCode": 200}	1b078d48-a7f3-4c08-9bb8-9ae6ce2ee2ae	\N	{}
961893fc-e079-46eb-b052-fe8a76bbb030	urbateam-media	1784570579823-maisons-georges-menez.jpeg	\N	2026-07-20 18:03:00.152416+00	2026-07-20 18:03:00.152416+00	2026-07-20 18:03:00.152416+00	{"eTag": "\\"2de03e3f124f1d3a60b2651029fab2ca\\"", "size": 16457, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-07-20T18:03:01.000Z", "contentLength": 16457, "httpStatusCode": 200}	290be5d5-2349-4555-9a63-bdf8ed01fee7	\N	{}
ced40e23-c308-4265-a7b3-10b23f7f7417	urbateam-media	1784570609241-logo-perco-constructions.png	\N	2026-07-20 18:03:29.569609+00	2026-07-20 18:03:29.569609+00	2026-07-20 18:03:29.569609+00	{"eTag": "\\"4101140af8840f0e09941bf1bf55267f\\"", "size": 23377, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-07-20T18:03:30.000Z", "contentLength": 23377, "httpStatusCode": 200}	83d0668c-dd00-40cf-ae62-e2906ffffb51	\N	{}
00c780ee-91e2-4b18-88c7-6938590f742e	urbateam-media	1784570741271-primo-construction-logo.png	\N	2026-07-20 18:05:41.729379+00	2026-07-20 18:05:41.729379+00	2026-07-20 18:05:41.729379+00	{"eTag": "\\"5cb2158f799a8c36b1b525e83f84f2fb\\"", "size": 103132, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-07-20T18:05:42.000Z", "contentLength": 103132, "httpStatusCode": 200}	7ad18ea4-0851-45d9-80d8-5bdd2e102788	\N	{}
03e6a4dc-687d-42c6-bc5a-51792aa28f83	urbateam-media	1784570804256-ccpi.jpeg	\N	2026-07-20 18:06:44.386586+00	2026-07-20 18:06:44.386586+00	2026-07-20 18:06:44.386586+00	{"eTag": "\\"1b890100a860b681f8b2ea3b3f38f180\\"", "size": 4963, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-07-20T18:06:45.000Z", "contentLength": 4963, "httpStatusCode": 200}	ba5f6066-8289-40d6-bbbd-eb2317d5ec5f	\N	{}
b8ae0fd9-b629-4f9b-ae43-e0c6aea950b0	urbateam-media	1784570840805-ddtm-image.png	\N	2026-07-20 18:07:21.234331+00	2026-07-20 18:07:21.234331+00	2026-07-20 18:07:21.234331+00	{"eTag": "\\"d3ae06c3ae17be519ab4f48a99231baf\\"", "size": 89955, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-07-20T18:07:22.000Z", "contentLength": 89955, "httpStatusCode": 200}	46435326-e5df-4063-9b4b-823adbb550f0	\N	{}
28c2071d-fa71-4d91-b4b3-270f7e717cdd	urbateam-media	1785319092820-bm.png	\N	2026-07-29 09:58:13.199741+00	2026-07-29 09:58:13.199741+00	2026-07-29 09:58:13.199741+00	{"eTag": "\\"46a9f6cc0c8175061749be47b0e8d44c\\"", "size": 24022, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-07-29T09:58:14.000Z", "contentLength": 24022, "httpStatusCode": 200}	b74f2c95-4ea5-4508-ac8f-d49dcdf1704c	\N	{}
45711a0f-ea2b-4c09-afc8-7171d9e80fc5	urbateam-media	1784570865747-conservatoire-du-littoral.png	\N	2026-07-20 18:07:46.409261+00	2026-07-20 18:07:46.409261+00	2026-07-20 18:07:46.409261+00	{"eTag": "\\"38d71382d1362386a18e4217309637fa\\"", "size": 7067, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-07-20T18:07:47.000Z", "contentLength": 7067, "httpStatusCode": 200}	b5a89476-abf9-44f4-aa41-9af6e01929c9	\N	{}
021e33bc-56d5-4acc-ae40-08969f78ef9d	urbateam-media	1784570978254-etablissement-public-foncier-de-bretagne.png	\N	2026-07-20 18:09:38.548992+00	2026-07-20 18:09:38.548992+00	2026-07-20 18:09:38.548992+00	{"eTag": "\\"478bb6690c2e168b0322486abf53199a\\"", "size": 19693, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-07-20T18:09:39.000Z", "contentLength": 19693, "httpStatusCode": 200}	e5d6037f-30b8-460d-a6c1-0b7eb3060572	\N	{}
082cf459-ef64-4f68-95e8-d6082660619c	urbateam-media	1785319159439-maisons-le-masson.png	\N	2026-07-29 09:59:19.637371+00	2026-07-29 09:59:19.637371+00	2026-07-29 09:59:19.637371+00	{"eTag": "\\"eec675014441ba7c74e67f0523ec3aad\\"", "size": 83991, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-07-29T09:59:20.000Z", "contentLength": 83991, "httpStatusCode": 200}	9f1efcb1-2dbc-4305-ad46-b1cd78973055	\N	{}
7cea2ef9-80fe-4041-8d5a-bf8b8fc9648a	urbateam-media	1785319357640-amenatys.png	\N	2026-07-29 10:02:37.815144+00	2026-07-29 10:02:37.815144+00	2026-07-29 10:02:37.815144+00	{"eTag": "\\"2d69162a3834583c825d17f03c1cfc2f\\"", "size": 17077, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-07-29T10:02:38.000Z", "contentLength": 17077, "httpStatusCode": 200}	a77b954d-8cf0-49eb-bf48-9721dedb8f6f	\N	{}
d89b12a6-deee-4c03-956b-fa69797d5abe	urbateam-media	1785319516143-123webimmo.png	\N	2026-07-29 10:05:16.760856+00	2026-07-29 10:05:16.760856+00	2026-07-29 10:05:16.760856+00	{"eTag": "\\"36b4e324ebbf7516337fcb27f004143f\\"", "size": 24989, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-07-29T10:05:17.000Z", "contentLength": 24989, "httpStatusCode": 200}	d83af494-1237-4e72-887c-44a391320b82	\N	{}
c4027df9-3ff0-4ff4-94e7-197ef64b29cf	urbateam-media	1785319604664-maisons-georges-menez.png	\N	2026-07-29 10:06:45.186686+00	2026-07-29 10:06:45.186686+00	2026-07-29 10:06:45.186686+00	{"eTag": "\\"8621eb1ad9afbd9f684feb7180158665\\"", "size": 94268, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-07-29T10:06:46.000Z", "contentLength": 94268, "httpStatusCode": 200}	d83ced53-6e21-40ca-8ed8-1293aba3a9e9	\N	{}
99d222e2-e073-418c-bf4b-380ba914d8c3	urbateam-media	1785319643419-capture-d-ecran-2026-07-29-120712.png	\N	2026-07-29 10:07:23.549363+00	2026-07-29 10:07:23.549363+00	2026-07-29 10:07:23.549363+00	{"eTag": "\\"e581605189033cef2a91f918db8dfb42\\"", "size": 65467, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-07-29T10:07:24.000Z", "contentLength": 65467, "httpStatusCode": 200}	08d55a62-0358-47ea-90ec-506a1c005b59	\N	{}
0126328a-4408-45c6-a6bb-53ef85866600	urbateam-media	1785319679152-human-immobilier.png	\N	2026-07-29 10:07:59.281873+00	2026-07-29 10:07:59.281873+00	2026-07-29 10:07:59.281873+00	{"eTag": "\\"9d7eae2cde2be04132cd4c70c21a3659\\"", "size": 28473, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-07-29T10:08:00.000Z", "contentLength": 28473, "httpStatusCode": 200}	cb147912-05c8-484d-aebe-2e0af31fec02	\N	{}
fba09d7c-5f48-40bb-850f-6f2adaa5494a	urbateam-media	1785319753340-bouygues-immobilier.png	\N	2026-07-29 10:09:13.890075+00	2026-07-29 10:09:13.890075+00	2026-07-29 10:09:13.890075+00	{"eTag": "\\"b8a53762cbf1917ba4020aacef6c7268\\"", "size": 101898, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-07-29T10:09:14.000Z", "contentLength": 101898, "httpStatusCode": 200}	a9866291-90ba-4fe9-acb7-a52a561a1972	\N	{}
4ccd45a1-74ac-4a79-ab9c-30f7718cff1e	urbateam-media	1785319856744-groupe-soft.png	\N	2026-07-29 10:10:56.870993+00	2026-07-29 10:10:56.870993+00	2026-07-29 10:10:56.870993+00	{"eTag": "\\"ec0c219d286545279df71ce536a2d3bd\\"", "size": 13420, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-07-29T10:10:57.000Z", "contentLength": 13420, "httpStatusCode": 200}	714a28f8-2f6c-41c4-ae53-7c6578e75d56	\N	{}
8dc27d0e-21a4-4fed-804e-a5db8b36db3b	urbateam-media	1784570891935-douarnenez-habitat.jpeg	\N	2026-07-20 18:08:12.211715+00	2026-07-20 18:08:12.211715+00	2026-07-20 18:08:12.211715+00	{"eTag": "\\"52c8374621f3b7ea6931069dd4b89279\\"", "size": 9035, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-07-20T18:08:13.000Z", "contentLength": 9035, "httpStatusCode": 200}	80f2311e-896a-4fc7-a0cf-ee8752df1fd9	\N	{}
4dfbf98f-5382-4ce2-be02-b503480affee	urbateam-media	1785319904984-bmg.png	\N	2026-07-29 10:11:45.139238+00	2026-07-29 10:11:45.139238+00	2026-07-29 10:11:45.139238+00	{"eTag": "\\"46ef5071df268c57242d1cded8400f9b\\"", "size": 44580, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-07-29T10:11:46.000Z", "contentLength": 44580, "httpStatusCode": 200}	d83c7e24-d151-42c3-910b-4f511d47d63b	\N	{}
781daf2a-06f7-46fb-a9d3-60ecbe681abb	urbateam-media	1784571829910-webp-to-jpg-conversion.jpg	\N	2026-07-20 18:23:50.368139+00	2026-07-20 18:23:50.368139+00	2026-07-20 18:23:50.368139+00	{"eTag": "\\"089870f8507e708e3d7b4ca2745b087b\\"", "size": 137718, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-07-20T18:23:51.000Z", "contentLength": 137718, "httpStatusCode": 200}	64bb8c82-5498-47bb-a66f-38d29abeae1c	\N	{}
3ae262cc-8357-4648-b6d5-263172d5c4ca	urbateam-media	1784574634684-webp-to-jpg-conversion.jpg	\N	2026-07-20 19:10:35.325688+00	2026-07-20 19:10:35.325688+00	2026-07-20 19:10:35.325688+00	{"eTag": "\\"feb2b534655c1f6987c93f0a23039c41\\"", "size": 190157, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-07-20T19:10:36.000Z", "contentLength": 190157, "httpStatusCode": 200}	587f55b3-ce79-4a58-bff7-e07f00a5411c	\N	{}
ce934dcd-f6b8-45e6-a275-89617083e18e	urbateam-media	1785319970477-ccpa.png	\N	2026-07-29 10:12:50.625681+00	2026-07-29 10:12:50.625681+00	2026-07-29 10:12:50.625681+00	{"eTag": "\\"b2f7c578571099428c756ae569a8f098\\"", "size": 57819, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-07-29T10:12:51.000Z", "contentLength": 57819, "httpStatusCode": 200}	c286b68b-17a3-4d29-98fa-016483b9822d	\N	{}
468ad84a-0a06-4674-9af7-0fa6d6310d26	urbateam-media	1784574647350-webp-to-jpg-conversion-(1).jpg	\N	2026-07-20 19:10:47.87714+00	2026-07-20 19:10:47.87714+00	2026-07-20 19:10:47.87714+00	{"eTag": "\\"e68d1bc67a3caf169bfa4ad401cc16c0\\"", "size": 341222, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-07-20T19:10:48.000Z", "contentLength": 341222, "httpStatusCode": 200}	1c4807c7-0702-4489-b444-273c006960f6	\N	{}
6cb2a9e8-3585-4362-94f8-0f85326376ea	urbateam-media	1784574697116-webp-to-jpg-conversion.jpg	\N	2026-07-20 19:11:37.711078+00	2026-07-20 19:11:37.711078+00	2026-07-20 19:11:37.711078+00	{"eTag": "\\"32da5ebdef5caae0ba5c872d41bfa73e\\"", "size": 249649, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-07-20T19:11:38.000Z", "contentLength": 249649, "httpStatusCode": 200}	39cb0ce4-7e6d-4657-a7e0-27b19457ee51	\N	{}
1b34bdf7-233e-4dcd-a894-231e1de3dcf1	urbateam-media	1785320016668-departement-finistere.png	\N	2026-07-29 10:13:36.779886+00	2026-07-29 10:13:36.779886+00	2026-07-29 10:13:36.779886+00	{"eTag": "\\"701db2b7df755682da08337855e062d3\\"", "size": 42338, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-07-29T10:13:37.000Z", "contentLength": 42338, "httpStatusCode": 200}	46f32603-6965-4b11-9de4-e3c6f31398a9	\N	{}
49971add-3786-4fe1-9462-4cbc799db504	urbateam-media	1784574703908-webp-to-jpg-conversion-(1).jpg	\N	2026-07-20 19:11:44.482534+00	2026-07-20 19:11:44.482534+00	2026-07-20 19:11:44.482534+00	{"eTag": "\\"e68d1bc67a3caf169bfa4ad401cc16c0\\"", "size": 341222, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-07-20T19:11:45.000Z", "contentLength": 341222, "httpStatusCode": 200}	34c5d837-65e8-4427-8d95-f73763e67820	\N	{}
cb145913-8de3-4ee2-b0cc-85e46adea5b3	urbateam-media	1784574779809-webp-to-jpg-conversion.jpg	\N	2026-07-20 19:13:00.327633+00	2026-07-20 19:13:00.327633+00	2026-07-20 19:13:00.327633+00	{"eTag": "\\"cf2026d66caca9e0092301503b2a56bb\\"", "size": 73961, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-07-20T19:13:01.000Z", "contentLength": 73961, "httpStatusCode": 200}	33442cc7-8fef-4114-a227-96c039f9c80a	\N	{}
4f86aa53-cf6d-4f42-9001-e51452c9df35	urbateam-media	1785320059290-capture-d-ecran-2026-07-29-121405.png	\N	2026-07-29 10:14:19.407715+00	2026-07-29 10:14:19.407715+00	2026-07-29 10:14:19.407715+00	{"eTag": "\\"b503116a09bc7257fe1c07a7f6aeb7b9\\"", "size": 18601, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-07-29T10:14:20.000Z", "contentLength": 18601, "httpStatusCode": 200}	9241a452-d060-4638-86c4-37e2c1ac25bd	\N	{}
b17dcd60-37b5-4955-a89f-5bdd5f7248c8	urbateam-media	1784574799833-webp-to-jpg-conversion-(1).jpg	\N	2026-07-20 19:13:20.198924+00	2026-07-20 19:13:20.198924+00	2026-07-20 19:13:20.198924+00	{"eTag": "\\"290f914fbf339d1b4788bdea9ca2f0ae\\"", "size": 73946, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-07-20T19:13:21.000Z", "contentLength": 73946, "httpStatusCode": 200}	3bd77d94-1d03-41bc-b4eb-d8c3cf01966f	\N	{}
57e3be6c-110d-445b-9580-094280d12454	urbateam-media	1784660174799-presentation-urbateam.pdf	\N	2026-07-21 18:56:15.80969+00	2026-07-21 18:56:15.80969+00	2026-07-21 18:56:15.80969+00	{"eTag": "\\"0bea437752429763ca15e0e1aded88e5\\"", "size": 2427601, "mimetype": "application/pdf", "cacheControl": "max-age=3600", "lastModified": "2026-07-21T18:56:16.000Z", "contentLength": 2427601, "httpStatusCode": 200}	05d45b1b-bef0-43d5-8e99-ea18d8e3ac8b	\N	{}
37c42ab8-75f8-467a-997b-00d237535430	urbateam-media	1784660429646-capture-d-ecran-2026-07-21-a-14.59.49.png	\N	2026-07-21 19:00:31.333744+00	2026-07-21 19:00:31.333744+00	2026-07-21 19:00:31.333744+00	{"eTag": "\\"51ad9bc21dcbfb4d6e311bac5849192f\\"", "size": 1112690, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-07-21T19:00:32.000Z", "contentLength": 1112690, "httpStatusCode": 200}	ae09c46c-a68e-4d45-b93a-8f6583efc680	\N	{}
ca46ac69-ef20-41d3-aa2a-c9bfd3532443	urbateam-media	1784660431905-capture-d-ecran-2026-07-21-a-14.59.57.png	\N	2026-07-21 19:00:32.589107+00	2026-07-21 19:00:32.589107+00	2026-07-21 19:00:32.589107+00	{"eTag": "\\"1552199b207dd5e11b25b47713350af6\\"", "size": 1125221, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-07-21T19:00:33.000Z", "contentLength": 1125221, "httpStatusCode": 200}	3ac2d159-daab-4973-8e30-81faa6dcf696	\N	{}
e79b0603-61ff-48d0-b688-2000ef330ec8	urbateam-media	1785320209070-douarnenez-communuate.png	\N	2026-07-29 10:16:49.328777+00	2026-07-29 10:16:49.328777+00	2026-07-29 10:16:49.328777+00	{"eTag": "\\"9c3c239fda6b382d7b706763581b0bb6\\"", "size": 54881, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-07-29T10:16:50.000Z", "contentLength": 54881, "httpStatusCode": 200}	792a28cd-aa58-4bfd-bb48-f97cebb9194f	\N	{}
c769b653-1d5a-4cf3-9691-e896786508fd	urbateam-media	1785308958365-1776844514439.jpg	\N	2026-07-29 07:09:19.129411+00	2026-07-29 07:09:19.129411+00	2026-07-29 07:09:19.129411+00	{"eTag": "\\"ef7bd53c2ca660dd3ef1a2d2338110c9\\"", "size": 2959382, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-07-29T07:09:20.000Z", "contentLength": 2959382, "httpStatusCode": 200}	2089cc98-aacc-476e-8018-432d6552c6b7	\N	{}
6d7a5115-ca86-4f64-a683-d879074cc964	urbateam-media	1785320253060-bma.png	\N	2026-07-29 10:17:33.202984+00	2026-07-29 10:17:33.202984+00	2026-07-29 10:17:33.202984+00	{"eTag": "\\"ffd84bf338affb070b9be9092b2fd622\\"", "size": 21332, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-07-29T10:17:34.000Z", "contentLength": 21332, "httpStatusCode": 200}	8b416ff6-3dec-4780-b9bd-79e86f9a1098	\N	{}
\.


--
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.s3_multipart_uploads (id, in_progress_size, upload_signature, bucket_id, key, version, owner_id, created_at, user_metadata, metadata) FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.s3_multipart_uploads_parts (id, upload_id, size, part_number, bucket_id, key, etag, owner_id, version, created_at) FROM stdin;
\.


--
-- Data for Name: vector_indexes; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.vector_indexes (id, name, bucket_id, data_type, dimension, distance_metric, metadata_configuration, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: supabase_migrations; Owner: postgres
--

COPY supabase_migrations.schema_migrations (version, statements, name) FROM stdin;
20260531000000	{"-- supabase/migrations/20260531000000_create_urbateam_schema.sql\n-- Urbateam Database Schema for Supabase\n\n-- Enable required extensions\nCREATE EXTENSION IF NOT EXISTS \\"uuid-ossp\\"","-- 1. Table ARTICLES (Blog posts)\nCREATE TABLE IF NOT EXISTS articles (\n    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,\n    status TEXT DEFAULT 'published' CHECK (status IN ('published', 'draft')),\n    sort INTEGER,\n    slug TEXT UNIQUE NOT NULL,\n    title TEXT NOT NULL,\n    excerpt TEXT,\n    content TEXT,\n    featured_image TEXT,\n    author TEXT,\n    tags JSONB DEFAULT '[]'::jsonb,\n    category TEXT,\n    date_published TIMESTAMP WITH TIME ZONE DEFAULT NOW(),\n    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),\n    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()\n)","-- 2. Table PROJETS (Portfolio cases with geospatial coordinates)\nCREATE TABLE IF NOT EXISTS projets (\n    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,\n    status TEXT DEFAULT 'published' CHECK (status IN ('published', 'draft')),\n    sort INTEGER,\n    slug TEXT UNIQUE NOT NULL,\n    title TEXT NOT NULL,\n    description TEXT,\n    location TEXT,\n    category TEXT,\n    client TEXT,\n    missions JSONB DEFAULT '[]'::jsonb,\n    technical_details TEXT,\n    image_before TEXT,\n    image_after TEXT,\n    images_gallery JSONB DEFAULT '[]'::jsonb,\n    latitude DOUBLE PRECISION,\n    longitude DOUBLE PRECISION,\n    date TIMESTAMP WITH TIME ZONE,\n    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),\n    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()\n)","-- 3. Table CLIENTS (Logos and brand references)\nCREATE TABLE IF NOT EXISTS clients (\n    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,\n    status TEXT DEFAULT 'published' CHECK (status IN ('published', 'draft')),\n    sort INTEGER,\n    name TEXT NOT NULL,\n    logo TEXT,\n    tags JSONB DEFAULT '[]'::jsonb,\n    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()\n)","-- 4. Table PARTENAIRES (Professional ecosystem)\nCREATE TABLE IF NOT EXISTS partenaires (\n    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,\n    status TEXT DEFAULT 'published' CHECK (status IN ('published', 'draft')),\n    sort INTEGER,\n    name TEXT NOT NULL,\n    logo TEXT,\n    role TEXT,\n    website TEXT,\n    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()\n)","-- 5. Table FAQ (Multilingual Q&A)\nCREATE TABLE IF NOT EXISTS faq (\n    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,\n    status TEXT DEFAULT 'published' CHECK (status IN ('published', 'draft')),\n    sort INTEGER,\n    question_fr TEXT NOT NULL,\n    answer_fr TEXT,\n    question_en TEXT,\n    answer_en TEXT,\n    question_br TEXT,\n    answer_br TEXT,\n    category TEXT,\n    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()\n)","-- 6. Table GLOSSAIRE (Definitions of land terms)\nCREATE TABLE IF NOT EXISTS glossaire (\n    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,\n    status TEXT DEFAULT 'published' CHECK (status IN ('published', 'draft')),\n    sort INTEGER,\n    term_fr TEXT NOT NULL,\n    definition_fr TEXT,\n    term_en TEXT,\n    definition_en TEXT,\n    term_br TEXT,\n    definition_br TEXT,\n    related_expertise TEXT,\n    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()\n)","-- 7. Table TEAM_HEADER (Header photo and intro)\nCREATE TABLE IF NOT EXISTS team_header (\n    id INT PRIMARY KEY DEFAULT 1,\n    title_fr TEXT,\n    subtitle_fr TEXT,\n    title_en TEXT,\n    subtitle_en TEXT,\n    title_br TEXT,\n    subtitle_br TEXT,\n    team_photo TEXT,\n    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),\n    CONSTRAINT only_one_row CHECK (id = 1)\n)","-- 8. Table TEAM_MEMBERS (Team members and specialists)\nCREATE TABLE IF NOT EXISTS team_members (\n    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,\n    status TEXT DEFAULT 'published' CHECK (status IN ('published', 'draft')),\n    sort INTEGER,\n    slug TEXT UNIQUE,\n    image TEXT,\n    linkedin TEXT,\n    generic BOOLEAN DEFAULT FALSE,\n    email TEXT,\n    phone TEXT,\n    name_fr TEXT,\n    role_fr TEXT,\n    desc_fr TEXT,\n    name_en TEXT,\n    role_en TEXT,\n    desc_en TEXT,\n    name_br TEXT,\n    role_br TEXT,\n    desc_br TEXT,\n    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()\n)","-- 9. Table SOCIAL_POSTS (Instagram posts feed)\nCREATE TABLE IF NOT EXISTS social_posts (\n    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,\n    status TEXT DEFAULT 'published' CHECK (status IN ('published', 'draft')),\n    sort INTEGER,\n    url TEXT NOT NULL,\n    caption TEXT,\n    date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),\n    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()\n)","-- Enable Row Level Security (RLS)\n-- We make the reading public for simplicity, and keep write operations private to authenticated admin users (Supabase Auth).\n\nALTER TABLE articles ENABLE ROW LEVEL SECURITY","ALTER TABLE projets ENABLE ROW LEVEL SECURITY","ALTER TABLE clients ENABLE ROW LEVEL SECURITY","ALTER TABLE partenaires ENABLE ROW LEVEL SECURITY","ALTER TABLE faq ENABLE ROW LEVEL SECURITY","ALTER TABLE glossaire ENABLE ROW LEVEL SECURITY","ALTER TABLE team_header ENABLE ROW LEVEL SECURITY","ALTER TABLE team_members ENABLE ROW LEVEL SECURITY","ALTER TABLE social_posts ENABLE ROW LEVEL SECURITY","-- Create Public Read Policies\nCREATE POLICY \\"Allow public read access on articles\\" ON articles FOR SELECT USING (true)","CREATE POLICY \\"Allow public read access on projets\\" ON projets FOR SELECT USING (true)","CREATE POLICY \\"Allow public read access on clients\\" ON clients FOR SELECT USING (true)","CREATE POLICY \\"Allow public read access on partenaires\\" ON partenaires FOR SELECT USING (true)","CREATE POLICY \\"Allow public read access on faq\\" ON faq FOR SELECT USING (true)","CREATE POLICY \\"Allow public read access on glossaire\\" ON glossaire FOR SELECT USING (true)","CREATE POLICY \\"Allow public read access on team_header\\" ON team_header FOR SELECT USING (true)","CREATE POLICY \\"Allow public read access on team_members\\" ON team_members FOR SELECT USING (true)","CREATE POLICY \\"Allow public read access on social_posts\\" ON social_posts FOR SELECT USING (true)","-- Create Write/Modify Policies for Authenticated Admin Users\nCREATE POLICY \\"Allow all actions for authenticated users on articles\\" ON articles FOR ALL TO authenticated USING (true)","CREATE POLICY \\"Allow all actions for authenticated users on projets\\" ON projets FOR ALL TO authenticated USING (true)","CREATE POLICY \\"Allow all actions for authenticated users on clients\\" ON clients FOR ALL TO authenticated USING (true)","CREATE POLICY \\"Allow all actions for authenticated users on partenaires\\" ON partenaires FOR ALL TO authenticated USING (true)","CREATE POLICY \\"Allow all actions for authenticated users on faq\\" ON faq FOR ALL TO authenticated USING (true)","CREATE POLICY \\"Allow all actions for authenticated users on glossaire\\" ON glossaire FOR ALL TO authenticated USING (true)","CREATE POLICY \\"Allow all actions for authenticated users on team_header\\" ON team_header FOR ALL TO authenticated USING (true)","CREATE POLICY \\"Allow all actions for authenticated users on team_members\\" ON team_members FOR ALL TO authenticated USING (true)","CREATE POLICY \\"Allow all actions for authenticated users on social_posts\\" ON social_posts FOR ALL TO authenticated USING (true)"}	create_urbateam_schema
20260531000001	{"-- supabase/migrations/20260531000001_create_simulations_table.sql\n-- Table pour stocker les prospects générés par le Simulateur de Division Foncière\n\nCREATE TABLE IF NOT EXISTS public.simulations (\n    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),\n    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,\n    address TEXT NOT NULL,\n    parcel_ref TEXT,\n    total_surface TEXT,\n    lot_a_surface TEXT,\n    lot_b_surface TEXT,\n    client_name TEXT NOT NULL,\n    client_email TEXT NOT NULL,\n    client_phone TEXT,\n    client_message TEXT,\n    status TEXT DEFAULT 'new' NOT NULL\n)","-- Activation de RLS (Row Level Security)\nALTER TABLE public.simulations ENABLE ROW LEVEL SECURITY","-- Politique d'insertion publique (permet à n'importe quel prospect de soumettre sa simulation)\nCREATE POLICY \\"Allow public inserts on simulations\\" \nON public.simulations \nFOR INSERT \nWITH CHECK (true)","-- Politiques administratives (lecture/mise à jour/suppression uniquement pour les admins connectés)\nCREATE POLICY \\"Allow authenticated select on simulations\\" \nON public.simulations \nFOR SELECT \nTO authenticated \nUSING (true)","CREATE POLICY \\"Allow authenticated update on simulations\\" \nON public.simulations \nFOR UPDATE \nTO authenticated \nUSING (true)","CREATE POLICY \\"Allow authenticated delete on simulations\\" \nON public.simulations \nFOR DELETE \nTO authenticated \nUSING (true)"}	create_simulations_table
20260531000002	{"-- supabase/migrations/20260531000002_secure_rls_policies.sql\n-- Sécurisation des politiques RLS pour la mise en production\n\n-- 1. Nettoyage des anciennes politiques permissives\nDROP POLICY IF EXISTS \\"Allow all actions for authenticated users on articles\\" ON articles","DROP POLICY IF EXISTS \\"Allow all actions for authenticated users on projets\\" ON projets","DROP POLICY IF EXISTS \\"Allow all actions for authenticated users on clients\\" ON clients","DROP POLICY IF EXISTS \\"Allow all actions for authenticated users on partenaires\\" ON partenaires","DROP POLICY IF EXISTS \\"Allow all actions for authenticated users on faq\\" ON faq","DROP POLICY IF EXISTS \\"Allow all actions for authenticated users on glossaire\\" ON glossaire","DROP POLICY IF EXISTS \\"Allow all actions for authenticated users on team_header\\" ON team_header","DROP POLICY IF EXISTS \\"Allow all actions for authenticated users on team_members\\" ON team_members","DROP POLICY IF EXISTS \\"Allow all actions for authenticated users on social_posts\\" ON social_posts","DROP POLICY IF EXISTS \\"Allow authenticated select on simulations\\" ON public.simulations","DROP POLICY IF EXISTS \\"Allow authenticated update on simulations\\" ON public.simulations","DROP POLICY IF EXISTS \\"Allow authenticated delete on simulations\\" ON public.simulations","-- 2. Création de politiques basées sur l'adresse email de l'administrateur\nCREATE POLICY \\"Allow admin write access on articles\\" ON articles \n    FOR ALL TO authenticated \n    USING (auth.jwt() ->> 'email' = 'admin@urbateam.fr')\n    WITH CHECK (auth.jwt() ->> 'email' = 'admin@urbateam.fr')","CREATE POLICY \\"Allow admin write access on projets\\" ON projets \n    FOR ALL TO authenticated \n    USING (auth.jwt() ->> 'email' = 'admin@urbateam.fr')\n    WITH CHECK (auth.jwt() ->> 'email' = 'admin@urbateam.fr')","CREATE POLICY \\"Allow admin write access on clients\\" ON clients \n    FOR ALL TO authenticated \n    USING (auth.jwt() ->> 'email' = 'admin@urbateam.fr')\n    WITH CHECK (auth.jwt() ->> 'email' = 'admin@urbateam.fr')","CREATE POLICY \\"Allow admin write access on partenaires\\" ON partenaires \n    FOR ALL TO authenticated \n    USING (auth.jwt() ->> 'email' = 'admin@urbateam.fr')\n    WITH CHECK (auth.jwt() ->> 'email' = 'admin@urbateam.fr')","CREATE POLICY \\"Allow admin write access on faq\\" ON faq \n    FOR ALL TO authenticated \n    USING (auth.jwt() ->> 'email' = 'admin@urbateam.fr')\n    WITH CHECK (auth.jwt() ->> 'email' = 'admin@urbateam.fr')","CREATE POLICY \\"Allow admin write access on glossaire\\" ON glossaire \n    FOR ALL TO authenticated \n    USING (auth.jwt() ->> 'email' = 'admin@urbateam.fr')\n    WITH CHECK (auth.jwt() ->> 'email' = 'admin@urbateam.fr')","CREATE POLICY \\"Allow admin write access on team_header\\" ON team_header \n    FOR ALL TO authenticated \n    USING (auth.jwt() ->> 'email' = 'admin@urbateam.fr')\n    WITH CHECK (auth.jwt() ->> 'email' = 'admin@urbateam.fr')","CREATE POLICY \\"Allow admin write access on team_members\\" ON team_members \n    FOR ALL TO authenticated \n    USING (auth.jwt() ->> 'email' = 'admin@urbateam.fr')\n    WITH CHECK (auth.jwt() ->> 'email' = 'admin@urbateam.fr')","CREATE POLICY \\"Allow admin write access on social_posts\\" ON social_posts \n    FOR ALL TO authenticated \n    USING (auth.jwt() ->> 'email' = 'admin@urbateam.fr')\n    WITH CHECK (auth.jwt() ->> 'email' = 'admin@urbateam.fr')","-- 3. Sécurisation stricte des simulations (leads clients)\nCREATE POLICY \\"Allow admin full access on simulations\\" ON public.simulations \n    FOR ALL TO authenticated \n    USING (auth.jwt() ->> 'email' = 'admin@urbateam.fr')\n    WITH CHECK (auth.jwt() ->> 'email' = 'admin@urbateam.fr')"}	secure_rls_policies
20260602000003	{"-- supabase/migrations/20260602000003_create_visits_table.sql\n-- Create table to track live user visits in real-time\n\nCREATE TABLE IF NOT EXISTS public.visits (\n    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,\n    path TEXT NOT NULL,\n    is_article BOOLEAN DEFAULT FALSE,\n    device TEXT DEFAULT 'Desktop',\n    browser TEXT DEFAULT 'Autre',\n    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()\n)","-- Enable Row Level Security (RLS)\nALTER TABLE public.visits ENABLE ROW LEVEL SECURITY","-- 1. Policy to allow anonymous visitors to log page visits\nCREATE POLICY \\"Allow public insert on visits\\" ON public.visits\n    FOR INSERT WITH CHECK (true)","-- 2. Policy to restrict select queries to admin@urbateam.fr users\nCREATE POLICY \\"Allow admin read access on visits\\" ON public.visits\n    FOR SELECT TO authenticated\n    USING (auth.jwt() ->> 'email' = 'admin@urbateam.fr')"}	create_visits_table
\.


--
-- Data for Name: secrets; Type: TABLE DATA; Schema: vault; Owner: supabase_admin
--

COPY vault.secrets (id, name, description, secret, key_id, nonce, created_at, updated_at) FROM stdin;
\.


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: supabase_auth_admin
--

SELECT pg_catalog.setval('auth.refresh_tokens_id_seq', 44, true);


--
-- Name: articles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.articles_id_seq', 5, true);


--
-- Name: clients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.clients_id_seq', 32, true);


--
-- Name: faq_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.faq_id_seq', 24, true);


--
-- Name: glossaire_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.glossaire_id_seq', 65, true);


--
-- Name: partenaires_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.partenaires_id_seq', 1, false);


--
-- Name: projets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.projets_id_seq', 3, true);


--
-- Name: social_posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.social_posts_id_seq', 8, true);


--
-- Name: team_members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.team_members_id_seq', 48, true);


--
-- Name: visits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.visits_id_seq', 988, true);


--
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: supabase_realtime_admin
--

SELECT pg_catalog.setval('realtime.subscription_id_seq', 1, false);


--
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT amr_id_pk PRIMARY KEY (id);


--
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.audit_log_entries
    ADD CONSTRAINT audit_log_entries_pkey PRIMARY KEY (id);


--
-- Name: custom_oauth_providers custom_oauth_providers_identifier_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.custom_oauth_providers
    ADD CONSTRAINT custom_oauth_providers_identifier_key UNIQUE (identifier);


--
-- Name: custom_oauth_providers custom_oauth_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.custom_oauth_providers
    ADD CONSTRAINT custom_oauth_providers_pkey PRIMARY KEY (id);


--
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.flow_state
    ADD CONSTRAINT flow_state_pkey PRIMARY KEY (id);


--
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_pkey PRIMARY KEY (id);


--
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_provider_id_provider_unique UNIQUE (provider_id, provider);


--
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.instances
    ADD CONSTRAINT instances_pkey PRIMARY KEY (id);


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_authentication_method_pkey UNIQUE (session_id, authentication_method);


--
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_pkey PRIMARY KEY (id);


--
-- Name: mfa_factors mfa_factors_last_challenged_at_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_last_challenged_at_key UNIQUE (last_challenged_at);


--
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_pkey PRIMARY KEY (id);


--
-- Name: oauth_authorizations oauth_authorizations_authorization_code_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_authorization_code_key UNIQUE (authorization_code);


--
-- Name: oauth_authorizations oauth_authorizations_authorization_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_authorization_id_key UNIQUE (authorization_id);


--
-- Name: oauth_authorizations oauth_authorizations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_pkey PRIMARY KEY (id);


--
-- Name: oauth_client_states oauth_client_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_client_states
    ADD CONSTRAINT oauth_client_states_pkey PRIMARY KEY (id);


--
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_clients
    ADD CONSTRAINT oauth_clients_pkey PRIMARY KEY (id);


--
-- Name: oauth_consents oauth_consents_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_pkey PRIMARY KEY (id);


--
-- Name: oauth_consents oauth_consents_user_client_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_user_client_unique UNIQUE (user_id, client_id);


--
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_unique UNIQUE (token);


--
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_entity_id_key UNIQUE (entity_id);


--
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_pkey PRIMARY KEY (id);


--
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_pkey PRIMARY KEY (id);


--
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_providers
    ADD CONSTRAINT sso_providers_pkey PRIMARY KEY (id);


--
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_phone_key UNIQUE (phone);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: webauthn_challenges webauthn_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.webauthn_challenges
    ADD CONSTRAINT webauthn_challenges_pkey PRIMARY KEY (id);


--
-- Name: webauthn_credentials webauthn_credentials_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_pkey PRIMARY KEY (id);


--
-- Name: articles articles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_pkey PRIMARY KEY (id);


--
-- Name: articles articles_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_slug_key UNIQUE (slug);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: faq faq_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faq
    ADD CONSTRAINT faq_pkey PRIMARY KEY (id);


--
-- Name: glossaire glossaire_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.glossaire
    ADD CONSTRAINT glossaire_pkey PRIMARY KEY (id);


--
-- Name: partenaires partenaires_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.partenaires
    ADD CONSTRAINT partenaires_pkey PRIMARY KEY (id);


--
-- Name: projets projets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projets
    ADD CONSTRAINT projets_pkey PRIMARY KEY (id);


--
-- Name: projets projets_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projets
    ADD CONSTRAINT projets_slug_key UNIQUE (slug);


--
-- Name: simulations simulations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.simulations
    ADD CONSTRAINT simulations_pkey PRIMARY KEY (id);


--
-- Name: site_texts site_texts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.site_texts
    ADD CONSTRAINT site_texts_pkey PRIMARY KEY (key);


--
-- Name: social_posts social_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.social_posts
    ADD CONSTRAINT social_posts_pkey PRIMARY KEY (id);


--
-- Name: team_header team_header_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team_header
    ADD CONSTRAINT team_header_pkey PRIMARY KEY (id);


--
-- Name: team_members team_members_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_pkey PRIMARY KEY (id);


--
-- Name: team_members team_members_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_slug_key UNIQUE (slug);


--
-- Name: visits visits_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.visits
    ADD CONSTRAINT visits_pkey PRIMARY KEY (id);


--
-- Name: messages messages_payload_exclusive; Type: CHECK CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE realtime.messages
    ADD CONSTRAINT messages_payload_exclusive CHECK (((payload IS NULL) OR (binary_payload IS NULL))) NOT VALID;


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY realtime.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: subscription pk_subscription; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY realtime.subscription
    ADD CONSTRAINT pk_subscription PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: buckets_analytics buckets_analytics_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.buckets_analytics
    ADD CONSTRAINT buckets_analytics_pkey PRIMARY KEY (id);


--
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.buckets
    ADD CONSTRAINT buckets_pkey PRIMARY KEY (id);


--
-- Name: buckets_vectors buckets_vectors_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.buckets_vectors
    ADD CONSTRAINT buckets_vectors_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_name_key UNIQUE (name);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT objects_pkey PRIMARY KEY (id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_pkey PRIMARY KEY (id);


--
-- Name: s3_multipart_uploads s3_multipart_uploads_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_pkey PRIMARY KEY (id);


--
-- Name: vector_indexes vector_indexes_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.vector_indexes
    ADD CONSTRAINT vector_indexes_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: supabase_migrations; Owner: postgres
--

ALTER TABLE ONLY supabase_migrations.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX audit_logs_instance_id_idx ON auth.audit_log_entries USING btree (instance_id);


--
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX confirmation_token_idx ON auth.users USING btree (confirmation_token) WHERE ((confirmation_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: custom_oauth_providers_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX custom_oauth_providers_created_at_idx ON auth.custom_oauth_providers USING btree (created_at);


--
-- Name: custom_oauth_providers_enabled_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX custom_oauth_providers_enabled_idx ON auth.custom_oauth_providers USING btree (enabled);


--
-- Name: custom_oauth_providers_identifier_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX custom_oauth_providers_identifier_idx ON auth.custom_oauth_providers USING btree (identifier);


--
-- Name: custom_oauth_providers_provider_type_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX custom_oauth_providers_provider_type_idx ON auth.custom_oauth_providers USING btree (provider_type);


--
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX email_change_token_current_idx ON auth.users USING btree (email_change_token_current) WHERE ((email_change_token_current)::text !~ '^[0-9 ]*$'::text);


--
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX email_change_token_new_idx ON auth.users USING btree (email_change_token_new) WHERE ((email_change_token_new)::text !~ '^[0-9 ]*$'::text);


--
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX factor_id_created_at_idx ON auth.mfa_factors USING btree (user_id, created_at);


--
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX flow_state_created_at_idx ON auth.flow_state USING btree (created_at DESC);


--
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX identities_email_idx ON auth.identities USING btree (email text_pattern_ops);


--
-- Name: INDEX identities_email_idx; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX auth.identities_email_idx IS 'Auth: Ensures indexed queries on the email column';


--
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX identities_user_id_idx ON auth.identities USING btree (user_id);


--
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_auth_code ON auth.flow_state USING btree (auth_code);


--
-- Name: idx_oauth_client_states_created_at; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_oauth_client_states_created_at ON auth.oauth_client_states USING btree (created_at);


--
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_user_id_auth_method ON auth.flow_state USING btree (user_id, authentication_method);


--
-- Name: idx_users_created_at_desc; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_users_created_at_desc ON auth.users USING btree (created_at DESC);


--
-- Name: idx_users_email; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_users_email ON auth.users USING btree (email);


--
-- Name: idx_users_last_sign_in_at_desc; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_users_last_sign_in_at_desc ON auth.users USING btree (last_sign_in_at DESC);


--
-- Name: idx_users_name; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_users_name ON auth.users USING btree (((raw_user_meta_data ->> 'name'::text))) WHERE ((raw_user_meta_data ->> 'name'::text) IS NOT NULL);


--
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX mfa_challenge_created_at_idx ON auth.mfa_challenges USING btree (created_at DESC);


--
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX mfa_factors_user_friendly_name_unique ON auth.mfa_factors USING btree (friendly_name, user_id) WHERE (TRIM(BOTH FROM friendly_name) <> ''::text);


--
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX mfa_factors_user_id_idx ON auth.mfa_factors USING btree (user_id);


--
-- Name: oauth_auth_pending_exp_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_auth_pending_exp_idx ON auth.oauth_authorizations USING btree (expires_at) WHERE (status = 'pending'::auth.oauth_authorization_status);


--
-- Name: oauth_clients_deleted_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_clients_deleted_at_idx ON auth.oauth_clients USING btree (deleted_at);


--
-- Name: oauth_consents_active_client_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_consents_active_client_idx ON auth.oauth_consents USING btree (client_id) WHERE (revoked_at IS NULL);


--
-- Name: oauth_consents_active_user_client_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_consents_active_user_client_idx ON auth.oauth_consents USING btree (user_id, client_id) WHERE (revoked_at IS NULL);


--
-- Name: oauth_consents_user_order_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_consents_user_order_idx ON auth.oauth_consents USING btree (user_id, granted_at DESC);


--
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX one_time_tokens_relates_to_hash_idx ON auth.one_time_tokens USING hash (relates_to);


--
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX one_time_tokens_token_hash_hash_idx ON auth.one_time_tokens USING hash (token_hash);


--
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX one_time_tokens_user_id_token_type_key ON auth.one_time_tokens USING btree (user_id, token_type);


--
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX reauthentication_token_idx ON auth.users USING btree (reauthentication_token) WHERE ((reauthentication_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX recovery_token_idx ON auth.users USING btree (recovery_token) WHERE ((recovery_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_instance_id_idx ON auth.refresh_tokens USING btree (instance_id);


--
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_instance_id_user_id_idx ON auth.refresh_tokens USING btree (instance_id, user_id);


--
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_parent_idx ON auth.refresh_tokens USING btree (parent);


--
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_session_id_revoked_idx ON auth.refresh_tokens USING btree (session_id, revoked);


--
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_updated_at_idx ON auth.refresh_tokens USING btree (updated_at DESC);


--
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_providers_sso_provider_id_idx ON auth.saml_providers USING btree (sso_provider_id);


--
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_created_at_idx ON auth.saml_relay_states USING btree (created_at DESC);


--
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_for_email_idx ON auth.saml_relay_states USING btree (for_email);


--
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_sso_provider_id_idx ON auth.saml_relay_states USING btree (sso_provider_id);


--
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sessions_not_after_idx ON auth.sessions USING btree (not_after DESC);


--
-- Name: sessions_oauth_client_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sessions_oauth_client_id_idx ON auth.sessions USING btree (oauth_client_id);


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sessions_user_id_idx ON auth.sessions USING btree (user_id);


--
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX sso_domains_domain_idx ON auth.sso_domains USING btree (lower(domain));


--
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sso_domains_sso_provider_id_idx ON auth.sso_domains USING btree (sso_provider_id);


--
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX sso_providers_resource_id_idx ON auth.sso_providers USING btree (lower(resource_id));


--
-- Name: sso_providers_resource_id_pattern_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sso_providers_resource_id_pattern_idx ON auth.sso_providers USING btree (resource_id text_pattern_ops);


--
-- Name: unique_phone_factor_per_user; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX unique_phone_factor_per_user ON auth.mfa_factors USING btree (user_id, phone);


--
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX user_id_created_at_idx ON auth.sessions USING btree (user_id, created_at);


--
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX users_email_partial_key ON auth.users USING btree (email) WHERE (is_sso_user = false);


--
-- Name: INDEX users_email_partial_key; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX auth.users_email_partial_key IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_instance_id_email_idx ON auth.users USING btree (instance_id, lower((email)::text));


--
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_instance_id_idx ON auth.users USING btree (instance_id);


--
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_is_anonymous_idx ON auth.users USING btree (is_anonymous);


--
-- Name: webauthn_challenges_expires_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX webauthn_challenges_expires_at_idx ON auth.webauthn_challenges USING btree (expires_at);


--
-- Name: webauthn_challenges_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX webauthn_challenges_user_id_idx ON auth.webauthn_challenges USING btree (user_id);


--
-- Name: webauthn_credentials_credential_id_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX webauthn_credentials_credential_id_key ON auth.webauthn_credentials USING btree (credential_id);


--
-- Name: webauthn_credentials_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX webauthn_credentials_user_id_idx ON auth.webauthn_credentials USING btree (user_id);


--
-- Name: ix_realtime_subscription_entity; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX ix_realtime_subscription_entity ON realtime.subscription USING btree (entity);


--
-- Name: messages_inserted_at_topic_index; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX messages_inserted_at_topic_index ON ONLY realtime.messages USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- Name: subscription_subscription_id_entity_filters_action_filter_selec; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE UNIQUE INDEX subscription_subscription_id_entity_filters_action_filter_selec ON realtime.subscription USING btree (subscription_id, entity, filters, action_filter, COALESCE(selected_columns, '{}'::text[]));


--
-- Name: bname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX bname ON storage.buckets USING btree (name);


--
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX bucketid_objname ON storage.objects USING btree (bucket_id, name);


--
-- Name: buckets_analytics_unique_name_idx; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX buckets_analytics_unique_name_idx ON storage.buckets_analytics USING btree (name) WHERE (deleted_at IS NULL);


--
-- Name: idx_multipart_uploads_list; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_multipart_uploads_list ON storage.s3_multipart_uploads USING btree (bucket_id, key, created_at);


--
-- Name: idx_objects_bucket_id_name; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_objects_bucket_id_name ON storage.objects USING btree (bucket_id, name COLLATE "C");


--
-- Name: idx_objects_bucket_id_name_lower; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_objects_bucket_id_name_lower ON storage.objects USING btree (bucket_id, lower(name) COLLATE "C");


--
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX name_prefix_search ON storage.objects USING btree (name text_pattern_ops);


--
-- Name: vector_indexes_name_bucket_id_idx; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX vector_indexes_name_bucket_id_idx ON storage.vector_indexes USING btree (name, bucket_id);


--
-- Name: subscription tr_check_filters; Type: TRIGGER; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TRIGGER tr_check_filters BEFORE INSERT OR UPDATE ON realtime.subscription FOR EACH ROW EXECUTE FUNCTION realtime.subscription_check_filters();


--
-- Name: buckets enforce_bucket_name_length_trigger; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER enforce_bucket_name_length_trigger BEFORE INSERT OR UPDATE OF name ON storage.buckets FOR EACH ROW EXECUTE FUNCTION storage.enforce_bucket_name_length();


--
-- Name: buckets protect_buckets_delete; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER protect_buckets_delete BEFORE DELETE ON storage.buckets FOR EACH STATEMENT EXECUTE FUNCTION storage.protect_delete();


--
-- Name: objects protect_objects_delete; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER protect_objects_delete BEFORE DELETE ON storage.objects FOR EACH STATEMENT EXECUTE FUNCTION storage.protect_delete();


--
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER update_objects_updated_at BEFORE UPDATE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.update_updated_at_column();


--
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_auth_factor_id_fkey FOREIGN KEY (factor_id) REFERENCES auth.mfa_factors(id) ON DELETE CASCADE;


--
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_client_id_fkey FOREIGN KEY (client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_client_id_fkey FOREIGN KEY (client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_flow_state_id_fkey FOREIGN KEY (flow_state_id) REFERENCES auth.flow_state(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_oauth_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_oauth_client_id_fkey FOREIGN KEY (oauth_client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: webauthn_challenges webauthn_challenges_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.webauthn_challenges
    ADD CONSTRAINT webauthn_challenges_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: webauthn_credentials webauthn_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads s3_multipart_uploads_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_upload_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES storage.s3_multipart_uploads(id) ON DELETE CASCADE;


--
-- Name: vector_indexes vector_indexes_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.vector_indexes
    ADD CONSTRAINT vector_indexes_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets_vectors(id);


--
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.audit_log_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.flow_state ENABLE ROW LEVEL SECURITY;

--
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.identities ENABLE ROW LEVEL SECURITY;

--
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.instances ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_amr_claims ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_challenges ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_factors ENABLE ROW LEVEL SECURITY;

--
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.one_time_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.refresh_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.saml_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.saml_relay_states ENABLE ROW LEVEL SECURITY;

--
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.schema_migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sso_domains ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sso_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

--
-- Name: simulations Allow admin full access on simulations; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow admin full access on simulations" ON public.simulations TO authenticated USING (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text)) WITH CHECK (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text));


--
-- Name: visits Allow admin read access on visits; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow admin read access on visits" ON public.visits FOR SELECT TO authenticated USING (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text));


--
-- Name: articles Allow admin write access on articles; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow admin write access on articles" ON public.articles TO authenticated USING (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text)) WITH CHECK (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text));


--
-- Name: clients Allow admin write access on clients; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow admin write access on clients" ON public.clients TO authenticated USING (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text)) WITH CHECK (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text));


--
-- Name: faq Allow admin write access on faq; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow admin write access on faq" ON public.faq TO authenticated USING (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text)) WITH CHECK (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text));


--
-- Name: glossaire Allow admin write access on glossaire; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow admin write access on glossaire" ON public.glossaire TO authenticated USING (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text)) WITH CHECK (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text));


--
-- Name: partenaires Allow admin write access on partenaires; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow admin write access on partenaires" ON public.partenaires TO authenticated USING (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text)) WITH CHECK (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text));


--
-- Name: projets Allow admin write access on projets; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow admin write access on projets" ON public.projets TO authenticated USING (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text)) WITH CHECK (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text));


--
-- Name: social_posts Allow admin write access on social_posts; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow admin write access on social_posts" ON public.social_posts TO authenticated USING (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text)) WITH CHECK (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text));


--
-- Name: team_header Allow admin write access on team_header; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow admin write access on team_header" ON public.team_header TO authenticated USING (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text)) WITH CHECK (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text));


--
-- Name: team_members Allow admin write access on team_members; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow admin write access on team_members" ON public.team_members TO authenticated USING (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text)) WITH CHECK (((auth.jwt() ->> 'email'::text) = 'admin@urbateam.fr'::text));


--
-- Name: site_texts Allow all actions for authenticated users on site_texts; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow all actions for authenticated users on site_texts" ON public.site_texts TO authenticated USING (true);


--
-- Name: visits Allow public insert on visits; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public insert on visits" ON public.visits FOR INSERT WITH CHECK (true);


--
-- Name: simulations Allow public inserts on simulations; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public inserts on simulations" ON public.simulations FOR INSERT WITH CHECK (true);


--
-- Name: articles Allow public read access on articles; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public read access on articles" ON public.articles FOR SELECT USING (true);


--
-- Name: clients Allow public read access on clients; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public read access on clients" ON public.clients FOR SELECT USING (true);


--
-- Name: faq Allow public read access on faq; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public read access on faq" ON public.faq FOR SELECT USING (true);


--
-- Name: glossaire Allow public read access on glossaire; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public read access on glossaire" ON public.glossaire FOR SELECT USING (true);


--
-- Name: partenaires Allow public read access on partenaires; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public read access on partenaires" ON public.partenaires FOR SELECT USING (true);


--
-- Name: projets Allow public read access on projets; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public read access on projets" ON public.projets FOR SELECT USING (true);


--
-- Name: site_texts Allow public read access on site_texts; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public read access on site_texts" ON public.site_texts FOR SELECT USING (true);


--
-- Name: social_posts Allow public read access on social_posts; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public read access on social_posts" ON public.social_posts FOR SELECT USING (true);


--
-- Name: team_header Allow public read access on team_header; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public read access on team_header" ON public.team_header FOR SELECT USING (true);


--
-- Name: team_members Allow public read access on team_members; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public read access on team_members" ON public.team_members FOR SELECT USING (true);


--
-- Name: articles; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.articles ENABLE ROW LEVEL SECURITY;

--
-- Name: clients; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.clients ENABLE ROW LEVEL SECURITY;

--
-- Name: faq; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.faq ENABLE ROW LEVEL SECURITY;

--
-- Name: glossaire; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.glossaire ENABLE ROW LEVEL SECURITY;

--
-- Name: partenaires; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.partenaires ENABLE ROW LEVEL SECURITY;

--
-- Name: projets; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.projets ENABLE ROW LEVEL SECURITY;

--
-- Name: simulations; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.simulations ENABLE ROW LEVEL SECURITY;

--
-- Name: site_texts; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.site_texts ENABLE ROW LEVEL SECURITY;

--
-- Name: social_posts; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.social_posts ENABLE ROW LEVEL SECURITY;

--
-- Name: team_header; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.team_header ENABLE ROW LEVEL SECURITY;

--
-- Name: team_members; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.team_members ENABLE ROW LEVEL SECURITY;

--
-- Name: visits; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.visits ENABLE ROW LEVEL SECURITY;

--
-- Name: messages; Type: ROW SECURITY; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE realtime.messages ENABLE ROW LEVEL SECURITY;

--
-- Name: objects Authenticated delete on urbateam-media; Type: POLICY; Schema: storage; Owner: supabase_storage_admin
--

CREATE POLICY "Authenticated delete on urbateam-media" ON storage.objects FOR DELETE TO authenticated USING ((bucket_id = 'urbateam-media'::text));


--
-- Name: objects Authenticated upload on urbateam-media; Type: POLICY; Schema: storage; Owner: supabase_storage_admin
--

CREATE POLICY "Authenticated upload on urbateam-media" ON storage.objects FOR INSERT TO authenticated WITH CHECK ((bucket_id = 'urbateam-media'::text));


--
-- Name: objects Public read access on urbateam-media; Type: POLICY; Schema: storage; Owner: supabase_storage_admin
--

CREATE POLICY "Public read access on urbateam-media" ON storage.objects FOR SELECT USING ((bucket_id = 'urbateam-media'::text));


--
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.buckets ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_analytics; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.buckets_analytics ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_vectors; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.buckets_vectors ENABLE ROW LEVEL SECURITY;

--
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.s3_multipart_uploads ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads_parts; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.s3_multipart_uploads_parts ENABLE ROW LEVEL SECURITY;

--
-- Name: vector_indexes; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.vector_indexes ENABLE ROW LEVEL SECURITY;

--
-- Name: supabase_realtime; Type: PUBLICATION; Schema: -; Owner: postgres
--

CREATE PUBLICATION supabase_realtime WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION supabase_realtime OWNER TO postgres;

--
-- Name: SCHEMA auth; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA auth TO anon;
GRANT USAGE ON SCHEMA auth TO authenticated;
GRANT USAGE ON SCHEMA auth TO service_role;
GRANT ALL ON SCHEMA auth TO supabase_auth_admin;
GRANT ALL ON SCHEMA auth TO dashboard_user;
GRANT USAGE ON SCHEMA auth TO postgres;


--
-- Name: SCHEMA extensions; Type: ACL; Schema: -; Owner: postgres
--

GRANT USAGE ON SCHEMA extensions TO anon;
GRANT USAGE ON SCHEMA extensions TO authenticated;
GRANT USAGE ON SCHEMA extensions TO service_role;
GRANT ALL ON SCHEMA extensions TO dashboard_user;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO postgres;
GRANT USAGE ON SCHEMA public TO anon;
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT USAGE ON SCHEMA public TO service_role;


--
-- Name: SCHEMA realtime; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA realtime TO postgres WITH GRANT OPTION;
GRANT USAGE ON SCHEMA realtime TO anon;
GRANT USAGE ON SCHEMA realtime TO authenticated;
GRANT USAGE ON SCHEMA realtime TO service_role;
GRANT ALL ON SCHEMA realtime TO supabase_realtime_admin;


--
-- Name: SCHEMA storage; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA storage TO postgres WITH GRANT OPTION;
GRANT USAGE ON SCHEMA storage TO anon;
GRANT USAGE ON SCHEMA storage TO authenticated;
GRANT USAGE ON SCHEMA storage TO service_role;
GRANT ALL ON SCHEMA storage TO supabase_storage_admin WITH GRANT OPTION;
GRANT ALL ON SCHEMA storage TO dashboard_user;


--
-- Name: SCHEMA vault; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA vault TO postgres WITH GRANT OPTION;
GRANT USAGE ON SCHEMA vault TO service_role;


--
-- Name: FUNCTION email(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.email() TO dashboard_user;


--
-- Name: FUNCTION jwt(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.jwt() TO postgres;
GRANT ALL ON FUNCTION auth.jwt() TO dashboard_user;


--
-- Name: FUNCTION role(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.role() TO dashboard_user;


--
-- Name: FUNCTION uid(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.uid() TO dashboard_user;


--
-- Name: FUNCTION armor(bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.armor(bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.armor(bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.armor(bytea) TO dashboard_user;


--
-- Name: FUNCTION armor(bytea, text[], text[]); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.armor(bytea, text[], text[]) FROM postgres;
GRANT ALL ON FUNCTION extensions.armor(bytea, text[], text[]) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.armor(bytea, text[], text[]) TO dashboard_user;


--
-- Name: FUNCTION crypt(text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.crypt(text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.crypt(text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.crypt(text, text) TO dashboard_user;


--
-- Name: FUNCTION dearmor(text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.dearmor(text) FROM postgres;
GRANT ALL ON FUNCTION extensions.dearmor(text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.dearmor(text) TO dashboard_user;


--
-- Name: FUNCTION decrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.decrypt(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.decrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.decrypt(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION decrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.decrypt_iv(bytea, bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.decrypt_iv(bytea, bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.decrypt_iv(bytea, bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION digest(bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.digest(bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.digest(bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.digest(bytea, text) TO dashboard_user;


--
-- Name: FUNCTION digest(text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.digest(text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.digest(text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.digest(text, text) TO dashboard_user;


--
-- Name: FUNCTION encrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.encrypt(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.encrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.encrypt(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION encrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.encrypt_iv(bytea, bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.encrypt_iv(bytea, bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.encrypt_iv(bytea, bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION gen_random_bytes(integer); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.gen_random_bytes(integer) FROM postgres;
GRANT ALL ON FUNCTION extensions.gen_random_bytes(integer) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.gen_random_bytes(integer) TO dashboard_user;


--
-- Name: FUNCTION gen_random_uuid(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.gen_random_uuid() FROM postgres;
GRANT ALL ON FUNCTION extensions.gen_random_uuid() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.gen_random_uuid() TO dashboard_user;


--
-- Name: FUNCTION gen_salt(text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.gen_salt(text) FROM postgres;
GRANT ALL ON FUNCTION extensions.gen_salt(text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.gen_salt(text) TO dashboard_user;


--
-- Name: FUNCTION gen_salt(text, integer); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.gen_salt(text, integer) FROM postgres;
GRANT ALL ON FUNCTION extensions.gen_salt(text, integer) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.gen_salt(text, integer) TO dashboard_user;


--
-- Name: FUNCTION grant_pg_cron_access(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION extensions.grant_pg_cron_access() FROM supabase_admin;
GRANT ALL ON FUNCTION extensions.grant_pg_cron_access() TO supabase_admin WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.grant_pg_cron_access() TO dashboard_user;


--
-- Name: FUNCTION grant_pg_graphql_access(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.grant_pg_graphql_access() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION grant_pg_net_access(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION extensions.grant_pg_net_access() FROM supabase_admin;
GRANT ALL ON FUNCTION extensions.grant_pg_net_access() TO supabase_admin WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.grant_pg_net_access() TO dashboard_user;


--
-- Name: FUNCTION hmac(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.hmac(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.hmac(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.hmac(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION hmac(text, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.hmac(text, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.hmac(text, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.hmac(text, text, text) TO dashboard_user;


--
-- Name: FUNCTION pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT shared_blk_read_time double precision, OUT shared_blk_write_time double precision, OUT local_blk_read_time double precision, OUT local_blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision, OUT jit_deform_count bigint, OUT jit_deform_time double precision, OUT stats_since timestamp with time zone, OUT minmax_stats_since timestamp with time zone); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT shared_blk_read_time double precision, OUT shared_blk_write_time double precision, OUT local_blk_read_time double precision, OUT local_blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision, OUT jit_deform_count bigint, OUT jit_deform_time double precision, OUT stats_since timestamp with time zone, OUT minmax_stats_since timestamp with time zone) FROM postgres;
GRANT ALL ON FUNCTION extensions.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT shared_blk_read_time double precision, OUT shared_blk_write_time double precision, OUT local_blk_read_time double precision, OUT local_blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision, OUT jit_deform_count bigint, OUT jit_deform_time double precision, OUT stats_since timestamp with time zone, OUT minmax_stats_since timestamp with time zone) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT shared_blk_read_time double precision, OUT shared_blk_write_time double precision, OUT local_blk_read_time double precision, OUT local_blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision, OUT jit_deform_count bigint, OUT jit_deform_time double precision, OUT stats_since timestamp with time zone, OUT minmax_stats_since timestamp with time zone) TO dashboard_user;


--
-- Name: FUNCTION pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone) FROM postgres;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone) TO dashboard_user;


--
-- Name: FUNCTION pg_stat_statements_reset(userid oid, dbid oid, queryid bigint, minmax_only boolean); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pg_stat_statements_reset(userid oid, dbid oid, queryid bigint, minmax_only boolean) FROM postgres;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_reset(userid oid, dbid oid, queryid bigint, minmax_only boolean) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_reset(userid oid, dbid oid, queryid bigint, minmax_only boolean) TO dashboard_user;


--
-- Name: FUNCTION pgp_armor_headers(text, OUT key text, OUT value text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_armor_headers(text, OUT key text, OUT value text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_armor_headers(text, OUT key text, OUT value text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_armor_headers(text, OUT key text, OUT value text) TO dashboard_user;


--
-- Name: FUNCTION pgp_key_id(bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_key_id(bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_key_id(bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_key_id(bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_encrypt(text, bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_encrypt(text, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_decrypt(bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_decrypt(bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_encrypt(text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_encrypt(text, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgrst_ddl_watch(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgrst_ddl_watch() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION pgrst_drop_watch(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgrst_drop_watch() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION set_graphql_placeholder(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.set_graphql_placeholder() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION uuid_generate_v1(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v1() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1() TO dashboard_user;


--
-- Name: FUNCTION uuid_generate_v1mc(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v1mc() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1mc() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1mc() TO dashboard_user;


--
-- Name: FUNCTION uuid_generate_v3(namespace uuid, name text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v3(namespace uuid, name text) FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v3(namespace uuid, name text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v3(namespace uuid, name text) TO dashboard_user;


--
-- Name: FUNCTION uuid_generate_v4(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v4() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v4() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v4() TO dashboard_user;


--
-- Name: FUNCTION uuid_generate_v5(namespace uuid, name text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v5(namespace uuid, name text) FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v5(namespace uuid, name text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v5(namespace uuid, name text) TO dashboard_user;


--
-- Name: FUNCTION uuid_nil(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_nil() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_nil() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_nil() TO dashboard_user;


--
-- Name: FUNCTION uuid_ns_dns(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_ns_dns() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_ns_dns() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_ns_dns() TO dashboard_user;


--
-- Name: FUNCTION uuid_ns_oid(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_ns_oid() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_ns_oid() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_ns_oid() TO dashboard_user;


--
-- Name: FUNCTION uuid_ns_url(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_ns_url() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_ns_url() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_ns_url() TO dashboard_user;


--
-- Name: FUNCTION uuid_ns_x500(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_ns_x500() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_ns_x500() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_ns_x500() TO dashboard_user;


--
-- Name: FUNCTION graphql("operationName" text, query text, variables jsonb, extensions jsonb); Type: ACL; Schema: graphql_public; Owner: supabase_admin
--

GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO postgres;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO anon;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO authenticated;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO service_role;


--
-- Name: FUNCTION pg_reload_conf(); Type: ACL; Schema: pg_catalog; Owner: supabase_admin
--

GRANT ALL ON FUNCTION pg_catalog.pg_reload_conf() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION get_auth(p_usename text); Type: ACL; Schema: pgbouncer; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION pgbouncer.get_auth(p_usename text) FROM PUBLIC;
GRANT ALL ON FUNCTION pgbouncer.get_auth(p_usename text) TO pgbouncer;


--
-- Name: FUNCTION apply_rls(wal jsonb, max_record_bytes integer); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO postgres;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO anon;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO authenticated;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO service_role;


--
-- Name: FUNCTION broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text) TO postgres;
GRANT ALL ON FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text) TO dashboard_user;


--
-- Name: FUNCTION build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO postgres;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO anon;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO authenticated;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO service_role;


--
-- Name: FUNCTION "cast"(val text, type_ regtype); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO postgres;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO dashboard_user;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO anon;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO authenticated;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO service_role;


--
-- Name: FUNCTION check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO postgres;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO anon;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO authenticated;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO service_role;


--
-- Name: FUNCTION check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text, negate boolean); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text, negate boolean) TO postgres;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text, negate boolean) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text, negate boolean) TO anon;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text, negate boolean) TO authenticated;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text, negate boolean) TO service_role;


--
-- Name: FUNCTION is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO postgres;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO anon;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO authenticated;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO service_role;


--
-- Name: FUNCTION list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO postgres;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO dashboard_user;


--
-- Name: FUNCTION quote_wal2json(entity regclass); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO postgres;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO anon;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO authenticated;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO service_role;


--
-- Name: FUNCTION send(payload jsonb, event text, topic text, private boolean); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean) TO postgres;
GRANT ALL ON FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean) TO dashboard_user;


--
-- Name: FUNCTION send_binary(payload bytea, event text, topic text, private boolean); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.send_binary(payload bytea, event text, topic text, private boolean) TO postgres;
GRANT ALL ON FUNCTION realtime.send_binary(payload bytea, event text, topic text, private boolean) TO dashboard_user;


--
-- Name: FUNCTION subscription_check_filters(); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO postgres;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO dashboard_user;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO anon;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO authenticated;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO service_role;


--
-- Name: FUNCTION to_regrole(role_name text); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO postgres;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO anon;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO authenticated;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO service_role;


--
-- Name: FUNCTION topic(); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.topic() TO postgres;
GRANT ALL ON FUNCTION realtime.topic() TO dashboard_user;


--
-- Name: FUNCTION wal2json_escape_identifier(name text); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.wal2json_escape_identifier(name text) TO postgres;
GRANT ALL ON FUNCTION realtime.wal2json_escape_identifier(name text) TO dashboard_user;


--
-- Name: FUNCTION _crypto_aead_det_decrypt(message bytea, additional bytea, key_id bigint, context bytea, nonce bytea); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION vault._crypto_aead_det_decrypt(message bytea, additional bytea, key_id bigint, context bytea, nonce bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION vault._crypto_aead_det_decrypt(message bytea, additional bytea, key_id bigint, context bytea, nonce bytea) TO service_role;


--
-- Name: FUNCTION create_secret(new_secret text, new_name text, new_description text, new_key_id uuid); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION vault.create_secret(new_secret text, new_name text, new_description text, new_key_id uuid) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION vault.create_secret(new_secret text, new_name text, new_description text, new_key_id uuid) TO service_role;


--
-- Name: FUNCTION update_secret(secret_id uuid, new_secret text, new_name text, new_description text, new_key_id uuid); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION vault.update_secret(secret_id uuid, new_secret text, new_name text, new_description text, new_key_id uuid) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION vault.update_secret(secret_id uuid, new_secret text, new_name text, new_description text, new_key_id uuid) TO service_role;


--
-- Name: TABLE audit_log_entries; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.audit_log_entries TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.audit_log_entries TO postgres;
GRANT SELECT ON TABLE auth.audit_log_entries TO postgres WITH GRANT OPTION;


--
-- Name: TABLE custom_oauth_providers; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.custom_oauth_providers TO postgres;
GRANT ALL ON TABLE auth.custom_oauth_providers TO dashboard_user;


--
-- Name: TABLE flow_state; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.flow_state TO postgres;
GRANT SELECT ON TABLE auth.flow_state TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.flow_state TO dashboard_user;


--
-- Name: TABLE identities; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.identities TO postgres;
GRANT SELECT ON TABLE auth.identities TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.identities TO dashboard_user;


--
-- Name: TABLE instances; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.instances TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.instances TO postgres;
GRANT SELECT ON TABLE auth.instances TO postgres WITH GRANT OPTION;


--
-- Name: TABLE mfa_amr_claims; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.mfa_amr_claims TO postgres;
GRANT SELECT ON TABLE auth.mfa_amr_claims TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.mfa_amr_claims TO dashboard_user;


--
-- Name: TABLE mfa_challenges; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.mfa_challenges TO postgres;
GRANT SELECT ON TABLE auth.mfa_challenges TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.mfa_challenges TO dashboard_user;


--
-- Name: TABLE mfa_factors; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.mfa_factors TO postgres;
GRANT SELECT ON TABLE auth.mfa_factors TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.mfa_factors TO dashboard_user;


--
-- Name: TABLE oauth_authorizations; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.oauth_authorizations TO postgres;
GRANT ALL ON TABLE auth.oauth_authorizations TO dashboard_user;


--
-- Name: TABLE oauth_client_states; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.oauth_client_states TO postgres;
GRANT ALL ON TABLE auth.oauth_client_states TO dashboard_user;


--
-- Name: TABLE oauth_clients; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.oauth_clients TO postgres;
GRANT ALL ON TABLE auth.oauth_clients TO dashboard_user;


--
-- Name: TABLE oauth_consents; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.oauth_consents TO postgres;
GRANT ALL ON TABLE auth.oauth_consents TO dashboard_user;


--
-- Name: TABLE one_time_tokens; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.one_time_tokens TO postgres;
GRANT SELECT ON TABLE auth.one_time_tokens TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.one_time_tokens TO dashboard_user;


--
-- Name: TABLE refresh_tokens; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.refresh_tokens TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.refresh_tokens TO postgres;
GRANT SELECT ON TABLE auth.refresh_tokens TO postgres WITH GRANT OPTION;


--
-- Name: SEQUENCE refresh_tokens_id_seq; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON SEQUENCE auth.refresh_tokens_id_seq TO dashboard_user;
GRANT ALL ON SEQUENCE auth.refresh_tokens_id_seq TO postgres;


--
-- Name: TABLE saml_providers; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.saml_providers TO postgres;
GRANT SELECT ON TABLE auth.saml_providers TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.saml_providers TO dashboard_user;


--
-- Name: TABLE saml_relay_states; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.saml_relay_states TO postgres;
GRANT SELECT ON TABLE auth.saml_relay_states TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.saml_relay_states TO dashboard_user;


--
-- Name: TABLE schema_migrations; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT SELECT ON TABLE auth.schema_migrations TO postgres WITH GRANT OPTION;


--
-- Name: TABLE sessions; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.sessions TO postgres;
GRANT SELECT ON TABLE auth.sessions TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.sessions TO dashboard_user;


--
-- Name: TABLE sso_domains; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.sso_domains TO postgres;
GRANT SELECT ON TABLE auth.sso_domains TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.sso_domains TO dashboard_user;


--
-- Name: TABLE sso_providers; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.sso_providers TO postgres;
GRANT SELECT ON TABLE auth.sso_providers TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.sso_providers TO dashboard_user;


--
-- Name: TABLE users; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.users TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.users TO postgres;
GRANT SELECT ON TABLE auth.users TO postgres WITH GRANT OPTION;


--
-- Name: TABLE webauthn_challenges; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.webauthn_challenges TO postgres;
GRANT ALL ON TABLE auth.webauthn_challenges TO dashboard_user;


--
-- Name: TABLE webauthn_credentials; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.webauthn_credentials TO postgres;
GRANT ALL ON TABLE auth.webauthn_credentials TO dashboard_user;


--
-- Name: TABLE pg_stat_statements; Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON TABLE extensions.pg_stat_statements FROM postgres;
GRANT ALL ON TABLE extensions.pg_stat_statements TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE extensions.pg_stat_statements TO dashboard_user;


--
-- Name: TABLE pg_stat_statements_info; Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON TABLE extensions.pg_stat_statements_info FROM postgres;
GRANT ALL ON TABLE extensions.pg_stat_statements_info TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE extensions.pg_stat_statements_info TO dashboard_user;


--
-- Name: TABLE articles; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.articles TO anon;
GRANT ALL ON TABLE public.articles TO authenticated;
GRANT ALL ON TABLE public.articles TO service_role;


--
-- Name: SEQUENCE articles_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.articles_id_seq TO anon;
GRANT ALL ON SEQUENCE public.articles_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.articles_id_seq TO service_role;


--
-- Name: TABLE clients; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.clients TO anon;
GRANT ALL ON TABLE public.clients TO authenticated;
GRANT ALL ON TABLE public.clients TO service_role;


--
-- Name: SEQUENCE clients_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.clients_id_seq TO anon;
GRANT ALL ON SEQUENCE public.clients_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.clients_id_seq TO service_role;


--
-- Name: TABLE faq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.faq TO anon;
GRANT ALL ON TABLE public.faq TO authenticated;
GRANT ALL ON TABLE public.faq TO service_role;


--
-- Name: SEQUENCE faq_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.faq_id_seq TO anon;
GRANT ALL ON SEQUENCE public.faq_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.faq_id_seq TO service_role;


--
-- Name: TABLE glossaire; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.glossaire TO anon;
GRANT ALL ON TABLE public.glossaire TO authenticated;
GRANT ALL ON TABLE public.glossaire TO service_role;


--
-- Name: SEQUENCE glossaire_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.glossaire_id_seq TO anon;
GRANT ALL ON SEQUENCE public.glossaire_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.glossaire_id_seq TO service_role;


--
-- Name: TABLE partenaires; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.partenaires TO anon;
GRANT ALL ON TABLE public.partenaires TO authenticated;
GRANT ALL ON TABLE public.partenaires TO service_role;


--
-- Name: SEQUENCE partenaires_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.partenaires_id_seq TO anon;
GRANT ALL ON SEQUENCE public.partenaires_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.partenaires_id_seq TO service_role;


--
-- Name: TABLE projets; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.projets TO anon;
GRANT ALL ON TABLE public.projets TO authenticated;
GRANT ALL ON TABLE public.projets TO service_role;


--
-- Name: SEQUENCE projets_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.projets_id_seq TO anon;
GRANT ALL ON SEQUENCE public.projets_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.projets_id_seq TO service_role;


--
-- Name: TABLE simulations; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.simulations TO anon;
GRANT ALL ON TABLE public.simulations TO authenticated;
GRANT ALL ON TABLE public.simulations TO service_role;


--
-- Name: TABLE site_texts; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.site_texts TO anon;
GRANT ALL ON TABLE public.site_texts TO authenticated;
GRANT ALL ON TABLE public.site_texts TO service_role;


--
-- Name: TABLE social_posts; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.social_posts TO anon;
GRANT ALL ON TABLE public.social_posts TO authenticated;
GRANT ALL ON TABLE public.social_posts TO service_role;


--
-- Name: SEQUENCE social_posts_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.social_posts_id_seq TO anon;
GRANT ALL ON SEQUENCE public.social_posts_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.social_posts_id_seq TO service_role;


--
-- Name: TABLE team_header; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.team_header TO anon;
GRANT ALL ON TABLE public.team_header TO authenticated;
GRANT ALL ON TABLE public.team_header TO service_role;


--
-- Name: TABLE team_members; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.team_members TO anon;
GRANT ALL ON TABLE public.team_members TO authenticated;
GRANT ALL ON TABLE public.team_members TO service_role;


--
-- Name: SEQUENCE team_members_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.team_members_id_seq TO anon;
GRANT ALL ON SEQUENCE public.team_members_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.team_members_id_seq TO service_role;


--
-- Name: TABLE visits; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.visits TO anon;
GRANT ALL ON TABLE public.visits TO authenticated;
GRANT ALL ON TABLE public.visits TO service_role;


--
-- Name: SEQUENCE visits_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.visits_id_seq TO anon;
GRANT ALL ON SEQUENCE public.visits_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.visits_id_seq TO service_role;


--
-- Name: TABLE messages; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE realtime.messages TO postgres;
GRANT ALL ON TABLE realtime.messages TO dashboard_user;
GRANT SELECT,INSERT,UPDATE ON TABLE realtime.messages TO anon;
GRANT SELECT,INSERT,UPDATE ON TABLE realtime.messages TO authenticated;
GRANT SELECT,INSERT,UPDATE ON TABLE realtime.messages TO service_role;


--
-- Name: TABLE subscription; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE realtime.subscription TO postgres;
GRANT ALL ON TABLE realtime.subscription TO dashboard_user;
GRANT SELECT ON TABLE realtime.subscription TO anon;
GRANT SELECT ON TABLE realtime.subscription TO authenticated;
GRANT SELECT ON TABLE realtime.subscription TO service_role;


--
-- Name: SEQUENCE subscription_id_seq; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON SEQUENCE realtime.subscription_id_seq TO postgres;
GRANT ALL ON SEQUENCE realtime.subscription_id_seq TO dashboard_user;
GRANT USAGE ON SEQUENCE realtime.subscription_id_seq TO anon;
GRANT USAGE ON SEQUENCE realtime.subscription_id_seq TO authenticated;
GRANT USAGE ON SEQUENCE realtime.subscription_id_seq TO service_role;


--
-- Name: TABLE buckets; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

REVOKE ALL ON TABLE storage.buckets FROM supabase_storage_admin;
GRANT ALL ON TABLE storage.buckets TO supabase_storage_admin WITH GRANT OPTION;
GRANT ALL ON TABLE storage.buckets TO service_role;
GRANT ALL ON TABLE storage.buckets TO authenticated;
GRANT ALL ON TABLE storage.buckets TO anon;
GRANT ALL ON TABLE storage.buckets TO postgres WITH GRANT OPTION;


--
-- Name: TABLE buckets_analytics; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.buckets_analytics TO service_role;
GRANT ALL ON TABLE storage.buckets_analytics TO authenticated;
GRANT ALL ON TABLE storage.buckets_analytics TO anon;


--
-- Name: TABLE buckets_vectors; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT SELECT ON TABLE storage.buckets_vectors TO service_role;
GRANT SELECT ON TABLE storage.buckets_vectors TO authenticated;
GRANT SELECT ON TABLE storage.buckets_vectors TO anon;


--
-- Name: TABLE objects; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

REVOKE ALL ON TABLE storage.objects FROM supabase_storage_admin;
GRANT ALL ON TABLE storage.objects TO supabase_storage_admin WITH GRANT OPTION;
GRANT ALL ON TABLE storage.objects TO service_role;
GRANT ALL ON TABLE storage.objects TO authenticated;
GRANT ALL ON TABLE storage.objects TO anon;
GRANT ALL ON TABLE storage.objects TO postgres WITH GRANT OPTION;


--
-- Name: TABLE s3_multipart_uploads; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.s3_multipart_uploads TO service_role;
GRANT SELECT ON TABLE storage.s3_multipart_uploads TO authenticated;
GRANT SELECT ON TABLE storage.s3_multipart_uploads TO anon;


--
-- Name: TABLE s3_multipart_uploads_parts; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.s3_multipart_uploads_parts TO service_role;
GRANT SELECT ON TABLE storage.s3_multipart_uploads_parts TO authenticated;
GRANT SELECT ON TABLE storage.s3_multipart_uploads_parts TO anon;


--
-- Name: TABLE vector_indexes; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT SELECT ON TABLE storage.vector_indexes TO service_role;
GRANT SELECT ON TABLE storage.vector_indexes TO authenticated;
GRANT SELECT ON TABLE storage.vector_indexes TO anon;


--
-- Name: TABLE secrets; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE vault.secrets TO postgres WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE vault.secrets TO service_role;


--
-- Name: TABLE decrypted_secrets; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE vault.decrypted_secrets TO postgres WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE vault.decrypted_secrets TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON SEQUENCES TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON FUNCTIONS TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON TABLES TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON SEQUENCES TO postgres WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON FUNCTIONS TO postgres WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON TABLES TO postgres WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON SEQUENCES TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON FUNCTIONS TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON TABLES TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES TO service_role;


--
-- Name: issue_graphql_placeholder; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_graphql_placeholder ON sql_drop
         WHEN TAG IN ('DROP EXTENSION')
   EXECUTE FUNCTION extensions.set_graphql_placeholder();


ALTER EVENT TRIGGER issue_graphql_placeholder OWNER TO supabase_admin;

--
-- Name: issue_pg_cron_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_pg_cron_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_cron_access();


ALTER EVENT TRIGGER issue_pg_cron_access OWNER TO supabase_admin;

--
-- Name: issue_pg_graphql_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_pg_graphql_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_graphql_access();


ALTER EVENT TRIGGER issue_pg_graphql_access OWNER TO supabase_admin;

--
-- Name: issue_pg_net_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_pg_net_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_net_access();


ALTER EVENT TRIGGER issue_pg_net_access OWNER TO supabase_admin;

--
-- Name: pgrst_ddl_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER pgrst_ddl_watch ON ddl_command_end
   EXECUTE FUNCTION extensions.pgrst_ddl_watch();


ALTER EVENT TRIGGER pgrst_ddl_watch OWNER TO supabase_admin;

--
-- Name: pgrst_drop_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER pgrst_drop_watch ON sql_drop
   EXECUTE FUNCTION extensions.pgrst_drop_watch();


ALTER EVENT TRIGGER pgrst_drop_watch OWNER TO supabase_admin;

--
-- PostgreSQL database dump complete
--

\unrestrict bjjv4gxQgSFFManpRl8upBzS9tsUJJNh4H6gnTfwmIEGHI4ZSVYmyEz0hqwHeao

